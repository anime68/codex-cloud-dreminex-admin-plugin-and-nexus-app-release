<?php
$root = dirname(__DIR__);
$suite = file_get_contents($root . '/includes/class-dreminex-suite.php');
$native = file_get_contents($root . '/includes/class-dreminex-native-mcp.php');
$app = file_get_contents($root . '/includes/class-dreminex-nexus-app.php');
$config = file_get_contents($root . '/modules/dreminex_delivery_advance_api_config.php');
$css = file_get_contents($root . '/assets/suite-admin.css');

function wallet_sync_check($condition, $message) {
    if (!$condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
}

wallet_sync_check(str_contains($suite, "'delivery_advance'=>['Delivery Advance & Wallet'") , 'Delivery Advance & Wallet remains in the Suite module catalogue.');
wallet_sync_check(str_contains($suite, "in_array(\$key,['checkout_protection','newsletter_offers','contact_requests'],true)") , 'Wallet is not hidden behind the app-managed early return.');
wallet_sync_check(str_contains($suite, 'elseif ($key===\'delivery_advance\')') && str_contains($suite, 'self::wallet_panel()'), 'The module page renders the wallet controls.');
wallet_sync_check(str_contains($native, "'payments'=>'delivery_advance'") && str_contains($native, 'A mapped module is the shared source of truth'), 'App payments feature maps to the shared module option.');
wallet_sync_check(str_contains($native, 'Dreminex_Suite::app_module_transition($module,$enabled') && str_contains($native, "update_option('dreminex_suite_modules'"), 'The app toggle writes the same module option.');
wallet_sync_check(str_contains($config, 'dreminex-payment-connections'), 'Payment connections use the responsive scroll container.');
wallet_sync_check(str_contains($suite, 'ds-collapsible') && str_contains($css, 'ds-wallet-panel'), 'Wallet queues and ledger are collapsible and responsive.');
wallet_sync_check(str_contains($app, "'payments'=>'operations/payments'"), 'Payment notifications retain the payments deep link.');
wallet_sync_check(str_contains($suite, "add_submenu_page('dreminex-suite','Supplier Monitor'") && !str_contains($suite, "add_submenu_page('woocommerce','Supplier Monitor'"), 'Supplier Monitor is nested under the Dreminex Suite dashboard.');

echo "Delivery Advance & Wallet module visibility and app/WordPress sync: PASS\n";
