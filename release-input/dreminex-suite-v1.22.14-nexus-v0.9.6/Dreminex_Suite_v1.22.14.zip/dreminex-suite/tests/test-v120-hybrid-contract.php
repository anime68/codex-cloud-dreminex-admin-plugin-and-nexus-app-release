<?php
/** Stable source contracts for the v1.20.0 provider-aware MCP and Nexus app surfaces. */
function check_v120($condition, $message) {
    if (!$condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
}

$root = dirname(__DIR__);
$spec = json_decode((string) file_get_contents($root . '/data/native-mcp-abilities-v2.json'), true);
$policy = file_get_contents($root . '/includes/class-dreminex-mcp-registry-policy.php');
$abilities = file_get_contents($root . '/includes/class-dreminex-mcp-abilities-v2.php');
$media = file_get_contents($root . '/includes/class-dreminex-mcp-media-v2.php');
$upload = file_get_contents($root . '/includes/class-dreminex-mcp-upload.php');
$app = file_get_contents($root . '/includes/class-dreminex-nexus-app.php');
$native = file_get_contents($root . '/includes/class-dreminex-native-mcp.php');
$upgrades = file_get_contents($root . '/includes/class-dreminex-suite-upgrades.php');
$security = file_get_contents($root . '/includes/class-dreminex-security-center.php');
$operations = file_get_contents($root . '/includes/class-dreminex-nexus-operations.php');

check_v120(is_array($spec) && count($spec['abilities'] ?? []) === 52, 'The v1.20 ability spec must contain exactly 52 reviewed first-party abilities.');
$names = array_column($spec['abilities'], 'name');
check_v120(count($names) === count(array_unique($names)), 'Every MCP ability name must be unique.');
foreach ($spec['abilities'] as $ability) {
    check_v120(($ability['input_schema']['type'] ?? '') === 'object', 'Every ability must declare an object input schema.');
    check_v120(($ability['input_schema']['additionalProperties'] ?? null) === false, 'Ability schemas must reject unspecified input fields.');
}
check_v120(str_contains($policy, "'unknown'") && str_contains($policy, "'provider_unknown'"), 'Unknown providers must remain denied by explicit provider policy.');
check_v120(str_contains($policy, 'abilities_master_disabled') && str_contains($policy, 'ability_disabled'), 'Automatic ability defaults must retain master and explicit per-ability disable controls.');
check_v120(str_contains($abilities, 'output_contract') && !str_contains($abilities, "\$spec['purpose_bn']"), 'Runtime MCP descriptions must use the English output contract, not Bengali-only spec fields.');
check_v120(str_contains($media, 'wp_check_filetype_and_ext') && str_contains($media, 'hash_file'), 'Media ingest must validate WordPress MIME policy and content integrity.');
check_v120(str_contains($upload, 'const CHUNK_BYTES = 4194304') && str_contains($upload, 'const SESSION_TTL = 900'), 'Resumable media upload must retain bounded chunks and short-lived tickets.');
check_v120(str_contains($native, "'orders'=>"), 'The order API must have an explicit app feature gate.');
check_v120(str_contains($operations, "'/nexus/orders/(?P<order_id>\\d+)'" ) && str_contains($operations, "'GET','POST'"), 'Exact order deep links must read one order and status writes must remain separately authorized.');
check_v120(str_contains($operations, 'evidence_too_large') && str_contains($operations, '10*1024*1024'), 'Private contact evidence must have a bounded app-download limit.');
check_v120(str_contains($operations, "if(is_string(\$raw_products))\$raw_products=preg_split"), 'Welcome offer product IDs must accept the app form string and the native array format.');
check_v120(str_contains($app, 'is_wp_error($features)?$features'), 'App feature update errors must preserve their proper WordPress REST error status.');
check_v120(str_contains($app, 'const SCHEMA=2') && str_contains($app, "'security','action_center'"), 'Action Center notifications must migrate additively to Security without deleting records.');
check_v120(str_contains($app, "esc_like('action-center')") && str_contains($app, "'ready-to-ship'"), 'Migration must handle JSON route escaping and the Security queue status must be filterable.');
check_v120(str_contains($app, "if(\$category==='action_center')\$category='security'"), 'Older Nexus notification filters must resolve Action Center records under Security.');
check_v120(str_contains($security, "'operations_summary'=>\$operations") && str_contains($app, 'function operations_summary()'), 'Security dashboard must expose the migrated read-only operations summary.');
check_v120(!str_contains($app, 'dreminex-operations/action-center-read') && str_contains($app, "'/nexus/action-center'"), 'The standalone Action Center ability is removed while its old app endpoint remains as a compatibility alias.');
check_v120(!str_contains($native, "'action_center'=>") && !str_contains($native, 'return $id===\'action_center\''), 'Action Center must no longer be a separately switchable app capability.');
check_v120(str_contains($upgrades,'const SCHEMA=6') && str_contains($upgrades,"unset(\$modules['action_center'])"), 'Migration must remove only the obsolete Action Center module switch.');
check_v120(str_contains($native,'self::module_status()') && str_contains($native,'Dreminex_Suite::catalog()'), 'Module status must expose only the current module catalog, not stale retired switches.');
echo "Suite v1.20 hybrid contracts: PASS\n";
