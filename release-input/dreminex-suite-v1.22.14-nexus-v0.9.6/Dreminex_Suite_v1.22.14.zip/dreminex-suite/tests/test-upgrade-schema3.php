<?php
define('ABSPATH',__DIR__.'/');define('DREMINEX_SUITE_VERSION','1.20.0');
$GLOBALS['opts']=[
 'dreminex_suite_schema_version'=>2,'dreminex_suite_version'=>'1.14.1',
 'dreminex_suite_modules'=>['phone_validation'=>1,'duplicate_checkout'=>0,'receipt_ip_warning'=>1,'customer_order_limit'=>1,'partial_checkout'=>1,'receipt_message'=>1,'checkout_error_popup'=>1,'customer_history'=>1,'admin_order_alert'=>1,'order_email_notification'=>1,'order_statuses'=>1,'order_tracking'=>1,'registration_email'=>1,'password_reset'=>1,'action_center'=>1],
 'dreminex_suite_module_settings'=>['duplicate_checkout'=>['cooldown_hours'=>4],'order_email_notification'=>['recipient'=>'owner@example.com'],'checkout_error_popup'=>['title'=>'Check details'],'action_center'=>['legacy_note'=>'retain']],
 'dreminex_suite_activity'=>['action_center'=>['legacy_note'=>'retain']],
];
function get_option($name,$default=false){return array_key_exists($name,$GLOBALS['opts'])?$GLOBALS['opts'][$name]:$default;}
function update_option($name,$value,$autoload=false){$GLOBALS['opts'][$name]=$value;return true;}
function add_option($name,$value,$deprecated='',$autoload=false){if(!array_key_exists($name,$GLOBALS['opts']))$GLOBALS['opts'][$name]=$value;return true;}
require dirname(__DIR__).'/includes/class-dreminex-suite-upgrades.php';Dreminex_Suite_Upgrades::run();
$m=$GLOBALS['opts']['dreminex_suite_modules'];$s=$GLOBALS['opts']['dreminex_suite_module_settings'];
$checks=[
 $GLOBALS['opts']['dreminex_suite_schema_version']===6,$m['checkout_protection']===1,$m['checkout_experience']===1,$m['order_management']===1,$m['registration_email']===1,$m['supplier_monitor']===1,
 $m['phone_validation']===0,$m['order_tracking']===0,$m['password_reset']===0,$m['mail_engine']===0,$s['checkout_protection']['cooldown_hours']===4,$s['order_management']['recipient']==='owner@example.com',$s['checkout_experience']['title']==='Check details',$s['registration_email']['password_reset_enabled']===1,
 !array_key_exists('action_center',$m),$s['action_center']['legacy_note']==='retain',$GLOBALS['opts']['dreminex_suite_activity']['action_center']['legacy_note']==='retain',
 $GLOBALS['opts']['dreminex_supplier_monitor_architecture']['source']==='universal_accounts',$GLOBALS['opts']['dreminex_supplier_monitor_architecture']['legacy_configuration_imported']===false,
];
if(in_array(false,$checks,true)){fwrite(STDERR,"Suite migration failed\n");var_export([$m,$s]);exit(1);}echo "Suite schema 3/4/5/6 migration: PASS\n";
