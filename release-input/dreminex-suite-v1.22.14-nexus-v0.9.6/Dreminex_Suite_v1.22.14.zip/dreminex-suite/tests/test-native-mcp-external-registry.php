<?php
define('ABSPATH', __DIR__ . '/');
define('DREMINEX_SUITE_PATH', dirname(__DIR__) . '/');
$GLOBALS['external_options'] = [
    'dreminex_native_mcp_settings' => ['abilities_enabled'=>1,'provider_states'=>[],'category_states'=>[],'ability_states'=>[]],
    'dreminex_native_mcp_custom_abilities' => [],
];
$GLOBALS['external_abilities'] = [];
function get_option($key, $default = []) { return $GLOBALS['external_options'][$key] ?? $default; }
function sanitize_key($value) { return preg_replace('/[^a-z0-9_\-]/', '', strtolower((string) $value)); }
function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }
function absint($value) { return abs((int) $value); }
final class Dreminex_Native_MCP {
    public static function settings() { return $GLOBALS['external_options']['dreminex_native_mcp_settings']; }
    public static function environment() { return 'staging'; }
}
final class Dreminex_Native_OAuth {
    public static function scopes() { return ['mcp:discover','content:read','content:write','catalog:read','catalog:write','security:write']; }
    public static function high_risk_scopes() { return ['security:write']; }
}
final class External_Ability {
    private $name; private $meta; private $annotations;
    public function __construct($name, $readonly, $public = true) {
        $this->name = $name;
        $this->annotations = ['readonly'=>$readonly,'destructive'=>false,'idempotent'=>true];
        $this->meta = ['annotations'=>$this->annotations,'mcp'=>['public'=>$public]];
    }
    public function get_name() { return $this->name; }
    public function get_category() { return 'external'; }
    public function get_meta() { return $this->meta; }
    public function get_annotations() { return $this->annotations; }
}
require dirname(__DIR__) . '/includes/class-dreminex-mcp-registry-policy.php';
function external_check($condition, $message) { if (!$condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } }

$read = new External_Ability('acme-store/catalog-read', true);
$write = new External_Ability('acme-store/catalog-update', false);
$hidden = new External_Ability('acme-store/internal-helper', true, false);

$read_decision = Dreminex_MCP_Registry_Policy::decision($read->get_name(), $read);
external_check($read_decision['enabled'] === true, 'Public external read abilities should be auto-discovered.');
external_check($read_decision['provider'] === 'external-acme-store', 'External provider ownership should be stable.');
external_check($read_decision['required_scope'] === 'content:read', 'External reads should receive the bounded content read scope.');

$write_decision = Dreminex_MCP_Registry_Policy::decision($write->get_name(), $write);
external_check($write_decision['enabled'] === true && $write_decision['risk'] === 'write', 'Non-destructive external writes should remain ordinary writes.');
external_check($write_decision['required_scope'] === 'content:write', 'External writes should receive the bounded content write scope.');

$hidden_decision = Dreminex_MCP_Registry_Policy::decision($hidden->get_name(), $hidden);
external_check($hidden_decision['reason_code'] === 'not_public', 'Unmarked external abilities must fail closed.');

$GLOBALS['external_options']['dreminex_native_mcp_custom_abilities'][$write->get_name()] = [
    'scope' => 'catalog:write', 'capability' => 'manage_options', 'risk' => 'write', 'public' => true, 'enabled' => true,
];
$custom = Dreminex_MCP_Registry_Policy::decision($write->get_name(), $write);
external_check($custom['required_scope'] === 'catalog:write', 'Owner custom scope overrides must be applied.');
external_check($custom['capability'] === 'manage_options', 'Owner custom capability overrides must be applied.');

echo "Native MCP external registry and custom policy tests: PASS\n";
