<?php
define('ABSPATH',__DIR__.'/');
class WP_Error {public $code;public function __construct($code){$this->code=$code;}}
class Dreminex_Native_OAuth {
 public static array $granted=[];public static array $requested=[];
 public static function authenticate($request,$scopes){self::$requested=$scopes;foreach($scopes as $scope)if(!in_array($scope,self::$granted,true))return new WP_Error('missing_scope');return true;}
}
require dirname(__DIR__).'/includes/class-dreminex-supplier-accounts.php';
function auth_ok($value,$message){if(!$value){fwrite(STDERR,"FAIL: $message\n");exit(1);}}
Dreminex_Native_OAuth::$granted=['suppliers:write'];
auth_ok(Dreminex_Supplier_Accounts::write_auth(null)===true,'suppliers:write must authorize account creation');
auth_ok(Dreminex_Native_OAuth::$requested===['suppliers:write'],'account creation must request only suppliers:write');
Dreminex_Native_OAuth::$granted=['suppliers:read'];
auth_ok(Dreminex_Supplier_Accounts::write_auth(null) instanceof WP_Error,'read-only supplier token must not create accounts');
Dreminex_Native_OAuth::$granted=['suppliers:read'];
auth_ok(Dreminex_Supplier_Accounts::read_auth(null)===true,'suppliers:read must authorize account reads');
echo "Supplier account OAuth scope tests: PASS\n";
