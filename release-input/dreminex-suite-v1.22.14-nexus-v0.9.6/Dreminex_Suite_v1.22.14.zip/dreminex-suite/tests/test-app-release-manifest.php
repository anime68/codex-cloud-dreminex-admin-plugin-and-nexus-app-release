<?php
define('ABSPATH', __DIR__ . '/');
define('MINUTE_IN_SECONDS', 60);
$fixture = sys_get_temp_dir() . '/dreminex-app-release-' . bin2hex(random_bytes(6)) . '/';
define('DREMINEX_SUITE_PATH', $fixture);
define('DREMINEX_SUITE_FILE', $fixture . 'dreminex-suite.php');

function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }
function esc_url_raw($value) { return filter_var((string) $value, FILTER_VALIDATE_URL) ? (string) $value : ''; }
function plugins_url($path, $plugin_file) { return 'https://store.example/wp-content/plugins/dreminex-suite/' . ltrim($path, '/'); }
function get_transient($key) { return $GLOBALS['release_transients'][$key] ?? false; }
function set_transient($key, $value, $ttl) { $GLOBALS['release_transients'][$key] = $value; return true; }
function delete_transient($key) { unset($GLOBALS['release_transients'][$key]); return true; }
function wp_safe_remote_get($url, $args = []) { return $GLOBALS['release_http_response'] ?? ['code'=>503,'body'=>'']; }
function wp_remote_retrieve_response_code($response) { return (int)($response['code'] ?? 0); }
function wp_remote_retrieve_body($response) { return (string)($response['body'] ?? ''); }
function is_wp_error($value) { return $value instanceof WP_Error; }
class WP_Error {}

require_once __DIR__ . '/../includes/class-dreminex-native-mcp.php';

function release_assert($condition, $message) {
    if (!$condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
}

$apk = 'Dreminex_Nexus_v0.7.1_signed.apk';
$hash = hash('sha256', 'signed-apk-fixture');
$manifest = [
    'schema_version' => 1,
    'android' => ['version' => '0.7.1', 'download_url' => 'https://github.com/anime68/codex-cloud-dreminex-admin-plugin-and-nexus-app-release/releases/download/test/' . $apk, 'sha256' => $hash],
    'windows' => ['version' => '', 'download_url' => ''],
    'release_notes_url' => '',
];
$GLOBALS['release_http_response'] = ['code'=>200,'body'=>json_encode($manifest)];

$distribution = Dreminex_Native_MCP::app_distribution();
release_assert($distribution['android_version'] === '0.7.1', 'Android version should come from the generated manifest.');
release_assert($distribution['android_sha256'] === $hash, 'Android checksum should be read from the verified public manifest.');
release_assert($distribution['android_download_url'] === $manifest['android']['download_url'], 'Android URL should come from the public GitHub release manifest.');
release_assert($distribution['windows_download_url'] === '' && $distribution['windows_version'] === '', 'A release without the Windows installer must not advertise a broken download.');
release_assert($distribution['release_notes_url'] === '', 'A private GitHub release notes URL must not be exposed to connected app clients.');
release_assert(Dreminex_Native_MCP::app_release_manifest()['android']['download_url'] === $distribution['android_download_url'], 'The existing app-release schema should expose the dynamic package URL.');

$manifest['android']['sha256'] = 'invalid-checksum';
$GLOBALS['release_http_response'] = ['code'=>200,'body'=>json_encode($manifest)];
delete_transient('dreminex_public_nexus_release');
$tampered = Dreminex_Native_MCP::app_distribution();
release_assert($tampered['android_download_url'] === '' && $tampered['android_sha256'] === '', 'An invalid public checksum must prevent an app update from being offered.');
echo "Dynamic app release manifest tests: PASS\n";
