<?php
if (!defined('ABSPATH')) return;
/** Configuration and bKash v2 contract verified against developer.bka.sh on 2026-10-01. */
final class Dreminex_Payments_Security {
 private static $locks=[];
 public static function seal($data) {
  if(!function_exists('openssl_encrypt'))return new WP_Error('crypto_missing','OpenSSL is required for credential storage.');
  $iv=random_bytes(12);$tag='';$key=hash('sha256',wp_salt('auth').'dreminex-payments-v1',true);
  $cipher=openssl_encrypt(wp_json_encode($data),'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag,'dreminex-payments');
  return $cipher===false?new WP_Error('crypto_failed','Credential encryption failed.'):base64_encode($iv.$tag.$cipher);
 }
 public static function open($blob) {
  $raw=base64_decode((string)$blob,true);if(!$raw||strlen($raw)<29||!function_exists('openssl_decrypt'))return [];
  $key=hash('sha256',wp_salt('auth').'dreminex-payments-v1',true);
  $json=openssl_decrypt(substr($raw,28),'aes-256-gcm',$key,OPENSSL_RAW_DATA,substr($raw,0,12),substr($raw,12,16),'dreminex-payments');
  $data=$json===false?null:json_decode($json,true);return is_array($data)?$data:[];
 }
 public static function secrets($id) { $all=(array)get_option('dreminex_payment_secrets',[]);return self::open($all[$id]??''); }
 public static function save_secrets($id,$data) { $sealed=self::seal($data);if(is_wp_error($sealed))return $sealed;$all=(array)get_option('dreminex_payment_secrets',[]);$all[$id]=$sealed;update_option('dreminex_payment_secrets',$all,false);return true; }
 public static function lock($id) { return self::lock_named('dreminex_pay_lock_'.absint($id)); }
 public static function unlock($id) { return self::release_named_lock('dreminex_pay_lock_'.absint($id)); }
 public static function lock_named($key,$ttl=300) {
  $key=sanitize_key($key);if($key==='')return false;
  $owner=time().':'.wp_generate_uuid4();
  if(add_option($key,$owner,'no',false)){self::$locks[$key]=$owner;return true;}
  global $wpdb;
  $raw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s LIMIT 1",$key));
  if(!is_string($raw)||$raw==='')return false;
  $created=0;
  if(ctype_digit($raw))$created=(int)$raw;
  elseif(preg_match('/^([0-9]{10}):[a-f0-9-]{36}$/D',$raw,$match))$created=(int)$match[1];
  if($created<1||$created>time()-max(60,(int)$ttl))return false;
  // Delete only the exact stale value we inspected. A concurrent request that
  // already replaced it keeps its lock, and only one request can reacquire it.
  $deleted=$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$key,$raw));
  if((int)$deleted!==1)return false;
  wp_cache_delete($key,'options');wp_cache_delete('notoptions','options');
  if(!add_option($key,$owner,'no',false))return false;
  self::$locks[$key]=$owner;return true;
 }
 public static function release_named_lock($key) {
  $key=sanitize_key($key);if($key===''||!isset(self::$locks[$key]))return false;
  global $wpdb;$owner=self::$locks[$key];
  $deleted=$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$key,$owner));
  wp_cache_delete($key,'options');wp_cache_delete('notoptions','options');unset(self::$locks[$key]);
  return (int)$deleted===1;
 }
 public static function valid_base($url,$environment) {
  $p=wp_parse_url($url);$host=strtolower($p['host']??'');
  return ($p['scheme']??'')==='https' && !isset($p['user']) && !isset($p['pass']) && !isset($p['query']) && !isset($p['fragment']) && (!isset($p['port']) || $p['port']===443)
    && preg_match('/(?:^|\.)bka\.sh$/D',$host) && rtrim($p['path']??'','/')==='/v2/tokenized-checkout'
    && ($environment==='sandbox'?str_contains($host,'sandbox'):!str_contains($host,'sandbox'));
 }
 public static function valid_redirect($url) { $p=wp_parse_url($url);return ($p['scheme']??'')==='https' && !isset($p['user']) && !isset($p['pass']) && (!isset($p['port'])||$p['port']===443) && preg_match('/(?:^|\.)(?:bkash\.com|bka\.sh)$/D',strtolower($p['host']??'')); }
 public static function inflight($id) {
  if(!function_exists('wc_get_orders'))return true;
  $meta=[['key'=>'_dreminex_payment_profile_id','value'=>$id],['key'=>'_dreminex_payment_state','value'=>['pending','unknown'],'compare'=>'IN']];
  if(class_exists('Automattic\\WooCommerce\\Utilities\\OrderUtil') && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled()) {
   $orders=wc_get_orders(['limit'=>1,'return'=>'ids','payment_method'=>'dreminex_mobile_payment','meta_query'=>$meta]);return !empty($orders);
  }
  $meta[]=['key'=>'_payment_method','value'=>'dreminex_mobile_payment'];
  $query=new WP_Query(['post_type'=>'shop_order','post_status'=>'any','posts_per_page'=>1,'fields'=>'ids','no_found_rows'=>true,'meta_query'=>$meta]);return !empty($query->posts);
 }
 public static function remove($id) {
  if(self::inflight($id))return new WP_Error('profile_in_use','An unresolved payment references this connection. Disable it and reconcile that payment before deleting.');
  foreach(['dreminex_payment_profiles','dreminex_payment_secrets'] as $key){$all=(array)get_option($key,[]);unset($all[$id]);update_option($key,$all,false);}
  // Do not remove a possibly live auth lock here. Its owner releases it in
  // finally; a crashed request is reclaimed after the lock lease expires.
  delete_option('dreminex_payment_token_'.md5($id));delete_option('dreminex_payment_rate_'.md5($id));return true;
 }
}

final class Dreminex_Bkash_V2_Provider implements Dreminex_Payment_Provider_Interface {
 public function id(){return 'bkash';} public function label(){return 'bKash — Tokenized Checkout v2';}
 public function missing($id) {
  $p=(new Dreminex_Payments_Connection_Profile_Repository())->get($id);if(!$p)return ['Connection profile'];
  $missing=[];if(!Dreminex_Payments_Security::valid_base($p['api_base_url']??'',$p['environment']??'sandbox'))$missing[]='Official v2 API base URL';
  $s=Dreminex_Payments_Security::secrets($id);foreach(['app_key','app_secret','username','password'] as $key)if(empty($s[$key]))$missing[]=$key;
  return $missing;
 }
 public function is_profile_configured($id){return !$this->missing($id);}
 public function capabilities($id){return ['create','execute','query'];}
 private function request($id,$path,$body,$headers=[]) {
  $p=(new Dreminex_Payments_Connection_Profile_Repository())->get($id);
  if(!$p||($p['environment']??'')!==Dreminex_Payments_Connection_Profile_Repository::expected_environment())return new WP_Error('environment_mismatch','This WordPress environment only permits '.Dreminex_Payments_Connection_Profile_Repository::expected_environment().' payment credentials. No API request was made.');
  if(!Dreminex_Payments_Security::valid_base($p['api_base_url']??'',$p['environment']??'sandbox'))return new WP_Error('invalid_endpoint','Enter the provider-approved HTTPS v2 API base URL.');
  $r=wp_safe_remote_post(rtrim($p['api_base_url'],'/').'/'.$path,['timeout'=>30,'redirection'=>0,'sslverify'=>true,'headers'=>array_merge(['Accept'=>'application/json','Content-Type'=>'application/json'],$headers),'body'=>wp_json_encode($body),'limit_response_size'=>131072]);
  if(is_wp_error($r))return new WP_Error('provider_network','Provider response was not received. Payment state is unknown; query before any retry.');
  $data=json_decode(wp_remote_retrieve_body($r),true);$http=wp_remote_retrieve_response_code($r);
  if($http<200||$http>=300||!is_array($data)||!empty($data['externalCode'])||(!empty($data['statusCode'])&&$data['statusCode']!=='0000'))return new WP_Error('provider_rejected','Provider rejected this request. Verify the account, API version and credentials in the merchant portal.');
  return $data;
 }
 public function token($id) {
  $profile=(new Dreminex_Payments_Connection_Profile_Repository())->get($id);
  if(!$profile)return new WP_Error('unknown_profile','Unknown payment connection.');
  if(($profile['environment']??'')!==Dreminex_Payments_Connection_Profile_Repository::expected_environment())return new WP_Error('environment_mismatch','This WordPress environment only permits '.Dreminex_Payments_Connection_Profile_Repository::expected_environment().' payment credentials. No API request was made.');
  if(!$this->is_profile_configured($id))return new WP_Error('credentials_missing','Required connection fields: '.implode(', ',$this->missing($id)));
  $cachekey='dreminex_payment_token_'.md5($id);$cached=Dreminex_Payments_Security::open(get_option($cachekey,''));
  if(!empty($cached['id_token'])&&($cached['refresh_after']??0)>time())return $cached['id_token'];
  $lock='dreminex_payment_auth_lock_'.md5($id);if(!Dreminex_Payments_Security::lock_named($lock))return new WP_Error('auth_busy','Authentication is running or recently interrupted. Wait five minutes and retry; do not repeatedly request tokens.');
  try {
   $ratekey='dreminex_payment_rate_'.md5($id);$rate=array_values(array_filter((array)get_option($ratekey,[]),static fn($t)=>(int)$t>time()-HOUR_IN_SECONDS));
   if(count($rate)>=2)return new WP_Error('auth_rate_limit','Two token requests were already attempted within an hour. Reuse a valid token or wait.');
   $rate[]=time();update_option($ratekey,$rate,false);$s=Dreminex_Payments_Security::secrets($id);$body=['app_key'=>$s['app_key'],'app_secret'=>$s['app_secret']];$path='auth/grant-token';
   if(!empty($cached['refresh_token'])){$path='auth/refresh-token';$body['refresh_token']=$cached['refresh_token'];}
   $r=$this->request($id,$path,$body,['username'=>$s['username'],'password'=>$s['password']]);if(is_wp_error($r))return $r;
   if(empty($r['id_token'])||empty($r['refresh_token']))return new WP_Error('invalid_token_response','Provider token response is incomplete.');
   $ttl=min(3600,max(60,(int)($r['expires_in']??3600)));$r['refresh_after']=time()+max(30,$ttl-300);
   $blob=Dreminex_Payments_Security::seal($r);if(is_wp_error($blob))return $blob;update_option($cachekey,$blob,false);return $r['id_token'];
  }finally{Dreminex_Payments_Security::release_named_lock($lock);}
 }
 private function authorized($id,$path,$body) { $token=$this->token($id);if(is_wp_error($token))return $token;$s=Dreminex_Payments_Security::secrets($id);return $this->request($id,$path,$body,['Authorization'=>'Bearer '.$token,'X-App-Key'=>$s['app_key']]); }
 public function create_payment(array $c,$id) {
  if(($c['currency']??'')!=='BDT')return new WP_Error('currency_unsupported','bKash requires BDT.');
  $r=$this->authorized($id,'payment/create',['payerReference'=>$c['payer_reference'],'callbackURL'=>$c['callback_url'],'amount'=>$c['amount'],'currency'=>'BDT','intent'=>'sale','merchantInvoiceNumber'=>$c['invoice']]);if(is_wp_error($r))return $r;
  $url=$r['bkashURL']??$r['bKashURL']??'';
  if(empty($r['paymentId'])||empty($r['signature'])||!Dreminex_Payments_Security::valid_redirect($url)||($r['transactionStatus']??'')!=='Initiated'||wc_format_decimal($r['amount']??'',2)!==wc_format_decimal($c['amount'],2)||($r['currency']??'')!=='BDT'||($r['merchantInvoiceNumber']??'')!==$c['invoice'])return new WP_Error('create_mismatch','Provider creation details did not match this order. Review before retrying.');
  return ['payment_id'=>sanitize_text_field($r['paymentId']),'signature'=>(string)$r['signature'],'redirect'=>$url];
 }
 public function verify_payment(array $c,$id){return $this->authorized($id,'payment/execute',['paymentId'=>$c['payment_id']]);}
 public function query_payment($payment_id,$id){return $this->authorized($id,'query/payment',['paymentId'=>$payment_id]);}
 public function parse_callback(WP_REST_Request $request,$id){return ['payment_id'=>sanitize_text_field($request['paymentID']??$request['paymentId']??''),'signature'=>(string)($request['signature']??''),'status'=>sanitize_key($request['status']??'')];}
 public function verify_callback(array $callback,$id){return !empty($callback['signature'])&&!empty($callback['payment_id']);}
 public function refund(array $c,$id){return new WP_Error('refund_unsupported','Automatic refunds are not enabled. Use the provider merchant portal.');}
}

final class Dreminex_Payments_Callback {
 public static function handle(WP_REST_Request $request) {
  $id=sanitize_text_field($request['profile']);$provider=Dreminex_Payments_Provider_Registry::get($request['provider']);$order=wc_get_order(absint($request['order_id']??0));
  if(!$order||!$provider||!$provider->is_profile_configured($id)||$order->get_payment_method()!=='dreminex_mobile_payment'||(string)$order->get_meta('_dreminex_payment_profile_id')!==$id||$order->get_meta('_dreminex_payment_provider')!==$provider->id())return new WP_Error('payment_not_found','Payment could not be identified.',['status'=>404]);
  $cb=$provider->parse_callback($request,$id);if(is_wp_error($cb))return $cb;
  $state=(string)($request['state']??'');$expected=(string)$order->get_meta('_dreminex_callback_state');$signature=(string)$order->get_meta('_dreminex_provider_signature');
  if(!$state||!$expected||!hash_equals($expected,hash('sha256',$state))||!$signature||!hash_equals($signature,$cb['signature'])||!hash_equals((string)$order->get_meta('_dreminex_provider_payment_id'),$cb['payment_id']))return new WP_Error('invalid_callback','Payment return verification failed.',['status'=>403]);
  if(!Dreminex_Payments_Security::lock($order->get_id()))return new WP_Error('payment_busy','Payment is being verified. If the request was interrupted, wait five minutes before retrying reconciliation.',['status'=>409]);
  try {
   if($order->get_meta('_dreminex_payment_state')==='verified')return self::redirect($order);
   if($cb['status']==='success'&&!$order->get_meta('_dreminex_execute_started')) { $order->update_meta_data('_dreminex_execute_started',gmdate('c'));$order->save();$r=$provider->verify_payment(['payment_id'=>$cb['payment_id']],$id); }
   else $r=$provider->query_payment($cb['payment_id'],$id);
   if(is_wp_error($r))$r=$provider->query_payment($cb['payment_id'],$id);
   $service=new Dreminex_Payments_Order_Service();
   if(is_wp_error($r)||($r['transactionStatus']??'')!=='Completed') { $service->mark_unverified($order,'Payment is not confirmed Completed. Reconcile with the provider before a retry.');return self::redirect($order); }
   $invoice=$r['merchantInvoiceNumber']??$r['merchantInvoice']??'';
   if($invoice!==(string)$order->get_meta('_dreminex_payment_invoice')||($r['intent']??'')!=='sale'||($r['paymentId']??'')!==$cb['payment_id']) { $service->mark_unverified($order,'Provider order mapping mismatch.');return new WP_Error('payment_mismatch','Payment requires manual review.',['status'=>409]); }
   $done=$service->finalize_verified($order,['verified'=>true,'amount'=>$r['amount']??null,'currency'=>$r['currency']??null,'profile_id'=>$id,'provider_payment_id'=>$r['paymentId'],'transaction_id'=>$r['trxId']??'']);
   if(is_wp_error($done))return new WP_Error('payment_review','Payment requires manual review.',['status'=>409]);return self::redirect($order);
  } finally {Dreminex_Payments_Security::unlock($order->get_id());}
 }
 private static function redirect($order){return new WP_REST_Response(['message'=>'Review your order status.'],303,['Location'=>$order->get_checkout_order_received_url(),'Cache-Control'=>'no-store']);}
}

final class Dreminex_Payments_Config_Admin {
 private static function tr($en,$bn){return Dreminex_Suite_Control::tr($en,$bn);}
 public static function register_menu(){add_menu_page('Dreminex Payments','Dreminex Payments','manage_options','dreminex-payments',[__CLASS__,'render'],'dashicons-money-alt',57);}
 private static function fields($provider){return $provider==='bkash'?['app_key'=>'App Key','app_secret'=>'App Secret','username'=>'Merchant API Username','password'=>'Merchant API Password']:($provider==='nagad'?['merchant_id'=>'Merchant ID','merchant_private_key'=>'Merchant Private Key','provider_public_key'=>'Nagad Public Key']:['merchant_id'=>'Merchant ID','api_key'=>'API Key','api_secret'=>'API Secret']);}
 public static function status($id,$p){
  $provider=Dreminex_Payments_Provider_Registry::get($p['provider_id']??'');
  if(!$provider||$provider instanceof Dreminex_Payments_Unconfigured_Provider)return self::tr('Official adapter required','Official provider adapter লাগবে');
  if(($p['environment']??'')!==Dreminex_Payments_Connection_Profile_Repository::expected_environment())return self::tr('Wrong environment; no API request was made','ভুল environment; কোনও API request করা হয়নি');
  if(!$provider->is_profile_configured($id))return self::tr('Missing configuration: ','Configuration বাকি: ').implode(', ',$provider->missing($id));
  if(($p['health_status']??'')!=='Healthy')return self::tr('Run connection test','Connection test চালান');
  return self::tr('Authentication verified','API authentication যাচাই হয়েছে').(($p['environment']??'sandbox')==='sandbox'?' — Sandbox, non-production only':' — Live, production only');
 }
 public static function render(){
  if(!current_user_can('manage_options'))return;
  $repo=new Dreminex_Payments_Connection_Profile_Repository();$profiles=$repo->all();$id=sanitize_text_field(wp_unslash($_GET['edit_profile']??''));$p=$repo->get($id);
  echo '<div class="wrap dreminex-suite"><h1>Delivery Advance & Wallet</h1><p>'.esc_html(self::tr('Manage merchant connections. Credentials remain server-side and are never shown again. Authentication does not prove a completed payment.','Merchant connection পরিচালনা করুন। Credentials server-এ থাকবে; সংরক্ষণের পরে দেখানো হবে না। Authentication মানেই payment complete নয়।')).'</p>';
  Dreminex_Payments_Order_View::reconcile_form();
  if(!empty($_GET['result']))echo '<div class="notice notice-info inline"><p>'.esc_html(self::tr('Action result: ','কাজের ফল: ').sanitize_text_field(wp_unslash($_GET['result']))).'</p></div>';
  echo '<p><a class="button" href="'.esc_url(admin_url('admin.php?page=wc-settings&tab=checkout&section=dreminex_mobile_payment')).'">'.esc_html(self::tr('Gateway settings','Gateway settings')).'</a> <a class="button" href="'.esc_url(admin_url('admin.php?page=dreminex-suite&module=delivery_advance')).'">Suite module On/Off</a></p>';
  $expected=Dreminex_Payments_Connection_Profile_Repository::expected_environment();$site_env=function_exists('wp_get_environment_type')?wp_get_environment_type():'production';
  echo '<div class="notice notice-info inline"><p>'.esc_html(sprintf(self::tr('WordPress environment: %1$s. This site accepts only %2$s payment connections.','WordPress environment: %1$s। এই site-এ কেবল %2$s payment connection চলবে।'),$site_env,$expected)).'</p></div>';
  echo '<div class="notice notice-warning inline"><p>'.esc_html(self::tr('bKash v2 has an API adapter. Sandbox connections are available only on staging/development/local checkout and cannot create production payments. Live connections are accepted only in production. Nagad and Rocket need official merchant API documentation and an implemented adapter; saving keys alone will not enable payment. Customer OTP/PIN must only be entered on the provider page.','bKash v2 API adapter আছে। Sandbox connection কেবল staging/development/local checkout-এ চলে; production payment করতে পারে না। Live connection শুধু production-এ চলে। Nagad/Rocket-এর official merchant API documentation ও adapter লাগবে; শুধু key save করলে payment চালু হবে না। Customer OTP/PIN কেবল provider-এর পেজে দিতে হবে।')).'</p></div>';
  echo '<h2>'.esc_html(self::tr('Connections','Connections')).'</h2><div class="dreminex-payment-connections"><table class="widefat striped"><thead><tr><th>Name</th><th>Provider</th><th>Environment</th><th>Status / next step</th><th>Enabled</th><th>Actions</th></tr></thead><tbody>';
  foreach($profiles as $pid=>$profile){echo '<tr><td>'.esc_html($profile['profile_name']??$pid).'</td><td>'.esc_html($profile['provider_id']??'').'</td><td>'.esc_html($profile['environment']??'sandbox').'</td><td>'.esc_html(self::status($pid,$profile)).'<br><small>'.esc_html($profile['last_test_message']??'').'</small></td><td>'.(!empty($profile['enabled'])?'Yes':'No').'</td><td><a class="button" href="'.esc_url(add_query_arg(['page'=>'dreminex-payments','edit_profile'=>$pid],admin_url('admin.php'))).'">Edit / API keys</a> ';
   self::action_form('toggle_profile',$pid,!empty($profile['enabled'])?'Disable':'Enable');self::action_form('connection_test',$pid,'Test connection');self::action_form('delete_profile',$pid,'Delete',true);echo '</td></tr>';}
  if(!$profiles)echo '<tr><td colspan="6">No connections yet. Add one below.</td></tr>';echo '</tbody></table></div>';
  echo '<h2>'.esc_html($p?'Edit connection':'Add connection').'</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_payment_save_profile"><input type="hidden" name="profile_id" value="'.esc_attr($id).'">';wp_nonce_field('dreminex_save_profile');
  echo '<p><label>Name <input required maxlength="120" class="regular-text" name="profile_name" value="'.esc_attr($p['profile_name']??'').'"></label></p><p><label>Provider <select name="provider_id">';
  foreach(['bkash'=>'bKash','nagad'=>'Nagad','rocket'=>'Rocket'] as $key=>$label)echo '<option value="'.esc_attr($key).'" '.selected($p['provider_id']??'bkash',$key,false).'>'.esc_html($label).'</option>';
  echo '</select></label> <label>Environment <select name="environment"><option value="'.esc_attr($expected).'" selected>'.esc_html(ucfirst($expected)).' (required here)</option></select></label></p>';
  if($p&&($p['environment']??'')!==$expected)echo '<div class="notice notice-warning inline"><p>'.esc_html(self::tr('This saved profile belongs to a different environment and cannot make API requests here. Saving it as the required environment clears its old credentials; enter fresh credentials issued for this environment.','এই saved profile-টি অন্য environment-এর। এখানে এটি API request করতে পারবে না। প্রয়োজনীয় environment-এ Save করলে আগের credentials মুছে যাবে; এই environment-এর নতুন credentials দিন।')).'</p></div>';
  echo '<p><label>Priority (lower first) <input type="number" min="0" max="1000" name="priority" value="'.esc_attr($p['priority']??100).'"></label></p>';
  echo '<p><label>Official v2 API base URL <input class="large-text" type="url" name="api_base_url" value="'.esc_attr($p['api_base_url']??((($p['environment']??'sandbox')==='sandbox'&&($p['provider_id']??'bkash')==='bkash')?'https://tokenized.sandbox.bka.sh/v2/tokenized-checkout':'')).'"></label><br><small>bKash Sandbox: https://tokenized.sandbox.bka.sh/v2/tokenized-checkout — For Live, enter the v2 base URL supplied by bKash. Do not use a v1 account with the v2 adapter.</small></p>';
  if($p){$secrets=(($p['environment']??'')===$expected)?Dreminex_Payments_Security::secrets($id):[];foreach(self::fields($p['provider_id']) as $key=>$label){$placeholder=!empty($secrets[$key])?'Saved; leave blank to keep':'Not saved for this environment';echo '<p><label>'.esc_html($label).' ';
    if(in_array($key,['merchant_private_key','provider_public_key'],true))echo '<textarea rows="4" class="large-text" autocomplete="off" name="credentials['.esc_attr($key).']" placeholder="'.esc_attr($placeholder).'" maxlength="16384"></textarea>';
    else echo '<input class="regular-text" type="password" autocomplete="new-password" name="credentials['.esc_attr($key).']" value="" placeholder="'.esc_attr($placeholder).'" maxlength="16384">';echo '</label></p>';}echo '<p><label><input type="checkbox" name="clear_credentials" value="1"> Clear all stored credentials (also disables this connection)</label></p>';}
  else echo '<p>Create the connection first, then use Edit / API keys to enter provider-specific credentials.</p>';
  echo '<p><label><input type="checkbox" name="enabled" value="1" '.checked(!empty($p['enabled']),true,false).'> Enable connection (checkout still requires successful authentication)</label></p>';submit_button($p?'Save changes':'Create connection');echo '</form>';
  echo '<h2>Setup steps</h2><ol><li>Obtain an approved merchant/API account; a personal wallet number is not an API credential.</li><li>Create a connection using the environment shown above: Sandbox on non-production sites or Live on production. Enter the matching provider API URL and credentials.</li><li>Run Test connection. This only authenticates. A profile for the wrong WordPress environment is blocked before any API request.</li><li>Complete a controlled Sandbox integration test on staging before configuring a Live connection on production.</li><li>Enable the production Live connection and gateway only after the provider integration is approved.</li></ol><p>Delete removes local connection and encrypted credentials; it does not revoke keys at the provider or delete historical orders. Pending/unknown payments prevent deletion. Disable first if you need to stop new payments.</p></div>';
 }
 private static function action_form($action,$id,$label,$confirm=false){
  echo '<form style="display:inline-block;margin:3px" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_payment_'.esc_attr($action).'"><input type="hidden" name="profile_id" value="'.esc_attr($id).'">';wp_nonce_field('dreminex_'.$action.'_'.$id);
  if($confirm)echo '<label><input type="checkbox" name="confirm_delete" value="1" required> Confirm </label>';
  echo '<button class="button" type="submit">'.esc_html($label).'</button></form>';
 }
 private static function authorize($action){if(!current_user_can('manage_options'))wp_die('Access denied.');$id=sanitize_text_field(wp_unslash($_POST['profile_id']??''));check_admin_referer('dreminex_'.$action.'_'.$id);return $id;}
 private static function finish($result,$id=''){wp_safe_redirect(add_query_arg(array_filter(['page'=>'dreminex-payments','result'=>$result,'edit_profile'=>$id]),admin_url('admin.php')));exit;}
 public static function save_profile(){
  if(!current_user_can('manage_options'))wp_die('Access denied.');check_admin_referer('dreminex_save_profile');
  $id=sanitize_text_field(wp_unslash($_POST['profile_id']??''));$repo=new Dreminex_Payments_Connection_Profile_Repository();$all=$repo->all();$old=$id?$repo->get($id):null;if($id&&!$old)wp_die('Unknown connection.');
  $name=sanitize_text_field(wp_unslash($_POST['profile_name']??''));$provider=sanitize_key(wp_unslash($_POST['provider_id']??''));$env=sanitize_key(wp_unslash($_POST['environment']??''));
  if(!$name||strlen($name)>120||!in_array($provider,['bkash','nagad','rocket'],true)||!in_array($env,['sandbox','live'],true))wp_die('Invalid connection details.');
  if($env!==Dreminex_Payments_Connection_Profile_Repository::expected_environment())wp_die('This WordPress environment only accepts '.esc_html(Dreminex_Payments_Connection_Profile_Repository::expected_environment()).' payment connections. No credentials were saved.');
  $base=trim((string)wp_unslash($_POST['api_base_url']??''));if($provider==='bkash'&&$base!==''&&!Dreminex_Payments_Security::valid_base($base,$env))wp_die('Use a provider-approved HTTPS bka.sh URL ending in /v2/tokenized-checkout for the selected environment.');
  if($old&&Dreminex_Payments_Security::inflight($id))wp_die('Unresolved payments reference this connection. Disable it and reconcile before editing credentials or routing.');
  if(!$id)$id=wp_generate_uuid4();$secrets=$old?Dreminex_Payments_Security::secrets($id):[];if($old&&(($old['provider_id']??'')!==$provider || ($old['environment']??'')!==$env || rtrim($old['api_base_url']??'','/')!==rtrim($base,'/')))$secrets=[];
  $input=is_array($_POST['credentials']??null)?wp_unslash($_POST['credentials']):[];
  foreach(self::fields($provider) as $key=>$label){$v=$input[$key]??'';if(!is_string($v)||strlen($v)>16384)wp_die('Invalid credential input.');if($v!==''){if(in_array($key,['app_key','username','password','api_key','api_secret'],true)&&preg_match('/[\r\n]/',$v))wp_die('Credential headers cannot contain newlines.');$secrets[$key]=$v;}}
  $clear=!empty($_POST['clear_credentials']);if($clear)$secrets=[];$saved=Dreminex_Payments_Security::save_secrets($id,$secrets);if(is_wp_error($saved))wp_die(esc_html($saved->get_error_message()));
  $all[$id]=array_merge($old??[],['profile_id'=>$id,'profile_name'=>$name,'provider_id'=>$provider,'environment'=>$env,'api_base_url'=>$base,'enabled'=>!$clear&&!empty($_POST['enabled']),'priority'=>min(1000,absint($_POST['priority']??100)),'credential_source'=>'encrypted_options','health_status'=>'Unknown','last_connection_test'=>null,'last_test_message'=>'Configuration changed; run connection test.']);
  update_option(Dreminex_Payments_Connection_Profile_Repository::OPTION,$all,false);delete_option('dreminex_payment_token_'.md5($id));Dreminex_Suite_Control::queue_scan();self::finish('Saved',$id);
 }
 public static function toggle_profile(){ $id=self::authorize('toggle_profile');$all=(new Dreminex_Payments_Connection_Profile_Repository())->all();if(!isset($all[$id]))wp_die('Unknown connection.');$all[$id]['enabled']=empty($all[$id]['enabled']);update_option(Dreminex_Payments_Connection_Profile_Repository::OPTION,$all,false);Dreminex_Suite_Control::queue_scan();self::finish($all[$id]['enabled']?'Enabled':'Disabled'); }
 public static function delete_profile(){ $id=self::authorize('delete_profile');if(($_POST['confirm_delete']??'')!=='1')wp_die('Confirm deletion first.');$r=Dreminex_Payments_Security::remove($id);Dreminex_Suite_Control::queue_scan();self::finish(is_wp_error($r)?$r->get_error_message():'Deleted'); }
 public static function test($id){
  $all=(new Dreminex_Payments_Connection_Profile_Repository())->all();if(!isset($all[$id]))return new WP_Error('unknown_profile','Unknown connection.');$p=$all[$id];$provider=Dreminex_Payments_Provider_Registry::get($p['provider_id']);
  if(!$provider||!($provider instanceof Dreminex_Bkash_V2_Provider))$r=new WP_Error('adapter_required','Official provider API documentation and adapter are required.');else $r=$provider->token($id);
  $all[$id]['health_status']=is_wp_error($r)?'Needs configuration':'Healthy';$all[$id]['last_test_message']=is_wp_error($r)?$r->get_error_message():'Authentication succeeded. No payment was created.';$all[$id]['last_connection_test']=gmdate('c');update_option(Dreminex_Payments_Connection_Profile_Repository::OPTION,$all,false);return is_wp_error($r)?$r:true;
 }
 public static function connection_test(){ $id=self::authorize('connection_test');$r=self::test($id);Dreminex_Suite_Control::queue_scan();self::finish(is_wp_error($r)?$r->get_error_message():'Authentication verified; no charge attempted'); }
}

final class Dreminex_Payments_Order_View {
 public static function summary($order,$plain=false){
  if(!$order instanceof WC_Order||$order->get_payment_method()!=='dreminex_mobile_payment')return;
  $state=(string)$order->get_meta('_dreminex_payment_state');
  $text=$state==='verified'?Dreminex_Suite_Control::tr('Provider payment verified.','Provider payment যাচাই হয়েছে।'):Dreminex_Suite_Control::tr('Payment has not been verified. Contact us before paying again.','Payment নিশ্চিত হয়নি। আবার টাকা দেওয়ার আগে আমাদের সঙ্গে যোগাযোগ করুন।');
  $paid=wc_price((float)$order->get_meta('_dreminex_paid_amount'),['currency'=>$order->get_currency()]);$balance=$state==='verified'?(float)$order->get_meta('_dreminex_remaining_due'):max(0,(float)$order->get_total()-(float)$order->get_meta('_dreminex_paid_amount'));$due=wc_price($balance,['currency'=>$order->get_currency()]);
  if($plain)echo "\n".$text.' Paid: '.wp_strip_all_tags($paid).' Remaining due: '.wp_strip_all_tags($due)."\n";
  else echo Dreminex_Suite_Setup::text('<section class="dreminex-payment-summary" style="border-left:4px solid #00B4D7;padding:12px"><strong>').esc_html($text).'</strong><p>Paid: '.wp_kses_post($paid).' · Remaining due: '.wp_kses_post($due).'</p></section>';
 }
 public static function admin($order){
  if(!$order instanceof WC_Order||$order->get_payment_method()!=='dreminex_mobile_payment')return;
  self::summary($order);if(!current_user_can('manage_options'))return;
  echo '<p><a class="button" href="'.esc_url(add_query_arg(['page'=>'dreminex-payments','reconcile_order'=>$order->get_id()],admin_url('admin.php'))).'">Reconcile payment →</a></p>';
 }
 public static function reconcile_form(){
  $id=absint($_GET['reconcile_order']??0);if(!$id)return;$order=wc_get_order($id);
  if(!$order instanceof WC_Order||$order->get_payment_method()!=='dreminex_mobile_payment')return;
  echo '<h2>Query order #'.esc_html($order->get_order_number()).'</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_payment_query_order"><input type="hidden" name="order_id" value="'.esc_attr($id).'">';wp_nonce_field('dreminex_query_order_'.$id);echo '<button class="button" type="submit">Query payment status (no new charge)</button></form>';
 }
 public static function query(){
  if(!current_user_can('manage_options'))wp_die('Access denied.');$oid=absint($_POST['order_id']??0);check_admin_referer('dreminex_query_order_'.$oid);$order=wc_get_order($oid);
  if(!$order instanceof WC_Order||$order->get_payment_method()!=='dreminex_mobile_payment')wp_die('Not a Dreminex API payment.');
  if(!Dreminex_Payments_Security::lock($oid))wp_die('Payment verification is running or was recently interrupted. Wait five minutes before retrying reconciliation.');
  try{
   $pid=(string)$order->get_meta('_dreminex_payment_profile_id');$payment=(string)$order->get_meta('_dreminex_provider_payment_id');$provider=Dreminex_Payments_Provider_Registry::get($order->get_meta('_dreminex_payment_provider'));
   if(!$provider||!$payment||!$provider->is_profile_configured($pid)){$order->add_order_note('Provider query unavailable. Check connection configuration and merchant portal. No payment attempt was made.');}
   else{
    $r=$provider->query_payment($payment,$pid);
    if(!is_wp_error($r)&&($r['transactionStatus']??'')==='Completed'&&($r['paymentId']??'')===$payment&&($r['merchantInvoiceNumber']??$r['merchantInvoice']??'')===(string)$order->get_meta('_dreminex_payment_invoice')&&($r['intent']??'')==='sale'){
     $done=(new Dreminex_Payments_Order_Service())->finalize_verified($order,['verified'=>true,'amount'=>$r['amount']??null,'currency'=>$r['currency']??null,'profile_id'=>$pid,'provider_payment_id'=>$payment,'transaction_id'=>$r['trxId']??'']);
     $order->add_order_note(is_wp_error($done)?'Provider query requires manual review.':'Provider query confirmed this payment.');
    }else $order->add_order_note('Provider query did not confirm a matching Completed payment. Review in merchant portal; do not blindly retry.');
   }
  }finally{Dreminex_Payments_Security::unlock($oid);}
  wp_safe_redirect($order->get_edit_order_url());exit;
 }
}
