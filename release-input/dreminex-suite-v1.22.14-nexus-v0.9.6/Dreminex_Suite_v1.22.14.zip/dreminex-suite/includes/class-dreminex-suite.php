<?php
if (!defined('ABSPATH')) exit;
final class Dreminex_Suite {
 private static $loading='';
 private static $modules=[
  'delivery_advance'=>['Delivery Advance & Wallet','dreminex_delivery_advance.php',5,'Checkout','Advance or full payment, customer wallet, provider verification, offer credit and withdrawals'],
  'checkout_protection'=>['Checkout Protection','dreminex_checkout_protection.php',0,'Checkout','Phone, IP cooldown, browser limits, receipt privacy and consented recovery','edit.php?post_type=dreminex_partial'],
  'checkout_experience'=>['Checkout Experience','dreminex_checkout_experience.php',0,'Checkout','Thank-you content and accessible checkout error dialog'],
  'order_management'=>['Order Management','dreminex_order_management.php',0,'Orders','Customer history, alerts, owner email, statuses and courier tracking'],
  'flash_sale'=>['Flash Sale','dreminex_flash_sale.php',0,'Marketing','Selected products, page-only offer prices, countdown and campaign controls','dreminex-flash-sale'],
  'newsletter_offers'=>['Newsletter and offers','dreminex_newsletter_offers.php',18,'Marketing','Subscription, confirmation, coupon and offers','dreminex-newsletter'],
  'contact_requests'=>['Contact requests and media','dreminex_contact_requests.php',19,'Support','Contact form, private media, replies and status emails','dreminex-contact-requests'],
  'native_mcp'=>['Native MCP','dreminex_native_mcp.php',0,'Operations','Scoped AI connections, abilities, approvals and audit','dreminex-native-mcp'],
  'supplier_monitor'=>['Supplier Monitor','dreminex_supplier_monitor.php',0,'Operations','Universal supplier accounts, protected device login, phone scans and controlled supplier workflows','dreminex-supplier-monitor'],
  'storefront_design'=>['Storefront Design','dreminex_storefront_design.php',0,'Design','Homepage, products, shop, cart, checkout and customer pages'],
  'registration_email'=>['Account Experience & Security','dreminex_account_experience.php',0,'Accounts','Account pages, registration, email verification and safe cross-account password reset'],
  'store_email_branding'=>['Store email branding','dreminex_store_email_branding.php',0,'Store setup','WooCommerce email logo, brand colors, sender identity and core email controls'],
  'mail_engine'=>['Mail Engine','dreminex_mail_engine.php',0,'Store setup','Monitor-first email routing, encrypted queue, provider diagnostics and contact-form bot controls','dreminex-mail-engine'],
  'advanced_optimizations'=>['Advanced Optimizations','dreminex_advanced_optimizations.php',0,'Performance','Conditional module and asset loading readiness'],
 ];
 public static function activate() {
  if (false===get_option('dreminex_suite_modules',false)) add_option('dreminex_suite_modules',[], '', false);
  self::log('Native MCP and Nexus-managed modules enable by default when unset; matching legacy snippets stay protected from duplicate loading.');
  Dreminex_Suite_Upgrades::run();
 }
 public static function boot() {
  Dreminex_Suite_Upgrades::run();
  self::initialize_nexus_module_defaults();
  if(get_option('dreminex_suite_language','en')!=='en')update_option('dreminex_suite_language','en',false);
  if(class_exists('WooCommerce')) Dreminex_Flash_Sale::boot();
  Dreminex_Suite_Features::boot();
  Dreminex_Suite_Cache::boot();
  Dreminex_Suite_Access::boot();
  Dreminex_Suite_Control::boot();
  Dreminex_Suite_Setup::boot();
  Dreminex_Suite_Data::boot();
  Dreminex_Native_MCP::boot();
  Dreminex_Security_Center::boot();
  if(Dreminex_Native_MCP::enabled()&&class_exists('WooCommerce')){
   foreach(['modules/dreminex_ai_product_publisher.php'] as $service_file){
    if(is_readable(DREMINEX_SUITE_PATH.$service_file))require_once DREMINEX_SUITE_PATH.$service_file;
   }
  }
  Dreminex_Supplier_Nexus::boot();
  Dreminex_Supplier_Monitor::boot();
  Dreminex_Supplier_Workflow::boot();
  Dreminex_Nexus_Operations::boot();
  Dreminex_Nexus_App::boot();
  add_action('admin_menu',[__CLASS__,'menu'],30);
  add_action('admin_menu',[__CLASS__,'reorder_submenus'],999);
  add_action('admin_head',[__CLASS__,'hide_submenu_links'],99);
  add_action('admin_post_dreminex_suite_change',[__CLASS__,'change']);
  add_action('admin_post_dreminex_suite_module_settings',[__CLASS__,'save_module_settings']);
  add_action('admin_post_dreminex_suite_language',[__CLASS__,'save_language']);
  add_action('admin_post_dreminex_suite_dismiss',[__CLASS__,'dismiss_notice']);
  add_filter('map_meta_cap',[__CLASS__,'map_supplier_monitor_cap'],10,4);
  add_action('dreminex_suite_module_panel',[__CLASS__,'extended_module_panel'],5);
  add_filter('site_status_tests',[__CLASS__,'site_health_tests']);
  add_filter('upgrader_source_selection',[__CLASS__,'inspect_source'],10,4);
  register_shutdown_function([__CLASS__,'shutdown']);
  self::record_revisions();
  foreach(self::$modules as $key=>$module) {
   $load_for_admin=self::admin_managed_request($key);
   $legacy_active=self::app_managed_module($key)?self::legacy_snippet_running($module[2]):self::snippet_active($module[2]);
   if ((!self::enabled($key) && !$load_for_admin) || $legacy_active || !class_exists('WooCommerce')) continue;
   $file=DREMINEX_SUITE_PATH.'modules/'.$module[1];
   if (!is_file($file)) { self::fault($key,'Module file is missing.'); continue; }
   try { self::$loading=$key; require_once $file; self::$loading=''; }
   catch (Throwable $e) { self::$loading=''; self::fault($key,get_class($e).': '.$e->getMessage()); }
  }
  Dreminex_Suite_Routing::boot();
  Dreminex_Suite_Experience::boot();
  Dreminex_Suite_Imports::boot();
 }
 public static function save_language() {
  if (!current_user_can('manage_options')) wp_die('Access denied.');
  check_admin_referer('dreminex_suite_language');
  update_option('dreminex_suite_language','en',false);
  wp_safe_redirect(admin_url('admin.php?page=dreminex-suite-settings&saved=language')); exit;
 }
 private static function admin_managed_request($key) {
  if (!is_admin()) return false;
  $page=isset($_REQUEST['page'])?sanitize_key(wp_unslash($_REQUEST['page'])):'';
  $action=isset($_REQUEST['action'])?sanitize_key(wp_unslash($_REQUEST['action'])):'';
  $routes=[
   'newsletter_offers'=>['pages'=>['dreminex-newsletter','dreminex-newsletter-settings','dreminex-offers'],'prefixes'=>['dreminex_newsletter_','dreminex_offer_']],
   'contact_requests'=>['pages'=>['dreminex-contact-requests','dreminex-contact-mail-media'],'prefixes'=>['dreminex_contact_']],
   'ai_product_publisher'=>['pages'=>['dreminex-ai-product-publisher'],'prefixes'=>['dreminex_publisher_','dreminex_workflow_']],
   'native_mcp'=>['pages'=>['dreminex-native-mcp'],'prefixes'=>['dreminex_mcp_']],
   'mail_engine'=>['pages'=>['dreminex-mail-engine'],'prefixes'=>['dreminex_mail_engine_']],
   'supplier_monitor'=>['pages'=>['dreminex-supplier-monitor'],'prefixes'=>['dreminex_sm_','dreminex_nexus_']],
   'storefront_design'=>['pages'=>[],'prefixes'=>['dreminex_design_','dreminex_home_']],
  ];
  if($page==='dreminex-suite' && isset($_GET['module']) && sanitize_key(wp_unslash($_GET['module']))===$key) return true;
  if (!isset($routes[$key])) return false;
  if (in_array($page,$routes[$key]['pages'],true)) return true;
  foreach($routes[$key]['prefixes'] as $prefix) if($action!=='' && strpos($action,$prefix)===0) return true;
  return false;
 }
 public static function dismiss_notice() {
  if (!current_user_can('manage_options')) wp_die('Access denied.');
  check_admin_referer('dreminex_suite_dismiss');
  $id=isset($_POST['notice_id'])?sanitize_key(wp_unslash($_POST['notice_id'])):'';
  if ($id) update_user_meta(get_current_user_id(),'dreminex_suite_dismissed_'.$id,1);
  wp_safe_redirect(wp_get_referer()?:admin_url('admin.php?page=dreminex-suite')); exit;
 }
 public static function security_notices() {
  if (!current_user_can('manage_options')) return;
  $active=(array)get_option('active_plugins',[]);
  $missing=[];
  foreach($active as $plugin) if (!file_exists(WP_PLUGIN_DIR.'/'.$plugin)) $missing[]=$plugin;
  if ($missing && !get_user_meta(get_current_user_id(),'dreminex_suite_dismissed_missing_plugins',true)) {
   echo '<div class="notice notice-error"><p><strong>Dreminex Suite:</strong> One or more active plugin files are missing. Review Plugins and Site Health.</p>';
   self::dismiss_form('missing_plugins'); echo '</div>';
  }
 }
 private static function dismiss_form($id) {
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline"><input type="hidden" name="action" value="dreminex_suite_dismiss"><input type="hidden" name="notice_id" value="'.esc_attr($id).'">';
  wp_nonce_field('dreminex_suite_dismiss'); submit_button('Dismiss','secondary small','submit',false); echo '</form>';
 }
 public static function site_health_tests($tests) {
  $tests['direct']['dreminex_suite_plugins']= ['label'=>'Dreminex Suite: active plugin files','test'=>[__CLASS__,'health_plugins']];
  $tests['direct']['dreminex_suite_findings']= ['label'=>'Dreminex Suite: monitored findings','test'=>[__CLASS__,'health_findings']];
  return $tests;
 }
 public static function health_findings() {
  $report=Dreminex_Suite_Control::report();$critical=0;$warning=0;
  foreach($report['findings'] as $finding){if($finding['severity']==='critical')$critical++;elseif($finding['severity']==='warning')$warning++;}
  return ['label'=>$critical?'Dreminex Suite found critical issues':($warning?'Dreminex Suite found warnings':'Dreminex Suite checks found no issues'),
   'status'=>$critical?'critical':($warning?'recommended':'good'),'badge'=>['label'=>'Dreminex Suite','color'=>$critical?'red':'blue'],
   'description'=>'<p>Checked plugin inventory, update state, Suite loader, cron, HTTPS, debug display and available disk. Unknown vulnerabilities are not ruled out.</p>',
   'actions'=>'<p><a href="'.esc_url(admin_url('admin.php?page=dreminex-suite-health')).'">Review findings and fixes</a></p>','test'=>'dreminex_suite_findings'];
 }
 public static function health_plugins() {
  $active=(array)get_option('active_plugins',[]); $missing=[];
  foreach($active as $plugin) if (!file_exists(WP_PLUGIN_DIR.'/'.$plugin)) $missing[]=$plugin;
  if ($missing) return ['label'=>'Active plugin files are missing','status'=>'critical','badge'=>['label'=>'Dreminex Suite','color'=>'red'],'description'=>'<p>One or more active plugin entry files cannot be found. Review Plugins and restore from a trusted backup.</p>','actions'=>'<p><a href="'.esc_url(admin_url('plugins.php')).'">Review plugins</a></p>','test'=>'dreminex_suite_plugins'];
  return ['label'=>'Active plugin entry files are present','status'=>'good','badge'=>['label'=>'Dreminex Suite','color'=>'blue'],'description'=>'<p>WordPress can find the entry file for every active plugin. This check does not scan plugin code or prove that plugins are safe.</p>','actions'=>'','test'=>'dreminex_suite_plugins'];
 }
 public static function inspect_source($source,$remote_source,$upgrader,$hook_extra) {
  if (is_wp_error($source)) return $source;
  $checked=self::inspect_install_package(true,$hook_extra,['source'=>$source]);
  return is_wp_error($checked)?$checked:$source;
 }
 public static function inspect_install_package($response,$hook_extra,$result=[]) {
  if (is_wp_error($response) || empty($hook_extra['type']) || !in_array($hook_extra['type'],['plugin','theme'],true)) return $response;
  if ((int)get_option('dreminex_suite_preinstall_scan',1)!==1) return $response;
  // The source-selection wrapper supplies the unpacked package path.
  $source=is_array($result)&&!empty($result['source'])?$result['source']:'';
  if (!is_dir($source)) return $response;
  $patterns=['/eval\s*\(\s*(?:base64_decode|gzinflate)\s*\(/i','/(?:shell_exec|passthru|system)\s*\(\s*\$_(?:GET|POST|REQUEST)/i'];
  $started=microtime(true); $bytes=0; $files=0;
  try { $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source,FilesystemIterator::SKIP_DOTS));
   foreach($it as $file) { if (!$file->isFile() || strtolower($file->getExtension())!=='php') continue;
    $bytes+=$file->getSize(); $files++;
    if ($bytes>67108864 || $files>3000 || microtime(true)-$started>10) return new WP_Error('dreminex_suite_scan_incomplete','Package scan exceeded its limits. Review the package before installation.');
    $code=file_get_contents($file->getPathname()); if ($code===false) return new WP_Error('dreminex_suite_scan_unreadable','A PHP file could not be read. Review the package before installation.');
    try { $tokens=token_get_all($code,TOKEN_PARSE); } catch(Throwable $syntax) { return new WP_Error('dreminex_suite_scan_syntax','A package PHP file is incompatible with the current server: '.wp_basename($file->getPathname())); }
    $code=''; foreach($tokens as $token) { $code.=is_array($token)?(in_array($token[0],[T_COMMENT,T_DOC_COMMENT,T_CONSTANT_ENCAPSED_STRING],true)?' ':$token[1]):$token; }
    foreach($patterns as $pattern) if (preg_match($pattern,$code)) {
     $name=isset($hook_extra['plugin'])?sanitize_text_field($hook_extra['plugin']):(isset($hook_extra['theme'])?sanitize_text_field($hook_extra['theme']):'package');
     update_option('dreminex_suite_last_scan_alert',['time'=>current_time('mysql'),'package'=>$name,'file'=>sanitize_text_field(wp_basename($file->getPathname()))],false);
     self::log('Pre-install scan blocked a package matching a high-risk PHP pattern: '.$name);
     return new WP_Error('dreminex_suite_scan_blocked','Dreminex Suite blocked installation because a PHP file matched a high-risk code pattern. Review the package with a trusted security scanner before retrying.');
    }
   }
  } catch(Throwable $e) { self::log('Pre-install scan could not complete.'); return new WP_Error('dreminex_suite_scan_failed','Package scan could not complete. Review the package before installation.'); }
  return $response;
 }
 private static function record_revisions() {
  $prior=get_option('dreminex_suite_file_revisions',[]);
  if (!is_array($prior)) $prior=[];
  $next=[];
  foreach(self::$modules as $key=>$module) {
   $path=DREMINEX_SUITE_PATH.'modules/'.$module[1];
   $next[$key]=is_file($path)?hash_file('sha256',$path):'';
   if (isset($prior[$key]) && $prior[$key]!==$next[$key]) self::log($module[0].' source changed; verify this module after the update.');
  }
  if ($prior!==$next) update_option('dreminex_suite_file_revisions',$next,false);
 }
 public static function catalog() { return self::$modules; }
 /* Delivery Advance & Wallet remains in the WordPress module catalogue. The
  * app and WordPress both read/write the same module option for its toggle. */
 private static function app_managed_module($key){return in_array($key,['checkout_protection','newsletter_offers','contact_requests'],true);}
 public static function initialize_nexus_module_defaults(){
  $modules=get_option('dreminex_suite_modules',[]);if(!is_array($modules))$modules=[];$changed=false;
  if(!array_key_exists('native_mcp',$modules)){$modules['native_mcp']=1;$changed=true;}
  if($changed)update_option('dreminex_suite_modules',$modules,false);
  if(empty($modules['native_mcp'])||get_option('dreminex_nexus_module_defaults_v1',0))return;
  if(!class_exists('WooCommerce'))return;
  $settings=Dreminex_Native_MCP::settings();$features=(array)($settings['app_features']??[]);$mapping=['supplier_monitor'=>'supplier_monitor','contacts'=>'contact_requests','checkout'=>'checkout_protection','welcome_offers'=>'newsletter_offers','payments'=>'delivery_advance'];
  foreach($mapping as $feature=>$module){if(array_key_exists($module,$modules))continue;$requested=!array_key_exists($feature,$features)||!empty($features[$feature]);if(!$requested)continue;$result=self::app_module_transition($module,true,false);if(!is_wp_error($result)){$modules=get_option('dreminex_suite_modules',[]);$features[$feature]=1;}}
  $settings['app_features']=$features;update_option(Dreminex_Native_MCP::SETTINGS,$settings,false);update_option('dreminex_nexus_module_defaults_v1',1,false);
 }
 public static function app_module_conflict($key){$module=self::$modules[$key]??null;if(!$module||!self::legacy_snippet_running($module[2]))return ['active'=>false,'migratable'=>false];return ['active'=>true,'migratable'=>self::source_matches($key,$module[2])&&function_exists('\\Code_Snippets\\deactivate_snippet')];}
 public static function app_module_transition($key,$on,$migrate=false){
  if(!isset(self::$modules[$key]))return new WP_Error('module_unknown','This app-managed module is unavailable.',['status'=>404,'module'=>$key]);$module=self::$modules[$key];
  if($on&&!class_exists('WooCommerce'))return new WP_Error('woocommerce_required','WooCommerce must be active before this module can be enabled.',['status'=>424,'module'=>$key]);
  if($on&&!is_file(DREMINEX_SUITE_PATH.'modules/'.$module[1]))return new WP_Error('module_missing','The Suite module file is missing.',['status'=>424,'module'=>$key]);
  if($on&&$key==='ai_product_publisher'&&function_exists('is_plugin_active')&&is_plugin_active('dreminex-ai-product-publisher/dreminex-ai-product-publisher.php'))return new WP_Error('publisher_conflict','Disable the standalone publisher before enabling the integrated module.',['status'=>409,'module'=>$key]);
  if($on&&self::legacy_snippet_running($module[2])){if(!$migrate||!function_exists('\\Code_Snippets\\deactivate_snippet'))return new WP_Error('legacy_snippet_conflict','An active legacy Code Snippets module is blocking activation.',['status'=>409,'module'=>$key,'migratable'=>self::source_matches($key,$module[2])]);if(!self::source_matches($key,$module[2]))return new WP_Error('legacy_source_changed','The active legacy snippet differs from the Suite copy and must be reviewed and disabled manually before migration.',['status'=>409,'module'=>$key]);\Code_Snippets\deactivate_snippet($module[2]);if(self::legacy_snippet_running($module[2]))return new WP_Error('legacy_snippet_conflict','The legacy snippet could not be deactivated.',['status'=>409,'module'=>$key]);self::log('Code Snippets #'.$module[2].' deactivated for '.$module[0].'.');}
  $values=get_option('dreminex_suite_modules',[]);if(!is_array($values))$values=[];$values[$key]=$on?1:0;update_option('dreminex_suite_modules',$values,false);$errors=get_option('dreminex_suite_errors',[]);if(!is_array($errors))$errors=[];unset($errors[$key]);update_option('dreminex_suite_errors',$errors,false);if(class_exists('Dreminex_Suite_Cache'))Dreminex_Suite_Cache::changed($key,true);self::log($module[0].($on?' enabled from Nexus.':' disabled from Nexus.'));return ['success'=>true,'module'=>$key,'enabled'=>(bool)$on];
 }
 private static function enabled($key) {
  $values=get_option('dreminex_suite_modules',[]);
  return is_array($values) && !empty($values[$key]);
 }
 private static function snippet_active($id) {
  if (!function_exists('\\Code_Snippets\\get_snippet')) return false;
  $snippet=\Code_Snippets\get_snippet($id);
  if (!$snippet || empty($snippet->active) || $id<=0) return false;
  $bindings=(array)get_option('dreminex_suite_legacy_bindings',[]);
  foreach(self::$modules as $key=>$module) if($module[2]===$id && (self::source_matches($key,$id) || (int)($bindings[$key]??0)===$id)) return true;
  return false;
 }
 private static function legacy_snippet_running($id) {
  if ($id<=0 || !function_exists('\\Code_Snippets\\get_snippet')) return false;
  $snippet=\Code_Snippets\get_snippet($id);
  return $snippet && !empty($snippet->active);
 }
 private static function source_matches($key,$id) {
  if (!function_exists('\\Code_Snippets\\get_snippet')) return false;
  $snippet=\Code_Snippets\get_snippet($id);
  $hashes=json_decode((string)file_get_contents(DREMINEX_SUITE_PATH.'includes/source-hashes.json'),true);
  return $snippet && is_array($hashes) && isset($hashes[$key])
   && hash('sha256',rtrim($snippet->code,"\r\n"))===$hashes[$key];
 }
 private static function log($message) {
  $log=get_option('dreminex_suite_log',[]);
  if (!is_array($log)) $log=[];
  array_unshift($log,['time'=>current_time('mysql'),'message'=>sanitize_text_field($message)]);
  update_option('dreminex_suite_log',array_slice($log,0,50),false);
 }
 private static function fault($key,$message) {
  $values=get_option('dreminex_suite_modules',[]); if (!is_array($values)) $values=[];
  $values[$key]=0; update_option('dreminex_suite_modules',$values,false);
  $errors=get_option('dreminex_suite_errors',[]); if (!is_array($errors)) $errors=[];
  $errors[$key]=['time'=>current_time('mysql'),'message'=>sanitize_text_field($message)];
  update_option('dreminex_suite_errors',$errors,false);
  self::log(self::$modules[$key][0].' stopped: '.$message);
 }
 public static function shutdown() {
  if (!self::$loading) return;
  $error=error_get_last();
  if ($error && in_array($error['type'],[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR],true)) self::fault(self::$loading,'PHP fatal during loading: '.$error['message']);
 }
 public static function menu() {
  add_menu_page('Dreminex Suite','Dreminex Suite','manage_options','dreminex-suite',[__CLASS__,'page'],'dashicons-admin-generic',56);
  remove_submenu_page('dreminex-suite','dreminex-suite');
  add_submenu_page('dreminex-suite','Dashboard','Dashboard','manage_options','dreminex-suite',[__CLASS__,'page']);
  add_submenu_page('dreminex-suite','All Modules','All Modules','manage_options','dreminex-suite-modules',[__CLASS__,'page']);
  add_submenu_page('dreminex-suite','Native MCP','Native MCP','manage_options','dreminex-native-mcp',[__CLASS__,'native_mcp_page']);
  if(class_exists('WooCommerce')) add_submenu_page('dreminex-suite','Supplier Monitor','Supplier Monitor',self::supplier_monitor_capability(),'dreminex-supplier-monitor',[__CLASS__,'supplier_monitor_page']);
 }
 public static function supplier_monitor_capability(){return 'dreminex_supplier_monitor_access';}
 public static function map_supplier_monitor_cap($caps,$cap,$user_id,$args){
  if($cap!==self::supplier_monitor_capability())return $caps;
  return (user_can($user_id,'manage_woocommerce')||user_can($user_id,'manage_options'))?['exist']:['do_not_allow'];
 }
 public static function reorder_submenus() {
  global $submenu;
  if (empty($submenu['dreminex-suite']) || !is_array($submenu['dreminex-suite'])) return;
  $priority=['dreminex-suite','dreminex-suite-modules','dreminex-native-mcp','dreminex-supplier-monitor','dreminex-suite-health','dreminex-suite-centre','dreminex-suite-settings'];
  $rank=array_flip($priority);$items=[];
  foreach($submenu['dreminex-suite'] as $index=>$item)$items[]=['index'=>$index,'rank'=>$rank[$item[2]]??(1000+$index),'item'=>$item];
  usort($items,static function($a,$b){return $a['rank']===$b['rank']?$a['index']<=>$b['index']:$a['rank']<=>$b['rank'];});
  $submenu['dreminex-suite']=array_column($items,'item');
 }
 public static function hide_submenu_links() {
  if (!current_user_can('manage_options')) return;
  $hidden=['dreminex-suite-modules','dreminex-suite-health','dreminex-suite-centre','dreminex-newsletter','dreminex-newsletter-settings','dreminex-offers','dreminex-contact-requests','dreminex-contact-mail-media','dreminex-suite-setup','dreminex-suite-data','dreminex-suite-imports','dreminex-suite-cache'];
  $selectors=[];
  foreach($hidden as $slug) $selectors[]='#adminmenu .wp-submenu li:has(> a[href*="page='.$slug.'"])';
  echo '<style id="dreminex-suite-hidden-submenus">'.implode(',', $selectors).'{display:none!important}</style>';
 }
 private static function hub_tabs($title,$tabs,$active) {
  echo '<div class="wrap dreminex-suite"><h1>'.esc_html($title).'</h1><nav class="nav-tab-wrapper" aria-label="'.esc_attr($title).'">';
  foreach($tabs as $key=>$tab) echo '<a class="nav-tab '.($active===$key?'nav-tab-active':'').'" href="'.esc_url(add_query_arg(['page'=>'dreminex-suite-settings','section'=>$key],admin_url('admin.php'))).'">'.esc_html($tab[0]).'</a>';
  echo '</nav></div>';
 }
 public static function settings_hub_page() {
  if(!current_user_can('manage_options'))wp_die('Access denied.',403);
  $tabs=['language'=>['Language',static function(){Dreminex_Suite_Control::settings_page();}], 'setup'=>['Store setup',static function(){Dreminex_Suite_Setup::page();}], 'backup'=>['Backup & module data',static function(){Dreminex_Suite_Data::page();}], 'imports'=>['Imported modules',static function(){Dreminex_Suite_Imports::page();}], 'cache'=>['Cache Management',static function(){Dreminex_Suite_Cache::page();}]];
  $active=isset($_GET['section'])?sanitize_key(wp_unslash($_GET['section'])):'language';if(!isset($tabs[$active]))$active='language';
  self::hub_tabs('Settings',$tabs,$active);call_user_func($tabs[$active][1]);
 }
 public static function welcome_offer_page() {
  if(!current_user_can('manage_options'))wp_die('Access denied.',403);
  echo '<div class="wrap"><h1>Welcome offers are managed in Dreminex Nexus</h1><p>Open the Nexus app and select Operations → Welcome Offers to manage future campaigns and module controls.</p></div>';return;
  $tabs=['subscribers'=>['Newsletters and subscribers','newsletter_subscribers_page'], 'settings'=>['Newsletter settings','newsletter_settings_page'], 'offers'=>['Offers','newsletter_offers_page']];
  $active=isset($_GET['section'])?sanitize_key(wp_unslash($_GET['section'])):'subscribers';
  if(isset($_GET['page'])&&sanitize_key(wp_unslash($_GET['page']))==='dreminex-newsletter-settings')$active='settings';
  if(isset($_GET['page'])&&sanitize_key(wp_unslash($_GET['page']))==='dreminex-offers')$active='offers';
  if(!isset($tabs[$active]))$active='subscribers';
  echo '<div class="wrap dreminex-suite"><h1>Welcome &amp; Offer</h1><nav class="nav-tab-wrapper" aria-label="Welcome & Offer">';
  foreach($tabs as $key=>$tab)echo '<a class="nav-tab '.($active===$key?'nav-tab-active':'').'" href="'.esc_url(add_query_arg(['page'=>'dreminex-newsletter','section'=>$key],admin_url('admin.php'))).'">'.esc_html($tab[0]).'</a>';
  echo '</nav></div>';call_user_func([__CLASS__,$tabs[$active][1]]);
 }
 public static function contact_hub_page() {
  if(!current_user_can('manage_options'))wp_die('Access denied.',403);
  echo '<div class="wrap"><h1>Contact requests are managed in Dreminex Nexus</h1><p>Open the Nexus app and select Operations → Contacts to review, reply, change status and manage request media.</p></div>';return;
  $active=(isset($_GET['section'])&&sanitize_key(wp_unslash($_GET['section']))==='media')||(!empty($_GET['page'])&&sanitize_key(wp_unslash($_GET['page']))==='dreminex-contact-mail-media')?'media':'requests';
  echo '<div class="wrap dreminex-suite"><h1>Contact Requests</h1><nav class="nav-tab-wrapper" aria-label="Contact Requests"><a class="nav-tab '.($active==='requests'?'nav-tab-active':'').'" href="'.esc_url(admin_url('admin.php?page=dreminex-contact-requests')).'">Requests</a><a class="nav-tab '.($active==='media'?'nav-tab-active':'').'" href="'.esc_url(admin_url('admin.php?page=dreminex-contact-requests&section=media')).'">Contact email media</a></nav></div>';
  if($active==='media')self::contact_media_page();else self::contact_requests_page();
 }
 public static function supplier_monitor_page() {
  self::render_managed_module_page('supplier_monitor','dreminex_supplier_monitor_page');
 }
 public static function native_mcp_page() {
  if (!current_user_can('manage_options')) wp_die('Access denied.',403);
  Dreminex_Native_MCP::page();
 }
 private static function render_managed_module_page($key,$callback) {
  $cap=$key==='supplier_monitor'?self::supplier_monitor_capability():'manage_options';
  if (!current_user_can($cap)) wp_die('You do not have permission to access this dashboard.',403);
  $module=self::$modules[$key]??null;
  if (!$module) wp_die('Unknown module.',404);
  if (self::snippet_active($module[2])) {
   echo '<div class="wrap"><h1>'.esc_html($module[0]).'</h1><div class="notice notice-warning"><p>The original Code Snippets version is active. Migrate or deactivate that snippet before opening this module dashboard.</p></div></div>';
   return;
  }
  if (!function_exists($callback)) {
   $file=DREMINEX_SUITE_PATH.'modules/'.$module[1];
   if (is_file($file)) require_once $file;
  }
  if (function_exists($callback)) call_user_func($callback);
  else wp_die('This module dashboard is unavailable. Verify the plugin files.',500);
 }
 public static function newsletter_subscribers_page(){self::render_managed_module_page('newsletter_offers','dreminex_news_admin_page');}
 public static function newsletter_settings_page(){self::render_managed_module_page('newsletter_offers','dreminex_news_settings_page');}
 public static function newsletter_offers_page(){self::render_managed_module_page('newsletter_offers','dreminex_offers_admin_page');}
 public static function contact_requests_page(){self::render_managed_module_page('contact_requests','dreminex_contact_admin_page');}
 public static function contact_media_page(){self::render_managed_module_page('contact_requests','dreminex_contact_mail_media_admin_page');}
 public static function change() {
  if (!current_user_can('manage_options')) wp_die('Access denied.');
  $key=isset($_POST['module'])?sanitize_key(wp_unslash($_POST['module'])):'';
  if (!isset(self::$modules[$key])) wp_die('Unknown module.');
  check_admin_referer('dreminex_suite_'.$key);
  if(self::app_managed_module($key))wp_die('This module is managed in Dreminex Nexus. Open the app to change its state.',403);
  $on=!empty($_POST['enable']); $migrate=!empty($_POST['migrate']); $module=self::$modules[$key]; $result='saved';
  if ($on && !class_exists('WooCommerce')) $result='woocommerce';
  elseif ($on && !is_file(DREMINEX_SUITE_PATH.'modules/'.$module[1])) $result='missing';
  elseif ($on && $key==='ai_product_publisher' && function_exists('is_plugin_active') && is_plugin_active('dreminex-ai-product-publisher/dreminex-ai-product-publisher.php')) $result='publisher_conflict';
  elseif ($on && self::snippet_active($module[2])) {
   if (!$migrate || !function_exists('\\Code_Snippets\\deactivate_snippet')) $result='conflict';
   elseif (!self::source_matches($key,$module[2])) $result='source_changed';
   else {
    \Code_Snippets\deactivate_snippet($module[2]);
    if (self::snippet_active($module[2])) $result='conflict';
    else self::log('Code Snippets #'.$module[2].' deactivated for '.$module[0].'.');
   }
  }
  if ($result==='saved') {
   $values=get_option('dreminex_suite_modules',[]); if (!is_array($values)) $values=[];
   $values[$key]=$on?1:0; update_option('dreminex_suite_modules',$values,false);
   $errors=get_option('dreminex_suite_errors',[]); if (!is_array($errors)) $errors=[];
   unset($errors[$key]); update_option('dreminex_suite_errors',$errors,false);
   self::log($module[0].($on?' enabled.':' disabled.'));
  }
  wp_safe_redirect(add_query_arg(['page'=>'dreminex-suite','module'=>$key,'result'=>$result],admin_url('admin.php'))); exit;
 }
 private static function status($key,$module,$errors) {
  if (!is_file(DREMINEX_SUITE_PATH.'modules/'.$module[1])) return 'File missing';
  if ($key==='ai_product_publisher' && function_exists('is_plugin_active') && is_plugin_active('dreminex-ai-product-publisher/dreminex-ai-product-publisher.php')) return 'Conflict: standalone publisher active';
  if (isset($errors[$key])) return 'Load error; automatically disabled';
  if (self::enabled($key) && self::snippet_active($module[2])) return 'Conflict: original snippet active; plugin module skipped';
  if (!self::enabled($key)) return self::snippet_active($module[2])?'Original Code Snippets version active; plugin module off':'Off';
  return class_exists('WooCommerce')?'On: loaded':'Waiting for WooCommerce';
 }
 public static function page() {
  if (!current_user_can('manage_options')) return;
  $route=isset($_GET['page'])?sanitize_key(wp_unslash($_GET['page'])):'dreminex-suite';
  $selected=$route==='dreminex-suite-modules'?'all':(isset($_GET['module'])?sanitize_key(wp_unslash($_GET['module'])):'summary');
  if (!in_array($selected,['summary','all'],true) && !isset(self::$modules[$selected])) $selected='summary';
  if(self::app_managed_module($selected)){echo '<div class="wrap"><h1>Managed in Dreminex Nexus</h1><p>Contact Requests, Checkout Protection and Welcome Offers are controlled from the Dreminex Nexus app. Open the matching Operations section in the app to change settings or review records.</p></div>';return;}
  if ($selected==='ai_product_publisher' && class_exists('Dreminex_Suite_AI_Product_Publisher')) {
   wp_safe_redirect(admin_url('edit.php?post_type=product&page=dreminex-ai-product-publisher'),303); exit;
  }
  $errors=get_option('dreminex_suite_errors',[]); if (!is_array($errors)) $errors=[];
  echo '<div class="wrap dreminex-suite"><header class="ds-page-header"><div><span class="ds-eyebrow">DREMINEX FASHION · CONTROL PANEL</span><h1>Dreminex Suite</h1><p>Store tools, design and operations in one place.</p></div><span class="ds-version">Version '.esc_html(DREMINEX_SUITE_VERSION).'</span></header>';
  if (isset($_GET['result'])) {
   $messages=['saved'=>'Setting saved. Refresh to confirm health.','conflict'=>'Original Code Snippets entry is still active. Migrate it or deactivate it first.','source_changed'=>'The live snippet differs from this plugin copy. Review and update the module before migrating.','woocommerce'=>'WooCommerce must be active.','missing'=>'Module file missing.','publisher_conflict'=>'Deactivate the older standalone AI Product Publisher plugin before enabling the integrated Suite module.'];
   $result=sanitize_key(wp_unslash($_GET['result']));
   if (isset($messages[$result])) echo '<div class="notice notice-'.($result==='saved'?'success':'error').'"><p>'.esc_html($messages[$result]).'</p></div>';
  }
  $saved=isset($_GET['saved'])?sanitize_key(wp_unslash($_GET['saved'])):'';
  if (in_array($saved,['settings','features','language','homepage'],true)) echo '<div class="notice notice-success"><p>'.esc_html($saved==='language'?'Language preference saved.':($saved==='homepage'?'Homepage changes saved.':'Module settings saved.')).'</p></div>';
  echo '<nav class="nav-tab-wrapper" aria-label="Suite sections"><a class="nav-tab '.($selected==='summary'?'nav-tab-active':'').'" href="'.esc_url(admin_url('admin.php?page=dreminex-suite')).'">Overview</a><a class="nav-tab '.($selected!=='summary'?'nav-tab-active':'').'" href="'.esc_url(admin_url('admin.php?page=dreminex-suite-modules')).'">Modules</a><a class="nav-tab" href="'.esc_url(admin_url('admin.php?page=dreminex-suite-centre')).'">Control center</a><a class="nav-tab" href="'.esc_url(admin_url('admin.php?page=dreminex-suite-health')).'">Site health</a><a class="nav-tab" href="'.esc_url(admin_url('admin.php?page=dreminex-suite-settings')).'">Settings</a></nav>';
  if ($selected==='summary') {
   Dreminex_Plugin_Updater::admin_card();
   $visible=array_filter(self::$modules,static fn($module,$key)=>!self::app_managed_module($key),ARRAY_FILTER_USE_BOTH);$enabled=0;$conflicts=0;
   foreach($visible as $key=>$module) {if(self::enabled($key)) $enabled++;if(self::enabled($key)&&self::snippet_active($module[2]))$conflicts++;}
   $health=Dreminex_Suite_Control::report();$critical=count(array_filter($health['findings'],static function($f){return $f['severity']==='critical';}));
   echo '<section class="ds-summary" aria-label="Suite status"><div class="ds-stat"><span>Modules on</span><strong>'.esc_html($enabled).' <small>/ '.esc_html(count($visible)).'</small></strong><a href="'.esc_url(admin_url('admin.php?page=dreminex-suite-modules')).'">Manage modules →</a></div><div class="ds-stat"><span>WooCommerce</span><strong class="ds-stat-word">'.(class_exists('WooCommerce')?'Available':'Missing').'</strong><a href="'.esc_url(admin_url('admin.php?page=dreminex-suite-health')).'">Check health →</a></div><div class="ds-stat"><span>Items to review</span><strong>'.esc_html($conflicts+count($errors)+$critical).'</strong><small>'.esc_html($conflicts).' loader conflicts · '.esc_html(count($errors)).' load errors · '.esc_html($critical).' critical findings</small></div></section>';
   echo '<section class="ds-workspace"><div class="ds-section-head"><div><h2>Workspace</h2><p>Choose what you want to manage.</p></div></div><div class="ds-shortcuts"><a href="'.esc_url(admin_url('admin.php?page=dreminex-suite&module=storefront_design')).'"><strong>Storefront design</strong><span>Homepage banners, motion and product display</span><b aria-hidden="true">→</b></a><a href="'.esc_url(admin_url('admin.php?page=dreminex-suite-modules')).'"><strong>All modules</strong><span>Find a feature and change its settings</span><b aria-hidden="true">→</b></a><a href="'.esc_url(admin_url('admin.php?page=dreminex-suite-centre')).'"><strong>Control center</strong><span>Module placement and setup</span><b aria-hidden="true">→</b></a><a href="'.esc_url(admin_url('admin.php?page=dreminex-suite-settings')).'"><strong>Settings &amp; backup</strong><span>Language, data and cache controls</span><b aria-hidden="true">→</b></a></div></section>';
   echo '<details class="ds-activity"><summary>Recent changes <span>Show activity</span></summary><ol>';
   foreach(array_slice((array)get_option('dreminex_suite_log',[]),0,20) as $event) echo '<li>'.esc_html(($event['time']??'').' - '.($event['message']??'')).'</li>';
   echo '</ol><p class="description">Health checks have limited coverage; confirm each feature in staging before release.</p></details>';
  } elseif ($selected==='all') {
   $visible=array_filter(self::$modules,static fn($module,$key)=>!self::app_managed_module($key),ARRAY_FILTER_USE_BOTH);echo '<div class="ds-section-head"><div><h2>All modules</h2><p>Browse '.esc_html(count($visible)).' features and open their controls.</p></div></div><div class="ds-module-tools"><label for="ds-module-search">Search modules<input type="search" id="ds-module-search" placeholder="Search by name or purpose" autocomplete="off"></label><label for="ds-module-filter">Status<select id="ds-module-filter"><option value="all">All statuses</option><option value="on">On</option><option value="off">Off</option></select></label><span id="ds-module-count" aria-live="polite"></span></div><div class="grid ds-module-grid">';
   $groups=[];foreach($visible as $key=>$module)$groups[$module[3]][$key]=$module;
   foreach($groups as $group=>$items){
    echo '<div class="ds-module-group-title" data-ds-group="'.esc_attr($group).'"><h2>'.esc_html($group).'</h2><span>'.esc_html(count($items)).' modules</span></div>';
    foreach($items as $key=>$module){
     $is_on=self::enabled($key);
     $module_url=$key==='ai_product_publisher'?admin_url('edit.php?post_type=product&page=dreminex-ai-product-publisher'):($key==='native_mcp'?admin_url('admin.php?page=dreminex-native-mcp'):add_query_arg(['page'=>'dreminex-suite','module'=>$key],admin_url('admin.php')));
     echo '<article class="card ds-module-card" data-ds-group="'.esc_attr($group).'" data-ds-status="'.($is_on?'on':'off').'" data-ds-search="'.esc_attr($key.' '.$module[0].' '.$module[4]).'"><div class="ds-module-card-top"><span class="ds-module-group-label">'.esc_html($group).'</span><span class="ds-state '.($is_on?'is-on':'is-off').'">'.($is_on?'On':'Off').'</span></div><h3>'.esc_html(Dreminex_Suite_Control::module_label($key,$module[0])).'</h3><p>'.esc_html(Dreminex_Suite_Control::module_summary($key,$module[4])).'</p><p class="ds-module-status"><strong>'.esc_html(self::status($key,$module,$errors)).'</strong></p><a href="'.esc_url($module_url).'" aria-label="Configure '.esc_attr($module[0]).'">Open controls <span aria-hidden="true">→</span></a></article>';
    }
   }
   echo '</div><p class="ds-module-empty" hidden>No modules match your search.</p>';
  } else {
   $module=self::$modules[$selected];$active=self::enabled($selected);
   $revisions=get_option('dreminex_suite_file_revisions',[]);
   $revision=is_array($revisions)&&isset($revisions[$selected])?substr($revisions[$selected],0,12):'unknown';
   echo '<div class="ds-breadcrumb"><a href="'.esc_url(admin_url('admin.php?page=dreminex-suite-modules')).'">← All modules</a><span aria-hidden="true">/</span>'.esc_html($module[3]).'</div>';
   echo '<section class="card ds-module-overview"><div class="ds-module-overview-head"><div><span class="ds-eyebrow">'.esc_html($module[3]).'</span><h2>'.esc_html(Dreminex_Suite_Control::module_label($selected,$module[0])).'</h2><p>'.esc_html(Dreminex_Suite_Control::module_summary($selected,$module[4])).'</p></div><span class="ds-state '.($active?'is-on':'is-off').'">'.($active?'On':'Off').'</span></div><p class="ds-current-status"><strong>Current status:</strong> '.esc_html(self::status($selected,$module,$errors)).'</p>';
   if (isset($errors[$selected])) echo '<p><strong>Last loading error:</strong> '.esc_html($errors[$selected]['time'].' - '.$errors[$selected]['message']).'</p>';
   self::form($selected,$active?'Turn off module':'Turn on module',!$active,false);
   if (!$active && self::snippet_active($module[2])) {echo '<p>The original snippet is currently running. Migration disables it and enables the plugin module for the next request.</p>';self::form($selected,'Migrate from Code Snippets',true,true);}
   echo '<details class="ds-technical"><summary>Technical details</summary><p>File: <code>'.esc_html($module[1]).'</code> · Source revision: <code>'.esc_html($revision).'</code> · Previous snippet ID: '.esc_html($module[2]).'</p></details></section>';
   echo '<section class="ds-module-settings"><div class="ds-section-head"><div><h2>Controls &amp; setup</h2><p>'.esc_html(Dreminex_Suite_Control::module_instructions($selected,self::instructions($selected))).'</p></div></div>';
   do_action('dreminex_suite_module_panel',$selected);
   $dashboard_available=$active||in_array($selected,['newsletter_offers','contact_requests','flash_sale','supplier_monitor','native_mcp'],true);
   if ($dashboard_available && !empty($module[5])) { $feature_url=strpos($module[5],'edit.php')===0?admin_url($module[5]):admin_url('admin.php?page='.$module[5]); echo '<p><a class="button" href="'.esc_url($feature_url).'">Open feature dashboard</a></p>'; }
   echo '<p class="description">Switching off keeps existing orders, subscribers, coupons and contact records.</p></section>';
  }
  echo '</div>';
 }
 public static function extended_module_panel($key) {
  if ($key==='registration_email') {
   self::registration_panel();
  } elseif ($key==='delivery_advance') {
   self::wallet_panel();
  }
 }
 private static function wallet_panel() {
  if(!class_exists('Dreminex_Nexus_Operations')||!class_exists('Dreminex_Customer_Wallet'))return;
  $data=Dreminex_Nexus_Operations::wallet_dashboard();$b=(array)($data['balances']??[]);$c=(array)($data['counts']??[]);
  echo '<section class="ds-wallet-panel"><div class="ds-section-head"><div><span class="ds-eyebrow">DELIVERY ADVANCE &amp; WALLET</span><h3>Wallet operations</h3><p>Cash, promotional credit, reservations and requests stay separate in the ledger.</p></div></div><div class="ds-summary">';
  foreach(['wallet_customers'=>'Wallet customers','promo_spending_customers'=>'Customers using offer credit','active_promo_customers'=>'Customers with active offer credit','active_cash_customers'=>'Customers with cash balance'] as $key=>$label)echo '<div class="ds-stat"><span>'.esc_html($label).'</span><strong>'.esc_html((int)($c[$key]??0)).'</strong></div>';
  echo '</div><div class="ds-summary">';
  foreach(['promo'=>'Active promotional balance','cash'=>'Customer-added cash','reserved'=>'Reserved balance','withdrawable'=>'Withdrawable cash'] as $key=>$label)echo '<div class="ds-stat"><span>'.esc_html($label).'</span><strong>'.wp_kses_post(wc_price((float)($b[$key]??0))).'</strong></div>';
  echo '</div><details class="ds-collapsible" open><summary>Review queues <span>Top-ups and withdrawals</span></summary><div class="ds-wallet-queues"><article class="card"><h4>Top-up review queue</h4><strong>'.esc_html((int)($c['pending_topups']??0)).'</strong><p>Verify the provider transaction before crediting customer cash.</p></article><article class="card"><h4>Withdrawal queue</h4><strong>'.esc_html((int)($c['pending_withdrawals']??0)).'</strong><p>Only settled customer-added cash can be approved and paid.</p></article></div></details>';
  if(!empty($data['customers'])){echo '<details class="ds-collapsible"><summary>Recent customer balances <span>Show ledger summary</span></summary><div class="table-responsive"><table class="widefat striped"><thead><tr><th>Customer</th><th>Cash</th><th>Promotional</th><th>Reserved</th><th>Available total</th></tr></thead><tbody>';foreach(array_slice($data['customers'],0,20) as $customer)echo '<tr><td><strong>'.esc_html($customer['name']).'</strong><br><small>'.esc_html($customer['email']).'</small></td><td>'.wp_kses_post(wc_price((float)$customer['cash'])).'</td><td>'.wp_kses_post(wc_price((float)$customer['promo'])).'</td><td>'.wp_kses_post(wc_price((float)$customer['reserved'])).'</td><td><strong>'.wp_kses_post(wc_price((float)$customer['total'])).'</strong></td></tr>';echo '</tbody></table></div></details>';}
  echo '<p class="description">Use Dreminex Nexus for request review and status changes. Promotional credit cannot be withdrawn and expires automatically.</p></section>';
 }
 private static function registration_panel() {
  $groups=[
   'Module features'=>[
    'registration_core_enabled'=>['Account pages, registration and email confirmation',1,'Keeps the full WooCommerce account experience.'],
    'password_reset_enabled'=>['Cross-account password recovery',1,'Allows a verified reset link while another customer is signed in.'],
   ],
   'Account flow'=>[
    'enable_registration'=>['Enable customer registration',1,'Show the native WooCommerce registration form.'],
    'email_confirmation'=>['Send confirmation email',1,'Send a 48-hour verification link after registration.'],
    'choose_password'=>['Customer chooses a password',1,'Otherwise WooCommerce generates a password.'],
    'password_confirm'=>['Confirm password field',1,'Shown when customers choose a password.'],
   ],
   'Customer details'=>[
    'show_first_name'=>['Show first name',1,''],
    'require_first_name'=>['Require first name',1,'Ignored when hidden.'],
    'show_last_name'=>['Show last name',1,''],
    'require_last_name'=>['Require last name',1,'Ignored when hidden.'],
    'show_phone'=>['Show mobile number',1,'Bangladesh format.'],
    'require_phone'=>['Require mobile number',0,'Optional by default.'],
   ],
   'Experience'=>[
    'design_enabled'=>['Design the sign-in and registration page',1,'Only affects the logged-out My Account page.'],
    'show_password_toggle'=>['Show password visibility controls',1,'Customers can check what they typed.'],
   ],
   'Signed-in account'=>[
    'dashboard_enabled'=>['Style the signed-in account pages',1,'Dashboard, navigation, orders, downloads, addresses and profile. WooCommerce keeps all account functions.'],
    'empty_state_art'=>['Show the empty orders illustration',1,'A light visual when a customer has no orders.'],
   ],
  ];
  $s=static function($name,$default){return Dreminex_Suite_Control::setting('registration_email',$name,$default);};
  $account_url=function_exists('wc_get_page_permalink')?wc_get_page_permalink('myaccount'):'';
  echo '<div class="ds-registration-panel"><div class="ds-registration-head"><div><span class="ds-eyebrow">ACCOUNTS</span><h3>Account experience</h3><p>Shape the signed-in dashboard, customer form and confirmation email. WooCommerce keeps order data, account security and native endpoints.</p></div>';
  if($account_url)echo '<a class="button" href="'.esc_url($account_url).'" target="_blank" rel="noopener">Open My Account ↗</a>';
  echo '</div><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_suite_module_settings"><input type="hidden" name="module" value="registration_email">';
  wp_nonce_field('dreminex_suite_module_settings_registration_email');
  foreach($groups as $title=>$fields){
   echo '<fieldset class="ds-registration-group"><legend>'.esc_html($title).'</legend><div class="ds-registration-switches">';
   foreach($fields as $name=>$field){echo '<label class="ds-registration-switch" for="ds-registration-'.esc_attr($name).'"><input id="ds-registration-'.esc_attr($name).'" type="checkbox" name="settings['.esc_attr($name).']" value="1" '.checked($s($name,$field[1]),1,false).'><span><strong>'.esc_html($field[0]).'</strong>'.($field[2]!==''?'<small>'.esc_html($field[2]).'</small>':'').'</span></label>';}
   echo '</div></fieldset>';
  }
  echo '<fieldset class="ds-registration-group"><legend>Page content &amp; appearance</legend><div class="ds-registration-fields">';
  foreach([
   'hero_title'=>['Intro heading','Your style, your account',90],
   'hero_text'=>['Intro description','Keep your orders, addresses and account details together.',240],
  ] as $name=>$field){
   echo '<label for="ds-registration-'.esc_attr($name).'"><span>'.esc_html($field[0]).'</span><input class="regular-text" id="ds-registration-'.esc_attr($name).'" name="settings['.esc_attr($name).']" value="'.esc_attr($s($name,$field[1])).'" maxlength="'.(int)$field[2].'" required></label>';
  }
  $image_id=absint($s('hero_image_id',0));$thumb=$image_id?wp_get_attachment_image($image_id,'thumbnail'):null;
  echo '<div class="ds-registration-media" data-ds-media-field><label for="ds-registration-hero_image_id">Editorial image <small>Optional; choose a photo from this site.</small></label><div class="ds-registration-media-row"><input id="ds-registration-hero_image_id" type="number" min="0" name="settings[hero_image_id]" value="'.esc_attr($image_id).'" placeholder="Media ID"><button class="button" type="button" data-ds-media-choose>Choose image</button><button class="button" type="button" data-ds-media-clear>Clear</button></div><div class="ds-registration-media-preview" data-ds-media-preview>'.($thumb?wp_kses_post($thumb):'<span>No image selected</span>').'</div></div>';
  echo '<label for="ds-registration-hero_position"><span>Image focus</span><select id="ds-registration-hero_position" name="settings[hero_position]">';
  foreach(['center'=>'Centre','left'=>'Left','right'=>'Right','top'=>'Top'] as $value=>$label)echo '<option value="'.esc_attr($value).'" '.selected($s('hero_position','center'),$value,false).'>'.esc_html($label).'</option>';
  echo '</select></label>';
  foreach(['button_color'=>['Button background','#007D96'],'button_text_color'=>['Button text','#FFFFFF']] as $name=>$field)echo '<label for="ds-registration-'.esc_attr($name).'"><span>'.esc_html($field[0]).'</span><input id="ds-registration-'.esc_attr($name).'" type="color" name="settings['.esc_attr($name).']" value="'.esc_attr($s($name,$field[1])).'"></label>';
  echo '</div><p class="description">The button colour pair must meet readable text contrast. Without an image, the branded colour panel remains complete.</p></fieldset>';
  echo '<fieldset class="ds-registration-group"><legend>Signed-in dashboard</legend><div class="ds-registration-fields">';
  foreach([
   'dashboard_heading'=>['Dashboard heading','Your Dreminex space',90],
   'dashboard_text'=>['Dashboard description','Your orders, delivery details and profile, all in one easy place.',240],
  ] as $name=>$field){
   echo '<label for="ds-registration-'.esc_attr($name).'"><span>'.esc_html($field[0]).'</span><input class="regular-text" id="ds-registration-'.esc_attr($name).'" name="settings['.esc_attr($name).']" value="'.esc_attr($s($name,$field[1])).'" maxlength="'.(int)$field[2].'" required></label>';
  }
  echo '</div><p class="description">The welcome name comes from each customer account. Orders, addresses and profile shortcuts use WooCommerce links. The button colours above also style the signed-in action.</p></fieldset>';
  echo '<fieldset class="ds-registration-group"><legend>Account page descriptions</legend><div class="ds-registration-fields">';
  foreach([
   'orders_intro'=>['Orders','See current status and revisit past purchases.',160],
   'downloads_intro'=>['Downloads','Your available digital files will appear here.',160],
   'addresses_intro'=>['Addresses','Keep your billing and delivery details up to date.',160],
   'profile_intro'=>['Account details','Update your name, email address and password.',160],
  ] as $name=>$field){
   echo '<label for="ds-registration-'.esc_attr($name).'"><span>'.esc_html($field[0]).' description</span><input class="regular-text" id="ds-registration-'.esc_attr($name).'" name="settings['.esc_attr($name).']" value="'.esc_attr($s($name,$field[1])).'" maxlength="'.(int)$field[2].'" required></label>';
  }
  echo '</div><p class="description">These introductions appear above the native WooCommerce content. Order status, downloadable files, saved addresses and account changes still come from WooCommerce.</p></fieldset>';
  echo '<fieldset class="ds-registration-group"><legend>Confirmation email</legend><div class="ds-registration-fields">';
  foreach([
   'email_subject'=>['Subject','Confirm your Dreminex Fashion email',120],
   'email_intro'=>['Intro text','Welcome to Dreminex Fashion. Please confirm your email address.',300],
   'email_button'=>['Link label','Confirm my email',60],
  ] as $name=>$field)echo '<label for="ds-registration-'.esc_attr($name).'"><span>'.esc_html($field[0]).'</span><input class="regular-text" id="ds-registration-'.esc_attr($name).'" name="settings['.esc_attr($name).']" value="'.esc_attr($s($name,$field[1])).'" maxlength="'.(int)$field[2].'" required></label>';
  echo '</div><p class="description">The verification link and 48-hour expiry are managed by the module. Popup messages can be edited in Module settings below.</p></fieldset>';
  echo '<div class="ds-registration-save">';submit_button('Save account experience','primary','submit',false);echo '</div></form></div>';
 }
 private static function registration_contrast($a,$b) {
  $light=static function($hex){$channels=[];foreach([1,3,5] as $pos){$v=hexdec(substr($hex,$pos,2))/255;$channels[]=$v<=.04045?$v/12.92:pow(($v+.055)/1.055,2.4);}return .2126*$channels[0]+.7152*$channels[1]+.0722*$channels[2];};
  $x=$light($a);$y=$light($b);return (max($x,$y)+.05)/(min($x,$y)+.05);
 }
 public static function save_module_settings() {
  if (!current_user_can('manage_options')) wp_die('Access denied.',403);
  $key=isset($_POST['module'])?sanitize_key(wp_unslash($_POST['module'])):'';
  if ($key!=='registration_email') wp_die('Unknown module settings.',400);
  check_admin_referer('dreminex_suite_module_settings_'.$key);
  $all=get_option('dreminex_suite_module_settings',[]);if(!is_array($all))$all=[];
  $input=isset($_POST['settings'])&&is_array($_POST['settings'])?wp_unslash($_POST['settings']):[];
  if($key==='registration_email'){
   foreach(['registration_core_enabled','password_reset_enabled','enable_registration','email_confirmation','choose_password','password_confirm','show_first_name','require_first_name','show_last_name','require_last_name','show_phone','require_phone','design_enabled','show_password_toggle','dashboard_enabled','empty_state_art'] as $name)$all[$key][$name]=!empty($input[$name])?1:0;
   foreach(['hero_title'=>90,'hero_text'=>240,'dashboard_heading'=>90,'dashboard_text'=>240,'orders_intro'=>160,'downloads_intro'=>160,'addresses_intro'=>160,'profile_intro'=>160,'email_subject'=>120,'email_intro'=>300,'email_button'=>60] as $name=>$limit){
    $value=isset($input[$name])&&is_scalar($input[$name])?sanitize_text_field($input[$name]):'';
    $length=function_exists('mb_strlen')?mb_strlen($value):strlen($value);
    if($value===''||$length>$limit)wp_die('Complete the registration text fields within their character limits.',400);
    $all[$key][$name]=$value;
   }
   $image_id=absint($input['hero_image_id']??0);
   if($image_id&&!wp_attachment_is_image($image_id))wp_die('Choose an image from this site’s Media Library.',400);
   $all[$key]['hero_image_id']=$image_id;
   $position=sanitize_key($input['hero_position']??'center');
   $all[$key]['hero_position']=in_array($position,['center','left','right','top'],true)?$position:'center';
   $background=sanitize_hex_color($input['button_color']??'');
   $foreground=sanitize_hex_color($input['button_text_color']??'');
   if(!$background||!$foreground||self::registration_contrast($background,$foreground)<4.5)wp_die('Button background and text need a contrast ratio of at least 4.5:1. Choose a darker background or darker text.',400);
   $all[$key]['button_color']=$background;$all[$key]['button_text_color']=$foreground;
  }
  update_option('dreminex_suite_module_settings',$all,false);
  Dreminex_Suite_Cache::changed($key,true);
  wp_safe_redirect(add_query_arg(['page'=>'dreminex-suite','module'=>$key,'saved'=>'settings'],admin_url('admin.php')),303);exit;
 }
 private static function instructions($key) {
  $guides=['advanced_optimizations'=>'Enabled module PHP files are already loaded selectively. This module does not defer arbitrary third-party scripts. Do not enable aggressive asset removal: several existing features use inline hooks rather than registered asset handles. Reassess after module scripts/styles are registered with explicit page conditions.','delivery_advance'=>'Configure delivery advance, full payment and the customer wallet. Verify external transfers before confirmation; offer credit is purchase-only and expiring. COD appears only for products explicitly marked COD-only.','checkout_protection'=>'Choose each protection feature, set cooldown, browser threshold, retention and receipt privacy, then test allowed and rejected staging orders.','checkout_experience'=>'Place a staging order and trigger validation errors with mouse, keyboard and mobile to verify both customer messages.','order_management'=>'Use a test order to verify history, admin alert, owner email, workflow status and courier tracking independently.','phone_validation'=>'Enable only when WooCommerce checkout is active. Test valid and invalid Bangladesh numbers on staging and confirm the checkout error is visible.','duplicate_checkout'=>'Blocks repeat checkout from the same IP while a recent order is pending/on-hold. Review with shared networks and proxies in mind.','receipt_message'=>'Place a test order and verify the message on the order-received page.','receipt_ip_warning'=>'Review privacy disclosures before displaying visitor IP addresses. Verify order receipt and the [show_ip] shortcode.','customer_history'=>'Review WooCommerce Orders columns. History is this store only and matches billing phone numbers.','partial_checkout'=>'Verify consent copy, retention and privacy policy. Test opt-in and opt-out separately.','admin_order_alert'=>'Review the WordPress dashboard widget and dismiss/read behavior.','order_email_notification'=>'Verify the recipient address and SMTP delivery using a test order; inspect mail logs on failure.','order_statuses'=>'Check custom status labels and bulk actions on a test order before production use.','customer_order_limit'=>'Test browser cookie behavior and shared-device edge cases; this is not durable device identification.','checkout_error_popup'=>'Trigger a validation error on staging and confirm keyboard and mobile behavior.','order_tracking'=>'Enter a real courier reference and verify the customer tracking page and email.','newsletter_offers'=>'Review opt-in, confirmation, coupon rules, expiry and test email delivery.','contact_requests'=>'Test form submission, private attachment access, retention and reply email.','password_reset'=>'Test with a disposable account and valid/invalid reset links; never share reset links.','registration_email'=>'Register a disposable account, review name/mobile/password fields, verify the confirmation email and test the native lost-password link. The module controls My Account registration while enabled.',
   'store_email_branding'=>'Choose the store email logo and brand colors, then review each native WooCommerce email in the preview before sending customer messages.',
   'storefront_design'=>'Use Storefront controls for product and customer pages, and Homepage studio for banners, text, links and motion. Verify the relevant pages after saving.'];
  return isset($guides[$key])?$guides[$key]:'Review prerequisites and test on staging before enabling for customers.';
 }
 private static function form($key,$label,$enable,$migrate) {
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_suite_change"><input type="hidden" name="module" value="'.esc_attr($key).'"><input type="hidden" name="enable" value="'.($enable?'1':'0').'"><input type="hidden" name="migrate" value="'.($migrate?'1':'0').'">';
  echo str_replace(' id="_wpnonce"', '', wp_nonce_field('dreminex_suite_'.$key,'_wpnonce',true,false));
  submit_button($label,$migrate?'primary':'secondary',$migrate?'ds_migrate_'.$key:'ds_toggle_'.$key,false);
  echo '</form>';
 }
}
