<?php
if (!defined('ABSPATH')) exit;

/** Shared app-first services used by Nexus REST and Native MCP abilities. */
final class Dreminex_Nexus_App {
 const SCHEMA=2;
 const NOTIFICATION_DAYS=7;
 const VIEW_DAYS=30;
 private static function table($suffix){global $wpdb;return $wpdb->prefix.'dreminex_app_'.$suffix;}
 private static function now(){return current_time('mysql',true);}

 public static function boot(){
  if(!class_exists('WooCommerce')||!Dreminex_Native_MCP::enabled())return;
  self::install();
  add_action('rest_api_init',[__CLASS__,'routes'],40);
  add_action('wp_abilities_api_categories_init',[__CLASS__,'ability_category']);
  add_action('wp_abilities_api_init',[__CLASS__,'abilities'],45);
  add_action('wp_footer',[__CLASS__,'view_beacon'],99);
  add_action('woocommerce_new_product',static fn($id)=>self::notify('products','product_created','Product added','A new product was added to the catalog.',['product_id'=>(int)$id],'product-created-'.(int)$id));
  add_action('woocommerce_new_order',static fn($id)=>self::notify('orders','order_created','New order','A customer placed a new order.',['order_id'=>(int)$id],'order-created-'.(int)$id));
  add_action('woocommerce_order_status_changed',[__CLASS__,'order_status_notification'],10,4);
  add_action('transition_post_status',[__CLASS__,'status_notification'],10,3);
  add_action('dreminex_security_event_recorded',[__CLASS__,'security_event_notification'],10,1);
  add_action('dreminex_nexus_cleanup',[__CLASS__,'cleanup']);
  if(!wp_next_scheduled('dreminex_nexus_cleanup'))wp_schedule_event(time()+HOUR_IN_SECONDS,'daily','dreminex_nexus_cleanup');
 }

 public static function order_status_notification($order_id,$from,$to,$order=null){
  if(!$order instanceof WC_Order&&function_exists('wc_get_order'))$order=wc_get_order($order_id);if(!$order instanceof WC_Order||$from===$to)return;
  self::notify('orders','order_status_changed','Order status changed','Order #'.$order->get_order_number().' moved from '.$from.' to '.$to,['order_id'=>(int)$order_id,'from_status'=>sanitize_key($from),'to_status'=>sanitize_key($to)],'order-status-'.(int)$order_id.'-'.sanitize_key($to).'-'.($order->get_date_modified()?$order->get_date_modified()->getTimestamp():time()));
 }

 public static function install(){
  $installed=(int)get_option('dreminex_app_schema',0);if($installed>=self::SCHEMA)return;
  require_once ABSPATH.'wp-admin/includes/upgrade.php';global $wpdb;$c=$wpdb->get_charset_collate();$p=$wpdb->prefix.'dreminex_app_';
  dbDelta("CREATE TABLE {$p}notifications (
   id bigint unsigned NOT NULL AUTO_INCREMENT, user_id bigint unsigned NOT NULL DEFAULT 0,
   category varchar(32) NOT NULL, event_type varchar(64) NOT NULL, title varchar(191) NOT NULL,
   message text NOT NULL, payload_json text NOT NULL, event_key varchar(191) NOT NULL,
   is_read tinyint(1) NOT NULL DEFAULT 0, created_at datetime NOT NULL, expires_at datetime NOT NULL,
   PRIMARY KEY (id), UNIQUE KEY event_key (event_key), KEY user_created (user_id,created_at), KEY expires_at (expires_at)
  ) {$c};");
  dbDelta("CREATE TABLE {$p}views (
   product_id bigint unsigned NOT NULL, view_date date NOT NULL, views bigint unsigned NOT NULL DEFAULT 0,
   PRIMARY KEY (product_id,view_date), KEY view_date (view_date)
  ) {$c};");
  dbDelta("CREATE TABLE {$p}push_devices (
   device_id char(36) NOT NULL, user_id bigint unsigned NOT NULL, push_token text NOT NULL,
   enabled tinyint(1) NOT NULL DEFAULT 1, updated_at datetime NOT NULL,
   PRIMARY KEY (device_id), KEY user_id (user_id), KEY enabled (enabled)
  ) {$c};");
  if($installed<2){
   $notifications=self::table('notifications');
   $wpdb->query($wpdb->prepare("UPDATE {$notifications} SET category=%s WHERE category=%s",'security','action_center'));
   // Search only the route token so both escaped and unescaped JSON slashes match.
   $legacy_route='%'.$wpdb->esc_like('action-center').'%';
   $legacy=$wpdb->get_results($wpdb->prepare("SELECT id,payload_json FROM {$notifications} WHERE category=%s AND payload_json LIKE %s",'security',$legacy_route),ARRAY_A);
   foreach((array)$legacy as $row){$payload=json_decode((string)($row['payload_json']??''),true);if(!is_array($payload)||($payload['screen']??'')!=='operations/action-center')continue;$payload['screen']='security';$wpdb->update($notifications,['payload_json'=>wp_json_encode($payload)],['id'=>(int)$row['id']],['%s'],['%d']);}
  }
  update_option('dreminex_app_schema',self::SCHEMA,false);
 }

 public static function routes(){
  register_rest_route('dreminex/v1','/nexus/catalog/products',['methods'=>'GET','permission_callback'=>static fn($r)=>self::auth($r,['catalog:read'],'catalog'),'callback'=>[__CLASS__,'rest_products']]);
  register_rest_route('dreminex/v1','/nexus/catalog/categories',['methods'=>'GET','permission_callback'=>static fn($r)=>self::auth($r,['catalog:read'],'catalog'),'callback'=>[__CLASS__,'rest_categories']]);
  register_rest_route('dreminex/v1','/nexus/catalog/products/(?P<product_id>\d+)',['methods'=>['GET','PUT'],'permission_callback'=>static fn($r)=>self::auth($r,[$r->get_method()==='GET'?'catalog:read':'catalog:write'],'catalog'),'callback'=>[__CLASS__,'rest_product']]);
  register_rest_route('dreminex/v1','/nexus/catalog/products/(?P<product_id>\d+)/cod-policy',['methods'=>'POST','permission_callback'=>static fn($r)=>self::auth($r,['catalog:write'],'catalog'),'callback'=>[__CLASS__,'rest_cod_policy']]);
  register_rest_route('dreminex/v1','/nexus/catalog/products/(?P<product_id>\d+)/transition',['methods'=>'POST','permission_callback'=>static fn($r)=>self::auth($r,['catalog:write'],'catalog'),'callback'=>[__CLASS__,'rest_transition']]);
  register_rest_route('dreminex/v1','/nexus/catalog/products/bulk-transition',['methods'=>'POST','permission_callback'=>static fn($r)=>self::auth($r,['catalog:write'],'catalog'),'callback'=>[__CLASS__,'rest_bulk_transition']]);
  register_rest_route('dreminex/v1','/nexus/catalog/products/(?P<product_id>\d+)/supplier',['methods'=>WP_REST_Server::EDITABLE,'permission_callback'=>static fn($r)=>self::auth($r,['suppliers:write'],'supplier_monitor'),'callback'=>[__CLASS__,'rest_supplier']]);
  register_rest_route('dreminex/v1','/nexus/supplier-schedule',['methods'=>['GET','PUT'],'permission_callback'=>static fn($r)=>self::auth($r,[$r->get_method()==='GET'?'suppliers:read':'suppliers:write'],'supplier_monitor'),'callback'=>[__CLASS__,'rest_supplier_schedule']]);
  register_rest_route('dreminex/v1','/nexus/projects',['methods'=>'GET','permission_callback'=>static fn($r)=>self::auth($r,['workflow:read'],'projects'),'callback'=>[__CLASS__,'rest_projects']]);
  register_rest_route('dreminex/v1','/nexus/projects/(?P<profile>preparation|publisher)/sources/(?P<filename>[A-Za-z0-9._-]+)',['methods'=>['GET','PUT','DELETE'],'permission_callback'=>static fn($r)=>self::auth($r,[$r->get_method()==='GET'?'workflow:read':'workflow:write'],'projects'),'callback'=>[__CLASS__,'rest_project_source']]);
  register_rest_route('dreminex/v1','/nexus/projects/(?P<profile>preparation|publisher)/actions',['methods'=>'POST','permission_callback'=>static fn($r)=>self::auth($r,['workflow:write'],'projects'),'callback'=>[__CLASS__,'rest_project_action']]);
  register_rest_route('dreminex/v1','/nexus/publisher/settings',['methods'=>['GET','PUT'],'permission_callback'=>static fn($r)=>self::auth($r,[$r->get_method()==='GET'?'settings:read':'settings:write']),'callback'=>[__CLASS__,'rest_publisher_settings']]);
  // Keep this authenticated read-only route for already-installed Nexus builds.
  // New clients consume the same summary from /nexus/security.
  register_rest_route('dreminex/v1','/nexus/action-center',['methods'=>'GET','permission_callback'=>static fn($r)=>self::auth($r,['operations:read']),'callback'=>[__CLASS__,'rest_action_center']]);
  register_rest_route('dreminex/v1','/nexus/security',['methods'=>['GET','PUT'],'permission_callback'=>static fn($r)=>self::auth($r,[$r->get_method()==='GET'?'settings:read':'settings:write']),'callback'=>[__CLASS__,'rest_security']]);
  register_rest_route('dreminex/v1','/nexus/app-release',['methods'=>'GET','permission_callback'=>static fn($r)=>self::auth($r,['settings:read']),'callback'=>[__CLASS__,'rest_app_release']]);
  register_rest_route('dreminex/v1','/nexus/app-capabilities',['methods'=>['GET','PUT'],'permission_callback'=>static fn($r)=>self::auth($r,[$r->get_method()==='GET'?'settings:read':'settings:write']),'callback'=>[__CLASS__,'rest_app_capabilities']]);
  register_rest_route('dreminex/v1','/nexus/notifications',['methods'=>'GET','permission_callback'=>static fn($r)=>self::auth($r,['notifications:read']),'callback'=>[__CLASS__,'rest_notifications']]);
  register_rest_route('dreminex/v1','/nexus/notifications/(?P<notification_id>\d+)',['methods'=>['POST','DELETE'],'permission_callback'=>static fn($r)=>self::auth($r,[$r->get_method()==='DELETE'?'notifications:write':'notifications:write']),'callback'=>[__CLASS__,'rest_notification']]);
  register_rest_route('dreminex/v1','/nexus/device/push-token',['methods'=>'POST','permission_callback'=>static fn($r)=>self::auth($r,['devices:write']),'callback'=>[__CLASS__,'rest_push_token']]);
  register_rest_route('dreminex/v1','/metrics/product-view',['methods'=>'POST','permission_callback'=>'__return_true','callback'=>[__CLASS__,'record_view']]);
 }

 private static function auth($request,$scopes,$feature=''){ $ok=Dreminex_Supplier_Nexus::authorize_device($request,$scopes);if(is_wp_error($ok)||$feature===''||Dreminex_Native_MCP::app_feature_enabled($feature))return $ok;return new WP_Error('app_feature_disabled','This capability is disabled for this site.',['status'=>403,'feature'=>$feature]);}
 private static function input($request){$data=$request->get_json_params();return is_array($data)?$data:[];}
 private static function site_id(){return hash('sha256',home_url('/'));}

 public static function ability_category(){if(function_exists('wp_register_ability_category'))wp_register_ability_category('dreminex-operations',['label'=>'Dreminex App Operations','description'=>'Read Nexus catalog, performance, notifications, security and integrated store operations summaries.']);}
 public static function abilities(){
  if(!function_exists('wp_register_ability'))return;
  $read=['category'=>'dreminex-operations','output_schema'=>['type'=>'object','additionalProperties'=>true],'permission_callback'=>static fn()=>current_user_can('manage_woocommerce'),'annotations'=>['readonly'=>true,'destructive'=>false,'idempotent'=>true],'meta'=>['annotations'=>['readonly'=>true,'destructive'=>false,'idempotent'=>true],'mcp'=>['public'=>true]]];
  wp_register_ability('dreminex-products/catalog-page',$read+['label'=>'Read product catalog page','description'=>'Read one filtered Draft/Published or Trash catalog page with categories, badges, supplier scan state and performance.','input_schema'=>self::catalog_schema(),'execute_callback'=>static fn($i)=>self::catalog((array)$i)]);
  wp_register_ability('dreminex-products/product-detail',$read+['label'=>'Read product app detail','description'=>'Read one product detail with gallery, supplier, performance, reviews and lifecycle revision.','input_schema'=>['type'=>'object','properties'=>['product_id'=>['type'=>'integer','minimum'=>1]],'required'=>['product_id'],'additionalProperties'=>false],'execute_callback'=>static fn($i)=>self::product_detail(absint($i['product_id']??0))]);
  wp_register_ability('dreminex-products/cod-policy-update',['label'=>'Update product-only COD policy','description'=>'Enable or disable Cash on Delivery for one exact product. Standard products retain Delivery Advance, Full Payment and Wallet.','category'=>'dreminex-operations','input_schema'=>['type'=>'object','properties'=>['product_id'=>['type'=>'integer','minimum'=>1],'cod_only'=>['type'=>'boolean'],'expected_revision'=>['type'=>'string'],'confirm'=>['type'=>'boolean']],'required'=>['product_id','cod_only','confirm'],'additionalProperties'=>false],'output_schema'=>['type'=>'object','additionalProperties'=>true],'execute_callback'=>static fn($i)=>self::cod_policy(absint($i['product_id']??0),(array)$i),'permission_callback'=>static fn()=>current_user_can('manage_woocommerce'),'annotations'=>['readonly'=>false,'destructive'=>false,'idempotent'=>true],'meta'=>['annotations'=>['readonly'=>false,'destructive'=>false,'idempotent'=>true],'mcp'=>['public'=>true]]]);
  wp_register_ability('dreminex-products/performance-read',$read+['label'=>'Read product performance','description'=>'Read privacy-safe 30-day aggregate views, sales, revenue, reviews and relative performance score.','input_schema'=>['type'=>'object','properties'=>['product_id'=>['type'=>'integer','minimum'=>1]],'required'=>['product_id'],'additionalProperties'=>false],'execute_callback'=>static fn($i)=>self::performance(absint($i['product_id']??0))]);
  wp_register_ability('dreminex-operations/notifications-read',$read+['label'=>'Read Nexus notifications','description'=>'Read categorized unexpired notifications for the connected WordPress user.','input_schema'=>['type'=>'object','properties'=>['category'=>['type'=>'string'],'limit'=>['type'=>'integer','minimum'=>1,'maximum'=>100]],'additionalProperties'=>false],'execute_callback'=>static fn($i)=>self::notifications((array)$i)]);
 }
 private static function catalog_schema(){return ['type'=>'object','properties'=>['page'=>['type'=>'integer','minimum'=>1],'per_page'=>['type'=>'integer','minimum'=>1,'maximum'=>60],'status'=>['type'=>'string','enum'=>['active','draft','publish','trash']],'category_id'=>['type'=>'integer','minimum'=>0],'search'=>['type'=>'string'],'sort'=>['type'=>'string','enum'=>['newest','oldest','title','price_high','price_low']]],'additionalProperties'=>false];}

 public static function rest_products($request){return rest_ensure_response(self::catalog($request->get_params()));}
 public static function catalog($input=[]){
  $page=max(1,absint($input['page']??1));$per=max(1,min(60,absint($input['per_page']??20)));$status=sanitize_key((string)($input['status']??'active'));
  $statuses=$status==='trash'?['trash']:($status==='draft'?['draft']:($status==='publish'?['publish']:['draft','publish']));
  $sort=sanitize_key((string)($input['sort']??'newest'));$orderby='date';$order='DESC';$meta_key='';
  if($sort==='oldest')$order='ASC';elseif($sort==='title'){$orderby='title';$order='ASC';}elseif(in_array($sort,['price_high','price_low'],true)){$orderby='meta_value_num';$meta_key='_price';$order=$sort==='price_high'?'DESC':'ASC';}
  $args=['post_type'=>'product','post_status'=>$statuses,'posts_per_page'=>$per,'paged'=>$page,'orderby'=>$orderby,'order'=>$order,'s'=>sanitize_text_field((string)($input['search']??''))];
  if($meta_key)$args['meta_key']=$meta_key;if(absint($input['category_id']??0))$args['tax_query']=[['taxonomy'=>'product_cat','field'=>'term_id','terms'=>[absint($input['category_id'])]]];
  $q=new WP_Query($args);$metrics=self::metric_map();$items=[];foreach($q->posts as $post){$p=wc_get_product($post->ID);if($p)$items[]=self::summary($p,$metrics[$post->ID]??self::empty_metric());}
  return ['schema_version'=>2,'site_id'=>self::site_id(),'items'=>$items,'page'=>$page,'per_page'=>$per,'total'=>(int)$q->found_posts,'total_pages'=>(int)$q->max_num_pages,'has_more'=>$page<(int)$q->max_num_pages,'server_time'=>gmdate('c')];
 }

 public static function rest_categories(){return rest_ensure_response(['schema_version'=>1,'site_id'=>self::site_id(),'categories'=>self::categories()]);}
 private static function categories(){
  $terms=get_terms(['taxonomy'=>'product_cat','hide_empty'=>false]);$out=[];if(is_wp_error($terms))return $out;
  foreach($terms as $term)$out[]=['id'=>(int)$term->term_id,'name'=>$term->name,'slug'=>$term->slug,'parent_id'=>(int)$term->parent,'count'=>(int)$term->count];return $out;
 }
 public static function rest_product($request){$id=absint($request['product_id']);$value=$request->get_method()==='PUT'?self::update_product($id,self::input($request)):self::product_detail($id);return is_wp_error($value)?$value:rest_ensure_response($value);}
 public static function rest_supplier_schedule($request){if(!class_exists('Dreminex_Supplier_Nexus'))return new WP_Error('supplier_monitor_unavailable','Supplier Monitor is unavailable.',['status'=>424]);$settings=Dreminex_Supplier_Nexus::settings();if($request->get_method()==='PUT'){$input=self::input($request);$saved=Dreminex_Supplier_Nexus::set_scan_interval(absint($input['scan_interval_hours']??0));if(is_wp_error($saved))return $saved;$settings=Dreminex_Supplier_Nexus::settings();}return rest_ensure_response(['schema_version'=>1,'site_id'=>self::site_id(),'scan_interval_hours'=>(int)$settings['scan_interval_hours'],'allowed_intervals_hours'=>[3,6,12,24],'default_interval_hours'=>12]);}
 public static function product_detail($id){
  $product=wc_get_product($id);if(!$product||!in_array($product->get_status(),['draft','publish','trash'],true))return new WP_Error('product_not_found','Product is unavailable.',['status'=>404]);
  $metric=self::metric_map()[$id]??self::empty_metric();$result=self::summary($product,$metric);$gallery=[];
  foreach(array_values(array_unique(array_filter(array_merge([$product->get_image_id()],$product->get_gallery_image_ids())))) as $image_id)$gallery[]=['id'=>(int)$image_id,'url'=>(string)wp_get_attachment_image_url($image_id,'large'),'alt'=>(string)get_post_meta($image_id,'_wp_attachment_image_alt',true)];
  $tags=get_the_terms($id,'product_tag');$result['tags']=[];if(is_array($tags))foreach($tags as $tag)$result['tags'][]=['id'=>(int)$tag->term_id,'name'=>$tag->name,'slug'=>$tag->slug];
  $result['gallery']=$gallery;$result['description']=$product->get_description();$result['short_description']=$product->get_short_description();$result['sku']=$product->get_sku();$result['slug']=$product->get_slug();$result['manage_stock']=$product->get_manage_stock();$result['stock_quantity']=$product->get_stock_quantity();$result['stock_status']=$product->get_stock_status();$result['seo_title']=(string)get_post_meta($id,'_yoast_wpseo_title',true);$result['seo_description']=(string)get_post_meta($id,'_yoast_wpseo_metadesc',true);$result['permalink']=$product->get_permalink();$result['performance']=$metric;$result['lifecycle_revision']=self::revision($product);$result['all_badges']=self::badges($product);$result['variations']=$product->is_type('variable')?count($product->get_children()):0;$result['cod_only']=$product->get_meta('_dreminex_cod_only')==='yes';
  return ['schema_version'=>2,'site_id'=>self::site_id(),'product'=>$result];
 }
 public static function update_product($id,$input){
  $product=wc_get_product($id);if(!$product||!in_array($product->get_status(),['draft','publish'],true))return new WP_Error('product_not_found','Draft or published product was not found.',['status'=>404]);
  if(!current_user_can('edit_product',$id))return new WP_Error('permission_denied','You cannot edit this product.',['status'=>403]);
  $expected=(string)($input['expected_revision']??'');if($expected===''||!hash_equals(self::revision($product),$expected))return new WP_Error('product_revision_conflict','This product changed since it was opened. Refresh it before saving.',['status'=>409]);
  $name=sanitize_text_field((string)($input['title']??''));$slug=sanitize_title((string)($input['slug']??''));$sku=sanitize_text_field((string)($input['sku']??''));
  if($name===''||strlen($name)>200)return new WP_Error('invalid_product_title','Enter a product title under 200 characters.',['status'=>400]);
  if(strlen($sku)>64)return new WP_Error('invalid_product_sku','SKU cannot exceed 64 characters.',['status'=>400]);
  if(!array_key_exists('slug',$input)||$slug==='')$slug=sanitize_title($name);$slug=wp_unique_post_slug($slug,$id,$product->get_status(),'product',0);
  $regular=wc_format_decimal((string)($input['regular_price']??''));$sale=wc_format_decimal((string)($input['sale_price']??''));
  if($regular!==''&&!is_numeric($regular)||$sale!==''&&!is_numeric($sale))return new WP_Error('invalid_product_price','Product prices must be valid numbers.',['status'=>400]);
  if($sale!==''&&$regular!==''&&(float)$sale>(float)$regular)return new WP_Error('invalid_sale_price','Sale price cannot be higher than regular price.',['status'=>400]);
  $stock_status=sanitize_key((string)($input['stock_status']??'instock'));if(!in_array($stock_status,['instock','outofstock','onbackorder'],true))return new WP_Error('invalid_stock_status','Choose a valid stock status.',['status'=>400]);
  $manage_stock=!empty($input['manage_stock']);$quantity=null;if($manage_stock){if(!array_key_exists('stock_quantity',$input)||!is_numeric($input['stock_quantity'])||(int)$input['stock_quantity']<0)return new WP_Error('invalid_stock_quantity','Stock quantity must be zero or more.',['status'=>400]);$quantity=(int)$input['stock_quantity'];}
  $category_ids=array_values(array_unique(array_filter(array_map('absint',(array)($input['category_ids']??[])))));if(count($category_ids)>50)return new WP_Error('too_many_categories','Choose up to 50 categories.',['status'=>400]);foreach($category_ids as $term_id){$term=get_term($term_id,'product_cat');if(!$term||is_wp_error($term))return new WP_Error('invalid_category','One selected product category no longer exists.',['status'=>409]);}
  $tag_ids=[];
  $tag_values=explode(',',(string)($input['tags_csv']??''));
  $tag_names=[];foreach($tag_values as $raw_tag){$clean_tag=sanitize_text_field((string)$raw_tag);if($clean_tag!==''&&!in_array($clean_tag,$tag_names,true))$tag_names[]=$clean_tag;if(count($tag_names)>=50)break;}
  foreach($tag_names as $tag_name){if($tag_name==='')continue;$found=term_exists($tag_name,'product_tag');if(!$found){$found=wp_insert_term($tag_name,'product_tag');if(is_wp_error($found))return new WP_Error('product_tag_save_failed','A product tag could not be prepared.',['status'=>400]);}$tag_ids[]=(int)(is_array($found)?$found['term_id']:$found);}
  $gallery_ids=array_values(array_unique(array_filter(array_map('absint',(array)($input['gallery_ids']??[])))));if(count($gallery_ids)>30)return new WP_Error('too_many_images','A product gallery can contain up to 30 images.',['status'=>400]);foreach($gallery_ids as $image_id)if(get_post_type($image_id)!=='attachment'||!wp_attachment_is_image($image_id))return new WP_Error('invalid_gallery_image','One selected gallery image is not an image attachment.',['status'=>400]);
  $description=wp_kses_post((string)($input['description']??''));$short=wp_kses_post((string)($input['short_description']??''));if(strlen($description)>200000||strlen($short)>10000)return new WP_Error('product_description_too_long','Product description exceeds the supported size.',['status'=>400]);
  $product->set_name($name);$product->set_slug($slug);$product->set_sku($sku);$product->set_regular_price($regular);$product->set_sale_price($sale);$product->set_description($description);$product->set_short_description($short);$product->set_category_ids($category_ids);$product->set_tag_ids($tag_ids);$product->set_manage_stock($manage_stock);$product->set_stock_quantity($quantity);$product->set_stock_status($stock_status);
  if($gallery_ids){$product->set_image_id(array_shift($gallery_ids));$product->set_gallery_image_ids($gallery_ids);}else{$product->set_image_id(0);$product->set_gallery_image_ids([]);}
  try{$product->save();}catch(Throwable $e){return new WP_Error('product_save_failed','WooCommerce could not save these product changes. Check SKU and price values.',['status'=>400]);}
  wp_set_object_terms($id,$category_ids,'product_cat',false);wp_set_object_terms($id,$tag_ids,'product_tag',false);
  update_post_meta($id,'_yoast_wpseo_title',sanitize_text_field((string)($input['seo_title']??'')));update_post_meta($id,'_yoast_wpseo_metadesc',sanitize_text_field((string)($input['seo_description']??'')));
  clean_post_cache($id);$saved=self::product_detail($id);if(is_wp_error($saved))return $saved;
  $readback=$saved['product'];if($readback['title']!==$name||$readback['sku']!==$sku||$readback['slug']!==$slug||$readback['short_description']!==$short)return new WP_Error('product_readback_mismatch','WooCommerce readback did not match the submitted product details. Refresh before making another edit.',['status'=>409]);
  return $saved+['success'=>true,'readback_verified'=>true,'variation_management'=>in_array($product->get_type(),['simple','variable'],true)?'variation_items_not_changed':'unsupported_product_type'];
 }
 public static function rest_cod_policy($request){$value=self::cod_policy(absint($request['product_id']),self::input($request));return is_wp_error($value)?$value:rest_ensure_response($value);}
 public static function cod_policy($id,$input){
  $product=wc_get_product($id);if(!$product||!in_array($product->get_status(),['draft','publish'],true))return new WP_Error('product_not_found','Draft or published product was not found.',['status'=>404]);
  if(empty($input['confirm']))return new WP_Error('confirmation_required','Confirm the product payment policy change.',['status'=>409]);
  $expected=(string)($input['expected_revision']??'');if($expected!==''&&!hash_equals(self::revision($product),$expected))return new WP_Error('status_conflict','The product changed. Refresh it before changing the COD policy.',['status'=>409]);
  $enabled=!empty($input['cod_only']);$product->update_meta_data('_dreminex_cod_only',$enabled?'yes':'no');$product->save();$saved=wc_get_product($id);
  self::notify('products','product_cod_policy','Product payment policy updated',$enabled?'Cash on Delivery is enabled only for this product.':'This product uses the standard Delivery Advance, Full Payment and Wallet flow.',['product_id'=>$id,'screen'=>'products'],'product-cod-policy-'.$id.'-'.($enabled?'on':'off').'-'.time());
  return ['success'=>true,'product_id'=>$id,'cod_only'=>$enabled,'payment_route'=>$enabled?'cash_on_delivery':'delivery_advance_wallet','lifecycle_revision'=>$saved?self::revision($saved):null];
 }

 private static function summary($product,$metric){
  $id=$product->get_id();$terms=get_the_terms($id,'product_cat');$categories=[];if(is_array($terms))foreach($terms as $term)$categories[]=['id'=>(int)$term->term_id,'name'=>$term->name,'slug'=>$term->slug];
  $supplier=self::supplier_state($id);$badges=self::badges($product);
  return ['id'=>$id,'title'=>$product->get_name(),'status'=>$product->get_status(),'type'=>$product->get_type(),'thumbnail_url'=>(string)wp_get_attachment_image_url($product->get_image_id(),'woocommerce_thumbnail'),'regular_price'=>(string)$product->get_regular_price(),'sale_price'=>(string)$product->get_sale_price(),'current_price'=>(string)$product->get_price(),'display_price'=>html_entity_decode(wp_strip_all_tags($product->get_price_html()),ENT_QUOTES|ENT_HTML5,'UTF-8'),'price'=>self::structured_price($product),'currency'=>get_woocommerce_currency(),'categories'=>$categories,'primary_badge'=>$badges[0]??null,'review_rating'=>(float)$product->get_average_rating(),'review_count'=>(int)$product->get_review_count(),'stock_status'=>$product->get_stock_status(),'supplier'=>$supplier,'scan_status'=>$supplier['scan_status'],'performance'=>['score'=>$metric['score'],'label'=>$metric['label'],'views_30d'=>$metric['views_30d'],'units_30d'=>$metric['units_30d']],'modified_gmt'=>get_post_field('post_modified_gmt',$id),'lifecycle_revision'=>self::revision($product)];
 }
 private static function structured_price($product){
  $currency=get_woocommerce_currency();$symbol=html_entity_decode(wp_strip_all_tags((string)get_woocommerce_currency_symbol($currency)),ENT_QUOTES|ENT_HTML5,'UTF-8');$regular=(string)$product->get_regular_price();$sale=(string)$product->get_sale_price();$current=(string)$product->get_price();$min='';$max='';
  if($product->is_type('variable')){$min=(string)$product->get_variation_price('min',true);$max=(string)$product->get_variation_price('max',true);$current=$min;}
  return ['currency_code'=>$currency,'currency_symbol'=>$symbol,'decimal_places'=>wc_get_price_decimals(),'regular'=>$regular,'sale'=>$sale,'current'=>$current,'min'=>$min,'max'=>$max,'on_sale'=>$product->is_on_sale()];
 }
 private static function revision($product){return hash('sha256',$product->get_id().'|'.$product->get_status().'|'.get_post_field('post_modified_gmt',$product->get_id()));}
 private static function badges($product){$b=[];if(!$product->is_in_stock())$b[]='Out of Stock';elseif($product->managing_stock()&&$product->get_stock_quantity()!==null&&$product->get_stock_quantity()<=wc_get_low_stock_amount($product))$b[]='Low Stock';if($product->is_on_sale())$b[]='On Sale';$created=$product->get_date_created();if($created&&$created->getTimestamp()>=time()-30*DAY_IN_SECONDS)$b[]='New';if($product->is_featured())$b[]='Featured';return array_values(array_unique($b));}
 private static function supplier_state($id){
  $sources=(array)get_post_meta($id,Dreminex_Supplier_Nexus::SOURCE_META,true);$source=[];foreach($sources as $key=>$row)if(is_array($row)&&!empty($row['url'])){$source=['platform_id'=>(string)($row['platform_id']??$key),'url'=>(string)$row['url']];break;}
  if(!$source)return ['connected'=>false,'platform_id'=>null,'platform_name'=>null,'url'=>null,'scan_status'=>'unlinked','last_scanned_at'=>null,'error_code'=>null];
  global $wpdb;$table=$wpdb->prefix.'dreminex_nexus_jobs';$job=$wpdb->get_row($wpdb->prepare("SELECT status,error_code,completed_at,updated_at FROM {$table} WHERE product_id=%d ORDER BY updated_at DESC LIMIT 1",$id),ARRAY_A);$status='never_scanned';
  if($job){$map=['pending'=>'queued','claimed'=>'scanning','running'=>'scanning','completed'=>'healthy','failed'=>'error','restricted'=>'paused'];$status=$map[$job['status']]??sanitize_key($job['status']);}
  $platform=Dreminex_Supplier_Nexus::platform($source['platform_id']);return array_merge($source,['connected'=>true,'platform_name'=>$platform['name']??$source['platform_id'],'scan_status'=>$status,'last_scanned_at'=>$job['completed_at']??null,'error_code'=>$job['error_code']??null]);
 }

 public static function rest_transition($request){$result=self::transition(absint($request['product_id']),self::input($request));return is_wp_error($result)?$result:rest_ensure_response($result);}
 public static function transition($id,$input){
  $product=wc_get_product($id);if(!$product)return new WP_Error('product_not_found','Product is unavailable.',['status'=>404]);$action=sanitize_key((string)($input['action']??''));$status=$product->get_status();$expected=(string)($input['expected_revision']??'');
  if($expected!==''&&!hash_equals(self::revision($product),$expected))return new WP_Error('status_conflict','Product status or content changed. Refresh before retrying.',['status'=>409]);
  $allowed=['draft'=>['publish','trash'],'publish'=>['trash'],'trash'=>['restore','delete']];if(!in_array($action,$allowed[$status]??[],true))return new WP_Error('invalid_transition','This product status transition is not allowed.',['status'=>409]);
  if($action==='delete'){
   $token=(string)($input['confirmation_token']??'');$key='dreminex_delete_confirm_'.get_current_user_id().'_'.$id;
   if($token===''||!hash_equals((string)get_transient($key),hash('sha256',$token.'|'.$id.'|'.$status))){$raw=wp_generate_password(40,false,false);set_transient($key,hash('sha256',$raw.'|'.$id.'|'.$status),5*MINUTE_IN_SECONDS);return ['success'=>true,'executed'=>false,'confirmation_required'=>true,'confirmation_token'=>$raw,'product_id'=>$id,'current_status'=>$status,'message'=>'Confirm permanent deletion of this exact Trash product within five minutes.'];}
   delete_transient($key);wp_delete_post($id,true);self::notify('products','product_deleted','Product permanently deleted','A Trash product was permanently deleted.',['product_id'=>$id],'product-deleted-'.$id.'-'.time());return ['success'=>true,'executed'=>true,'product_id'=>$id,'status'=>'deleted'];
  }
  if($action==='trash')wp_trash_post($id);elseif($action==='restore'){wp_untrash_post($id);$product=wc_get_product($id);$product->set_status('draft');$product->save();}else{$product->set_status($action);$product->save();}
  $read=wc_get_product($id);return ['success'=>true,'executed'=>true,'product_id'=>$id,'status'=>$read?$read->get_status():$action,'lifecycle_revision'=>$read?self::revision($read):null];
 }
 public static function rest_bulk_transition($request){$v=self::bulk_transition(self::input($request));return is_wp_error($v)?$v:rest_ensure_response($v);}
 public static function bulk_transition($input){
  $action=sanitize_key((string)($input['action']??''));$items=is_array($input['items']??null)?array_values($input['items']):[];if(!in_array($action,['publish','trash','restore','delete'],true))return new WP_Error('invalid_transition','Choose publish, trash, restore or delete.',['status'=>400]);if(!$items||count($items)>100)return new WP_Error('invalid_batch','Select 1–100 products.',['status'=>400]);$results=[];$confirm=(string)($input['confirmation_token']??'');
  if($action==='delete'&&$confirm===''){$raw=wp_generate_password(40,false,false);set_transient('dreminex_bulk_delete_'.get_current_user_id(),hash('sha256',$raw.'|'.wp_json_encode(array_column($items,'id'))),5*MINUTE_IN_SECONDS);return ['success'=>true,'executed'=>false,'confirmation_required'=>true,'confirmation_token'=>$raw,'count'=>count($items)];}
  if($action==='delete'){$saved=(string)get_transient('dreminex_bulk_delete_'.get_current_user_id());if(!$saved||!hash_equals($saved,hash('sha256',$confirm.'|'.wp_json_encode(array_column($items,'id')))))return new WP_Error('invalid_confirmation','Bulk delete confirmation expired or does not match this selection.',['status'=>409]);delete_transient('dreminex_bulk_delete_'.get_current_user_id());}
  foreach($items as $row){$id=absint($row['id']??0);$product=wc_get_product($id);if(!$product){$results[]=['id'=>$id,'success'=>false,'error'=>'product_not_found'];continue;}$status=$product->get_status();$allowed=['draft'=>['publish','trash'],'publish'=>['trash'],'trash'=>['restore','delete']];if(!in_array($action,$allowed[$status]??[],true)){$results[]=['id'=>$id,'success'=>false,'error'=>'invalid_transition','status'=>$status];continue;}$expected=(string)($row['expected_revision']??'');if($expected!==''&&!hash_equals(self::revision($product),$expected)){$results[]=['id'=>$id,'success'=>false,'error'=>'status_conflict','status'=>$status];continue;}if($action==='delete')wp_delete_post($id,true);elseif($action==='trash')wp_trash_post($id);elseif($action==='restore'){wp_untrash_post($id);$p=wc_get_product($id);$p->set_status('draft');$p->save();}else{$product->set_status('publish');$product->save();}$saved=$action==='delete'?null:wc_get_product($id);$results[]=['id'=>$id,'success'=>true,'status'=>$saved?$saved->get_status():'deleted','lifecycle_revision'=>$saved?self::revision($saved):null];}
  $ok=count(array_filter($results,static fn($r)=>!empty($r['success'])));return ['success'=>$ok===count($results),'executed'=>true,'action'=>$action,'changed'=>$ok,'failed'=>count($results)-$ok,'results'=>$results];
 }

 public static function rest_supplier($request){$result=self::connect_supplier(absint($request['product_id']),self::input($request));return is_wp_error($result)?$result:rest_ensure_response($result);}
 public static function connect_supplier($id,$input){
  if(!wc_get_product($id))return new WP_Error('product_not_found','Product is unavailable.',['status'=>404]);$url=esc_url_raw((string)($input['url']??''));$platform=Dreminex_Supplier_Nexus::platform_for_url($url);if(!$platform)return new WP_Error('unsupported_supplier_url','Choose a URL matching an enabled supplier platform.',['status'=>400]);
  if(!empty($input['platform_id'])&&sanitize_key($input['platform_id'])!==$platform['platform_id'])return new WP_Error('platform_mismatch','The URL does not match the selected platform.',['status'=>400]);
  $sources=(array)get_post_meta($id,Dreminex_Supplier_Nexus::SOURCE_META,true);$key=$platform['platform_id'];$sources[$key]=array_replace((array)($sources[$key]??[]),['url'=>$url,'platform_id'=>$platform['platform_id'],'updated_at'=>self::now()]);update_post_meta($id,Dreminex_Supplier_Nexus::SOURCE_META,$sources);
  $queued=null;if(!empty($input['scan_now'])){$q=Dreminex_Supplier_Nexus::enqueue($id,$platform['platform_id'],$url,'manual',true);$queued=!is_wp_error($q);}
  return ['success'=>true,'product_id'=>$id,'supplier'=>self::supplier_state($id),'scan_queued'=>$queued];
 }

 public static function rest_projects(){return rest_ensure_response(['schema_version'=>1,'site_id'=>self::site_id(),'projects'=>Dreminex_AI_Workflow_Projects::app_projects()]);}
 public static function rest_app_release(){return rest_ensure_response(array_merge(['site_id'=>self::site_id(),'server_version'=>DREMINEX_SUITE_VERSION,'notification_delivery'=>self::notification_delivery()],Dreminex_Native_MCP::app_release_manifest()));}
 public static function rest_app_capabilities($request){
  if($request->get_method()==='PUT'){$features=Dreminex_Native_MCP::update_app_features((array)(self::input($request)['features']??[]));return is_wp_error($features)?$features:rest_ensure_response(['features'=>$features]);}
  return rest_ensure_response(['schema_version'=>1,'site_id'=>self::site_id(),'features'=>Dreminex_Native_MCP::app_features()]);
 }
 public static function rest_project_source($request){
  $profile=(string)$request['profile'];$name=(string)$request['filename'];
  if($request->get_method()==='GET'){$value=Dreminex_AI_Workflow_Projects::app_source($profile,$name);return is_wp_error($value)?$value:rest_ensure_response($value);}
  if($request->get_method()==='DELETE'){$value=Dreminex_AI_Workflow_Projects::app_source_action($profile,$name,'remove');return is_wp_error($value)?$value:rest_ensure_response($value);}
  $data=self::input($request);$value=Dreminex_AI_Workflow_Projects::app_source_put($profile,$name,(string)($data['content']??''),!empty($data['replace']),!array_key_exists('activate',$data)||!empty($data['activate']));return is_wp_error($value)?$value:rest_ensure_response($value);
 }
 public static function rest_project_action($request){$data=self::input($request);$value=Dreminex_AI_Workflow_Projects::app_source_action((string)$request['profile'],(string)($data['filename']??''),sanitize_key((string)($data['action']??'')));return is_wp_error($value)?$value:rest_ensure_response($value);}
 public static function rest_publisher_settings($request){if($request->get_method()==='GET')return rest_ensure_response(['settings'=>Dreminex_Suite_AI_Product_Publisher::app_settings()]);$value=Dreminex_Suite_AI_Product_Publisher::update_app_settings(self::input($request));return is_wp_error($value)?$value:rest_ensure_response(['settings'=>$value]);}

 public static function rest_action_center(){return rest_ensure_response(self::operations_summary());}
 public static function rest_security($request){
  if($request->get_method()==='GET')return rest_ensure_response(Dreminex_Security_Center::dashboard());
  $input=self::input($request);
  $settings=Dreminex_Security_Center::update_settings((array)($input['settings']??$input));
  self::notify('security','security_policy_updated','Security settings updated','Website protection settings were updated from Dreminex Nexus.',['screen'=>'security'],'security-policy-'.hash('sha256',wp_json_encode($settings)).'-'.gmdate('YmdHi'));
  return rest_ensure_response(Dreminex_Security_Center::dashboard());
 }
 public static function operations_summary(){
  if(!function_exists('wc_get_orders'))return ['schema_version'=>1,'site_id'=>self::site_id(),'generated_at'=>gmdate('c'),'orders'=>[],'supplier_alerts'=>0,'new_contact_requests'=>0,'inventory_attention'=>0,'partial_checkouts'=>0];
  $orders=[];foreach(['pending','on-hold','ready-to-ship'] as $status){$result=wc_get_orders(['status'=>[$status],'limit'=>1,'paginate'=>true,'return'=>'ids']);$orders[$status]=is_object($result)?(int)$result->total:0;}
  global $wpdb;$events=$wpdb->prefix.'dreminex_supplier_events';$supplier=self::table_exists($events)?(int)$wpdb->get_var("SELECT COUNT(*) FROM {$events} WHERE state='pending'"):0;$contact=$wpdb->prefix.'dreminex_contact_requests';$contacts=self::table_exists($contact)?(int)$wpdb->get_var("SELECT COUNT(*) FROM {$contact} WHERE request_status='new'"):0;
  $low=(int)get_transient('dreminex_app_low_stock');if($low===0){$low=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID=pm.post_id WHERE p.post_type IN ('product','product_variation') AND p.post_status IN ('publish','draft') AND pm.meta_key='_stock_status' AND pm.meta_value='outofstock'");set_transient('dreminex_app_low_stock',$low,10*MINUTE_IN_SECONDS);}
  return ['schema_version'=>1,'site_id'=>self::site_id(),'generated_at'=>gmdate('c'),'orders'=>$orders,'supplier_alerts'=>$supplier,'new_contact_requests'=>$contacts,'inventory_attention'=>$low,'partial_checkouts'=>post_type_exists('dreminex_partial')?(int)(wp_count_posts('dreminex_partial')->private??0):0];
 }
 private static function table_exists($name){global $wpdb;return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($name)))===$name;}

 public static function notify($category,$event_type,$title,$message,$payload=[],$event_key=''){
  if(!Dreminex_Native_MCP::enabled())return 0;if($category==='action_center')$category='security';$category=in_array($category,['suppliers','products','orders','contacts','checkout','payments','security','system'],true)?$category:'system';$payload=self::notification_thumbnail($payload);$event_key=$event_key?:sanitize_key($event_type).'-'.hash('sha256',wp_json_encode($payload).'|'.time());
  global $wpdb;$device_table=$wpdb->prefix.'dreminex_nexus_devices';$users=self::table_exists($device_table)?array_map('intval',$wpdb->get_col("SELECT DISTINCT user_id FROM {$device_table} WHERE user_id>0")):[];
  if(!$users){$users=array_map('intval',get_users(['role__in'=>['administrator','shop_manager'],'fields'=>'ID','number'=>10]));}if(!$users)return 0;$first=0;
  foreach(array_values(array_unique($users)) as $user_id){$user_key=substr($event_key.'-u'.$user_id,0,191);$wpdb->query($wpdb->prepare('INSERT IGNORE INTO '.self::table('notifications').' (user_id,category,event_type,title,message,payload_json,event_key,is_read,created_at,expires_at) VALUES (%d,%s,%s,%s,%s,%s,%s,0,%s,%s)',$user_id,$category,sanitize_key($event_type),substr(sanitize_text_field($title),0,191),sanitize_textarea_field($message),wp_json_encode($payload),$user_key,self::now(),gmdate('Y-m-d H:i:s',time()+self::NOTIFICATION_DAYS*DAY_IN_SECONDS)));$id=(int)$wpdb->insert_id;if($id){if(!$first)$first=$id;$route=array_merge(['notification_id'=>$id,'site_id'=>self::site_id(),'category'=>$category,'event_type'=>sanitize_key($event_type),'screen'=>self::notification_screen($category),'title'=>$title,'message'=>$message],$payload);self::push_user($user_id,$route);}}
  return $first;
 }
 private static function notification_thumbnail($payload){
  if(!empty($payload['thumbnail_url'])){$url=esc_url_raw((string)$payload['thumbnail_url']);if(str_starts_with($url,'https://')){$payload['thumbnail_url']=$url;return $payload;}unset($payload['thumbnail_url']);}$product_id=absint($payload['product_id']??0);
  if(!$product_id&&!empty($payload['order_id'])&&function_exists('wc_get_order')){$order=wc_get_order(absint($payload['order_id']));if($order)foreach($order->get_items('line_item') as $item){$product=$item->get_product();if($product){$product_id=$product->is_type('variation')?$product->get_parent_id():$product->get_id();break;}}}
  if(!$product_id||!function_exists('wc_get_product'))return $payload;$product=wc_get_product($product_id);if(!$product)return $payload;$url=(string)wp_get_attachment_image_url($product->get_image_id(),'woocommerce_thumbnail');if($url&&str_starts_with($url,'https://'))$payload['thumbnail_url']=$url;return $payload;
 }
 private static function notification_screen($category){return ['products'=>'products','orders'=>'operations/orders','contacts'=>'operations/contacts','checkout'=>'operations/checkout','payments'=>'operations/payments','suppliers'=>'operations/supplier','security'=>'security'][$category]??'notifications';}
 public static function supplier_notification($product_id,$kind='change_detected'){return self::notify('suppliers',$kind,'Supplier update detected','A connected supplier product needs review.',['product_id'=>(int)$product_id],'supplier-'.$kind.'-'.(int)$product_id.'-'.gmdate('YmdHi'));}
 public static function security_event_notification($event){
  $type=sanitize_key((string)($event['event_type']??'security_event'));$key='dreminex_security_notice_'.$type;
  if(get_transient($key))return;
  set_transient($key,1,15*MINUTE_IN_SECONDS);
  self::notify('security','security_activity_blocked','Suspicious activity blocked','Dreminex Security Center blocked suspicious website activity. Open Security to review the recent event summary.',['screen'=>'security','source'=>sanitize_key((string)($event['source']??'unknown'))],'security-block-'.$type.'-'.gmdate('YmdHi'));
 }
 public static function status_notification($new,$old,$post){if(!$post instanceof WP_Post||$post->post_type!=='product'||$new===$old||!in_array($new,['draft','publish','trash'],true))return;self::notify('products','product_status_changed','Product status changed','A product moved from '.$old.' to '.$new.'.',['product_id'=>(int)$post->ID,'old_status'=>$old,'new_status'=>$new],'product-status-'.$post->ID.'-'.$new.'-'.get_post_modified_time('U',true,$post));}

 public static function rest_notifications($request){return rest_ensure_response(self::notifications($request->get_params()));}
 public static function notifications($input=[]){
  self::cleanup();$limit=max(1,min(100,absint($input['limit']??50)));$category=sanitize_key((string)($input['category']??''));if($category==='action_center')$category='security';global $wpdb;$where='user_id=%d AND expires_at>=%s';$args=[get_current_user_id(),self::now()];if($category){$where.=' AND category=%s';$args[]=$category;}$args[]=$limit;$rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM '.self::table('notifications')." WHERE {$where} ORDER BY created_at DESC LIMIT %d",...$args),ARRAY_A);foreach($rows as &$row){$row['id']=(int)$row['id'];$row['is_read']=(bool)$row['is_read'];$row['payload']=(array)json_decode($row['payload_json'],true);unset($row['payload_json'],$row['user_id'],$row['event_key']);}return ['schema_version'=>1,'site_id'=>self::site_id(),'notifications'=>$rows,'unread_count'=>(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM '.self::table('notifications').' WHERE user_id=%d AND is_read=0 AND expires_at>=%s',get_current_user_id(),self::now()))];
 }
 public static function rest_notification($request){$id=absint($request['notification_id']);global $wpdb;if($request->get_method()==='DELETE')$ok=$wpdb->delete(self::table('notifications'),['id'=>$id,'user_id'=>get_current_user_id()],['%d','%d']);else $ok=$wpdb->update(self::table('notifications'),['is_read'=>1],['id'=>$id,'user_id'=>get_current_user_id()],['%d'],['%d','%d']);return rest_ensure_response(['success'=>$ok!==false,'notification_id'=>$id]);}
 public static function cleanup(){global $wpdb;$wpdb->query($wpdb->prepare('DELETE FROM '.self::table('notifications').' WHERE expires_at < %s',self::now()));$wpdb->query($wpdb->prepare('DELETE FROM '.self::table('views').' WHERE view_date < %s',gmdate('Y-m-d',time()-120*DAY_IN_SECONDS)));}

 public static function rest_push_token($request){$data=self::input($request);$token=trim((string)($data['push_token']??''));if(strlen($token)<20||strlen($token)>4096)return new WP_Error('invalid_push_token','A valid push token is required.',['status'=>400]);$device=Dreminex_Supplier_Nexus::device_context();global $wpdb;$wpdb->replace(self::table('push_devices'),['device_id'=>$device['device_id'],'user_id'=>get_current_user_id(),'push_token'=>$token,'enabled'=>!array_key_exists('enabled',$data)||!empty($data['enabled'])?1:0,'updated_at'=>self::now()],['%s','%d','%s','%d','%s']);return rest_ensure_response(['registered'=>true]+self::notification_delivery());}
 public static function notification_delivery(){return ['delivery'=>self::fcm_ready()?'push_with_sync_fallback':'sync_fallback','retention_days'=>self::NOTIFICATION_DAYS];}
 private static function fcm_ready(){return defined('DREMINEX_FCM_SERVICE_ACCOUNT_FILE')&&is_readable(DREMINEX_FCM_SERVICE_ACCOUNT_FILE)&&extension_loaded('openssl');}
 private static function push_user($user_id,$payload){if(!self::fcm_ready())return;global $wpdb;$tokens=$wpdb->get_col($wpdb->prepare('SELECT push_token FROM '.self::table('push_devices').' WHERE user_id=%d AND enabled=1',$user_id));foreach($tokens as $token)self::send_fcm($token,$payload);}
 private static function b64url($value){return rtrim(strtr(base64_encode($value),'+/','-_'),'=');}
 private static function fcm_access_token($account){
  $cached=get_transient('dreminex_fcm_access_token');if(is_string($cached)&&$cached!=='')return $cached;$now=time();$header=self::b64url(wp_json_encode(['alg'=>'RS256','typ'=>'JWT']));$claims=self::b64url(wp_json_encode(['iss'=>$account['client_email'],'scope'=>'https://www.googleapis.com/auth/firebase.messaging','aud'=>$account['token_uri'],'iat'=>$now,'exp'=>$now+3500]));$unsigned=$header.'.'.$claims;$signature='';if(!openssl_sign($unsigned,$signature,$account['private_key'],OPENSSL_ALGO_SHA256))return '';$jwt=$unsigned.'.'.self::b64url($signature);$response=wp_remote_post($account['token_uri'],['timeout'=>12,'body'=>['grant_type'=>'urn:ietf:params:oauth:grant-type:jwt-bearer','assertion'=>$jwt]]);if(is_wp_error($response))return '';$body=json_decode(wp_remote_retrieve_body($response),true);$token=(string)($body['access_token']??'');if($token!=='')set_transient('dreminex_fcm_access_token',$token,50*MINUTE_IN_SECONDS);return $token;
 }
 private static function send_fcm($device_token,$payload){
  $account=json_decode((string)file_get_contents(DREMINEX_FCM_SERVICE_ACCOUNT_FILE),true);if(!is_array($account)||empty($account['project_id'])||empty($account['client_email'])||empty($account['private_key'])||empty($account['token_uri']))return;$access=self::fcm_access_token($account);if($access==='')return;
  $data=[];foreach($payload as $k=>$v)$data[(string)$k]=is_scalar($v)?(string)$v:wp_json_encode($v);$notification=['title'=>$payload['title']??'Dreminex Nexus','body'=>$payload['message']??'New activity'];$image=esc_url_raw((string)($payload['thumbnail_url']??''));if(str_starts_with($image,'https://'))$notification['image']=$image;$notification['click_action']='com.dreminex.nexus.OPEN_NOTIFICATION';$notification['channel_id']='nexus_activity';$notification['sound']='default';wp_remote_post('https://fcm.googleapis.com/v1/projects/'.rawurlencode($account['project_id']).'/messages:send',['timeout'=>12,'headers'=>['Authorization'=>'Bearer '.$access,'Content-Type'=>'application/json'],'body'=>wp_json_encode(['message'=>['token'=>$device_token,'notification'=>$notification,'data'=>$data,'android'=>['priority'=>'high','notification'=>['channel_id'=>'nexus_activity','click_action'=>'com.dreminex.nexus.OPEN_NOTIFICATION','sound'=>'default']]]])]);
 }

 public static function view_beacon(){if(!is_product())return;$id=get_queried_object_id();if(!$id||get_post_status($id)!=='publish')return;$url=esc_url_raw(rest_url('dreminex/v1/metrics/product-view'));echo '<script id="dreminex-product-view">document.addEventListener("DOMContentLoaded",function(){var b=JSON.stringify({product_id:'.(int)$id.'});if(navigator.sendBeacon){navigator.sendBeacon('.wp_json_encode($url).',new Blob([b],{type:"application/json"}));}else{fetch('.wp_json_encode($url).',{method:"POST",headers:{"Content-Type":"application/json"},body:b,keepalive:true,credentials:"omit"}).catch(function(){});}});</script>';}
 public static function record_view($request){$data=self::input($request);$id=absint($data['product_id']??0);if(!$id||get_post_type($id)!=='product'||get_post_status($id)!=='publish')return new WP_Error('invalid_product','Published product required.',['status'=>400]);$raw=(string)($_SERVER['REMOTE_ADDR']??'').'|'.(string)($_SERVER['HTTP_USER_AGENT']??'').'|'.$id.'|'.gmdate('YmdH');$key='dreminex_view_'.hash_hmac('sha256',$raw,wp_salt('nonce'));if(get_transient($key))return rest_ensure_response(['counted'=>false]);set_transient($key,1,HOUR_IN_SECONDS);global $wpdb;$day=gmdate('Y-m-d');$wpdb->query($wpdb->prepare('INSERT INTO '.self::table('views').' (product_id,view_date,views) VALUES (%d,%s,1) ON DUPLICATE KEY UPDATE views=views+1',$id,$day));delete_transient('dreminex_app_metric_map');return rest_ensure_response(['counted'=>true]);}

 private static function empty_metric(){return ['views_30d'=>0,'units_30d'=>0.0,'revenue_30d'=>0.0,'review_rating'=>0.0,'review_count'=>0,'score'=>0,'label'=>'No data','period_days'=>self::VIEW_DAYS];}
 public static function performance($id){$map=self::metric_map();return ['schema_version'=>1,'site_id'=>self::site_id(),'product_id'=>$id,'performance'=>$map[$id]??self::empty_metric()];}
 private static function percentile($value,$values){if($value<=0||!$values)return 0.0;$less=0;foreach($values as $v)if($v<$value)$less++;return count($values)===1?100.0:100.0*$less/(count($values)-1);}
 private static function metric_map(){
  $cached=get_transient('dreminex_app_metric_map');if(is_array($cached))return $cached;global $wpdb;$ids=array_map('intval',$wpdb->get_col("SELECT ID FROM {$wpdb->posts} WHERE post_type='product' AND post_status IN ('draft','publish')"));if(!$ids)return [];$in=implode(',',$ids);$from=gmdate('Y-m-d',time()-(self::VIEW_DAYS-1)*DAY_IN_SECONDS);$views=[];foreach($wpdb->get_results($wpdb->prepare('SELECT product_id,SUM(views) total FROM '.self::table('views')." WHERE view_date >= %s AND product_id IN ({$in}) GROUP BY product_id",$from),ARRAY_A) as $row)$views[(int)$row['product_id']]=(int)$row['total'];
  $sales=[];$stats=$wpdb->prefix.'wc_order_stats';if(self::table_exists($stats)){$sql="SELECT CAST(pid.meta_value AS UNSIGNED) product_id,SUM(CAST(qty.meta_value AS DECIMAL(18,4))) units,SUM(CAST(total.meta_value AS DECIMAL(18,4))) revenue FROM {$wpdb->prefix}woocommerce_order_items oi JOIN {$wpdb->prefix}woocommerce_order_itemmeta pid ON pid.order_item_id=oi.order_item_id AND pid.meta_key='_product_id' LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta qty ON qty.order_item_id=oi.order_item_id AND qty.meta_key='_qty' LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta total ON total.order_item_id=oi.order_item_id AND total.meta_key='_line_total' JOIN {$stats} os ON os.order_id=oi.order_id WHERE oi.order_item_type='line_item' AND os.date_created >= %s AND os.status IN ('wc-processing','wc-completed','wc-on-hold','wc-delivered') AND CAST(pid.meta_value AS UNSIGNED) IN ({$in}) GROUP BY CAST(pid.meta_value AS UNSIGNED)";foreach($wpdb->get_results($wpdb->prepare($sql,gmdate('Y-m-d H:i:s',time()-self::VIEW_DAYS*DAY_IN_SECONDS)),ARRAY_A) as $row)$sales[(int)$row['product_id']]=['units'=>(float)$row['units'],'revenue'=>(float)$row['revenue']];}
  $raw=[];foreach($ids as $id){$p=wc_get_product($id);if(!$p)continue;$raw[$id]=['views_30d'=>$views[$id]??0,'units_30d'=>$sales[$id]['units']??0.0,'revenue_30d'=>$sales[$id]['revenue']??0.0,'review_rating'=>(float)$p->get_average_rating(),'review_count'=>(int)$p->get_review_count()];$raw[$id]['review_confidence']=$raw[$id]['review_rating']*log(1+$raw[$id]['review_count']);}
  $dimensions=[];foreach(['views_30d','units_30d','revenue_30d','review_confidence'] as $field)$dimensions[$field]=array_values(array_filter(array_column($raw,$field),static fn($v)=>$v>0));$out=[];foreach($raw as $id=>$m){$score=.35*self::percentile($m['views_30d'],$dimensions['views_30d'])+.35*self::percentile($m['units_30d'],$dimensions['units_30d'])+.20*self::percentile($m['revenue_30d'],$dimensions['revenue_30d'])+.10*self::percentile($m['review_confidence'],$dimensions['review_confidence']);$has=$m['views_30d']>0||$m['units_30d']>0||$m['review_count']>0;$m['score']=$has?(int)round($score):0;$m['label']=!$has?'No data':($score>=75?'High':($score>=40?'Good':'Low'));$m['period_days']=self::VIEW_DAYS;unset($m['review_confidence']);$out[$id]=$m;}set_transient('dreminex_app_metric_map',$out,5*MINUTE_IN_SECONDS);return $out;
 }
}
