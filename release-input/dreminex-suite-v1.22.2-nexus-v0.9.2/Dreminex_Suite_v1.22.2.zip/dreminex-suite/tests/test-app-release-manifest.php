<?php
define('ABSPATH', __DIR__ . '/');
$fixture = sys_get_temp_dir() . '/dreminex-app-release-' . bin2hex(random_bytes(6)) . '/';
define('DREMINEX_SUITE_PATH', $fixture);
define('DREMINEX_SUITE_FILE', $fixture . 'dreminex-suite.php');

function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }
function esc_url_raw($value) { return filter_var((string) $value, FILTER_VALIDATE_URL) ? (string) $value : ''; }
function plugins_url($path, $plugin_file) { return 'https://store.example/wp-content/plugins/dreminex-suite/' . ltrim($path, '/'); }

require_once __DIR__ . '/../includes/class-dreminex-native-mcp.php';

function release_assert($condition, $message) {
    if (!$condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
}

mkdir($fixture . 'release-assets', 0700, true);
$apk = $fixture . 'release-assets/Dreminex_Nexus_v0.7.1.apk';
$exe = $fixture . 'release-assets/Dreminex_Nexus_Windows_v1.0.0_Setup.exe';
file_put_contents($apk, 'signed-apk-fixture');
$hash = hash_file('sha256', $apk);
$manifest = [
    'schema_version' => 1,
    'android' => ['version' => '0.7.1', 'file' => basename($apk), 'sha256' => $hash],
    'windows' => ['version' => '', 'download_url' => ''],
    'release_notes_url' => '',
];
file_put_contents($fixture . 'release-assets/nexus-app-release.json', json_encode($manifest));

$distribution = Dreminex_Native_MCP::app_distribution();
release_assert($distribution['android_version'] === '0.7.1', 'Android version should come from the generated manifest.');
release_assert($distribution['android_sha256'] === $hash, 'Android checksum should be read only when it matches the packaged APK.');
release_assert($distribution['android_download_url'] === 'https://store.example/wp-content/plugins/dreminex-suite/release-assets/' . basename($apk), 'Android URL should be derived from this plugin installation, not GitHub settings.');
release_assert($distribution['windows_download_url'] === '' && $distribution['windows_version'] === '', 'A release without the Windows installer must not advertise a broken download.');
release_assert($distribution['release_notes_url'] === '', 'A private GitHub release notes URL must not be exposed to connected app clients.');
release_assert(Dreminex_Native_MCP::app_release_manifest()['android']['download_url'] === $distribution['android_download_url'], 'The existing app-release schema should expose the dynamic package URL.');

$manifest['windows'] = ['version' => '1.0.0', 'download_url' => 'https://github.com/anime68/ChatGPT-cloud-repository/releases/download/dreminex-suite-v1.20.2-nexus-v0.7.1/Dreminex_Nexus_Windows_v1.0.0_Setup.exe'];
file_put_contents($fixture . 'release-assets/nexus-app-release.json', json_encode($manifest));
$external = Dreminex_Native_MCP::app_distribution();
release_assert($external['windows_download_url'] === '' && $external['windows_version'] === '', 'External Windows URLs must not be exposed because this release uses authenticated site-local assets.');

file_put_contents($exe, 'windows-installer-fixture');
$manifest['windows'] = ['version' => '1.0.0', 'file' => basename($exe)];
file_put_contents($fixture . 'release-assets/nexus-app-release.json', json_encode($manifest));
$legacy = Dreminex_Native_MCP::app_distribution();
release_assert($legacy['windows_download_url'] === 'https://store.example/wp-content/plugins/dreminex-suite/release-assets/' . basename($exe), 'Existing plugin packages with a bundled Windows installer remain compatible.');

file_put_contents($apk, 'modified-apk-fixture');
$tampered = Dreminex_Native_MCP::app_distribution();
release_assert($tampered['android_download_url'] === '' && $tampered['android_sha256'] === '', 'A checksum mismatch must prevent an APK update from being offered.');

unlink($fixture . 'release-assets/nexus-app-release.json');
unlink($apk);
unlink($exe);
rmdir($fixture . 'release-assets');
rmdir($fixture);
echo "Dynamic app release manifest tests: PASS\n";
