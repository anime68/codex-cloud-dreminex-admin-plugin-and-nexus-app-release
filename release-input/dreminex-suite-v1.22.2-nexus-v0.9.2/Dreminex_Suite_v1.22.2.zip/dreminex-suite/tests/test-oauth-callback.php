<?php
define('ABSPATH',__DIR__.'/');
class WP_Error {private $code;public function __construct($code){$this->code=$code;}public function get_error_code(){return $this->code;}}
function wp_parse_url($url,$component=-1){return parse_url($url,$component);}
function home_url($path=''){return 'https://cyan-horse-545619.hostingersite.com'.$path;}
require dirname(__DIR__).'/includes/class-dreminex-native-oauth.php';
$url=Dreminex_Native_OAuth::authorization_response_url('https://chatgpt.com/connector_platform_oauth_redirect?existing=yes',['code'=>'a+b','state'=>'x y']);
$expected='https://chatgpt.com/connector_platform_oauth_redirect?existing=yes&code=a%2Bb&state=x%20y&iss=https%3A%2F%2Fcyan-horse-545619.hostingersite.com%2Fdreminex-oauth';
if($url!==$expected){fwrite(STDERR,"Unexpected callback:\n$url\n");exit(1);}
if(!(Dreminex_Native_OAuth::authorization_response_url('https://chatgpt.com/callback#fragment',[]) instanceof WP_Error)){fwrite(STDERR,"Fragment was accepted\n");exit(1);}
echo "OAuth callback builder: PASS\n";

