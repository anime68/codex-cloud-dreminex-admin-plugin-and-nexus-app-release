<?php
define('ABSPATH', '/var/www/wordpress/');
define('DAY_IN_SECONDS', 86400);
$safe_root = sys_get_temp_dir() . '/dreminex-mcp-v3-' . bin2hex(random_bytes(5));
mkdir($safe_root, 0700, true);
define('DREMINEX_MCP_SAFE_ROOTS', ['test' => $safe_root]);

class WP_Error { private $code; private $message; private $data; public function __construct($code, $message = '', $data = []) { $this->code=$code; $this->message=$message; $this->data=$data; } public function get_error_code(){return $this->code;} public function get_error_message(){return $this->message;} }
class TestWPDB { public $options='wp_options'; public function esc_like($value){return addcslashes($value, '_%\\');} public function prepare($query, ...$args){return $query;} public function get_col($query){$names=[];foreach(array_keys($GLOBALS['test_options']) as $name)if(str_starts_with($name,'dreminex_mcp_design_'))$names[]=$name;return $names;} }
$GLOBALS['wpdb'] = new TestWPDB();
$GLOBALS['test_options'] = [];
$GLOBALS['test_user_id'] = 7;
$GLOBALS['test_posts'] = [42 => (object)['ID'=>42,'post_content'=>'<p>Old</p>','post_modified_gmt'=>'2026-10-26 00:00:00']];

function is_wp_error($value){return $value instanceof WP_Error;}
function sanitize_key($value){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$value));}
function sanitize_title($value){return trim(preg_replace('/[^a-z0-9-]+/','-',strtolower((string)$value)),'-');}
function sanitize_text_field($value){return trim(strip_tags((string)$value));}
function sanitize_textarea_field($value){return trim((string)$value);}
function absint($value){return abs((int)$value);}
function wp_normalize_path($value){return str_replace('\\','/',(string)$value);}
function current_user_can($capability,$object_id=null){if($capability==='manage_options')return $GLOBALS['test_user_id']===7;return in_array($capability,['edit_posts','edit_post'],true);}
function get_current_user_id(){return $GLOBALS['test_user_id'];}
function wp_get_current_user(){return new class {public $roles=['administrator'];public function exists(){return true;}};}
function wp_get_environment_type(){return 'staging';}
function home_url($path=''){return 'https://example.test'.$path;}
function esc_url_raw($value){return (string)$value;}
function get_bloginfo($key){return 'test';}
function wp_generate_uuid4(){return bin2hex(random_bytes(16));}
function wp_generate_password($length=8,$special=false,$extra=false){return substr(bin2hex(random_bytes((int)ceil($length/2))),0,$length);}
function wp_json_encode($value,$flags=0){return json_encode($value,$flags);}
function wp_kses_post($value){return (string)$value;}
function wp_mkdir_p($path){return is_dir($path)||mkdir($path,0700,true);}
function get_option($name,$default=false){return $GLOBALS['test_options'][$name]??$default;}
function update_option($name,$value,$autoload=null){$GLOBALS['test_options'][$name]=$value;return true;}
function delete_option($name){unset($GLOBALS['test_options'][$name]);return true;}
function get_post($id){return $GLOBALS['test_posts'][(int)$id]??null;}
function get_post_field($field,$id){$post=get_post($id);return $post->{$field}??'';}
function get_the_title($post){return 'Test post';}
function admin_url($path=''){return 'https://example.test/wp-admin/'.$path;}
function wp_get_abilities(){return [];}
function parse_blocks($content){return [$content];}
function serialize_blocks($blocks){return (string)($blocks[0]??'');}
function wp_kses_post_dummy($value){return $value;}
function wp_update_post($postarr,$wp_error=false){$id=(int)$postarr['ID'];$GLOBALS['test_posts'][$id]->post_content=$postarr['post_content'];$GLOBALS['test_posts'][$id]->post_modified_gmt='2026-10-26 00:01:00';return $id;}
function get_userdata($id){return null;}
function maybe_unserialize($value){return $value;}

require __DIR__ . '/../includes/class-dreminex-mcp-abilities-v3.php';
function guard_check($condition,$message){if(!$condition){fwrite(STDERR,"FAIL: {$message}\n");exit(1);}}
function remove_tree($path){if(!file_exists($path))return;if(is_dir($path)&&!is_link($path)){foreach(scandir($path) as $child)if($child!=='.'&&$child!=='..')remove_tree($path.'/'.$child);rmdir($path);}else unlink($path);}

try {
    file_put_contents($safe_root.'/settings.txt', "password=TopSecret\npublic=ok\n");
    $raw_hash=hash_file('sha256',$safe_root.'/settings.txt');
    $read=Dreminex_MCP_Abilities_V3::execute('dreminex-files/scoped-read',['root_id'=>'test','path'=>'settings.txt']);
    guard_check(!is_wp_error($read) && !str_contains($read['content'],'TopSecret') && str_contains($read['content'],'[REDACTED]'), 'Scoped reads must redact common secret fields.');
    guard_check(($read['sha256']??'')===$raw_hash && ($read['content_sha256']??'')===hash('sha256',$read['content']), 'Read metadata must keep the original revision hash separate from redacted bytes.');
    $edit=Dreminex_MCP_Abilities_V3::execute('dreminex-files/scoped-edit',['root_id'=>'test','path'=>'settings.txt','expected_sha256'=>$raw_hash,'content'=>'public=updated','confirm'=>true]);
    guard_check(!is_wp_error($edit) && file_get_contents($safe_root.'/settings.txt')==='public=updated', 'Revision-guarded text edits must save atomically.');
    $escape=Dreminex_MCP_Abilities_V3::execute('dreminex-files/scoped-read',['root_id'=>'test','path'=>'../outside.txt']);
    guard_check(is_wp_error($escape) && $escape->get_error_code()==='path_not_allowed', 'Parent traversal must be denied.');
    $php=Dreminex_MCP_Abilities_V3::execute('dreminex-files/scoped-write',['root_id'=>'test','path'=>'run.php','content'=>'<?php echo 1;','confirm'=>true]);
    guard_check(is_wp_error($php) && $php->get_error_code()==='file_type_not_allowed', 'Executable file extensions must be denied.');
    $html=Dreminex_MCP_Abilities_V3::execute('dreminex-files/scoped-write',['root_id'=>'test','path'=>'page.html','content'=>'<script>alert(1)</script>','confirm'=>true]);
    guard_check(is_wp_error($html) && $html->get_error_code()==='active_content_blocked', 'Active HTML must be denied.');
    $written=Dreminex_MCP_Abilities_V3::execute('dreminex-files/scoped-write',['root_id'=>'test','path'=>'config.json','content'=>'{"ok":true}','confirm'=>true]);
    guard_check(!is_wp_error($written) && json_decode(file_get_contents($safe_root.'/config.json'),true)['ok']===true, 'Valid JSON file creation must work in a configured root.');
    $trash_hash=hash_file('sha256',$safe_root.'/config.json');$trashed=Dreminex_MCP_Abilities_V3::execute('dreminex-files/scoped-trash',['root_id'=>'test','path'=>'config.json','expected_sha256'=>$trash_hash,'confirm'=>true]);
    guard_check(!is_wp_error($trashed) && !file_exists($safe_root.'/config.json') && is_file($safe_root.'/.dreminex-trash/'.$trashed['recovery_id']), 'Trash must move a file into the private scoped recovery folder.');
    $GLOBALS['test_options']['dreminex_mcp_design_brand']=['revision'=>str_repeat('a',64),'tokens'=>['color'=>'teal'],'saved_at'=>'2026-10-26T00:00:00Z'];
    $GLOBALS['test_options']['dreminex_mcp_active_design']='brand';
    $designs=Dreminex_MCP_Abilities_V3::execute('dreminex-design/design-list',['limit'=>20]);
    guard_check(count($designs['designs']??[])===1 && ($designs['designs'][0]['active']??false), 'Design listings must find non-autoloaded saved options.');
    $revision=hash('sha256',wp_json_encode(['color'=>'teal']));$GLOBALS['test_options']['dreminex_mcp_design_brand']['revision']=$revision;
    $activated=Dreminex_MCP_Abilities_V3::execute('dreminex-design/design-activate',['slug'=>'brand','expected_revision'=>$revision,'confirm'=>true]);
    guard_check(!is_wp_error($activated) && ($activated['activated']??false), 'Design activation must verify the exact saved revision.');
    $queue=Dreminex_MCP_Abilities_V3::execute('dreminex-editor/queue-create',['title'=>'Test queue']);$queue_id=$queue['queue_id']??'';
    $post=get_post(42);$post_revision=hash('sha256',$post->ID.'|'.$post->post_modified_gmt.'|'.$post->post_content);
    $candidate='<!-- wp:paragraph --><p>New</p><!-- /wp:paragraph -->';
    $change=Dreminex_MCP_Abilities_V3::execute('dreminex-editor/queue-add-change',['queue_id'=>$queue_id,'post_id'=>42,'expected_revision'=>$post_revision,'candidate_content'=>$candidate]);
    guard_check(!is_wp_error($change), 'Editor changes must stage against the current post revision.');
    $duplicate=Dreminex_MCP_Abilities_V3::execute('dreminex-editor/queue-add-change',['queue_id'=>$queue_id,'post_id'=>42,'expected_revision'=>$post_revision,'candidate_content'=>$candidate]);
    guard_check(is_wp_error($duplicate) && $duplicate->get_error_code()==='duplicate_post_target', 'A queue must reject an ambiguous second change for the same post.');
    $ready=Dreminex_MCP_Abilities_V3::execute('dreminex-editor/queue-ready',['queue_id'=>$queue_id,'confirm'=>true]);
    $read_queue=Dreminex_MCP_Abilities_V3::execute('dreminex-editor/queue-read',['queue_id'=>$queue_id]);
    guard_check(!is_wp_error($ready) && !isset($read_queue['changes'][0]['candidate_content']), 'Ready queues must be reviewable without exposing staged bodies in MCP metadata.');
    $GLOBALS['test_user_id']=8;$other_user=Dreminex_MCP_Abilities_V3::execute('dreminex-editor/queue-read',['queue_id'=>$queue_id]);
    guard_check(is_wp_error($other_user), 'A different editor cannot read another user’s queue.');
    echo "Native MCP v3 guard tests: PASS (filesystem, design revision, editor queue)\n";
} finally { remove_tree($safe_root); }
