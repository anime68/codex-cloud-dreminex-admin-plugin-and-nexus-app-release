<?php
define('ABSPATH', __DIR__ . '/');
define('DREMINEX_SUITE_PATH', dirname(__DIR__) . '/');
define('DREMINEX_SUITE_VERSION', '1.21.1');
$GLOBALS['repair_options'] = ['dreminex_native_mcp_settings' => ['settings_schema'=>2,'abilities_enabled'=>1,'provider_states'=>[],'category_states'=>[],'ability_states'=>[]]];
$GLOBALS['repair_caps'] = ['manage_options'=>true,'manage_woocommerce'=>true,'upload_files'=>true,'edit_posts'=>true];
$GLOBALS['repair_abilities'] = [];
function get_option($key,$default=[]){return $GLOBALS['repair_options'][$key]??$default;}
function sanitize_key($value){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$value));}
function sanitize_text_field($value){return trim((string)$value);}
function absint($value){return abs((int)$value);}
function current_user_can($capability){return !empty($GLOBALS['repair_caps'][$capability]);}
function home_url($path=''){return 'https://staging.example'.(string)$path;}
function wp_parse_url($url,$component=-1){return parse_url($url,$component);}
function wp_get_environment_type(){return 'staging';}
function wp_get_abilities(){return $GLOBALS['repair_abilities'];}
function wp_get_ability($name){return $GLOBALS['repair_abilities'][$name]??null;}
function is_wp_error($value){return $value instanceof WP_Error;}
class WP_Error {private $code;private $message;private $data;public function __construct($code,$message='',$data=[]){$this->code=$code;$this->message=$message;$this->data=$data;}public function get_error_code(){return $this->code;}public function get_error_message(){return $this->message;}public function get_error_data(){return $this->data;}}
final class Repair_Ability {
 private $name;private $category;private $annotations;private $meta;public $executions=0;
 public function __construct($name,$category,$readonly,$provider=''){$this->name=$name;$this->category=$category;$this->annotations=['readonly'=>$readonly,'destructive'=>false,'idempotent'=>true];$this->meta=['annotations'=>$this->annotations,'mcp'=>['public'=>true]];if($provider!=='')$this->meta['provider_plugin']=$provider;}
 public function get_name(){return $this->name;}public function get_category(){return $this->category;}public function get_label(){return $this->name;}public function get_description(){return 'repair test';}public function get_annotations(){return $this->annotations;}public function get_meta(){return $this->meta;}public function get_input_schema(){return ['type'=>'object'];}public function get_output_schema(){return ['type'=>'object'];}public function check_permissions($input=[]){return true;}public function validate_input($input){return true;}public function execute($input){$this->executions++;return ['ok'=>true];}
}
require dirname(__DIR__) . '/includes/class-dreminex-mcp-registry-policy.php';
require dirname(__DIR__) . '/includes/class-dreminex-native-oauth.php';
require dirname(__DIR__) . '/includes/class-dreminex-native-mcp.php';
function repair_check($condition,$message){if(!$condition){fwrite(STDERR,"FAIL: {$message}\n");exit(1);}}
function repair_context($mode,$scopes,$selected=null){$property=new ReflectionProperty(Dreminex_Native_OAuth::class,'context');$property->setValue(null,['client_id'=>'repair','user_id'=>1,'permission_mode'=>$mode,'scopes'=>$scopes,'selected_scopes'=>$selected??$scopes,'scope_revision'=>Dreminex_Native_OAuth::SCOPE_REVISION,'reconnect_required'=>false]);}
function repair_add($name,$category,$readonly,$provider=''){$ability=new Repair_Ability($name,$category,$readonly,$provider);$GLOBALS['repair_abilities'][$name]=$ability;return $ability;}

$notification=repair_add('dreminex-operations/notifications-read','dreminex-operations',true);
$workflow=repair_add('dreminex-products/workflow-profile','dreminex-products',true);
$media_read=repair_add('dreminex-media/metadata-read','dreminex-media',true);
$media_write=repair_add('dreminex-media/metadata-update','dreminex-media',false);
$product=repair_add('dreminex-products/catalog','dreminex-products',true);
$supplier=repair_add('dreminex-suppliers/jobs-read','dreminex-suppliers',true);

repair_context('full_access',['mcp:discover'],['mcp:discover']);
repair_check(Dreminex_Native_MCP::authorization_decision('dreminex-media/metadata-read',$media_read)['reason_code']==='client_scope_not_allowed','Globally exposed but unselected abilities must be filtered.');
repair_context('full_access',['mcp:discover','media:read'],['mcp:discover','media:read']);
repair_check(Dreminex_Native_MCP::authorization_decision('dreminex-media/metadata-read',$media_read)['reason_code']==='authorized','Granting the exact read scope must expose the ability.');
$status=Dreminex_Native_OAuth::scope_status('full_access',['mcp:discover'],['mcp:discover','media:read']);
repair_check($status['reconnect_required']&&$status['granted_scope_count']===1&&$status['missing_scopes']===['media:read'],'Policy changes must not expand an existing token.');
repair_context('read_only',['mcp:discover','media:write'],['mcp:discover','media:write']);
repair_check(Dreminex_Native_MCP::authorization_decision('dreminex-media/metadata-update',$media_write)['reason_code']==='permission_mode_denied','Read-only clients must reject writes.');
repair_context('full_access',['mcp:discover'],['mcp:discover','media:read']);
repair_check(Dreminex_Native_MCP::authorization_decision('dreminex-media/metadata-read',$media_read)['reason_code']==='insufficient_scope','Full access must not bypass a missing token scope.');
$media_provider=Dreminex_MCP_Registry_Policy::provider('dreminex-media/metadata-read',$media_read);$GLOBALS['repair_options']['dreminex_native_mcp_settings']['provider_states'][$media_provider]=0;
repair_context('full_access',['mcp:discover','media:read'],['mcp:discover','media:read']);
repair_check(Dreminex_Native_MCP::authorization_decision('dreminex-media/metadata-read',$media_read)['reason_code']==='provider_disabled','Disabled providers must be unavailable.');
$GLOBALS['repair_options']['dreminex_native_mcp_settings']['provider_states']=[];
repair_check(Dreminex_Native_MCP::authorization_decision('dreminex-media/metadata-read',$media_read)['reason_code']==='authorized','Re-enabled providers must return to scoped discovery.');
repair_context('full_access',['mcp:discover','workflow:read'],['mcp:discover','workflow:read']);
repair_check(Dreminex_Native_MCP::authorization_decision('dreminex-products/workflow-profile',$workflow)['reason_code']==='authorized','Product workflow reads must use workflow:read.');
repair_check(Dreminex_MCP_Registry_Policy::required_scope('dreminex-media/metadata-read',true)==='media:read'&&Dreminex_MCP_Registry_Policy::required_scope('dreminex-media/metadata-update',false)==='media:write','Media read and write scopes must remain separate.');
repair_check(Dreminex_MCP_Registry_Policy::required_scope('dreminex-editor/block-type-read',true)==='editor:read'&&Dreminex_MCP_Registry_Policy::required_scope('dreminex-files/scoped-write',false)==='files:write'&&Dreminex_MCP_Registry_Policy::required_scope('dreminex-design/design-read',true)==='design:read'&&Dreminex_MCP_Registry_Policy::required_scope('dreminex-workflow/skills-save',false)==='skills:write','Editor, files, design and skills scopes must be exact.');
repair_check(Dreminex_MCP_Registry_Policy::required_scope('dreminex-operations/notifications-read',true)==='notifications:read','Operations notification reads must use notifications:read.');
$internal=repair_add('novamira/skill-prompt-example','novamira',true,'novamira');
repair_check(Dreminex_MCP_Registry_Policy::decision('novamira/skill-prompt-example',$internal)['reason_code']==='internal_helper','Novamira skill prompt helpers must remain internal.');
$adapter=repair_add('novamira-mcp-adapter/execute-ability','adapter',false,'novamira-mcp-adapter');
repair_check(Dreminex_MCP_Registry_Policy::decision('novamira-mcp-adapter/execute-ability',$adapter)['reason_code']==='internal_helper','Generic adapter execution must not bypass authorization.');
repair_check(Dreminex_MCP_Registry_Policy::required_scope('novamira/execute-php',false)==='security:write'&&in_array('security:write',Dreminex_Native_OAuth::high_risk_scopes(),true),'PHP execution must retain high-risk security scope protection.');
repair_check(str_contains(file_get_contents(dirname(__DIR__).'/includes/class-dreminex-native-oauth.php'),"issue_tokens(\$client_id,(int)\$row['user_id'],json_decode(\$row['scopes'],true))"),'Refresh flow must retain the exact stored scope set.');
repair_check(Dreminex_Native_OAuth::SCOPE_REVISION===3&&str_contains(file_get_contents(dirname(__DIR__).'/includes/class-dreminex-native-mcp.php'),"Cache-Control','no-store"),'Reconnect revision and no-store transport must remain explicit.');
repair_context('full_access',['mcp:discover','catalog:read','suppliers:read'],['mcp:discover','catalog:read','suppliers:read']);
repair_check(Dreminex_Native_MCP::authorization_decision('dreminex-products/catalog',$product)['reason_code']==='authorized'&&Dreminex_Native_MCP::authorization_decision('dreminex-suppliers/jobs-read',$supplier)['reason_code']==='authorized','Existing product and supplier reads must not regress.');
repair_check($media_read->executions===0&&$media_write->executions===0,'Authorization tests must not mutate WordPress data.');
echo "Native MCP OAuth discovery repair acceptance tests: PASS\n";
