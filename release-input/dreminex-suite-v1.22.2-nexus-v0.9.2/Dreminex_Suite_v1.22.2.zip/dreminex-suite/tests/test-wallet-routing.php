<?php
define('ABSPATH',__DIR__.'/');
require dirname(__DIR__).'/includes/class-dreminex-suite-routing.php';
function check($condition,$message){if(!$condition){fwrite(STDERR,"FAIL: $message\n");exit(1);}}

check(Dreminex_Suite_Routing::decision(true,false,'none')==='manual','Normal cart without API must use manual advance/full-payment route.');
check(Dreminex_Suite_Routing::decision(true,true,'none')==='api','Normal cart with a healthy API must use the provider route.');
check(Dreminex_Suite_Routing::decision(true,true,'all')==='cod','An all COD-only cart must use COD even when a provider is ready.');
check(Dreminex_Suite_Routing::decision(true,true,'mixed')==='mixed','A mixed COD-only/normal cart must stop before payment routing.');
check(Dreminex_Suite_Routing::blocked('cod',true,'manual')===true,'COD must be blocked for normal products.');
check(Dreminex_Suite_Routing::blocked('cod',true,'cod')===false,'COD must be allowed for an all COD-only cart.');
check(Dreminex_Suite_Routing::blocked('bacs',true,'cod')===true,'Delivery advance must be hidden for an all COD-only cart.');

$delivery=file_get_contents(dirname(__DIR__).'/modules/dreminex_delivery_advance.php');
check(strpos($delivery,"\$plan==='cod_only'?'Cash on Delivery'")!==false,'COD-only orders must be labelled as Cash on Delivery in order and email summaries.');
$app=file_get_contents(dirname(__DIR__).'/includes/class-dreminex-nexus-app.php');
check(strpos($app,'/cod-policy')!==false && strpos($app,'_dreminex_cod_only')!==false,'Nexus must expose a guarded product-only COD policy control.');

$wallet=file_get_contents(dirname(__DIR__).'/modules/dreminex_customer_wallet.php');
check(strpos($wallet,"source='promo'")!==false && strpos($wallet,"withdrawable=1")!==false,'Wallet must retain separate promo and withdrawable-cash queries.');
check(strpos($wallet,"CASE WHEN source='promo' THEN 0 ELSE 1 END")!==false,'Purchases must spend promotional credit before cash.');
check(substr_count($wallet,'UNIQUE KEY idempotency_key')>=2,'Wallet credit and entry ledgers must retain idempotency keys.');
check(strpos($wallet,"\$source === 'cash' ? 1 : 0")!==false,'Only customer cash lots may be withdrawable.');

echo "Delivery Advance, Wallet and product-only COD policy: PASS\n";
