<?php
define('ABSPATH', __DIR__ . '/');
define('DREMINEX_SUITE_VERSION', '1.19.0');
$GLOBALS['opts'] = [
    'dreminex_suite_modules' => ['ai_product_publisher' => 1],
    'dreminex_ai_publisher_settings' => ['max_variation_rows' => 564, 'sku_prefix' => 'DRX', 'ability_access_mode' => 'full_access', 'ability_states' => []],
];
class WP_Error {
    private $code; private $message; private $data;
    public function __construct($code, $message = '', $data = null) { $this->code=$code; $this->message=$message; $this->data=$data; }
    public function get_error_code(){ return $this->code; }
    public function get_error_message(){ return $this->message; }
    public function get_error_data(){ return $this->data; }
}
function is_wp_error($value){ return $value instanceof WP_Error; }
function add_action(){ return true; } function add_filter(){ return true; }
function get_option($name,$default=false){ return array_key_exists($name,$GLOBALS['opts']) ? $GLOBALS['opts'][$name] : $default; }
function update_option($name,$value,$autoload=false){ $GLOBALS['opts'][$name]=$value; return true; }
function delete_option($name){ unset($GLOBALS['opts'][$name]); return true; }
function wp_parse_args($args,$defaults=[]){ return array_merge($defaults,is_array($args)?$args:[]); }
function absint($value){ return abs((int)$value); }
function sanitize_key($value){ return strtolower(preg_replace('/[^a-z0-9_\-]/','',(string)$value)); }
function sanitize_text_field($value){ return trim(strip_tags((string)$value)); }
function sanitize_textarea_field($value){ return trim(strip_tags((string)$value)); }
function sanitize_title($value){ $value=strtolower(remove_accents(strip_tags((string)$value))); $value=preg_replace('/[^a-z0-9]+/','-',$value); return trim($value,'-'); }
function remove_accents($value){ return (string)$value; }
function untrailingslashit($value){ return rtrim((string)$value,'/'); }
function home_url($path=''){ return 'https://staging.example.test'.($path ? '/'.ltrim($path,'/') : ''); }
function esc_url_raw($value){ return (string)$value; }
function wp_json_encode($value,$flags=0){ return json_encode($value,$flags); }
function wp_strip_all_tags($value){ return strip_tags((string)$value); }
function wc_format_decimal($value){ if($value===''||$value===null)return ''; return number_format((float)$value,2,'.',''); }
function wc_attribute_taxonomy_name($slug){ return 'pa_'.preg_replace('/^pa_/','',(string)$slug); }
function wc_attribute_taxonomy_id_by_name($slug){ $slug=preg_replace('/^pa_/','',(string)$slug); return in_array($slug,['color','kids-size'],true)?($slug==='color'?1:2):0; }
function wc_attribute_label($taxonomy){ return $taxonomy==='pa_color'?'Color':($taxonomy==='pa_kids-size'?'Kids Size':$taxonomy); }
function taxonomy_exists($taxonomy){ return in_array($taxonomy,['product_cat','product_tag','pa_color','pa_kids-size'],true); }
function get_term($id,$taxonomy=''){
    if($taxonomy==='product_cat' && (int)$id===7) return (object)['term_id'=>7,'name'=>'Kids Fashion','slug'=>'kids-fashion','parent'=>0];
    return false;
}
function get_term_by(){ return false; }
function get_term_meta(){ return ''; }
function get_post_meta($id,$key='',$single=false){ return ''; }
function get_posts(){ return []; }
function wc_get_product(){ return null; }
function wc_get_product_id_by_sku(){ return 0; }
function sanitize_hex_color($value){ return preg_match('/^#[0-9a-f]{6}$/i',(string)$value)?strtolower($value):null; }
function current_time(){ return '2026-10-22 00:00:00'; }
function wp_generate_uuid4(){ static $i=0; $i++; return sprintf('00000000-0000-4000-8000-%012d',$i); }
function get_permalink($id){ return 'https://staging.example.test/product/'.$id; }
function wp_get_object_terms(){ return []; }
function wp_get_attachment_url($id){ return 'https://staging.example.test/uploads/'.$id.'.jpg'; }
function __($v){ return $v; }

require dirname(__DIR__).'/modules/dreminex_ai_product_publisher.php';

function fail_test($message,$context=null){ fwrite(STDERR,"FAIL: $message\n"); if($context!==null)fwrite(STDERR,var_export($context,true)."\n"); exit(1); }
function assert_true($condition,$message,$context=null){ if(!$condition)fail_test($message,$context); }
function handoff_fixture(int $colors, int $sizes): array {
    $colorRows=[]; $sizeRows=[]; $variants=[];
    for($c=1;$c<=$colors;$c++) $colorRows[]=['name'=>'Design '.$c,'mode'=>'color','hex'=>sprintf('#%06x',0x110000+$c)];
    for($s=1;$s<=$sizes;$s++) $sizeRows[]=(string)(70+$s*10);
    foreach($colorRows as $ci=>$color) foreach($sizeRows as $size) $variants[]=['color'=>$color['name'],'size'=>$size,'regular_price'=>'900','sale_price'=>'700','stock_status'=>'instock'] + ($ci===0?['supplier_sku'=>'SUP-77']:[]);
    return [
        'handoff_type'=>'PUBLISHER HANDOFF','site_url'=>'https://staging.example.test/','site_lock'=>['url'=>'https://staging.example.test/'],
        'mode'=>'draft','product_id'=>null,'type'=>'variable','name'=>'Kids Printed Co-ord Set','slug'=>'kids-printed-co-ord-set',
        'sku'=>'DRX-KIDS-COORD','category_ids'=>[7],'category_names'=>['Kids Fashion'],'size_attribute'=>'pa_kids-size','color_attribute'=>'pa_color',
        'short_description'=>'Soft printed co-ord set for everyday kids wear.','description'=>'<h3>Kids Printed Co-ord Set</h3><p>A comfortable two-piece set with playful printed styling.</p>',
        'seo'=>['title'=>'Kids Printed Co-ord Set','description'=>'Shop a comfortable printed kids co-ord set.','focus_keyphrase'=>'kids printed co-ord set'],
        'tags'=>['kids co-ord','printed set'],'colors'=>$colorRows,'sizes'=>$sizeRows,'images'=>[],
        'variants'=>$variants,'full_matrix'=>true,'stock_status'=>'instock'
    ];
}

$case64=handoff_fixture(8,8);
$r64=Dreminex_Suite_AI_Product_Publisher::handoff_preflight(['handoff'=>$case64]);
assert_true($r64['ready']===true && $r64['normalized_variation_count']===64,'64-row handoff should be ready',$r64);
assert_true($r64['listing_parameters']['variants'][0]['sku']==='DRX-KIDS-COORD-DESIGN-1-80-SUP-77','supplier code should append to parent-based child SKU',$r64['listing_parameters']['variants'][0]);
assert_true($r64['listing_parameters']['variants'][8]['sku']==='DRX-KIDS-COORD-DESIGN-2-80','missing supplier code should keep unique parent-based child SKU',$r64['listing_parameters']['variants'][8]);

$case144=handoff_fixture(16,9);
$r144=Dreminex_Suite_AI_Product_Publisher::handoff_preflight(['handoff'=>$case144]);
assert_true($r144['ready']===true && $r144['normalized_variation_count']===144,'144-row handoff should be ready',$r144);
assert_true(count(array_unique(array_column($r144['listing_parameters']['variants'],'sku')))===144,'all normalized child SKUs must be unique');

$case564=handoff_fixture(47,12);
$r564=Dreminex_Suite_AI_Product_Publisher::handoff_preflight(['handoff'=>$case564]);
assert_true($r564['ready']===true && $r564['normalized_variation_count']===564,'configured maximum should pass',$r564);
$case565=handoff_fixture(113,5);
$r565=Dreminex_Suite_AI_Product_Publisher::handoff_preflight(['handoff'=>$case565]);
assert_true($r565['ready']===false && in_array('This handoff contains 565 variation rows, but the current site limit is 564 (hard maximum 564). Increase the dashboard limit or reduce the confirmed offered rows; nothing was saved.',$r565['hard_errors'],true),'above-capacity handoff must fail clearly',$r565);

$recoverable=handoff_fixture(2,2);
$recoverable['size_attribute']='pa_new-size';
$recoverable['publisher_prerequisites']=[['action'=>'ensure_attribute','kind'=>'size','label'=>'New Size','slug'=>'new-size','attribute_type'=>'select','terms'=>$recoverable['sizes']]];
$rr=Dreminex_Suite_AI_Product_Publisher::handoff_preflight(['handoff'=>$recoverable]);
assert_true($rr['ready']===false && $rr['recoverable']===true && $rr['workflow_state']==='ready_after_prerequisites','missing declared attribute should be recoverable',$rr);
assert_true(($rr['prerequisite_actions'][0]['action']??'')==='ensure_attribute','attribute prerequisite should be normalized',$rr);

$wrong=handoff_fixture(1,1); $wrong['site_lock']['url']='https://production.example.test/';
$rw=Dreminex_Suite_AI_Product_Publisher::handoff_preflight(['handoff'=>$wrong]);
assert_true($rw['ready']===false && $rw['workflow_state']==='blocked_external','immutable site mismatch must block',$rw);

$rule='When the same safe prerequisite repeats, resolve it before fresh preflight and keep the same site lock.';
for($i=1;$i<=3;$i++){
    $final=Dreminex_AI_Workflow_Projects::finalize_task(['profile'=>'publisher','task_id'=>'task-'.$i.'-stable','action'=>'handoff-execute','outcome'=>'completed','product_id'=>100+$i,'issue_code'=>'missing_size_attribute','resolution_code'=>'ensure_attribute_then_preflight','evidence_hash'=>hash('sha256','evidence-'.$i),'observation'=>'Saved readback matched the complete handoff.','proposed_rule'=>$rule]);
}
assert_true($final['verified_pattern_count']===3 && $final['proposal_queued']===true && $final['active_instructions_changed']===false,'third verified pattern should queue admin review without changing instructions',$final);
$duplicate=Dreminex_AI_Workflow_Projects::finalize_task(['profile'=>'publisher','task_id'=>'task-3-stable','action'=>'handoff-execute','outcome'=>'completed','issue_code'=>'missing_size_attribute','resolution_code'=>'ensure_attribute_then_preflight','evidence_hash'=>hash('sha256','evidence-3')]);
assert_true($duplicate['duplicate']===true && $duplicate['recorded']===false,'task finalization must be idempotent',$duplicate);
$profile=Dreminex_AI_Workflow_Projects::read_profile(['profile'=>'publisher']);
assert_true(!is_wp_error($profile) && ($profile['operational_hints'][0]['verified_count']??0)===3,'verified operational hint should be visible in profile',$profile);

echo "Advanced Hybrid product workflow: PASS\n";
