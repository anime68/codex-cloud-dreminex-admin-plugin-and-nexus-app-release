<?php
/** Source-contract checks for the v1.19 release surfaces that have no WordPress runtime dependency. */
function check_v119($condition, $message) { if (!$condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } }
$root = dirname(__DIR__);
$mail = file_get_contents($root . '/modules/dreminex_mail_engine.php');
$native = file_get_contents($root . '/includes/class-dreminex-native-mcp.php');
$app = file_get_contents($root . '/includes/class-dreminex-nexus-app.php');
$supplier = file_get_contents($root . '/modules/class-dreminex-supplier-nexus.php');

check_v119(strpos($mail, "'module_enabled'=>false") !== false && strpos($mail, "'operating_mode'=>'monitor'") !== false, 'Mail Engine must remain disabled and monitor-first by default.');
check_v119(strpos($mail, "DREMINEX_MAIL_ENGINE_KEY") !== false && strpos($mail, "aes-256-gcm") !== false, 'Mail Engine must require a server-side encryption key and AES-GCM.');
check_v119(strpos($mail, "['wp_mail','smtp','resend','brevo','smtp2go']") !== false, 'Mail Engine transport contract must retain WordPress mail, SMTP and declared providers.');
check_v119(strpos($mail, "dreminex_mail_engine_guard_contact") !== false, 'Mail Engine must retain the contact bot guard adapter.');
check_v119(strpos($native, "app_release_manifest") !== false && strpos($native, "app_feature_catalog") !== false, 'Native MCP must provide release and capability metadata.');
check_v119(strpos($app, "/nexus/app-release") !== false && strpos($app, "/nexus/app-capabilities") !== false, 'Nexus app API must expose paired release and capability routes.');
check_v119(strpos($app, 'const NOTIFICATION_DAYS=7') !== false && strpos($app, 'notification_delivery') !== false && strpos($app, "'sync_fallback'") !== false, 'Nexus notifications must retain seven-day cleanup and disclose the configured delivery path.');
check_v119(strpos($app, "app_feature_disabled") !== false, 'Disabled optional capability must be enforced server-side.');
check_v119(strpos($supplier, 'mapped_product_for_url') !== false && strpos($supplier, 'canonical_supplier_url($url)') !== false && strpos($supplier, "'manual_webview'") !== false, 'Custom supplier profiles must resolve canonical HTTPS mappings through saved browser sessions.');
check_v119(strpos($native, "app_feature_available") !== false && strpos($native, "class_exists('Dreminex_Supplier_Nexus')") === false, 'Supplier Monitor app capability must require the enabled module, not only a loaded class.');
echo "Suite v1.19 contracts: PASS\n";
