<?php
function check_v3_contract($condition, $message) {
    if (!$condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
}

$root = dirname(__DIR__);
$spec = json_decode((string) file_get_contents($root . '/data/native-mcp-abilities-v3.json'), true);
$policy = file_get_contents($root . '/includes/class-dreminex-mcp-registry-policy.php');
$oauth = file_get_contents($root . '/includes/class-dreminex-native-oauth.php');
$ability_v2 = file_get_contents($root . '/includes/class-dreminex-mcp-abilities-v2.php');
$ability_v3 = file_get_contents($root . '/includes/class-dreminex-mcp-abilities-v3.php');
$native = file_get_contents($root . '/includes/class-dreminex-native-mcp.php');

$expected = [
    'dreminex-developer/sandbox-code-task', 'dreminex-files/scoped-read', 'dreminex-files/scoped-write',
    'dreminex-files/scoped-edit', 'dreminex-files/scoped-trash', 'dreminex-admin/access-exchange-request',
    'dreminex-files/sandbox-disable', 'dreminex-files/sandbox-enable', 'dreminex-files/scoped-list',
    'dreminex-system/agent-context-read', 'dreminex-editor/finalizer-status', 'dreminex-editor/block-type-read',
    'dreminex-editor/queue-create', 'dreminex-editor/queue-add-change', 'dreminex-editor/queue-ready',
    'dreminex-editor/queue-read', 'dreminex-editor/queue-list', 'dreminex-editor/queue-cancel',
    'dreminex-editor/queue-cancel-change', 'dreminex-editor/finalization-url', 'dreminex-workflow/skills-delete',
    'dreminex-design/design-list', 'dreminex-design/design-activate', 'dreminex-design/design-delete',
];

check_v3_contract(is_array($spec) && count($spec['abilities'] ?? []) === 24, 'The Native MCP v3 spec must include all 24 canonical additions.');
$abilities = $spec['abilities'];
$names = array_column($abilities, 'name');
sort($names); sort($expected);
check_v3_contract($names === $expected, 'All 24 canonical names must be present exactly once.');
foreach ($abilities as $ability) {
    check_v3_contract(($ability['input_schema']['type'] ?? '') === 'object', 'Every v3 ability must declare an object schema.');
    check_v3_contract(($ability['input_schema']['additionalProperties'] ?? null) === false, 'Every v3 ability must reject undeclared input fields.');
    if (in_array($ability['operation'] ?? '', ['critical','destructive'], true)) check_v3_contract(isset($ability['default_enabled']), 'Critical/destructive v3 abilities must carry explicit contract metadata.');
}
check_v3_contract(str_contains($oauth, "'editor:read','editor:write','files:read','files:write','security:read','security:write'"), 'OAuth must expose the requested editor, file and security scopes.');
check_v3_contract(str_contains($policy, "'files:' . (\$write ? 'write' : 'read')") && str_contains($policy, "'editor:' . (\$write ? 'write' : 'read')"), 'File and editor abilities must map to their dedicated scopes.');
check_v3_contract(str_contains($policy, "return preg_match('/^[a-z0-9][a-z0-9-]{0,62}$/', \$namespace) ? 'external-'"), 'Unrecognized namespaced providers must be surfaced as external and denied by default.');
check_v3_contract(str_contains($policy, 'provider_unknown') && str_contains($policy, 'internal_helper') && str_contains($native, 'Every eligible ability is available automatically.'), 'Unknown providers and internal helpers must remain isolated from the automatic Abilities Hub.');
check_v3_contract(str_contains($native, 'admin_post_dreminex_mcp_editor_finalize') && str_contains($native, 'wp_nonce_field(\'dreminex_mcp_editor_finalize_'), 'Editor finalization must require the authenticated WordPress admin screen and nonce.');
check_v3_contract(str_contains($native, 'post_content') && str_contains($native, 'queue_not_ready') && str_contains($native, 'revision_conflict'), 'The editor finalizer must remain revision guarded and explicit.');
check_v3_contract(str_contains($ability_v3, 'safe_roots') && str_contains($ability_v3, 'symlink_not_allowed') && str_contains($ability_v3, 'file_type_not_allowed'), 'Scoped filesystem actions must enforce configured roots, reject symlinks and restrict file types.');
check_v3_contract(str_contains($ability_v3, 'expected_revision') && str_contains($ability_v3, 'file_revision_conflict'), 'File edits must check exact current revisions.');
check_v3_contract(str_contains($ability_v3, 'access_exchange_disabled') && str_contains($ability_v3, 'execution_sandbox_unavailable'), 'Unavailable high-risk primitives must fail closed.');
check_v3_contract(str_contains($ability_v2, 'mark_owned($name)') && !str_contains($policy, "if (str_starts_with(\$name, 'dreminex-')) return 'dreminex-suite'"), 'Provider identity must not be inferred from a Dreminex-looking namespace alone.');
check_v3_contract(str_contains($ability_v2, "'dreminex-system/agent-context-read','dreminex-workflow/skills-delete','dreminex-design/design-list','dreminex-design/design-activate','dreminex-design/design-delete'") && str_contains($ability_v2, 'return Dreminex_MCP_Abilities_V3::execute($name, $input);'), 'Agent context, design and skill lifecycle abilities must dispatch to the guarded v3 handlers.');
check_v3_contract(!preg_match('/\b(?:eval|shell_exec|exec|passthru)\s*\(/i', $ability_v3), 'The v3 handlers must not add raw PHP or shell execution.');
echo "Native MCP v3 contract checks: PASS (24 canonical abilities)\n";
