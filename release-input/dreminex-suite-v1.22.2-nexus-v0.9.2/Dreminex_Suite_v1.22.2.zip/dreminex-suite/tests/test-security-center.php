<?php
define('ABSPATH', __DIR__ . '/');
define('MINUTE_IN_SECONDS', 60);
define('HOUR_IN_SECONDS', 3600);
define('DAY_IN_SECONDS', 86400);

class WP_Error {
    private $code;
    public function __construct($code, $message = '', $data = null) { $this->code = $code; }
    public function get_error_code() { return $this->code; }
}
class Security_Test_DB {
    public $prefix = 'wp_';
    public function prepare($query, ...$args) { return $query; }
    public function query($query) { return false; }
    public function get_var($query) { return null; }
}
$GLOBALS['wpdb'] = new Security_Test_DB();
$GLOBALS['security_options'] = [];
$GLOBALS['security_transients'] = [];
function is_wp_error($value) { return $value instanceof WP_Error; }
function add_filter() { return true; }
function add_action() { return true; }
function do_action() { return true; }
function get_option($name, $default = false) { return $GLOBALS['security_options'][$name] ?? $default; }
function update_option($name, $value, $autoload = null) { $GLOBALS['security_options'][$name] = $value; return true; }
function wp_salt($scheme = 'auth') { return 'security-test-salt-that-is-not-a-real-secret'; }
function absint($value) { return abs((int)$value); }
function sanitize_key($value) { return strtolower(preg_replace('/[^a-z0-9_-]/', '', (string)$value)); }
function sanitize_email($value) { return filter_var((string)$value, FILTER_SANITIZE_EMAIL); }
function get_transient($key) { return $GLOBALS['security_transients'][$key] ?? false; }
function set_transient($key, $value, $ttl = 0) { $GLOBALS['security_transients'][$key] = $value; return true; }

require dirname(__DIR__) . '/includes/class-dreminex-security-center.php';

function security_assert($ok, $message) {
    if (!$ok) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
}

Dreminex_Security_Center::update_settings([
    'contact_max_per_10_minutes'=>2,
    'contact_max_per_day'=>10,
    'contact_email_max_per_hour'=>5,
    'login_max_failures'=>3,
    'login_lock_minutes'=>15,
]);

$_SERVER['REMOTE_ADDR'] = '192.0.2.44';
$valid = ['email'=>'buyer@example.test','message'=>'Please check my order.','started_at'=>time()-10,'honeypot'=>''];
$bot = Dreminex_Security_Center::guard_contact(true, array_merge($valid,['honeypot'=>'https://spam.example']));
security_assert(is_wp_error($bot) && $bot->get_error_code()==='contact_blocked', 'Filled honeypot must be rejected.');
$fast = Dreminex_Security_Center::guard_contact(true, array_merge($valid,['started_at'=>time()-1]));
security_assert(is_wp_error($fast), 'Sub-minimum form completion must be rejected.');
$linked = Dreminex_Security_Center::guard_contact(true, array_merge($valid,['message'=>'Visit https://one.example and https://two.example']));
security_assert(is_wp_error($linked), 'Messages over the configured link limit must be rejected.');
security_assert(Dreminex_Security_Center::guard_contact(true,$valid)===true, 'First allowed contact submission should pass.');
security_assert(Dreminex_Security_Center::guard_contact(true,array_merge($valid,['message'=>'A different support request.']))===true, 'Second allowed contact submission should pass.');
$over_limit = Dreminex_Security_Center::guard_contact(true,array_merge($valid,['message'=>'A third support request.']));
security_assert(is_wp_error($over_limit), 'Contact burst limit must reject the next submission.');

$_SERVER['REMOTE_ADDR'] = '198.51.100.18';
$_SERVER['REQUEST_METHOD'] = 'POST';
$_SERVER['SCRIPT_NAME'] = '/wp-login.php';
for ($i=0; $i<3; $i++) Dreminex_Security_Center::record_login_failure('test-user');
$locked = Dreminex_Security_Center::guard_login(null,'test-user','wrong-password');
security_assert(is_wp_error($locked) && $locked->get_error_code()==='dreminex_login_rate_limited', 'Login threshold must activate a temporary lockout.');

$clamped = Dreminex_Security_Center::update_settings(['login_lock_minutes'=>999,'event_retention_days'=>1]);
security_assert($clamped['login_lock_minutes']===120 && $clamped['event_retention_days']===7, 'Settings must be clamped to safe supported ranges.');

echo "Security Center protections: PASS\n";
