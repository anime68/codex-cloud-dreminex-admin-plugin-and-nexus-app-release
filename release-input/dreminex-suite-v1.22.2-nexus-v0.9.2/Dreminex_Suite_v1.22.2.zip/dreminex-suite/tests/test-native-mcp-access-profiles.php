<?php
define('ABSPATH', __DIR__ . '/');
define('DREMINEX_SUITE_PATH', dirname(__DIR__) . '/');
$GLOBALS['dmcp_settings'] = ['abilities_enabled'=>1,'provider_states'=>[],'category_states'=>[],'ability_states'=>[]];
$GLOBALS['dmcp_environment'] = 'staging';
function sanitize_key($value){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$value));}
function absint($value){return abs((int)$value);}
final class Dreminex_Native_MCP {
    public static function settings(){return array_replace(['abilities_enabled'=>1,'provider_states'=>[],'category_states'=>[],'ability_states'=>[]],$GLOBALS['dmcp_settings']);}
    public static function environment(){return $GLOBALS['dmcp_environment'];}
}
final class Dreminex_Native_OAuth {
    public static function scopes(){return ['mcp:discover','site:read','site:write','catalog:read','catalog:write','orders:read','orders:write','files:read','files:write','security:read','security:write'];}
}
final class Profile_Test_Ability {
    private $name; private $category; private $annotations;
    public function __construct($name,$category,$annotations){$this->name=$name;$this->category=$category;$this->annotations=$annotations;}
    public function get_name(){return $this->name;}
    public function get_category(){return $this->category;}
    public function get_annotations(){return $this->annotations;}
    public function get_meta(){return [];}
}
require dirname(__DIR__) . '/includes/class-dreminex-mcp-registry-policy.php';
function profile_check($condition,$message){if(!$condition){fwrite(STDERR,"FAIL: {$message}\n");exit(1);}}

$critical=new Profile_Test_Ability('dreminex-developer/sandbox-code-task','dreminex-developer',['readonly'=>false,'destructive'=>true,'idempotent'=>false]);
$decision=Dreminex_MCP_Registry_Policy::decision('dreminex-developer/sandbox-code-task',$critical);
profile_check($decision['enabled']===true&&$decision['required_scope']==='security:write','Staging critical abilities must be automatically eligible under exact scope and later approval policy.');
$internal=new Profile_Test_Ability('core/get-site-info','site',['readonly'=>true,'destructive'=>false,'idempotent'=>true]);
profile_check(Dreminex_MCP_Registry_Policy::decision('core/get-site-info',$internal)['reason_code']==='internal_helper','Core context helpers must remain internal.');
$adapter=new Profile_Test_Ability('novamira-mcp-adapter/execute-ability','adapter',['readonly'=>false,'destructive'=>true,'idempotent'=>false]);
profile_check(Dreminex_MCP_Registry_Policy::decision('novamira-mcp-adapter/execute-ability',$adapter)['reason_code']==='internal_helper','Recursive adapter execution must remain internal.');
profile_check(Dreminex_MCP_Registry_Policy::required_scope('novamira/read-file',true)==='files:read','Novamira reads must map automatically.');
profile_check(Dreminex_MCP_Registry_Policy::required_scope('novamira/write-file',false)==='files:write','Novamira writes must map automatically.');
profile_check(Dreminex_MCP_Registry_Policy::required_scope('woocommerce/orders-query',true)==='orders:read','WooCommerce order reads must use order scope.');
$GLOBALS['dmcp_settings']['ability_states']['dreminex-developer/sandbox-code-task']=0;
profile_check(Dreminex_MCP_Registry_Policy::decision('dreminex-developer/sandbox-code-task',$critical)['reason_code']==='ability_disabled','An explicit ability disable must override automatic enablement.');
$GLOBALS['dmcp_settings']['ability_states']=[];$GLOBALS['dmcp_settings']['category_states']['dreminex-developer']=0;
profile_check(Dreminex_MCP_Registry_Policy::decision('dreminex-developer/sandbox-code-task',$critical)['reason_code']==='category_disabled','A category disable must override automatic enablement.');
$GLOBALS['dmcp_settings']['category_states']=[];$GLOBALS['dmcp_environment']='production';
profile_check(Dreminex_MCP_Registry_Policy::decision('dreminex-developer/sandbox-code-task',$critical)['reason_code']==='production_guard','Developer abilities must fail closed in production.');
echo "Native MCP automatic access profile policy: PASS\n";
