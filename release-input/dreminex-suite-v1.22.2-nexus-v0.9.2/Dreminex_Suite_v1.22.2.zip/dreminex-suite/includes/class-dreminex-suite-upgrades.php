<?php
if (!defined('ABSPATH')) exit;
/** Additive, repeatable upgrades. Never reset merchant settings or business records. */
final class Dreminex_Suite_Upgrades {
 const SCHEMA=5;
 public static function run() {
  $schema=(int)get_option('dreminex_suite_schema_version',0);
  if($schema>self::SCHEMA)return; // An older package must not reverse a newer schema.
  if($schema<1){
   // add_option preserves existing values, including explicitly disabled options.
   foreach(['dreminex_suite_auto_newsletter'=>1,'dreminex_suite_classic_bridge'=>1] as $name=>$value)add_option($name,$value,'',false);
  }
  if($schema<2){
   // Add per-provider wallet records from the legacy receiver, without deleting or changing it.
   $settings=(array)get_option('dreminex_suite_module_settings',[]);
   $delivery=(array)($settings['delivery_advance']??[]);
   if(empty($delivery['wallet_bkash_number']) && !empty($delivery['wallet_number'])){
    $number=preg_replace('/\D/','',(string)$delivery['wallet_number']);
    $type=in_array(($delivery['account_type']??'personal'),['personal','merchant'],true)?$delivery['account_type']:'personal';
    foreach(['bkash','nagad','rocket'] as $provider){$delivery['wallet_'.$provider.'_number']=$number;$delivery['wallet_'.$provider.'_type']=$type;$delivery['wallet_'.$provider.'_enabled']=1;}
    $delivery['wallet_upay_number']='';$delivery['wallet_upay_type']='personal';$delivery['wallet_upay_enabled']=0;
    $settings['delivery_advance']=$delivery;update_option('dreminex_suite_module_settings',$settings,false);
   }
   add_option('dreminex_suite_email_branding',[], '', false);
   update_option('dreminex_suite_schema_version',2,false);
  }
  if($schema<3){
   $modules=(array)get_option('dreminex_suite_modules',[]);$settings=(array)get_option('dreminex_suite_module_settings',[]);
   $groups=[
    'checkout_protection'=>[
     'phone_enabled'=>'phone_validation','ip_cooldown_enabled'=>'duplicate_checkout','receipt_ip_enabled'=>'receipt_ip_warning','browser_limit_enabled'=>'customer_order_limit','partial_checkout_enabled'=>'partial_checkout'
    ],
    'checkout_experience'=>['receipt_enabled'=>'receipt_message','popup_enabled'=>'checkout_error_popup'],
    'order_management'=>['history_enabled'=>'customer_history','admin_alert_enabled'=>'admin_order_alert','owner_email_enabled'=>'order_email_notification','statuses_enabled'=>'order_statuses','tracking_enabled'=>'order_tracking'],
   ];
   foreach($groups as $parent=>$features){
    $known=false;$active=false;$parent_settings=(array)($settings[$parent]??[]);
    foreach($features as $flag=>$legacy){if(array_key_exists($legacy,$modules)){$known=true;$on=!empty($modules[$legacy]);$active=$active||$on;$parent_settings[$flag]=$on?1:0;}elseif(!array_key_exists($flag,$parent_settings))$parent_settings[$flag]=1;}
    if($known)$modules[$parent]=$active?1:0;elseif(!array_key_exists($parent,$modules))$modules[$parent]=0;
    $settings[$parent]=$parent_settings;foreach($features as $legacy){$modules[$legacy]=0;}
   }
   // Preserve configurable values from the former component tabs.
   $copy=[
    'checkout_protection'=>[
     'phone_validation'=>['msg_phone_invalid'],'duplicate_checkout'=>['cooldown_hours','msg_ip_cooldown'],'receipt_ip_warning'=>['msg_ip_warning'],
     'customer_order_limit'=>['msg_device_missing','msg_previous_unfinished','msg_today_unfinished']
    ],
    'checkout_experience'=>['receipt_message'=>['msg_receipt'],'checkout_error_popup'=>['title','message','button_text']],
    'order_management'=>['order_email_notification'=>['recipient']],
   ];
   foreach($copy as $parent=>$sources)foreach($sources as $legacy=>$names)foreach($names as $name)if(!array_key_exists($name,(array)$settings[$parent])&&array_key_exists($name,(array)($settings[$legacy]??[])))$settings[$parent][$name]=$settings[$legacy][$name];
   $registration_known=array_key_exists('registration_email',$modules);$reset_known=array_key_exists('password_reset',$modules);$registration_on=!empty($modules['registration_email']);$reset_on=!empty($modules['password_reset']);
   $settings['registration_email']=(array)($settings['registration_email']??[]);
   if(!array_key_exists('registration_core_enabled',$settings['registration_email']))$settings['registration_email']['registration_core_enabled']=$registration_known?($registration_on?1:0):1;
   if(!array_key_exists('password_reset_enabled',$settings['registration_email']))$settings['registration_email']['password_reset_enabled']=$reset_known?($reset_on?1:0):1;
   if($registration_known||$reset_known)$modules['registration_email']=($registration_on||$reset_on)?1:0;$modules['password_reset']=0;
   update_option('dreminex_suite_modules',$modules,false);update_option('dreminex_suite_module_settings',$settings,false);
   update_option('dreminex_suite_module_migration_map',['schema'=>3,'legacy_data_retained'=>true,'parents'=>array_keys($groups),'time'=>gmdate('c')],false);
   update_option('dreminex_suite_schema_version',3,false);
  }
  if($schema<4){
   // Consolidate the old module switch without touching encrypted profiles,
   // gateway options or historical order metadata.
   $modules=(array)get_option('dreminex_suite_modules',[]);
   if(!empty($modules['mobile_payment']))$modules['delivery_advance']=1;
   unset($modules['mobile_payment']);
   update_option('dreminex_suite_modules',$modules,false);
   update_option('dreminex_payment_module_migration',['schema'=>4,'target'=>'delivery_advance','legacy_options_retained'=>true,'time'=>gmdate('c')],false);
   update_option('dreminex_suite_schema_version',4,false);
  }
  if($schema<5){
   // Action Center is now an integrated Security view, not a switchable module.
   // Remove only its stale module toggle; retain unrelated options and records.
   $modules=(array)get_option('dreminex_suite_modules',[]);
   unset($modules['action_center']);
   update_option('dreminex_suite_modules',$modules,false);
   update_option('dreminex_suite_schema_version',5,false);
  }
  // Keep every current module visible to capability readers as an explicit
  // on/off state. Adding this default never enables Mail Engine or changes
  // its encrypted settings, queues, records or provider configuration.
  $modules=(array)get_option('dreminex_suite_modules',[]);
  if(!array_key_exists('mail_engine',$modules)){
   $modules['mail_engine']=0;
   update_option('dreminex_suite_modules',$modules,false);
  }
  $previous=(string)get_option('dreminex_suite_version','');
  if($previous===DREMINEX_SUITE_VERSION)return;
  $history=(array)get_option('dreminex_suite_upgrade_history',[]);
  $history[]=['from'=>$previous?:'fresh install','to'=>DREMINEX_SUITE_VERSION,'schema'=>self::SCHEMA,'time'=>gmdate('c'),'policy'=>'Additive upgrade; existing settings and records retained.'];
  update_option('dreminex_suite_upgrade_history',array_slice($history,-20),false);
  update_option('dreminex_suite_version',DREMINEX_SUITE_VERSION,false);
 }
}
