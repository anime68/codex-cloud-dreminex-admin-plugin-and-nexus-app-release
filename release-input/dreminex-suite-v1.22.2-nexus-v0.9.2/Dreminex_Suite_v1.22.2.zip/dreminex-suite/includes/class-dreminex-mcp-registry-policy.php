<?php
if (!defined('ABSPATH')) exit;

/** Automatic, profile-aware policy for the WordPress Abilities registry. */
final class Dreminex_MCP_Registry_Policy {
    private static $specs = null;
    private static $owned = [];

    public static function mark_owned($name) { self::$owned[(string) $name] = true; }
    public static function specs() {
        if (is_array(self::$specs)) return self::$specs;
        self::$specs = [];
        foreach (['native-mcp-abilities-v2.json','native-mcp-abilities-v3.json'] as $file) {
            $path = DREMINEX_SUITE_PATH . 'data/' . $file;
            $data = is_readable($path) ? json_decode((string) file_get_contents($path), true) : null;
            foreach ((array) ($data['abilities'] ?? []) as $spec) if (!empty($spec['name']) && is_array($spec)) self::$specs[$spec['name']] = $spec;
        }
        return self::$specs;
    }
    public static function spec($name) { $specs = self::specs(); return $specs[$name] ?? null; }

    /** Transport helpers and skill prompt resources are never agent-executable abilities. */
    public static function is_internal($name) {
        if (in_array($name, ['core/get-environment-info','core/get-site-info','core/get-user-info'], true)) return true;
        if (in_array($name, ['novamira-mcp-adapter/get-ability-info','novamira-mcp-adapter/execute-ability'], true)) return true;
        return str_starts_with($name, 'novamira/skill-prompt-');
    }

    public static function provider($name, $ability = null) {
        $meta = is_object($ability) && method_exists($ability, 'get_meta') ? (array) $ability->get_meta() : [];
        $declared = sanitize_key((string) ($meta['provider_plugin'] ?? $meta['provider'] ?? ''));
        // Exact contract membership identifies first-party abilities without trusting a namespace prefix.
        if (!empty(self::$owned[$name]) || self::spec($name)) return 'dreminex-suite';
        if ($declared !== '') return $declared;
        $namespace = strtolower((string) strtok($name, '/'));
        $known = [
            'woocommerce' => 'woocommerce', 'wc' => 'woocommerce',
            'wordpress-seo' => 'yoast-seo', 'yoast-seo' => 'yoast-seo',
            'jetpack' => 'jetpack', 'jetpack-forms' => 'jetpack',
            'pixelyoursite' => 'pixelyoursite', 'pys' => 'pixelyoursite',
            'elementor' => 'elementor', 'wpvivid' => 'wpvivid',
            'novamira' => 'novamira', 'novamira-mcp-adapter' => 'novamira-mcp-adapter',
        ];
        if (isset($known[$namespace])) return $known[$namespace];
        return preg_match('/^[a-z0-9][a-z0-9-]{0,62}$/', $namespace) ? 'external-' . sanitize_key($namespace) : 'unknown';
    }

    public static function category($name, $ability = null) {
        if (is_object($ability) && method_exists($ability, 'get_category')) {
            $category = sanitize_key((string) $ability->get_category());
            if ($category !== '') return $category;
        }
        return sanitize_key((string) strtok($name, '/'));
    }

    /** Explicit first-party contracts and curated providers are public; unknown providers must opt in. */
    public static function public_exposure($name, $ability = null) {
        if (self::is_internal($name)) return false;
        if (!empty(self::$owned[$name]) || self::spec($name)) return true;
        $meta = is_object($ability) && method_exists($ability, 'get_meta') ? (array) $ability->get_meta() : [];
        $mcp = is_array($meta['mcp'] ?? null) ? $meta['mcp'] : [];
        if (array_key_exists('public', $mcp)) return !empty($mcp['public']);
        return in_array(self::provider($name, $ability), ['woocommerce','yoast-seo','jetpack','pixelyoursite','elementor','novamira','novamira-mcp-adapter'], true);
    }

    private static function novamira_scope($name) {
        if ($name === 'novamira-mcp-adapter/discover-abilities') return 'mcp:discover';
        if ($name === 'novamira/agent-context') return 'site:read';
        if (preg_match('#^novamira/(?:read-file|list-directory)$#', $name)) return 'files:read';
        if (preg_match('#^novamira/(?:write-file|edit-file|delete-file|create-upload-link|disable-file|enable-file)$#', $name)) return 'files:write';
        if ($name === 'novamira/execute-php' || $name === 'novamira/create-admin-access-link') return 'security:write';
        if ($name === 'novamira/skill-get') return 'skills:read';
        if (str_starts_with($name, 'novamira/skill-')) return 'skills:write';
        if (preg_match('#^novamira/(?:list-design-library|get-active-design|get-design|check-design)$#', $name)) return 'design:read';
        if (preg_match('#^novamira/(?:activate-design|save-design|delete-design)$#', $name)) return 'design:write';
        if (str_starts_with($name, 'novamira/gutenberg-')) return preg_match('/(?:write|create|add|enable|delete)/', $name) ? 'editor:write' : 'editor:read';
        return '';
    }

    public static function required_scope($name, $readonly = true) {
        $spec = self::spec($name);
        if ($spec) {
            $group = (string) ($spec['functional_group'] ?? '');
            $write = ($spec['operation'] ?? 'read') !== 'read';
            if (str_contains($name, 'ability-coverage-read')) return 'mcp:discover';
            if (str_starts_with($name, 'dreminex-media/')) return 'media:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-files/')) return 'files:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-editor/')) return 'editor:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-admin/') || str_starts_with($name, 'dreminex-developer/')) return 'security:write';
            if (str_starts_with($name, 'dreminex-core/settings-')) return 'settings:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-core/users-')) return 'users:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-core/plugins-')) return 'plugins:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-workflow/')) return 'skills:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-design/')) return 'design:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-suppliers/')) return 'suppliers:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-core/')) return 'content:' . ($write ? 'write' : 'read');
            if ($group === 'MCP Gateway & Diagnostics') return 'site:read';
        }
        $namespace = strtolower((string) strtok($name, '/'));
        $write = !$readonly;
        if ($namespace === 'dreminex-products') return str_contains($name, '/workflow-') ? 'workflow:' . ($write ? 'write' : 'read') : 'catalog:' . ($write ? 'write' : 'read');
        if ($namespace === 'dreminex-operations') {
            if (str_contains($name, 'notification')) return 'notifications:' . ($write ? 'write' : 'read');
            if (str_contains($name, 'contact')) return 'contacts:' . ($write ? 'write' : 'read');
            if (str_contains($name, 'checkout')) return 'checkout:' . ($write ? 'write' : 'read');
            if (str_contains($name, 'payment') || str_contains($name, 'wallet') || str_contains($name, 'delivery-advance')) return 'payments:' . ($write ? 'write' : 'read');
            if (str_contains($name, 'supplier')) return 'suppliers:' . ($write ? 'write' : 'read');
            if (str_contains($name, 'order')) return 'orders:' . ($write ? 'write' : 'read');
            return 'operations:read';
        }
        if ($namespace === 'dreminex-security') return 'security:' . ($write ? 'write' : 'read');
        if ($namespace === 'dreminex-suppliers') return 'suppliers:' . ($write ? 'write' : 'read');
        if ($namespace === 'dreminex-system') return str_contains($name, 'coverage') ? 'mcp:discover' : 'site:read';
        if ($namespace === 'novamira' || $namespace === 'novamira-mcp-adapter') return self::novamira_scope($name);
        if (in_array($namespace, ['woocommerce','wc'], true)) return (str_contains($name, 'order') ? 'orders:' : 'catalog:') . ($write ? 'write' : 'read');
        if (in_array($namespace, ['wordpress-seo','yoast-seo'], true)) return 'seo:' . ($write ? 'write' : 'read');
        if (in_array($namespace, ['jetpack','jetpack-forms'], true)) return 'forms:' . ($write ? 'write' : 'read');
        if (in_array($namespace, ['pixelyoursite','pys'], true)) return 'settings:' . ($write ? 'write' : 'read');
        if ($namespace === 'elementor') return 'design:' . ($write ? 'write' : 'read');
        return '';
    }

    public static function required_capability($name) {
        if (str_starts_with($name, 'dreminex-media/')) return 'upload_files';
        if (str_starts_with($name, 'dreminex-files/') || str_starts_with($name, 'dreminex-admin/') || str_starts_with($name, 'dreminex-developer/')) return 'manage_options';
        if (str_starts_with($name, 'dreminex-editor/')) return 'edit_posts';
        if (str_starts_with($name, 'dreminex-core/settings-') || str_starts_with($name, 'dreminex-core/plugins-') || str_starts_with($name, 'dreminex-core/themes-')) return 'manage_options';
        if (str_starts_with($name, 'dreminex-core/users-')) return 'list_users';
        if (str_starts_with($name, 'dreminex-core/comments-')) return 'moderate_comments';
        if (str_starts_with($name, 'dreminex-core/menus-')) return 'edit_theme_options';
        if (str_starts_with($name, 'dreminex-workflow/') || str_starts_with($name, 'dreminex-design/') || str_starts_with($name, 'dreminex-security/')) return 'manage_options';
        if (str_starts_with($name, 'dreminex-suppliers/')) return 'manage_woocommerce';
        if (str_starts_with($name, 'dreminex-core/')) return 'edit_posts';
        if (str_starts_with($name, 'novamira/')) return 'manage_options';
        return '';
    }

    public static function risk($name, $ability = null) {
        $spec = self::spec($name);
        if ($spec) return (string) ($spec['operation'] ?? 'high_write');
        $annotations = is_object($ability) && method_exists($ability, 'get_annotations') ? (array) $ability->get_annotations() : [];
        $meta = is_object($ability) && method_exists($ability, 'get_meta') ? (array) $ability->get_meta() : [];
        $annotations = array_replace($annotations, (array) ($meta['annotations'] ?? []));
        if (!empty($annotations['destructive'])) return 'destructive';
        if (!empty($annotations['readonly'])) return 'read';
        return self::provider($name, $ability) === 'dreminex-suite' ? 'write' : 'high_write';
    }

    private static function environment_block($name) {
        if (!class_exists('Dreminex_Native_MCP') || Dreminex_Native_MCP::environment() !== 'production') return false;
        if (str_starts_with($name, 'dreminex-developer/') || str_starts_with($name, 'dreminex-admin/')) return true;
        if (in_array($name, ['novamira/execute-php','novamira/create-admin-access-link'], true)) return true;
        return (bool) preg_match('#^novamira/(?:read-file|write-file|edit-file|delete-file|create-upload-link|disable-file|enable-file|list-directory)$#', $name);
    }

    public static function decision($name, $ability = null) {
        if (!$ability) return ['registered' => false, 'enabled' => false, 'reason_code' => 'ability_missing', 'provider' => 'unknown', 'category' => '', 'required_scope' => ''];
        $provider = self::provider($name, $ability);
        $category = self::category($name, $ability);
        $settings = self::settings();
        $required = self::required_scope($name, self::risk($name, $ability) === 'read');
        $base = ['registered' => true, 'enabled' => false, 'provider_enabled' => true, 'category_enabled' => true, 'ability_enabled' => true, 'public_exposure' => self::public_exposure($name, $ability), 'provider' => $provider, 'category' => $category, 'required_scope' => $required, 'risk' => self::risk($name, $ability), 'override' => 'automatic'];
        if (self::is_internal($name)) return $base + ['reason_code' => 'internal_helper'];
        if (empty($settings['abilities_enabled'])) return $base + ['reason_code' => 'abilities_master_disabled'];
        if ($provider === 'unknown') return $base + ['reason_code' => 'provider_unknown'];
        if (array_key_exists($provider, (array) $settings['provider_states']) && empty($settings['provider_states'][$provider])) return array_replace($base, ['provider_enabled' => false, 'reason_code' => 'provider_disabled', 'override' => 'provider']);
        if (array_key_exists($category, (array) $settings['category_states']) && empty($settings['category_states'][$category])) return array_replace($base, ['category_enabled' => false, 'reason_code' => 'category_disabled', 'override' => 'category']);
        if (array_key_exists($name, (array) $settings['ability_states']) && empty($settings['ability_states'][$name])) return array_replace($base, ['ability_enabled' => false, 'reason_code' => 'ability_disabled', 'override' => 'ability']);
        if (!self::public_exposure($name, $ability)) return $base + ['reason_code' => 'not_public'];
        if ($required === '') return $base + ['reason_code' => 'scope_unmapped'];
        if (self::environment_block($name)) return $base + ['reason_code' => 'production_guard'];
        return array_replace($base, ['enabled' => true, 'reason_code' => 'enabled', 'capability' => self::required_capability($name)]);
    }

    public static function settings() {
        $settings = Dreminex_Native_MCP::settings();
        foreach (['provider_states','category_states','ability_states'] as $key) $settings[$key] = is_array($settings[$key] ?? null) ? $settings[$key] : [];
        return $settings;
    }

    public static function coverage($filter = []) {
        $rows = [];
        foreach ((array) (function_exists('wp_get_abilities') ? wp_get_abilities() : []) as $key => $ability) {
            $name = is_object($ability) && method_exists($ability, 'get_name') ? $ability->get_name() : (string) $key;
            $provider = self::provider($name, $ability);
            if (!empty($filter['provider']) && $filter['provider'] !== $provider) continue;
            if (!empty($filter['namespace']) && !str_starts_with($name, $filter['namespace'] . '/')) continue;
            $decision = self::decision($name, $ability);
            $rows[] = ['name' => $name, 'provider' => $provider, 'category' => $decision['category'], 'registered' => true, 'exposed' => !empty($decision['enabled']), 'reason_code' => $decision['reason_code'], 'required_scope' => $decision['required_scope'], 'risk' => $decision['risk'] ?? 'blocked'];
        }
        usort($rows, static fn($a, $b) => strcmp($a['name'], $b['name']));
        $page = max(1, absint($filter['page'] ?? 1));
        return ['registered_count' => count($rows), 'internal_count' => count(array_filter($rows, static fn($row) => $row['reason_code'] === 'internal_helper')), 'not_public_count' => count(array_filter($rows, static fn($row) => $row['reason_code'] === 'not_public')), 'exposed_count' => count(array_filter($rows, static fn($row) => $row['exposed'])), 'page' => $page, 'per_page' => 100, 'abilities' => array_slice($rows, ($page - 1) * 100, 100)];
    }

    public static function effective_count($mode, $scopes) {
        $count = 0; $scopes = (array) $scopes;
        foreach ((array) (function_exists('wp_get_abilities') ? wp_get_abilities() : []) as $key => $ability) {
            $name = is_object($ability) && method_exists($ability, 'get_name') ? $ability->get_name() : (string) $key;
            $decision = self::decision($name, $ability);
            if (empty($decision['enabled'])) continue;
            if ($mode === 'read_only' && ($decision['risk'] ?? 'read') !== 'read') continue;
            if (in_array($decision['required_scope'] ?? '', $scopes, true)) $count++;
        }
        return $count;
    }
}
