# Dreminex Suite changelog

# 1.22.16 — Independent Welcome contact and Offers flags (2026-10-30)

- Keep Newsletter/welcome-contact and Promotional Offers as separate feature flags inside the shared `newsletter_offers` module.
- Expose both flags to Nexus so either one can be enabled or disabled without changing the other.
- Preserve the selected subfeature states when the parent Suite module is toggled.

# 1.22.15 — Welcome Offers state and operations selection (2026-10-30)

- Keep the app-managed Welcome Offers module switch and its Newsletter/Offers feature flags in one synchronized state during boot and Nexus toggles.
- Make Operations workspaces horizontally scrollable so the mobile screen stays clean.
- Use a single combined tap/long-press gesture for Orders and Contacts; long-pressing a card visibly enters bulk selection mode without exposing checkboxes in the normal view.

# 1.22.14 — Wallet module visibility and responsive admin layout (2026-10-30)

- Kept Delivery Advance & Wallet in the WordPress All Modules catalogue so it can be enabled or disabled from either WordPress or Dreminex Nexus.
- Made the shared module option authoritative for the app feature read-back, keeping the app toggle synchronized with WordPress.
- Fixed mobile connection tables so columns scroll horizontally instead of collapsing into vertical letters.
- Added responsive wallet dashboard cards, scrollable ledger tables and collapsible review sections.
- Moved Supplier Monitor into the Dreminex Suite dashboard menu instead of the WooCommerce menu.

# 1.22.13 — Nexus operations management and notification delivery (2026-10-30)

- Added WooCommerce-style order detail readback, safe order notes and revision checks.
- Added claim-aware Welcome Offers deletion and visible Operations management.
- Added order status notification events for configured Android push delivery.
- Preserved the 1.22.12 UI, permission and module boundaries.

# 1.22.12 — Native MCP admin UI layout repair (2026-10-29)

- Restores the complete Native MCP admin stylesheet that was accidentally reduced to only the module-switch additions.
- Keeps tabs, cards, provider/category grids, ability rows, connection forms, diagnostics tables and mobile layouts readable.
- Adds responsive wrapping for provider controls and long ability/scope labels without changing authorization or data behavior.

# 1.22.11 — Native MCP module boundary and environment identity (2026-10-29)

- Adds a real Native MCP module switch: turning it off removes the MCP transport, OAuth routes and agent-facing provider while preserving settings, approvals and audit records.
- Adds explicit staging/production connection identity to the admin screen, MCP handshake, health response and protected-resource metadata.
- Adds provider-level enable/disable controls in the Abilities Hub without changing individual ability policy or OAuth grants.
- Keeps external ability discovery registry-driven, with per-provider and per-ability policy controls and the existing approval boundary.

# 1.22.10 — Native MCP access profiles and live registry baseline (2026-10-29)

- Reads the live WordPress Abilities registry so approved third-party providers can be discovered without a Native MCP code change.
- Separates registered, internal, globally exposed, client-discoverable and executable counts, with stable reason codes for every blocked ability.
- Adds mode-aware OAuth scope profiles. A mode change updates only the client policy ceiling; issued tokens remain unchanged until the owner reauthorizes.
- Keeps safe writes available in sandbox preview and full/auto-review modes while destructive and high-risk operations retain approval and explicit scope gates.
- Adds owner-managed metadata policies and bounded skills for already registered abilities; no PHP upload, eval or arbitrary code execution is accepted.
- Removes bundled Android/Windows assets and local app manifests from the plugin ZIP. App distribution now reads the checksum-verified public GitHub release manifest.

# 1.22.9 — Native MCP verified update release (2026-10-29)

- Carries the verified Native MCP discovery, metadata, diagnostics and activity export delta from 1.22.8.
- Keeps OAuth grants, approval records, typed handlers, safe roots and existing site data unchanged.
- Uses a higher patch version so installed Suite 1.22.8 sites can receive the update through the verified plugin updater.

# 1.22.8 — Native MCP discovery and activity delta (2026-10-28)

- Added normalized agent-facing metadata with fail-closed validation and stable diagnostic reason codes.
- Added distinct registered, internal, eligible, exposed, blocked and client-discoverable discovery fields with provider/category summaries.
- Added authenticated masked activity exports for 24 hours, 7 days, 14 days and rolling 30 days in JSON and CSV.
- Added configuration-event audit records, bounded discovery caching and retry-after circuit diagnostics.
- Preserved OAuth grants, approval binding, typed handlers, safe roots and existing transport routes.

## 1.22.0 — Supplier Monitor workflow (2026-10-27)

- Add immutable fixed initial price gap baselines and approval-only price proposals.
- Add normalized grouped alerts, idempotent actions, audit, read-back verification and rollback records.
- Add shared Supplier Workflow REST APIs and responsive WordPress management views.
- Add Nexus 0.9.0 Today, Alerts, Approvals, Products and More workflows.


- Evaluate global exposure, client scope policy, token grants, WordPress capabilities, permission mode and approval state separately.
- Preserve existing OAuth grants while adding owner-selected scope ceilings and explicit subset consent; high-risk write scopes remain opt-in.
- Add actionable authorization reason codes, separate registry/client counts, optional discovery pagination and connection diagnostics.
- Keep internal Novamira adapters, raw PHP, filesystem and administrator operations behind exact scopes, capabilities, environment gates and approvals.

## 1.20.4 — Guarded Native MCP v3 release candidate (2026-10-26)

- Build on the Nexus 0.8.0 / Suite 1.20.3 source and add 24 canonical Native MCP v3 abilities with strict schemas and dedicated editor, file and security scopes.
- Add provider-aware ability ownership, revision-bound editor queues, safe-root file operations, revision-checked skill/design lifecycle and fail-closed sandbox/admin exchange behavior.
- Keep the WordPress UI in English and leave existing 1.20.2 source, OAuth client identities, connected-site data and production untouched.
- Live staging parity, backup/rollback and behavioral acceptance remain release gates.

## 1.20.3 — Nexus 0.8.0 admin APIs and product controls (2026-10-26)

- Add revision-guarded product detail updates, scan schedule controls, dynamic order status handling and product lifecycle response improvements for Nexus 0.8.0.
- Keep existing site isolation, OAuth identity and Native MCP policy unchanged.
- Preserve the 1.20.2 plugin source as an immutable baseline; no staging or production deployment is included.

## 1.20.2 — Smaller plugin package and paused Windows installer distribution (2026-10-25)

- Keep the signed Android APK and checksum beside the plugin for same-site Nexus updates; exclude the 87 MB Windows executable from this release and from each WordPress plugin ZIP.
- Leave Windows installer version and download URL empty in the generated app manifest so connected sites never advertise a broken or unauthenticated private GitHub download.
- Continue supporting already-installed 1.20.1 packages that still contain the local Windows installer. Existing Windows app connections remain usable.

## 1.20.1 — Site-bound app distribution and safer module control (2026-10-25)

- Generate the Nexus release manifest from signed build artifacts and package the app installers with Suite, so older paired clients can update without access to private GitHub release APIs.
- Enable app-managed modules by default only when unset, preserve explicit off states, and block active legacy Code Snippets conflicts until they are safely migrated or reviewed.
- Enable Suite-owned Native MCP abilities by default unless an administrator explicitly disabled one; retain OAuth scopes, capability checks and approval rules.
- Add verified HTTPS product thumbnails to in-app and push notifications and return decoded currency text for older clients.

## 1.20.0 — Provider-aware Native MCP, integrated Nexus Security and operations (2026-10-25)

- Add a reviewed registry of 52 first-party MCP abilities, explicit provider/ability policy, scope and capability checks, diagnostics and default-deny behavior for newly specified abilities.
- Add bounded resumable media transfer with short-lived site/client/user-bound tickets, chunk and whole-file checksums, MIME verification and private staging.
- Move Nexus to 0.7.0: remove app-side project source editing while retaining external MCP Preparation/Publisher abilities; add exact-order deep-link readback, contact evidence review, Welcome Offer management and operational module controls.
- Use the official GitHub release path for Android updates. Nexus checks SHA-256, package identity, increasing versionCode and the permanent signing certificate before Android displays its installer.
- Keep app-controlled contact, checkout and Welcome Offer switches connected to the actual Suite module state, with server-side feature gates and administrator checks.
- Add the always-on Security Center: independent contact-form anti-bot checks, bounded sign-in failure lockouts, optional XML-RPC blocking, safe response headers, pseudonymous aggregated event history and a site-isolated Nexus Security screen in the former Projects navigation slot.
- Move the former read-only Daily Action Center queues into the Nexus Security screen, with direct links to filtered orders, products, supplier alerts, new contacts and incomplete checkout. Remove its separate Operations tab, WordPress service panel, app switch and Native MCP ability.
- Keep the authenticated Action Center REST URL as a read-only compatibility alias for older installed apps. Add an additive notification migration that retains old records and moves their category/deep link to Security.
- Advance the Suite option schema to remove the retired Action Center on/off flag while preserving its unrelated legacy settings and activity; module-status now reports only the current module catalog.
- Add authenticated Security Center read/update REST routes and default-deny Native MCP abilities using existing `settings:read/write` scopes. Keep raw IP addresses, email addresses and form contents out of the event report; retain security events for a configurable 7–90 days.
- Preserve existing OAuth clients, site data, Room schema 4, permanent app signer, wallet/order/product data and Windows desktop client.
- Update the module handoff references and add source contracts for the v1.20 MCP and app API surfaces.

## 1.19.0 — Mail governance, native Windows installer and app distribution (2026-10-23)

- Add the optional WordPress-only Mail Engine with monitor-first ownership, server-key encryption, encrypted queue/leases/retry, SMTP/Resend/Brevo/SMTP2GO transports, explicit test flow, recognized competing-mailer block and a contact-form bot-guard adapter. It starts off and does not change existing delivery.
- Repair custom supplier URL canonicalization and profile mapping. Dashboard-defined custom platforms use the same Nexus queue and extraction contract as built-ins, while using a saved interactive browser session instead of unsafe generic password automation.
- Add a per-site Nexus application manifest: Android and Windows release metadata, HTTPS download URLs, app capability dependency catalog, optional feature gates and exact production/staging/development/local detection with administrator override. Remove the obsolete Novamira dependency diagnostic.
- Add Nexus 0.6.0 update discovery, per-site capability display and re-pair-safe Android device registration. Existing five-site data and encrypted local sessions remain in place when an APK is signed with the same application identity and a higher versionCode.
- Add Dreminex Nexus for Windows source as a native Electron desktop application. GitHub Actions packages an NSIS `.exe`; it uses device-code pairing and Windows credential encryption, and is not a PWA.
- Keep Wallet data retained while its feature is off. Customer and admin wallet mutations stop with a clear disabled response until the feature is re-enabled.

## 1.18.0 — Faster operations, product-only COD and customer Wallet (2026-10-23)

- Upgrade Dreminex Nexus to 0.5.0 with cache-first screen refresh, in-place OAuth reconnect, structured product prices, two visible categories, product tags, paged catalog loading and guarded bulk Draft/Publish/Trash/Delete actions.
- Route Android notifications to the relevant operations screen, add Contact Requests and Checkout Protection boards, and expand Payments & Wallet with order verification, customer balance summaries, top-up and withdrawal queues.
- Bind each product task to the owner-selected MCP connection only, improve evidence-led category correction, generate short matching parent SKU tokens, accept up to five 24-character slash-separated SKU prefixes and prevent supplier identity from entering customer copy.
- Consolidate the former standalone Mobile Payment implementation into Delivery Advance & Wallet. Customers may pay the delivery advance or full amount using promotional credit first, customer cash next and an external provider for any remainder.
- Add an auditable Wallet ledger with withdrawable customer-added cash, nonwithdrawable expiring promotional credit, idempotent reservations, coupon claims, top-up verification, withdrawal approval/payment and customer My Account controls.
- Expose Wallet totals, customer counts, promotional users, customer-added cash, individual balances and request queues in both Suite administration and Nexus.
- Allow WooCommerce Cash on Delivery only when every cart item is explicitly marked COD-only. Standard products retain Delivery Advance/Full Payment and Wallet; mixed COD-only and standard carts must be ordered separately.
- Preserve the 564 variation maximum, 2 MB workflow file limit, Draft-by-default rule, five-site isolation and install-over-old Android package/signing identity.

## 1.17.0 — App-first catalog, workflows and operations (2026-10-22)

- Move AI Product Publisher, Supplier Monitor and Daily Action Center management into Dreminex Nexus while keeping their WordPress abilities behind Native MCP. Their standalone WordPress dashboard entries are removed; existing options, product metadata, events and workflow files are preserved.
- Add authenticated, site-isolated Nexus APIs and Native abilities for the complete Draft/Published catalog, separate Trash, product detail, guarded lifecycle transitions, supplier linking, project sources, Publisher settings, Daily Action Center, categorized notifications and 30-day performance analytics.
- Add a professional Nexus 0.4.0 interface with a fixed two-column phone catalog, category/status/search filters, product detail and confirmation flows, supplier scan state, Projects console, Operations dashboard, seven-day notifications, up to five sites and additive Room 2→3 offline-cache migration.
- Add privacy-safe hourly-deduplicated product views and a relative reach score combining views, units, revenue and review confidence. Add optional FCM delivery with authenticated 15-minute synchronization fallback; no FCM credential is stored in the plugin or app source.
- Correct Publisher category prerequisite execution, WordPress HTML canonicalization and saved-readback hashing. Unsupported visual-verification claims are ignored unless a method/evidence is present. Workflow bootstrap reduces repeated discovery and safe finalize writes no longer require an elevated product-write approval.
- Keep maximum variation capacity at 564, workflow files at 2 MB and lossless 45+ row JSON handoffs. Exact-name file replacement requires confirmation and preserves a previous revision. Quick forms now include the owner SKU prefix.
- Keep WordPress administrator and Nexus app surfaces in English while preserving separately configured customer-facing messages. Existing Nexus package ID and signing contract remain unchanged; versionCode 4 supports install-over-old signed updates without data loss.

## 1.16.0 — Advanced Hybrid product workflow autonomy (2026-10-22)

- Raise the administrator-configurable variation capacity hard maximum from 264 to 564 while retaining default 64 and matching preflight/create/update enforcement.
- Add read-only `identity-plan` for factual distinct product name/slug selection and prefix-based unique parent SKU planning against the selected site.
- Add recoverable preflight prerequisites and `attribute-ensure`; hard external blockers remain zero-write while exact global attribute/term setup and supplied original media can be completed safely by Publisher.
- Add `handoff-execute` as the single Publisher route: immutable site lock, prerequisite resolution, fresh preflight, Draft/Update/explicit Publish apply, same-product resume, handoff hash storage and saved readback comparison. Stale handoff readiness and legacy pending lists no longer override live state.
- Normalize every missing variable child SKU to a unique parent-colour-size identity and append an exact screenshot/user supplier code when present. Supplied child SKUs must retain the parent identity.
- Add guarded hybrid learning through idempotent `workflow-task-finalize`: bounded operational hints after repeated verified outcomes and an administrator review proposal after three matching successful tasks. Active instructions never change automatically.
- Replace Preparation and Publisher Project Settings, bootstrap sources, packaged skills and generator prompts with one-pass autonomous workflows. Preparation retains the 44-row inline boundary and 2 MB file limit; Publisher uses Dreminex Native as its listing authority and Draft remains the default.
- Retain PHP 8.0 compatibility in list detection and expand the A-to-Z maintenance reference, tests and staging release gate. Production is unchanged.

## 1.14.1 — ChatGPT OAuth compatibility and Nexus five-site isolation (2026-10-21)

- Fix ChatGPT DCR clients that register without a `scope` value: persisted client allow-lists now contain every supported Dreminex scope while initial empty-scope responses retain the read defaults. Existing active clients receive the compatible allow-list at authorization time without a database migration, client-ID change or redirect change, so `site:write` and other selected scopes no longer fail as unsupported.
- Reject a supplied authorization/token resource unless it is the exact MCP resource, and return that resource as the token audience. Advertise per-tool OAuth security schemes, return the issuer on authorization callbacks, keep OIDC out of Dreminex metadata, and retain Sandbox as the default client permission mode.
- Upgrade Dreminex Nexus to 0.2.0 with up to five isolated WordPress connections. Tokens, supplier credentials/cookies, platform cache, worker settings, Room retry rows, schedules, UI history and notifications are site-scoped; existing single-site data migrates automatically.
- Use the supplied Dreminex Nexus artwork for adaptive/round/legacy launcher icons, Android 12 splash, pairing, top-bar and About surfaces. Add a professional site switcher, connected-sites screen, duplicate-site handling, five-site limit and site-specific disconnect cleanup.
- Add focused connection-policy tests and update the Native MCP, Nexus Android, integration contract, install guide and separate OAuth/multi-site maintenance references. Staging OAuth and package readback remain release gates before production use.

## 1.14.0 — Native MCP and phone-only Dreminex Nexus supplier monitoring (2026-10-21)

- Add the independent Dreminex Native MCP endpoint with OAuth authorization code + PKCE, rotating refresh tokens, Nexus device code pairing, scoped ability discovery/validation/execution, per-client Sandbox/Auto-review/Read only/Full access policies, exact one-time approvals, ability switches, per-client rate limiting and sanitized audit logs. No Novamira runtime dependency is used.
- Rebuild Supplier Monitor around an idempotent WordPress queue and Android-owned supplier transport. Scheduled, manual, preview and legacy colour triggers only enqueue; the server-side supplier HTTP scanner is removed. Leases, two-device conflict protection, config hashes, exact variation/SKU validation, offline replay and duplicate-safe observation readback are included.
- Add versioned built-in ShopBaseBD and ResellKori platform profiles plus bounded dashboard-defined custom profiles, professional job/result/device screens, device revoke, evidence retention and network settings.
- Add the Dreminex Nexus 0.1.0 Android project (API 26–36) with OAuth pairing, Android Keystore encrypted sessions, WorkManager background/manual scans, Wi-Fi/Mobile Data binding without silent fallback, offline Room retry, exact-domain WebView login, bounded HTML/image evidence and Material 3 UI.
- Add separate Bengali A-to-Z references for Native MCP, Supplier Monitor, Nexus Android and their integration contract. This release is staging-first; production promotion remains a separate owner decision.

## 1.13.68 — Configurable variation capacity and Publisher control workspace (2026-10-20)

- Add one centralized variation-row policy with a default of 64, an administrator-configurable range of 1–264, full-matrix counting before writes, matching preflight/create/update enforcement, normalized/processed/remaining counts and same-operation Create/Update token/offset recovery. Above-capacity input fails before product creation or mutation and is never truncated.
- Add the responsive Products → AI Product Publisher dashboard with Overview, Workflow Projects, Abilities & Access, Listing Controls and Help & Release tabs. Every one of the 37 abilities has an On/Off control and accurate read/destructive/idempotent annotations. Read only and Full access are enforced server-side; Default and Auto-review are identified as client-side behavior.
- Require complete full-listing descriptions and core SEO while preserving exact-ID scoped description recovery. Normalize SEO aliases, reject internal implementation/variation-limit notes in customer copy, keep one representative image swatch per colour and retain alternate views in the gallery.
- Reduce Preparation and Publisher workflow source files to 2 MB each. Exact-name uploads require a client warning and a server confirmation before replacement; a prior version remains recoverable, different names add new files, and case-only collisions remain blocked.
- Add copyable direct Project instructions, a JSON prompt that regenerates instructions from live workflow files, minimal exact JSON triggers, and lossless handoff delivery: up to 44 variation rows inline and more than 44 as one complete attached JSON file with a SHA-256 receipt.
- Expand the Bengali A-to-Z handoff with the mandatory future maintenance, staging, packaging, checksum and rollback workflow. No Production/Main deployment is included in this release.

## 1.13.67 — AI Product Publisher A-to-Z maintenance handoff (2026-10-20)

- Add a separate Bengali A-to-Z module handoff covering architecture, all 37 registered abilities, settings, source files, Create/Update/Publish/lifecycle flows, SKU/media/variation rules, storage keys and error recovery.
- Document all main Publisher and workflow-manager functions, the impact map for future changes, and staging/release/rollback checklists so later additions or replacements can be made without losing existing safeguards.
- Documentation-only release: no product, media, settings, abilities, database data or storefront behavior is changed.

## 1.13.54 — Create by default, explicit product updates (2026-10-18)

- Product hand-offs now use Create by default. An existing listing is updated only with explicit `mode=update` and its exact product ID; an incidental ID in a Draft/Publish payload is ignored. Legacy `draft-complete` defaults to Create and requires `operation=resume` for same-run recovery.
- Preparation snapshot reports exact same-site title and slug matches. New Creates stop before writing when either collides, so the hand-off can be given a distinct name/slug without touching the matched product.
- Add default Preparation and Publisher operation-selection sources, including same-run partial-Draft recovery guidance. No new ability was added; the existing preparation-snapshot, listing-apply and legacy draft-complete abilities carry the rule. No database migration or product data change.

## 1.13.53 — Optional supplier source in listing flow (2026-10-17)

- Preparation and Publisher handoffs carry an exact supplier product URL only when the owner supplies it. Missing or blank URLs skip Supplier Monitor without blocking listing work.
- Listing add/update saves and verifies the product first, then connects and reads back the optional supplier source. Source-link failures are reported as a separate partial stage and do not undo or misreport the saved product.
- Publisher rules specify exact site-scoped readback and narrow source-only retry; no fabricated URLs or supplier credentials.

## 1.13.52 — PHP 8.5 image-comparison compatibility (2026-10-17)

- Remove deprecated GD cleanup calls without changing matching, alert or approval behavior.

## 1.13.51 — Supplier colour evidence, Publisher source linking, Action Center (2026-10-17)

- Supplier gallery and description observations with conservative colour image matching and review alerts; two successful scans required before a missing image can trigger a reversible hide action. A size absent from both description and surviving order controls follows the same gated review; text alone never hides a size.
- Publisher supplier-source abilities and listing input, Action Center queue, organized Supplier Monitor settings, handoff.
- Each authenticated supplier scan signs in again; product-level cost/stock never inferred for a colour/size.

## 1.13.49 — Fashion image swatches use the product’s colour attribute (2026-10-17)

- Resolve swatches against the exact global colour taxonomy selected in Preparation, such as `pa_solid-color`, `pa_colour` or a product-specific fashion colour attribute. Existing listings can infer a single unambiguous colour taxonomy from their assigned global attributes.
- Keep image mappings scoped to each product, require the swatch attachment to belong to that product’s featured/gallery/variation media, and expose the resolved taxonomy and image mapping in product readback.
- Render image swatches for each product’s own colour attribute and advertise available colour taxonomies to Preparation. Preparation and Publisher guidance now carries the taxonomy and exact representative image index through hand-off.
- No existing products, variations, prices, stock or media are modified by this plugin source update.

## 1.13.46 — Product image swatches, offer layout and Storefront parity (2026-10-16)

- AI Product Publisher accepts product-specific color image swatches through `color-swatch-set` and prepared listing colors (`swatch_image_id` or `swatch_image_index`). A saved mapping changes the swatch visual while preserving the global color attribute, color label, tooltip and variation behavior; unassigned colors remain circles. Product readback includes each mapping.
- Newsletter & Offers renders the automatic offer between the Elementor footer newsletter row and logo/app row. Long offer and welcome terms have keyboard-accessible scroll boxes. Coupons, claims and subscription logic are unchanged.
- Storefront applies the homepage card ground to mobile Shop, category and related grids, adds configurable brand sale badges with an optional reduced-motion-aware shine, and bundles a Bengali webfont with an administrator switch for consistent desktop and phone rendering.

## 1.13.44 — Quick View summary column sizing (2026-10-16)

- Explicitly assign ShopBuilder’s gallery and summary to the two desktop grid columns. Let the summary stretch to its column rather than retaining the theme’s narrow content width.
- Keep the correction inside the desktop breakpoint and Storefront Design module switch.
- No product, price, newsletter, Supplier Monitor, checkout or delivery settings are changed by this release.

## 1.13.43 — Quick View gallery width correction (2026-10-16)

- Fit ShopBuilder Quick View’s actual RTWPVG gallery and summary-content wrappers into the two-column desktop modal so the image and product details use their full columns.
- Keep gallery and summary width adjustments inside the desktop breakpoint and Storefront Design module switch.
- No product, price, newsletter, Supplier Monitor, checkout or delivery settings are changed by this release.

## 1.13.42 — Storefront card surface selector correction (2026-10-16)

- Target ShopBuilder’s live archive card markup and override its hard-coded white content surface using the Storefront Design module’s product-card colour setting.
- Keep the card and Quick View styling desktop-only; phone styling remains outside the media rule. All new switches and appearance values remain editable in Storefront Design.
- No product, price, newsletter, Supplier Monitor, checkout or delivery settings are changed by this release.

## 1.13.41 — Storefront desktop product surfaces (2026-10-16)

- Add independent Storefront Design controls for Shop/related-product cards and desktop Quick View, including card ground, corners and inner spacing, plus modal width, column gap and image ground.
- Match the desktop product-card ground to the homepage’s existing `#DEE2E6` surface and constrain Quick View to the viewport with internal scrolling. Changes are scoped to WooCommerce surfaces; phone styles remain unchanged.
- No product, price, newsletter, Supplier Monitor, checkout or delivery settings are changed by this release.

## 1.13.40 — Dropshipping cost model correction (2026-10-16)

- Remove merchant courier and COD settlement charges from the required price inputs. This store uses a dropshipping platform that fulfils delivery and COD.
- Count only the stated store costs: ৳15 packaging/other, ৳30 return reserve, ৳25 default product ad (selected products ৳30–৳90), and the 1.5% supplier payment fee on wholesale. Customer delivery advance remains separate and is included only in the delivered customer cap.
- Require pricing rule version 4; previously saved versions cannot create proposals until reviewed and saved under the corrected model. No product or price is changed by the migration.

## 1.13.39 — Offer placement, push media and supplier-fee pricing (2026-10-16)

- Render automatic offers just before the Sbmart footer with an independent private AJAX offer placeholder; keep the newsletter signup in its existing location. No subscriber or claim data is moved.
- Add a WordPress Media Library image picker, preview and remove control for each promotional offer. An additive offer-table column stores its attachment ID. The separate Dreminex PWA 1.3.7 reads this ID for newly activated offer pushes; older notifications are not resent and the small app icon stays branded.
- Supplier Monitor changes the ordinary ad budget to ৳30 (selected items ৳30–৳90), applies the owner's 1.5% supplier-transfer fee to wholesale, and keeps customer COD/advance collection fees as a separately verified input. Existing pricing rules require reconfiguration before any price proposal. Customer delivery charges are read from Woo shipping zones; actual merchant courier bills remain a separate mandatory input.
- No catalog price, active campaign, subscriber, module switch or main/staging installation is changed by this source package. Installed staging compatibility, checkout/notification rendering and rollback remain release gates.
## 1.13.38 — New-customer newsletter offer aligned with pricing (2026-10-16)

- Set the future welcome coupon to at most ৳30 off one eligible order with no minimum spend, one use per confirmed account/email and a 30-day default expiry. Previously saved higher discount, minimum spend and existing-customer allowance cannot issue new coupons under this policy; previously issued coupons retain their own saved terms.
- Check prior registered-account and guest orders by billing email before issuing. Exclude Woo sale items and Dreminex Flash Sale cart items even if Flash Sale later allows other coupons. Keep the delivery charge intact and do not combine with another Woo coupon.
- Newsletter coupon issuance defaults Off until the existing catalog margin and checkout are audited. The Supplier Monitor's prospective fixed coupon reserve defaults to ৳30; published older coupons and other offers still raise the required reserve when applicable. No site setting, existing coupon or catalog price is migrated.
- Pure pricing cases and Woo coupon setters exercised temporarily on staging PHP 8.3; installed-package newsletter and checkout E2E remain a staging release gate.

## 1.13.37 — Supplier Monitor delivered-price and promotion safeguards (2026-10-16)

- A BDT-only quote includes the owner's ৳15 other cost, ৳30 return reserve, default ৳25 ad cost, explicit maximum courier cost and payment fees. Selected products may carry a higher ad budget; each item needs a market-checked customer total cap including the highest live delivery charge.
- Uses the lowest live shipping charge for conservative courier recovery and the highest for payment fee and customer total. Existing published coupons, possible newsletter coupons and active offers increase the discount reserve. Free-shipping or unsupported coupon types, configured Flash Sale products, Woo sale prices, tax rates, non-flat shipping and missing inputs stop regular-price proposals.
- Chooses the lowest price ending in 9 that keeps discounted profit at or above the item target (at least ৳70), regular profit below ৳200 and customer total within its cap. If these cannot coexist, no proposal is made. Old v1 rules cannot enable proposals.
- Rechecks the full quote, current supplier scan, Woo price, coupon and shipping context at approval. An unavailable supplier supersedes pending price reviews. Observations still never write the Woo catalog.
- Pricing math and live Woo context exercised temporarily on staging PHP 8.3; module installation, authenticated supplier E2E, backup/rollback rehearsal and production deployment remain gated.

## 1.13.36 — Supplier Monitor safety and worker release candidate (2026-10-16)

- Derived only from the provided 1.13.35 foundation; the Supplier Monitor remains off by default. No WooCommerce catalog write happens during an observation.
- Restricts source URLs to the two exact supplier domains, gives the worker a separate scan capability, validates source and variation mappings server-side, preserves last successful observations on scan errors, and requires explicit evidence for missing options.
- Adds owner-verified per-supplier variation SKU mappings, observation replay IDs, event supersession, audit actor/readback fields, fresh multi-supplier stock checks, and optimistic approval claims.
- Removes inferred profit baselines. Regular-price proposals require an explicit per-item target, a confirmed fee/cost rule and an opt-in; active or scheduled sale prices and large changes are excluded.
- Separates private Playwright worker delivery from the installable plugin ZIP. Configured connectors, legitimate supplier sessions, worker host, PHP lint, staging activation and end-to-end supplier scans still require verification before release.

## 1.13.34 — Dashboard-managed AI product workflow projects (2026-10-15)

- Built on the supplied 1.13.33 package. AI Product Publisher now has separate Preparation and Publisher document panels within its existing dashboard module and Novamira connection.
- Bundles the latest twelve Preparation and nine Publisher source files as defaults. Admins can add, replace, remove, restore built-in, revert one prior version, preview and download privately stored UTF-8 Markdown/text documents. Each project enforces 20 active files and 5 MiB per file on the server.
- Adds live `workflow-profile`, chunked `workflow-source`, `workflow-experience`, `workflow-experience-record` and review-only `workflow-propose` abilities. Existing `workflow-guide` reads the active dashboard sources while keeping its legacy response shape. Large document sets return a manifest and require named retrieval instead of an oversized response.
- Maintains separate bounded private experience journals for the two projects. Publisher records supported listing/media/lifecycle operation outcomes automatically; assistants can submit verified notes and evidence-backed improvement proposals. Only a WordPress admin can approve a proposed rule into active sources.
- Added a responsive, keyboard-usable project UI with per-file state, hash, preview, replace and recovery controls. Files are stored in non-autoload WordPress options, not public Media Library URLs; source downloads require admin capability and a nonce.
- Does not migrate or alter products, media, OAuth configuration, existing module settings or Storefront Design. The additional source options are created only when an admin changes a file or a workflow records an event.

## 1.13.33 — Arbitrary Storefront HEX accent (2026-10-15)

- Storefront Design accepts any valid opaque #RGB or #RRGGBB colour through a text field or colour picker. Invalid codes are rejected before saving.
- The active module supplies the saved accent to its product, Shop, Cart, Checkout, tracking, saved-list and description styles, with readable button text and link tones.
- Existing site accent settings are preserved through the update. No database or product migration.

## 1.13.32 — Compact product heading and exact-ID lifecycle (2026-10-15)

- Description guidance now uses the exact product name once in a compact H3, a factual paragraph and optional H4 sections; storefront CSS keeps the heading small.
- Adds `dreminex-products/product-lifecycle` for exact-ID Draft, audited Publish, reversible Trash, Restore as Draft and confirmed permanent Delete from Trash. Media attachments are retained.
- Preparation chooses a visually verified featured original and ordered gallery; Publisher applies the handoff and reads back its saved fields.
- A scoped description-only handoff uses only `listing-update` on an exact existing product ID.

## 1.13.31 — concise product descriptions and bounded preparation snapshot
- Add read-only `dreminex-products/preparation-snapshot` to fetch the selected site's catalog/size terms, exact SKU/slug checks, recent media candidates and published related candidates in one bounded request. Results are candidates; photo identity and recommendation relevance still need Preparation review.
- Scope description heading sizes within single-product content, and update bundled Preparation rules to start with product details instead of repeating the product title as a large H2. Supplier provenance and unverified claims stay in internal evidence, not customer copy. No existing product copy is migrated by the plugin update.

## 1.13.30 — supplier map cleanup and media discovery guidance
- A first `listing-apply` or `draft-complete` now starts the colour-to-supplier-SKU map as an empty map when no saved map exists; numeric empty `0` entries are discarded on later updates.
- Preparation guidance checks recent attachments without filename filters before declaring uploaded originals missing. Existing product data and attachments are not migrated.

## 1.13.28 — conditional Preparation output
- Preparation’s workflow guide and bundled skill now choose context-only by default or on “hand-off ছাড়া”, and return only one complete JSON block on an explicit hand-off request.
- All Preparation-side checks and same-site media verification remain; Publisher’s execution ability and product/media data paths are unchanged.

## 1.13.27 — bounded visual matching requests
- Limit `media-visual-match` to 40 candidate IDs or attachments per page (default 30) after a 60-image page approached the staging request time limit. Clients page through the library instead of scanning a whole catalog in one request.
- Skip source images larger than 6 megapixels when an aspect-preserving medium derivative is unavailable; return the skipped count so Preparation can inspect those manually. No product or attachment metadata is changed by this read-only ability.
- Staging regression on 1.13.26 confirmed six screenshot hashes and one cropped JPEG rank their known original images first; retest this bounded release before using it.

## 1.13.26 — existing-original media handoff
- Added paginated `media-candidates` and bounded `media-visual-match` read-only abilities. The latter compares a cropped supplier screenshot photo to existing attachment images; its ranking needs visual verification and never edits media.
- `media-update` and opt-in `listing-apply` image metadata now support attachment permalink slugs alongside title and alt. A slug change does not rename the file or change its image URL.
- Preparation emits a complete verified same-site Media ID/URL handoff. Publisher passes one source per image and checks saved metadata. No product or media migration.

## 1.13.23 — checkout finishing
- Make the Checkout primary action span its order panel and remove the duplicate “(optional)” marker on the order notes label.
- Both changes are scoped to the active ShopBuilder checkout markup and retain its field and order behavior.

## 1.13.22 — checkout action and notices
- Keep Checkout's “Place order” button dark cyan/white and coupon/login notices visible against the page ground despite later theme and Additional CSS overrides.
- The rules are scoped to the active ShopBuilder checkout template; native validation and order submission remain unchanged.

## 1.13.21 — cart checkout action
- Keep the populated Cart's “Proceed to checkout” button in the Dreminex dark-cyan/white treatment even when the site's later Additional CSS overrides WooCommerce buttons.
- The rule is scoped to ShopBuilder's cart totals checkout link. Cart calculations, checkout navigation and saved settings are unchanged.

## 1.13.20 — storefront customer journey
- Added scoped Storefront Design controls for compact page banners, usable shop/category filters, cart/checkout/tracking presentation and native saved lists across devices.
- Restored legacy `[dreminex_saved_lists]` Elementor pages by delegating to the installed ShopBuilder wishlist/compare shortcodes, and replaced the theme demo label in home breadcrumbs. Cleaned the exact Contact placeholder at render time.
- Retained WooCommerce forms, cart calculation, checkout submission, customer data and ShopBuilder list actions. No page or theme rewrite, database migration or production change.

## 1.13.17 — account endpoint experience
- Styled native WooCommerce Orders, Downloads, Addresses, address edit, Account details and order detail views within the signed-in account design. Empty notices now place the text and Browse products action clearly; a compact optional illustration appears for empty orders.
- Added contextual page descriptions and a switch for the illustration to the Accounts module. The existing dashboard switch covers all signed-in account pages.
- Retained WooCommerce templates, order and customer data, nonces, validation, form actions and account endpoint links. No database migration or theme template override.

## 1.13.16 — signed-in account dashboard
- Replaced the plain logged-in WooCommerce account introduction with a branded welcome and Orders, Addresses and Account details shortcuts. The original WooCommerce endpoints and dashboard extension hooks remain available.
- Made account navigation compact and responsive on phone, tablet and desktop, with visible focus states and reduced-motion support.
- Added an on/off switch and editable dashboard heading and description in the Accounts module. No data migration, account record change or theme template edit.

## 1.13.15 — registration experience
- Redesigned the WooCommerce My Account registration and login view in the enabled Accounts module with a responsive brand introduction, readable form cards, password visibility controls and an accessible email result dialog.
- Added Suite controls for registration flow, customer fields, image selection, heading, description, button colours and confirmation email copy. Button colours are validated for readable contrast.
- Preserved native WooCommerce account creation, privacy text, password hashing, lost-password flow, saved module settings and all other Suite modules. New styling is scoped to the account page while the registration module is on.
- Accepted both local 11-digit and +880 Bangladesh mobile input, storing the same local number. No database migration.

## 1.13.14 — responsive Suite admin
- Redesigned the Suite overview, searchable module catalog, module detail, control center and shared admin forms for phone, tablet and desktop.
- Grouped Homepage Studio fields by content, typography, buttons and motion, with bounded thumbnail previews, Media Library and colour swatches.
- Corrected Homepage Studio asset routing and its save action when the module is off; keep the prior module settings and Elementor content unchanged.
- Added scoped admin assets and a clear homepage save notice. No database schema change; staging validation precedes production promotion.

## 1.13.13 — staging homepage studio
- Added Homepage studio inside Storefront Design for existing Elementor homepage banners, media, headings, buttons, links, moving text, feature content and countdown.
- Added per-banner image, text, button appearance, alignment and optional animations with reduced-motion support. Original Elementor data is preserved; overrides are scoped to the active homepage and module switch.
- Added mobile-friendly, grouped admin controls with Media Library picker; saved values are included in Suite module settings backup.
- Applied content overrides after Elementor's document cache so edits appear immediately without disabling page caching.
- Matched the theme's marquee animation target and kept image motion on the picture layer.
- No database schema migration; production is not updated.

## 1.13.25 — verified supplier SKU per colour
- Accept a supplier code explicitly matched to an image or colour in listing-apply, or on an offered variation row. Never OCR or invent a supplier code in PHP.
- Compose unique WooCommerce child SKUs from parent, supplier code, and size; preserve parent and unprovided child SKUs. Read back the saved supplier code and raw child SKU.
- Update packaged preparation and publishing handoffs. No storefront, checkout, existing product or database schema migration.

# Dreminex Suite Changelog

## 1.13.10 — Variation retry idempotency
- Use each existing variation's raw saved SKU during an upsert retry. WooCommerce may display the parent's SKU when the child has none; validating that inherited display value against the parent incorrectly rejected a safe retry.
- Continue returning the raw child SKU in the upsert result while preserving all 32 unique QA pairs on repeat runs.

## 1.13.9 — New Variable Draft recovery
- Handle WooCommerce's blank image ID safely in product read-back while a new Draft is being saved in stages. This prevents an exception after core/editorial persistence and lets the same product ID resume.
- Includes the 1.13.8 gallery replacement and resolution-report fixes.

## 1.13.8 — AI Product Publisher media recovery correction
- When an explicit featured image index is supplied, replace the product's image associations with that verified list. Historical product media no longer accumulate in the gallery; Media Library files remain intact.
- Return the caller's original image index and the actual resolution method for each attachment in the stage report.
- Preserve the 1.13.7 editorial and SEO recovery, same-site attachment reuse, and Draft variation gate.

## 1.13.7 — AI Product Publisher recovery
- Resolve same-site Media Library URLs to verified existing image attachments without downloading or duplicating files. Exact path, thumbnail metadata and unique corroborated filename fallbacks cover WordPress suffixes.
- Save Draft core, editorial, SEO, options and valid images independently of unknown or failed variations. Return stage results, pending inputs and the same resume product ID.
- Use explicit image-to-color mapping and verified gallery membership before filename heuristics; preserve unspecified fields and existing gallery order.
- Limit full-matrix generation to explicit confirmation, audit only the intended offered pairs, and keep publication behind a strict readiness check.
- Do not automatically change shared attachment alt/title unless update_media_metadata is explicit.

## 1.13.6 — Prepared listing handoff and quantity control
- Added `listing-apply` for prepared fields, accessible original media, category mapping, inferred Simple/Variable type, offered variations, related products and Draft/Publish/Update by product ID.
- Kept exact technical integrity checks but moved editorial title/SKU duplicate and pricing work to the separate preparation skill. Packaged two independent, version-agnostic Bengali workflows and stopped optional prompt windows.
- Preserved existing variations and SKUs on selective updates; returned saved product fields and resumable IDs for partial operations.
- Unified ShopBuilder quantity control dimensions, border, background and corner clipping across product, Quick View and cart layouts.

## 1.13.5 — Standalone listing recovery
- Direct complete listings to `dreminex-products/draft-complete` with populated schema fields; an empty request or a generic `woocommerce/product-create` payload cannot make a complete listing.
- Clarify that a color/size child of another product is not a separate product page.
- Give a specific `simple_size_selection` error when a Simple product is asked to carry multiple selectable sizes. Prevent silently publishing a product that cannot capture the customer's size.

## 1.13.4 — Faster assisted listings
- Added `media-batch-upload` for up to ten originals in one connector call with exact-byte repeat detection and resumable partial results.
- Added `listing-defaults` and a 0–10 second advisory optional prompt setting; missing SKU and stock never require a blocking question or fabricated inventory.
- `draft-complete` derives a slug and simple/variable type when omitted; the publishing guide now requests a short name/status/link result.
- Native timed ChatGPT popups and access to private chat attachment bytes still require a compatible host/MCP App file bridge, not just this WordPress module.

## 1.13.3 — Complete listing abilities
- Added category ensure, image byte/HTTPS imports, media metadata, selective listing and variation updates, and inventory and verified label-brand abilities for existing products.
- Added explicit audited publication through `draft-complete` (`publish=true`) or `draft-publish`, with dashboard control and read-back. Draft remains the default.
- Corrected audit for explicitly offered sparse color/size combinations; supports in-stock availability without inventing a quantity.
- Updated the packaged publishing workflow to avoid repeated permission questions when the user has already requested publication. Image attachments still require actual accessible bytes or a public URL.

## 1.13.2 — Product layout and publishing workflow
- Filled responsive description tables, aligned cart variation labels and values, and rounded ShopBuilder quantity controls on product, Quick View and cart screens. Added a dashboard switch for quantity styling.
- Added `media-find` and `draft-complete` for image discovery and resumable batched Draft creation with audit in one call.
- Described ability inputs for tool discovery and clarified the image transfer dependency. Existing products and settings are preserved.

## 1.13.1 — Storefront Design
- Moved product metadata, variation, description and title presentation from PWA into an optional Suite module.
- Added tag expansion and design settings for single product and Quick View; preserved WooCommerce term links and product selection behavior.
- Added mobile cart cards and totals rules for ShopBuilder's current cart markup, with all styling switched through the module.
- Render-only ShopBuilder full-description substitution keeps saved Elementor templates unchanged.

## 1.13.0 — integrated AI Product Publisher
- Bundled the Product Publisher in the Suite ZIP as an independently switched Operations module with a responsive settings panel.
- Added Draft creation, exact-HEX swatches, explicit variation images, manual or optional generated SKU, optional stock management and label-evidenced brand creation.
- Added `draft-brand-set`, `draft-audit` and `workflow-guide` abilities; packaged publishing and media/brand workflow guides.
- Preserved the prior Suite module states and settings. The bundled module starts off on existing installations. A running standalone Publisher must be deactivated before enabling it in the Suite.

## 1.11.0 — admin-controlled Flash Sale
- Added selected-product/variation campaign rules, fixed/percent/amount discounts, timezone-aware schedules, countdown, quantity limits, pagination and editable popup/page text.
- Preserved catalog prices; signed promotional cart lines use server-derived offer prices, separate cart identity, coupon policy, expiry/config validation and order audit metadata.
- Added responsive three-column desktop/two-column mobile storefront grid and scoped assets.
- Added generated shortcode page, native header route, exact-number official WhatsApp links and store setup number control.
- Preserved all existing module states, settings, product prices and orders. New campaign starts inactive.

## 1.10.9 — unified plugin admin design
- Applied one restrained Dreminex design system across the plugin’s own WordPress admin screens, including settings, module tools, Action Center, contacts, newsletter/offers, payments and Partial Checkouts.
- Standardized headings, buttons, form controls, notices and data tables; added mobile-friendly table scrolling and spacing.
- Scoped styling to plugin-owned screens; WordPress core, WooCommerce and other plugins are unaffected.
- Retained Action Center card layout at three columns on desktop and two on mobile with a visible gap. No data or schema changes.

## 1.10.8 — Daily Action Center responsive card columns
- Fixed the Action Center grid to three columns on desktop and two columns at the WordPress mobile breakpoint (782px and below), with spacing between cards.
- Constrained card width and enabled safe text wrapping on narrow screens.
- No data, route, or schema changes.

## 1.10.7 — Contact Requests status in Daily Action Center
- Added a read-only Contact Requests status card to Daily Action Center with total, new, in-progress and resolved counts, plus a direct link to the request dashboard. Trash is excluded.
- Added a default-on feature switch for the status card.
- Does not change contact records, request status, order status or payments. No schema migration.

## 1.10.6 — customer login persistence and clean module reset
- WooCommerce customer login now checks “Remember me” by default and issues the normal persistent WordPress login cookie; unchecking it keeps a browser-session login.
- Limited the cookie update to valid WooCommerce login submissions; other authentication flows are unchanged.
- No database/schema migration.

## 1.10.5 — Bengali language text fix
- Replaced four corrupted `?` placeholders in the Bengali + English Language and Install safety guidance with proper UTF-8 Bengali text.
- Kept the existing language preference and all settings/data unchanged; no schema migration.

## 1.10.4 — dashboard shortcut access fix
- Kept Suite child pages registered in WordPress's submenu capability map so Dashboard shortcuts remain accessible.
- Hid selected submenu rows with admin-side presentation CSS instead of removing the registered menu records; menu entries remain absent visually while their routes retain normal permissions.
- No database/schema migration; existing settings, module states and store/customer records are unchanged.

## 1.10.3 — popup message controls and dashboard navigation
- Removed All Modules, Site Health and Module Control Center from the Suite sidebar submenu; the Dashboard shortcuts remain available.
- Added optional per-module message overrides for checkout validation popups (delivery advance, phone validation, repeat-order cooldown and browser order limits), registration confirmation popups, and order-received/IP notices.
- Blank overrides retain each existing default message, including the current language-based defaults; saved message text is sanitized and length-limited.
- Preserved existing module settings and store/customer records; no schema migration.

## 1.10.2 — dashboard and admin navigation
- Kept the All Modules catalog at two cards per row on mobile, added a 16px card gap and constrained card sizing to prevent content overflow; desktop stays at three columns.
- Added Dashboard shortcuts for All Modules, Site Health, Module Control Center and Settings.
- Grouped Language, Store setup, Backup & module data, Imported modules and Cache Management under Settings tabs.
- Grouped Newsletter subscribers, Newsletter settings and Offers under Welcome & Offer tabs.
- Grouped Contact Requests and Contact email media under one menu with tabs.
- Retained the existing page routes and redirects needed by forms; no schema or customer/store data migration.


## 1.10.1 - checkout popup message control
- Added an optional message above checkout validation details. It defaults to blank, preserving the existing popup wording and behavior.

## 1.10.0 - dashboard and registration controls
- Rebuilt the Suite landing page as a default Summary view and moved the module catalog to a separate All Modules page with three desktop columns and two mobile columns.
- Put Dashboard, All Modules, Site Health and Module control centre in the Suite sidebar; renamed Suite Settings to Language.
- Restored always-visible Newsletter subscriber/settings/offer menus and Contact Requests/contact email media menus, so their dashboards remain available while the master module switch is off.
- Added registration dashboard controls for field visibility, required status, optional mobile number, customer-chosen password, password confirmation and email confirmation. Registration labels are English, stacked above equal-width inputs.
- Added checkout error popup heading and close-button controls while retaining the existing default text and live WooCommerce validation details.
- Removed the visible newsletter loading placeholder; no feature output is shown when both newsletter features are off.
- Added an option to issue welcome coupons to existing customers after confirmation. It defaults on to match the requested confirmation-to-offer flow; the welcome coupon amount, minimum, expiry and one-use/email restriction remain configurable.
- No schema migration or account/order/subscriber data reset.

## 1.9.1 — staging reliability fixes
- Recover payment/authentication locks only after a five-minute lease, using a conditional delete so a concurrent request's newer lock is preserved.
- Preserve historical delivery-advance provider labels and order currency in later order emails, even when a wallet is now disabled or its settings have changed.
- Do not delete an in-progress authentication lock while removing a connection profile.
- Allow sandbox payment profiles only on non-production WordPress environments; production continues to accept only live profiles. This enables safe staging checkout-route tests without real charges.
- Block payment API calls and credential tests when a profile's environment does not match the WordPress environment, even if a cached token exists; show the required environment and re-entry guidance in settings.
- No schema or data migration changes; existing 1.8/1.9 settings and records remain additive.

## 1.9.0 — staging package
- Fixed supported Elementor/widget shortcode rendering for Newsletter/Offers and hid empty offer-only auto placements.
- Ensured Newsletter and Offers run as independent feature switches; offers remain email-verified without newsletter consent.
- Removed duplicate Suite submenu navigation for Newsletter, Offers, Contact Requests and Partial Checkouts while preserving direct dashboard links.
- Grouped the dashboard cards by module category and improved responsive status cards.
- Added clearer import validation redirects/notices instead of a blank upload error response.
- Added four per-provider manual wallet configurations (bKash, Nagad, Rocket, Upay) with Personal/Merchant account type and independent provider switches. Migrates legacy wallet values additively.
- Added registration configuration sanitization, Woo email branding data backup, and courier-profile backup metadata with encrypted key values excluded.
- Preserved old module settings, module states, feature states and records; no live deployment in this release.
- Fixed duplicate receiver display in order summaries.

Known limitations: courier profile UI stores encrypted credentials but does not provide Pathao/Steadfast API authentication or live status sync; no license/update server is bundled; translation coverage is partial; site scanner is not antivirus.
## 1.13.29 — colour SKU, related preparation and size taxonomy
- Accept one `color_supplier_skus` code per confirmed colour, independent of the number of gallery views, and reject conflicting photo codes. Preserve unique child SKUs by appending actual sizes.
- Allow an explicit existing global `size_attribute` per product, read it back, expose candidate size taxonomies, and safely migrate a parent with no child variations. Block Men’s size taxonomy on a Women’s listing. Existing products are not migrated automatically.
- Preparation’s bundled guidance searches published comparable Upsells and complementary Cross-sells read-only. Empty recommendations remain empty; on an existing update, omit absent related fields to preserve saved links.

## 1.13.35 — Supplier Monitor foundation (2026-10-16)

- Adds an opt-in Supplier Monitor module to the existing Suite package. WooCommerce product create/update/trash and 12-hour catalog reconciliation maintain an ID-based source queue without changing product content.
- Adds authenticated REST jobs and observations, HTTPS source mappings, per-variation stock review, supplier-cost change alerts, simple-product profit-based price proposals, admin email and a responsive approval dashboard.
- Approvals check source, fresh observation and unchanged WooCommerce values. Quantity-managed inventory, uncertain availability, missing supplier variants and variable-product price changes require manual review. No supplier title, descriptions or SEO are overwritten.
- Bundles an optional private Playwright worker with encrypted per-supplier browser sessions and exact-host URL restrictions. Site-specific authenticated selectors and worker hosting have not been validated; the supplied example configuration deliberately has empty selectors and cannot report stock until verified.
- No database/product migration, module activation, external worker deployment or supplier-account login was performed by building this package.
## 1.13.48 — Product image corners, badge controls and supplier account setup (2026-10-17)
- Supplier Monitor allows one verified supplier product code across distinct size variations of the same linked product; a repeated code and size combination is rejected. This supports ShopBase's colour-level product codes without claiming unverified sizes are in stock.

- Storefront matches the ShopBuilder image wrapper to the configurable card image ground, removing the light corners left behind rounded photos. Badge distance from the image corner, padding, text size, background and text colour, radius and shine period are independently controlled in Storefront. Every Storefront colour control accepts an exact HEX code and synchronizes a visual picker.
- Supplier Monitor distinguishes twice-daily catalog reconciliation from an external authenticated supplier scan. The panel stores each supported account identifier/password encrypted at rest, does not display them after save, and exposes them only to a separate scoped auth-worker role over authenticated HTTPS. Existing scan-only worker accounts cannot read the account vault. The private worker supports an optional, explicitly configured password login and fails as `login_required` when verification or OTP/CAPTCHA blocks it.
- Credentials alone do not make a supplier connector live. Exact subscribed-page selectors, source URLs, variation SKU mappings, a private running worker and authenticated test evidence remain prerequisites. No stock, selling price, newsletter or supplier product data is changed by the upgrade.

## 1.13.50 — Supplier Monitor authenticated source scans (2026-10-17)

- Added a bounded native WordPress scanner for saved ShopBaseBD and ResellKori subscription accounts, with a 12-hour target, short-lived session cookies, a manual scan control, and product-editor URL field.
- ShopBaseBD product price and ResellKori single-item Reseller Price are kept distinct. ResellKori bulk Wholesale Price is excluded from the dropshipping cost.
- Product-level price, availability and reported quantity are recorded separately from colour/size stock. Unknown variation stock is never inferred or applied to WooCommerce.
- Scanner observations enter the existing review and audit flow; no storefront listing changes are applied automatically.


## 1.13.55 — Image swatches, complete offered matrix and restricted-account handling (2026-10-19)

- Publisher maps each verified `images[].color` to the matching product-specific image swatch when an explicit swatch choice is absent; explicit colour mode still wins. Accepts colour name strings as well as objects.
- A confirmed full colour/size matrix requires valid choices and a regular price before product creation. Child SKU falls back to a unique internal parent-colour-size form when no supplier code exists; supplier codes are never invented. An explicit `selling_price` alias retains a lower owner-supplied sale price.
- Preparation/Publisher workflow instructions preserve owner-specified regular and lower selling prices, build all explicitly offered pairs without supplier SKUs, and verify image swatches. Existing product IDs remain the recovery path for partial Drafts.
- Automatic ResellKori login attempts pause on an account-restricted response. Manual scan can resume after the supplier resolves access. No restricted-access bypass or claim of live tracking.

## 1.13.60 — Account restriction alert hardening (2026-10-19)

- Recognize a supplier restriction message nested in a login response and pause automatic attempts. A restriction while scanning a separate colour page immediately raises an Action Centre alert.

## 1.13.59 — ResellKori image match evidence (2026-10-19)

- Recognize near-identical ResellKori gallery files even when two local colours look similar, while requiring a clear second-best separation. Expose verified per-colour image evidence separately from product-level stock.
- Record the latest scheduler tick for scan-health readback.

## 1.13.58 — Supplier scan recovery and colour source observations (2026-10-19)

- Retry transient supplier scan failures after bounded 15-minute, 1-hour, 3-hour and 6-hour delays rather than waiting 12 hours. Successful observations retain the 12-hour target.
- Pause on account restriction, expose next attempt and stale status, and raise Action Centre alerts for overdue observations. Saving updated account credentials enables a fresh authorized verification.
- Scan one separately identified ShopBaseBD colour product code per scheduler tick and report colour-level price and stock changes for review. This does not infer individual size stock or change WooCommerce stock automatically.

## 1.13.57 — Image swatch rendering compatibility (2026-10-19)

- Render saved per-product color images over color circles when Variation Swatches for WooCommerce emits an inline style on the empty color span.

## 1.13.56 — Internal variation SKU readback correction (2026-10-19)

- Stage readback of the Polo Draft exposed that an optional auto-SKU setting could leave no-Supplier-code rows with blank SKUs. Generate the explicit parent-colour-size code regardless of that setting, preserve existing nonblank child codes, and fail if a code cannot be formed.

## 1.13.61 — Hand-off preflight and bounded supplier recovery (2026-10-19)

- Add read-only `dreminex-products/handoff-preflight` to check the exact target, identity, categories, taxonomies, image IDs/URLs, colour/size matrix, stock, sale and child SKU before any listing write. Raw complete hand-offs passed to `listing-apply` use the same guard. Preflight translates size measurement objects to selectable size names and Media ID+URL evidence to the single ID source expected by the live schema, and sets colour image swatch indices from verified media.
- Preparation source guides preserve the owner's product title, accept unique internal child SKUs when a supplier has no colour code, and require a ready preflight before a complete hand-off. Publisher guidance uses the normalized payload and reports blockers before a partial Draft.
- Supplier Monitor rechecks a restricted supplier account at most once per 24 hours, preserving ordinary transient retry intervals. Its dashboard displays the next attempt. Settings group advanced variation mapping and profit policy; the Action Center describes automated retries and owner review. Neither supplier observations nor uncertain colour/size stock silently change WooCommerce listings.

## 1.13.62 — Raw hand-off schema and staged save check (2026-10-19)

- Accept a complete raw Preparation hand-off in `listing-apply` without rejecting its null new-product ID, optional supplier URL, optional brand or featured index, size measurement objects and owner-stated “In stock” before the guarded PHP preflight runs. The normalized path remains supported. Fix the undeclared media ID schema descriptor in shared product fields.
- Staging confirmed a ready hand-off saved as a Draft with one correctly priced variation and a product-specific image swatch; its exact-ID readback matched and the test Draft was moved to Trash without deleting media.

## 1.13.63 — Preparation and Publisher handoff contract (2026-10-20)

- Add credential-safe, capability-gated `dreminex-suppliers/fact-preview` from the existing saved Supplier Monitor account, with exact product URL validation, bounded authenticated scan, rate limiting and status-specific results.
- Distinguish ResellKori single-item Reseller Price from ShopBaseBD product cost; return product-level stock, source title and exposed size/media evidence without credentials, cookies or page HTML.
- Align `handoff-preflight` with image-first colour swatches and explicit verified HEX/global-term fallback. Permit image-less Drafts with labelled fallback; block media-less Publish. Validate selected site and exact Update ID while preserving unspecified Update fields.
- Add current Preparation and Publisher profile contracts, correct the JSON handoff template, and document the role boundary and release gate.

## 1.13.64 — Staging variation and supplier evidence fixes (2026-10-20)

- Allow a verified `mode=color` option to save child variations without a variation image; never assign another colour's image. Retain image-first mapping for colours with verified originals.
- Return one actionable `colors[].name` error for an alias-only handoff instead of cascading one error per variation.
- Read ShopBaseBD source title and exposed age-size labels from its description fields; keep its verified item cost separate from its explicitly labelled maximum suggested selling price.
- Staging regression: v1.13.63 mixed-swatch Draft exposed an invalid-image failure for fallback children; v1.13.64 addresses that failure.

## 1.13.65 — Precise Update and variation image readback (2026-10-20)

- A scoped Update with no variation rows now reports variations as unchanged and finishes without a false partial result.
- `product-read` reports the saved variation image ID rather than WooCommerce's parent-image display fallback, and labels the display image source explicitly.
- Media updates retain prior gallery images and existing colour-image mappings unless the handoff explicitly supplies replacements; new featured media can still lead the gallery.
- Staging tests used exact isolated QA Draft IDs and verified mixed swatches, 40 child SKUs/prices, Update preservation and reversible lifecycle.

## 1.15.0 — OAuth issuer response and unified commerce modules (2026-10-21)

- Add the exact issuer to approve and deny callbacks with RFC 3986 query encoding, no-store headers and secret-free diagnostics; make the consent buttons submit unambiguous `approve` and `deny` decisions.
- Consolidate five checkout safeguards into Checkout Protection, two customer messages into Checkout Experience, five order tools into Order Management, and account/password recovery into Account Experience & Security.
- Add repeat-safe schema-3 migration that retains settings, records, order/user metadata and encrypted credentials while disabling legacy duplicate loaders.
- Normalize Bangladesh phone formats, add configurable protection limits, masked receipt IP, configurable unfinished-checkout retention and accessible popup focus trapping.
- Add delivery-advance duplicate TXID protection, editable checkout title/description and verification user/time audit.
- Add A-to-Z references, focused OAuth/migration tests and professional unified settings layouts.
- Refresh the WooCommerce Registration/Login page with an on-brand responsive hero, account-benefit band, clearer cards, registration-first mobile order and accessible live password-match feedback while retaining native WooCommerce validation and saved settings.


