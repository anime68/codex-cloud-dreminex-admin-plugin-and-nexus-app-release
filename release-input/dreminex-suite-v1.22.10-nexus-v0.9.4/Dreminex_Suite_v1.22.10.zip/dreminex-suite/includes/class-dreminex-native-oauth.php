<?php
if (!defined('ABSPATH')) exit;

/**
 * Minimal OAuth 2.1 authorization server for the Dreminex MCP resource.
 * Tokens are opaque, stored only as SHA-256 hashes and always bound to a
 * WordPress user, client, scope set and the exact MCP resource.
 */
final class Dreminex_Native_OAuth {
 const SCHEMA=2;
 const SCOPE_REVISION=4;
 const NEXUS_CLIENT='dreminex-nexus-android';
 const NEXUS_DESKTOP_CLIENT='dreminex-nexus-windows';
 const DEVICE_GRANT='urn:ietf:params:oauth:grant-type:device_code';
 private static $context=[];

 private static function table($suffix){global $wpdb;return $wpdb->prefix.'dreminex_oauth_'.$suffix;}
 private static function now(){return current_time('mysql',true);}
 private static function later($seconds){return gmdate('Y-m-d H:i:s',time()+$seconds);}
 private static function token($bytes=32){return rtrim(strtr(base64_encode(random_bytes($bytes)),'+/','-_'),'=');}
 private static function hash($value){return hash('sha256',(string)$value);}
 private static function json($value){return wp_json_encode($value,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);}
 public static function resource(){return rest_url('mcp/dreminex');}
 public static function issuer(){return home_url('/dreminex-oauth');}
 public static function protected_metadata(){return home_url('/.well-known/oauth-protected-resource/wp-json/mcp/dreminex');}
 public static function scopes(){return ['mcp:discover','site:read','site:write','catalog:read','catalog:write','orders:read','orders:write','suppliers:read','suppliers:write','workflow:read','workflow:write','operations:read','notifications:read','notifications:write','analytics:read','settings:read','settings:write','contacts:read','contacts:write','checkout:read','checkout:write','payments:read','payments:write','approvals:read','approvals:write','devices:read','devices:write','media:read','media:write','content:read','content:write','editor:read','editor:write','files:read','files:write','security:read','security:write','seo:read','seo:write','forms:read','forms:write','design:read','design:write','skills:read','skills:write','users:read','users:write','plugins:read','plugins:write'];}
 public static function read_scopes(){return array_values(array_filter(self::scopes(),static fn($scope)=>$scope==='mcp:discover'||str_ends_with($scope,':read')));}
 public static function normalize_mode($mode){$mode=sanitize_key((string)$mode);return in_array($mode,['sandbox','auto_review','read_only','full_access'],true)?$mode:($mode==='full_scoped'?'full_access':'sandbox');}
 /**
  * Access profiles describe the OAuth ceiling requested during consent. They
  * never mutate an already issued token; reauthorization is still required.
  * Sandbox and auto-review deliberately omit high-risk scopes by default.
  */
 public static function profile_scopes($mode){
  $mode=self::normalize_mode($mode);$all=self::scopes();
  if($mode==='read_only')return self::read_scopes();
  if(in_array($mode,['sandbox','auto_review'],true))return array_values(array_diff($all,self::high_risk_scopes()));
  return $all;
 }
 /** Default selections keep high-risk scopes opt-in while exposing every safe namespace. */
 public static function recommended_scopes($mode){return array_values(array_diff(self::profile_scopes($mode),self::high_risk_scopes()));}
 public static function default_scopes(){return self::recommended_scopes('sandbox');}
 public static function high_risk_scopes(){return ['files:write','security:write','plugins:write','users:write'];}
 public static function scope_status($mode,$granted,$selected=null){
  $mode=self::normalize_mode($mode);$granted=array_values(array_intersect(self::scopes(),(array)$granted));
  $selected=is_array($selected)?array_values(array_intersect(self::scopes(),$selected)):self::recommended_scopes($mode);
  if($mode==='read_only')$selected=array_values(array_intersect($selected,self::read_scopes()));
  $missing=array_values(array_diff($selected,$granted));
  return ['scope_revision'=>self::SCOPE_REVISION,'permission_profile'=>$mode,'profile_scope_count'=>count(self::profile_scopes($mode)),'recommended_scope_count'=>count(self::recommended_scopes($mode)),'granted_scope_count'=>count($granted),'selected_scope_count'=>count($selected),'required_scope_count'=>count($selected),'selected_scopes'=>$selected,'missing_scopes'=>$missing,'high_risk_missing_scopes'=>array_values(array_intersect($missing,self::high_risk_scopes())),'reconnect_required'=>!empty($missing)];
 }

 public static function install(){
  if((int)get_option('dreminex_native_oauth_schema',0)>=self::SCHEMA){self::migrate_access_profiles();return;}
  require_once ABSPATH.'wp-admin/includes/upgrade.php';global $wpdb;$c=$wpdb->get_charset_collate();$p=$wpdb->prefix.'dreminex_oauth_';
  dbDelta("CREATE TABLE {$p}clients (
   client_id varchar(64) NOT NULL, client_name varchar(191) NOT NULL, redirect_uris longtext NOT NULL,
   allowed_scopes text NOT NULL, permission_mode varchar(24) NOT NULL DEFAULT 'sandbox', created_by bigint unsigned NOT NULL DEFAULT 0,
   created_at datetime NOT NULL, last_used_at datetime NULL, revoked tinyint(1) NOT NULL DEFAULT 0,
   PRIMARY KEY (client_id), KEY revoked (revoked)
  ) {$c};");
  dbDelta("CREATE TABLE {$p}codes (
   code_hash char(64) NOT NULL, client_id varchar(64) NOT NULL, user_id bigint unsigned NOT NULL,
   redirect_uri text NOT NULL, code_challenge varchar(128) NOT NULL, scopes text NOT NULL, expires_at datetime NOT NULL,
   PRIMARY KEY (code_hash), KEY expires_at (expires_at)
  ) {$c};");
  dbDelta("CREATE TABLE {$p}tokens (
   token_hash char(64) NOT NULL, client_id varchar(64) NOT NULL, user_id bigint unsigned NOT NULL,
   scopes text NOT NULL, expires_at datetime NOT NULL, revoked tinyint(1) NOT NULL DEFAULT 0, created_at datetime NOT NULL,
   PRIMARY KEY (token_hash), KEY expires_at (expires_at), KEY client_id (client_id), KEY user_id (user_id)
  ) {$c};");
  dbDelta("CREATE TABLE {$p}refresh_tokens (
   token_hash char(64) NOT NULL, client_id varchar(64) NOT NULL, user_id bigint unsigned NOT NULL,
   scopes text NOT NULL, expires_at datetime NOT NULL, revoked tinyint(1) NOT NULL DEFAULT 0, created_at datetime NOT NULL,
   PRIMARY KEY (token_hash), KEY expires_at (expires_at), KEY client_id (client_id)
  ) {$c};");
  dbDelta("CREATE TABLE {$p}device_codes (
   device_hash char(64) NOT NULL, user_code_hash char(64) NOT NULL, client_id varchar(64) NOT NULL,
   user_id bigint unsigned NOT NULL DEFAULT 0, scopes text NOT NULL, status varchar(16) NOT NULL DEFAULT 'pending',
   expires_at datetime NOT NULL, last_polled_at datetime NULL, created_at datetime NOT NULL,
   PRIMARY KEY (device_hash), UNIQUE KEY user_code_hash (user_code_hash), KEY expires_at (expires_at)
  ) {$c};");
  if((int)get_option('dreminex_native_oauth_schema',0)<2)self::migrate_client_scope_policy();
  update_option('dreminex_native_oauth_schema',self::SCHEMA,false);self::migrate_access_profiles();
 }

 /** Expand only the safe mode profile for existing clients; issued tokens stay unchanged. */
 private static function migrate_access_profiles(){
  if(get_option('dreminex_native_oauth_access_profiles_v1',false))return;
  global $wpdb;$rows=$wpdb->get_results('SELECT client_id,allowed_scopes,permission_mode FROM '.self::table('clients'),ARRAY_A);$changed=0;
  foreach((array)$rows as $row){$mode=self::normalize_mode($row['permission_mode']??'sandbox');$old=json_decode((string)($row['allowed_scopes']??'[]'),true);$old=is_array($old)?$old:[];$expanded=array_values(array_unique(array_merge($old,self::recommended_scopes($mode))));if(!in_array('mcp:discover',$expanded,true))array_unshift($expanded,'mcp:discover');if($expanded!==$old){$wpdb->update(self::table('clients'),['allowed_scopes'=>self::json($expanded)],['client_id'=>$row['client_id']],['%s'],['%s']);$changed++;}}
  update_option('dreminex_native_oauth_access_profiles_v1',['time'=>gmdate('c'),'clients_changed'=>$changed,'scope_revision'=>self::SCOPE_REVISION,'policy'=>'safe_profile_ceiling_requires_reauthorization'],false);
 }

 private static function migrate_client_scope_policy(){
  global $wpdb;$clients=self::table('clients');$tokens=self::table('tokens');$refresh=self::table('refresh_tokens');
  foreach((array)$wpdb->get_results("SELECT client_id FROM {$clients}",ARRAY_A) as $client){
   $id=(string)$client['client_id'];$selected=[];
   foreach([$tokens,$refresh] as $table){$rows=$wpdb->get_col($wpdb->prepare("SELECT scopes FROM {$table} WHERE client_id=%s AND revoked=0",$id));foreach((array)$rows as $json)$selected=array_merge($selected,(array)json_decode($json,true));}
   $client_row=$wpdb->get_row($wpdb->prepare("SELECT permission_mode FROM {$clients} WHERE client_id=%s",$id),ARRAY_A);$mode=self::normalize_mode($client_row['permission_mode']??'sandbox');$selected=array_values(array_unique(array_merge(array_intersect(self::scopes(),$selected),self::recommended_scopes($mode))));if(!in_array('mcp:discover',$selected,true))array_unshift($selected,'mcp:discover');
   $wpdb->update($clients,['allowed_scopes'=>self::json($selected)],['client_id'=>$id],['%s'],['%s']);
  }
  update_option('dreminex_native_oauth_scope_policy_migration',['time'=>gmdate('c'),'scope_revision'=>self::SCOPE_REVISION,'policy'=>'preserve_granted_scopes'],false);
 }

 public static function boot(){
  self::install();
  add_action('rest_api_init',[__CLASS__,'routes']);
  add_action('parse_request',[__CLASS__,'maybe_discovery'],0);
  add_action('admin_menu',[__CLASS__,'hidden_pages']);
  add_action('admin_post_dreminex_oauth_consent',[__CLASS__,'consent']);
  add_action('admin_post_dreminex_oauth_device_approve',[__CLASS__,'device_approve']);
  add_action('dreminex_oauth_gc',[__CLASS__,'gc']);
  if(!wp_next_scheduled('dreminex_oauth_gc'))wp_schedule_event(time()+HOUR_IN_SECONDS,'daily','dreminex_oauth_gc');
 }

 public static function routes(){
  $public=['permission_callback'=>'__return_true'];
  register_rest_route('dreminex/v1','/oauth/register',$public+['methods'=>'POST','callback'=>[__CLASS__,'register_client']]);
  register_rest_route('dreminex/v1','/oauth/token',$public+['methods'=>'POST','callback'=>[__CLASS__,'token_endpoint']]);
  register_rest_route('dreminex/v1','/oauth/revoke',$public+['methods'=>'POST','callback'=>[__CLASS__,'revoke_endpoint']]);
  register_rest_route('dreminex/v1','/oauth/introspect',$public+['methods'=>'POST','callback'=>[__CLASS__,'introspect_endpoint']]);
  register_rest_route('dreminex/v1','/oauth/device',$public+['methods'=>'POST','callback'=>[__CLASS__,'device_endpoint']]);
 }

 private static function request_data($request){
  $data=$request->get_json_params();if(!is_array($data))$data=$request->get_params();return is_array($data)?$data:[];
 }
 private static function oauth_error($code,$description,$status=400){
  $data=['status'=>$status,'error'=>$code,'error_description'=>$description];
  if(in_array($code,['oauth_required','invalid_token','insufficient_scope'],true)){$challenge='Bearer resource_metadata="'.esc_url_raw(self::protected_metadata()).'"';$data['_meta']=['mcp/www_authenticate'=>$challenge];header('WWW-Authenticate: '.$challenge);}
  return new WP_Error($code,$description,$data);
 }
 private static function clean_scopes($raw,$allowed=null,$defaults=null){
  $requested=is_array($raw)?$raw:preg_split('/\s+/',trim((string)$raw));$requested=array_values(array_unique(array_filter(array_map('sanitize_text_field',(array)$requested))));
  $supported=self::scopes();if(is_array($allowed))$supported=array_values(array_intersect($supported,$allowed));
  foreach($requested as $scope)if(!in_array($scope,$supported,true))return self::oauth_error('invalid_scope','Unsupported OAuth scope: '.$scope,400);
  $fallback=is_array($defaults)&&$defaults?$defaults:self::default_scopes();return $requested?:array_values(array_intersect($fallback,$supported));
 }
 private static function valid_redirect($url){
  if(!is_string($url)||strlen($url)>1000||strpos($url,'#')!==false)return false;$p=wp_parse_url($url);if(!is_array($p)||empty($p['scheme'])||empty($p['host'])||isset($p['user'])||isset($p['pass']))return false;
  if(strtolower($p['scheme'])==='https')return true;return strtolower($p['scheme'])==='http'&&in_array(strtolower($p['host']),['localhost','127.0.0.1','::1'],true);
 }
 private static function client($client_id){
  if(in_array($client_id,[self::NEXUS_CLIENT,self::NEXUS_DESKTOP_CLIENT],true))return ['client_id'=>$client_id,'client_name'=>$client_id===self::NEXUS_CLIENT?'Dreminex Nexus Android':'Dreminex Nexus Windows','redirect_uris'=>'[]','allowed_scopes'=>self::json(['catalog:read','catalog:write','orders:read','orders:write','suppliers:read','suppliers:write','workflow:read','workflow:write','operations:read','notifications:read','notifications:write','analytics:read','settings:read','settings:write','contacts:read','contacts:write','checkout:read','checkout:write','payments:read','payments:write','approvals:read','approvals:write','devices:read','devices:write']),'permission_mode'=>'full_scoped','revoked'=>0];
  global $wpdb;$client=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::table('clients').' WHERE client_id=%s',$client_id),ARRAY_A);
  return $client;
 }

 public static function register_client($request){
  $ip=$_SERVER['REMOTE_ADDR']??'';$rate='dreminex_oauth_register_'.self::hash($ip);$count=(int)get_transient($rate);if($count>=10)return self::oauth_error('rate_limited','Too many client registrations.',429);set_transient($rate,$count+1,HOUR_IN_SECONDS);
  $data=self::request_data($request);$name=sanitize_text_field((string)($data['client_name']??'MCP Client'));$uris=$data['redirect_uris']??[];
  if(!is_array($uris)||!$uris||count($uris)>10)return self::oauth_error('invalid_client_metadata','One or more redirect_uris are required.');
  $clean=[];foreach($uris as $uri){$uri=esc_url_raw((string)$uri);if(!self::valid_redirect($uri))return self::oauth_error('invalid_redirect_uri','Only HTTPS or localhost redirect URIs are accepted.');$clean[]=$uri;}
  $scopes=self::clean_scopes($data['scope']??'',self::scopes(),self::default_scopes());if(is_wp_error($scopes))return $scopes;
  // Registration stores only supported scopes requested by the client. Consent persists the owner's exact subset.
  if(!in_array('mcp:discover',$scopes,true))array_unshift($scopes,'mcp:discover');
  $id='drx_'.substr(self::token(24),0,38);global $wpdb;$wpdb->insert(self::table('clients'),['client_id'=>$id,'client_name'=>substr($name?:'MCP Client',0,191),'redirect_uris'=>self::json(array_values(array_unique($clean))),'allowed_scopes'=>self::json($scopes),'permission_mode'=>'sandbox','created_by'=>0,'created_at'=>self::now()],['%s','%s','%s','%s','%s','%d','%s']);
  if(!$wpdb->insert_id&&$wpdb->last_error)return self::oauth_error('server_error','Could not register the OAuth client.',500);
  return rest_ensure_response(['client_id'=>$id,'client_id_issued_at'=>time(),'client_name'=>$name,'redirect_uris'=>$clean,'grant_types'=>['authorization_code','refresh_token'],'response_types'=>['code'],'token_endpoint_auth_method'=>'none','scope'=>implode(' ',$scopes)]);
 }

 public static function hidden_pages(){
  add_submenu_page(null,'Dreminex authorization','Dreminex authorization','read','dreminex-oauth-authorize',[__CLASS__,'authorize_page']);
  add_submenu_page(null,'Dreminex device verification','Dreminex device verification','read','dreminex-oauth-device',[__CLASS__,'device_page']);
 }
 public static function authorize_page(){
  if(!is_user_logged_in()){auth_redirect();return;}
  $client_id=sanitize_text_field(wp_unslash($_GET['client_id']??''));$redirect=esc_url_raw(wp_unslash($_GET['redirect_uri']??''));$state=sanitize_text_field(wp_unslash($_GET['state']??''));$challenge=sanitize_text_field(wp_unslash($_GET['code_challenge']??''));$method=sanitize_text_field(wp_unslash($_GET['code_challenge_method']??''));$resource=esc_url_raw(wp_unslash($_GET['resource']??''));$response_type=sanitize_key(wp_unslash($_GET['response_type']??''));$response_mode=sanitize_key(wp_unslash($_GET['response_mode']??'query'));
  $client=self::client($client_id);$uris=$client?json_decode($client['redirect_uris'],true):[];
  if(!$client||!empty($client['revoked'])||!in_array($redirect,(array)$uris,true)||$response_type!=='code'||$response_mode!=='query'||$method!=='S256'||!preg_match('/^[A-Za-z0-9_-]{43,128}$/',$challenge)||($resource!==''&&rtrim($resource,'/')!==rtrim(self::resource(),'/')))wp_die('Invalid OAuth authorization request.','Dreminex OAuth',['response'=>400]);
  $mode=self::normalize_mode($client['permission_mode']??'sandbox');$allowed=array_values(array_intersect(self::scopes(),(array)json_decode($client['allowed_scopes'],true)));$requested=self::clean_scopes(wp_unslash($_GET['scope']??''),self::scopes(),self::default_scopes());if(is_wp_error($requested))wp_die(esc_html($requested->get_error_message()),'Dreminex OAuth',['response'=>400]);
  // Reauthorization must offer the saved mode policy even when the client
  // repeats its old narrow scope request. The owner still consents to the
  // exact checkbox set and the resulting token is never expanded silently.
  $policy_scopes=array_values(array_intersect($allowed,self::profile_scopes($mode)));$scopes=array_values(array_unique(array_merge(array_intersect($requested,$allowed),$policy_scopes)));if(!in_array('mcp:discover',$scopes,true))wp_die('This client is not allowed to discover MCP abilities.','Dreminex OAuth',['response'=>403]);
  $pending=self::token(24);set_transient('dreminex_oauth_pending_'.self::hash($pending),['client_id'=>$client_id,'redirect_uri'=>$redirect,'state'=>$state,'challenge'=>$challenge,'scopes'=>$scopes],10*MINUTE_IN_SECONDS);
  echo '<div class="wrap"><h1>Connect '.esc_html($client['client_name']).'</h1><p>Permission profile: <strong>'.esc_html($mode).'</strong>. Select the exact scopes to grant. This consent creates the token; changing the mode never expands an existing token. High-risk scopes remain separately guarded.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_oauth_consent"><input type="hidden" name="request_token" value="'.esc_attr($pending).'">';wp_nonce_field('dreminex_oauth_consent');echo '<fieldset>';
  $previous=self::latest_granted_scopes($client_id);$recommended_profile=self::recommended_scopes($mode);foreach($scopes as $scope){$mandatory=$scope==='mcp:discover';$risk=in_array($scope,self::high_risk_scopes(),true);$recommended=$mandatory||(!$risk&&(in_array($scope,$previous,true)||in_array($scope,$recommended_profile,true)));echo '<label style="display:block;margin:.5rem 0"><input type="checkbox" name="approved_scopes[]" value="'.esc_attr($scope).'" '.checked($recommended,true,false).' '.disabled($mandatory,true,false).'> <code>'.esc_html($scope).'</code>'.($risk?' <strong>high risk · explicit opt-in</strong>':'').'</label>';if($mandatory)echo '<input type="hidden" name="approved_scopes[]" value="mcp:discover">';}
  echo '</fieldset><p><button type="submit" class="button button-primary" name="decision" value="approve">Approve selected scopes</button> <button type="submit" class="button button-secondary" name="decision" value="deny">Deny</button></p></form></div>';
 }
 public static function consent(){
  if(!is_user_logged_in())wp_die('Sign in required.',401);check_admin_referer('dreminex_oauth_consent');$token=sanitize_text_field(wp_unslash($_POST['request_token']??''));$key='dreminex_oauth_pending_'.self::hash($token);$pending=get_transient($key);delete_transient($key);if(!is_array($pending))wp_die('Authorization request expired.',400);
  $redirect=$pending['redirect_uri'];$state=$pending['state'];if(($_POST['decision']??'')!=='approve')self::redirect_oauth($redirect,['error'=>'access_denied','error_description'=>'The resource owner denied the request.','state'=>$state],$pending['client_id'],'denied');
  $submitted=array_values(array_unique(array_map('sanitize_text_field',(array)wp_unslash($_POST['approved_scopes']??[]))));$scopes=array_values(array_intersect((array)$pending['scopes'],$submitted));if(!in_array('mcp:discover',$scopes,true))wp_die('Ability discovery scope is required for this MCP connection.',400);
  $code=self::token(32);global $wpdb;$wpdb->update(self::table('clients'),['allowed_scopes'=>self::json($scopes)],['client_id'=>$pending['client_id']],['%s'],['%s']);$wpdb->insert(self::table('codes'),['code_hash'=>self::hash($code),'client_id'=>$pending['client_id'],'user_id'=>get_current_user_id(),'redirect_uri'=>$redirect,'code_challenge'=>$pending['challenge'],'scopes'=>self::json($scopes),'expires_at'=>self::later(10*MINUTE_IN_SECONDS)],['%s','%s','%d','%s','%s','%s','%s']);
  self::redirect_oauth($redirect,['code'=>$code,'state'=>$state],$pending['client_id'],'approved');
 }
 /** Build an exact RFC 3986 query response. ChatGPT validates this issuer byte-for-byte. */
 public static function authorization_response_url($url,$args){
  if(!self::valid_redirect($url))return new WP_Error('invalid_redirect_uri','OAuth redirect URI is invalid.');
  $parts=wp_parse_url($url);$current=[];if(!empty($parts['query']))parse_str($parts['query'],$current);
  $args=is_array($args)?$args:[];$args['iss']=self::issuer();$query=http_build_query(array_merge($current,$args),'','&',PHP_QUERY_RFC3986);
  $authority=strtolower($parts['scheme']).'://'.$parts['host'].(isset($parts['port'])?':'.(int)$parts['port']:'');
  return $authority.($parts['path']??'').($query!==''?'?'.$query:'');
 }
 private static function redirect_oauth($url,$args,$client_id='',$outcome='response'){
  $location=self::authorization_response_url($url,$args);if(is_wp_error($location))wp_die('Invalid OAuth redirect URI.',400);
  update_option('dreminex_oauth_last_authorization_response',['time'=>gmdate('c'),'client_hash'=>substr(self::hash($client_id),0,16),'redirect_host'=>(string)wp_parse_url($url,PHP_URL_HOST),'issuer'=>self::issuer(),'outcome'=>sanitize_key($outcome)],false);
  nocache_headers();header('Cache-Control: no-store');header('Pragma: no-cache');wp_redirect($location,302,'Dreminex OAuth');exit;
 }

 public static function token_endpoint($request){
  $data=self::request_data($request);$grant=(string)($data['grant_type']??'');
  if($grant==='authorization_code')return self::exchange_code($data);
  if($grant==='refresh_token')return self::exchange_refresh($data);
  if($grant===self::DEVICE_GRANT)return self::exchange_device($data);
  return self::oauth_error('unsupported_grant_type','Unsupported OAuth grant type.');
 }
 private static function exchange_code($data){
  $code=(string)($data['code']??'');$client_id=sanitize_text_field((string)($data['client_id']??''));$redirect=esc_url_raw((string)($data['redirect_uri']??''));$verifier=(string)($data['code_verifier']??'');global $wpdb;$table=self::table('codes');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE code_hash=%s",self::hash($code)),ARRAY_A);
  if(!$row||$row['client_id']!==$client_id||!hash_equals($row['redirect_uri'],$redirect)||strtotime($row['expires_at'])<time())return self::oauth_error('invalid_grant','Authorization code is invalid or expired.');
  $resource=esc_url_raw((string)($data['resource']??''));if($resource!==''&&rtrim($resource,'/')!==rtrim(self::resource(),'/'))return self::oauth_error('invalid_target','Tokens may only be issued for the Dreminex MCP resource.');$derived=rtrim(strtr(base64_encode(hash('sha256',$verifier,true)),'+/','-_'),'=');if(!hash_equals($row['code_challenge'],$derived))return self::oauth_error('invalid_grant','PKCE verification failed.');$wpdb->delete($table,['code_hash'=>$row['code_hash']],['%s']);return self::issue_tokens($client_id,(int)$row['user_id'],json_decode($row['scopes'],true));
 }
 private static function exchange_refresh($data){
  $raw=(string)($data['refresh_token']??'');$client_id=sanitize_text_field((string)($data['client_id']??''));global $wpdb;$table=self::table('refresh_tokens');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE token_hash=%s",self::hash($raw)),ARRAY_A);
  if(!$row||$row['client_id']!==$client_id||!empty($row['revoked'])||strtotime($row['expires_at'])<time())return self::oauth_error('invalid_grant','Refresh token is invalid or expired.');$resource=esc_url_raw((string)($data['resource']??''));if($resource!==''&&rtrim($resource,'/')!==rtrim(self::resource(),'/'))return self::oauth_error('invalid_target','Tokens may only be issued for the Dreminex MCP resource.');$wpdb->update($table,['revoked'=>1],['token_hash'=>$row['token_hash']],['%d'],['%s']);return self::issue_tokens($client_id,(int)$row['user_id'],json_decode($row['scopes'],true));
 }
 private static function issue_tokens($client_id,$user_id,$scopes){
  $access=self::token(32);$refresh=self::token(40);global $wpdb;$now=self::now();$scope_json=self::json(array_values((array)$scopes));
  $wpdb->insert(self::table('tokens'),['token_hash'=>self::hash($access),'client_id'=>$client_id,'user_id'=>$user_id,'scopes'=>$scope_json,'expires_at'=>self::later(HOUR_IN_SECONDS),'created_at'=>$now],['%s','%s','%d','%s','%s','%s']);
  $wpdb->insert(self::table('refresh_tokens'),['token_hash'=>self::hash($refresh),'client_id'=>$client_id,'user_id'=>$user_id,'scopes'=>$scope_json,'expires_at'=>self::later(30*DAY_IN_SECONDS),'created_at'=>$now],['%s','%s','%d','%s','%s','%s']);
  if(!in_array($client_id,[self::NEXUS_CLIENT,self::NEXUS_DESKTOP_CLIENT],true))$wpdb->update(self::table('clients'),['last_used_at'=>$now],['client_id'=>$client_id],['%s'],['%s']);
  $response=rest_ensure_response(['access_token'=>$access,'token_type'=>'Bearer','expires_in'=>HOUR_IN_SECONDS,'refresh_token'=>$refresh,'scope'=>implode(' ',(array)$scopes),'resource'=>self::resource(),'iss'=>self::issuer()]);$response->header('Cache-Control','no-store');$response->header('Pragma','no-cache');return $response;
 }

 public static function device_endpoint($request){
  $ip=(string)($_SERVER['REMOTE_ADDR']??'');$rate='dreminex_oauth_device_'.self::hash($ip);$count=(int)get_transient($rate);if($count>=20)return self::oauth_error('rate_limited','Too many device pairing requests.',429);set_transient($rate,$count+1,HOUR_IN_SECONDS);
  $data=self::request_data($request);$client_id=sanitize_text_field((string)($data['client_id']??self::NEXUS_CLIENT));$client=self::client($client_id);if(!$client||!empty($client['revoked']))return self::oauth_error('invalid_client','Unknown device client.',401);$allowed=json_decode($client['allowed_scopes'],true);$scopes=self::clean_scopes($data['scope']??'',is_array($allowed)?$allowed:null);if(is_wp_error($scopes))return $scopes;
  $device=self::token(40);$chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';$user='';for($i=0;$i<8;$i++)$user.=$chars[random_int(0,strlen($chars)-1)];$user=substr($user,0,4).'-'.substr($user,4);
  global $wpdb;$wpdb->insert(self::table('device_codes'),['device_hash'=>self::hash($device),'user_code_hash'=>self::hash(str_replace('-','',$user)),'client_id'=>$client_id,'scopes'=>self::json($scopes),'expires_at'=>self::later(10*MINUTE_IN_SECONDS),'created_at'=>self::now()],['%s','%s','%s','%s','%s','%s']);$verify=admin_url('admin.php?page=dreminex-oauth-device');
  return rest_ensure_response(['device_code'=>$device,'user_code'=>$user,'verification_uri'=>$verify,'verification_uri_complete'=>add_query_arg('user_code',$user,$verify),'expires_in'=>600,'interval'=>5]);
 }
 public static function device_page(){
  if(!is_user_logged_in()){auth_redirect();return;}if(!current_user_can('manage_woocommerce')&&!current_user_can('manage_options'))wp_die('Store management permission is required.',403);$code=sanitize_text_field(wp_unslash($_GET['user_code']??''));echo '<div class="wrap"><h1>Connect Dreminex Nexus</h1><p>Enter the code shown in the Nexus app. Approving binds this device to your current WordPress account.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_oauth_device_approve">';wp_nonce_field('dreminex_oauth_device_approve');echo '<label>Device code <input name="user_code" required pattern="[A-Za-z0-9-]{8,9}" value="'.esc_attr($code).'" autocomplete="one-time-code"></label>';submit_button('Approve device');echo '</form></div>';
 }
 public static function device_approve(){
  if(!is_user_logged_in())wp_die('Sign in required.',401);if(!current_user_can('manage_woocommerce')&&!current_user_can('manage_options'))wp_die('Store management permission is required.',403);check_admin_referer('dreminex_oauth_device_approve');$code=strtoupper(preg_replace('/[^A-Z0-9]/','',wp_unslash($_POST['user_code']??'')));global $wpdb;$table=self::table('device_codes');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE user_code_hash=%s",self::hash($code)),ARRAY_A);if(!$row||strtotime($row['expires_at'])<time()||$row['status']!=='pending')wp_die('Device code is invalid or expired.',400);$wpdb->update($table,['status'=>'approved','user_id'=>get_current_user_id()],['device_hash'=>$row['device_hash']],['%s','%d'],['%s']);wp_safe_redirect(admin_url('admin.php?page=dreminex-native-mcp&connected=nexus'));exit;
 }
 private static function exchange_device($data){
  $raw=(string)($data['device_code']??'');$client_id=sanitize_text_field((string)($data['client_id']??self::NEXUS_CLIENT));global $wpdb;$table=self::table('device_codes');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE device_hash=%s",self::hash($raw)),ARRAY_A);if(!$row||$row['client_id']!==$client_id||strtotime($row['expires_at'])<time())return self::oauth_error('expired_token','Device code is invalid or expired.');
  if($row['status']==='pending'){$wpdb->update($table,['last_polled_at'=>self::now()],['device_hash'=>$row['device_hash']],['%s'],['%s']);return self::oauth_error('authorization_pending','The owner has not approved this device yet.',400);}if($row['status']!=='approved')return self::oauth_error('access_denied','Device authorization was denied.');$wpdb->delete($table,['device_hash'=>$row['device_hash']],['%s']);return self::issue_tokens($client_id,(int)$row['user_id'],json_decode($row['scopes'],true));
 }

 public static function authenticate($request,$required=[]){
  $header=(string)$request->get_header('authorization');if(!preg_match('/^Bearer\s+(.+)$/i',$header,$m))return self::oauth_error('oauth_required','A valid Dreminex OAuth bearer token is required.',401);
  global $wpdb;$table=self::table('tokens');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE token_hash=%s",self::hash(trim($m[1]))),ARRAY_A);if(!$row||!empty($row['revoked'])||strtotime($row['expires_at'])<time())return self::oauth_error('invalid_token','The access token is invalid or expired.',401);$client=self::client($row['client_id']);if(!$client||!empty($client['revoked']))return self::oauth_error('invalid_client','The OAuth client is revoked.',401);$scopes=(array)json_decode($row['scopes'],true);foreach((array)$required as $scope)if(!in_array($scope,$scopes,true))return self::oauth_error('insufficient_scope','Missing required scope: '.$scope,403);
  $mode=self::normalize_mode($client['permission_mode']??'sandbox');$selected=(array)json_decode($client['allowed_scopes']??'[]',true);$status=self::scope_status($mode,$scopes,$selected);wp_set_current_user((int)$row['user_id']);self::$context=['client_id'=>$row['client_id'],'user_id'=>(int)$row['user_id'],'scopes'=>$scopes,'selected_scopes'=>$status['selected_scopes'],'missing_scopes'=>$status['missing_scopes'],'high_risk_missing_scopes'=>$status['high_risk_missing_scopes'],'permission_mode'=>$mode,'scope_revision'=>self::SCOPE_REVISION,'reconnect_required'=>$status['reconnect_required'],'token_hash'=>$row['token_hash']];return true;
 }
 public static function context(){return self::$context;}
 public static function has_scope($scope){return in_array($scope,self::$context['scopes']??[],true);}

 public static function revoke_endpoint($request){
  $data=self::request_data($request);$raw=(string)($data['token']??'');$client_id=sanitize_text_field((string)($data['client_id']??''));if($raw==='')return rest_ensure_response([]);global $wpdb;$hash=self::hash($raw);foreach(['tokens','refresh_tokens'] as $suffix){$table=self::table($suffix);if($client_id!=='')$wpdb->query($wpdb->prepare("UPDATE {$table} SET revoked=1 WHERE token_hash=%s AND client_id=%s",$hash,$client_id));else $wpdb->query($wpdb->prepare("UPDATE {$table} SET revoked=1 WHERE token_hash=%s",$hash));}return rest_ensure_response([]);
 }
 public static function introspect_endpoint($request){
  $data=self::request_data($request);$raw=(string)($data['token']??'');$client_id=sanitize_text_field((string)($data['client_id']??''));global $wpdb;$row=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::table('tokens').' WHERE token_hash=%s',self::hash($raw)),ARRAY_A);$active=$row&&!$row['revoked']&&strtotime($row['expires_at'])>=time()&&($client_id===''||$row['client_id']===$client_id);if(!$active)return rest_ensure_response(['active'=>false]);return rest_ensure_response(['active'=>true,'client_id'=>$row['client_id'],'username'=>(string)$row['user_id'],'scope'=>implode(' ',(array)json_decode($row['scopes'],true)),'exp'=>strtotime($row['expires_at']),'aud'=>self::resource()]);
 }

 public static function maybe_discovery(){
  if(!Dreminex_Native_MCP::enabled())return;$path=rtrim((string)wp_parse_url($_SERVER['REQUEST_URI']??'',PHP_URL_PATH),'/');$home=rtrim((string)wp_parse_url(home_url(),PHP_URL_PATH),'/');$pr=$home.'/.well-known/oauth-protected-resource';$pr_scoped=$home.'/.well-known/oauth-protected-resource/wp-json/mcp/dreminex';$as=$home.'/.well-known/oauth-authorization-server';$as_scoped=$home.'/.well-known/oauth-authorization-server/dreminex-oauth';
  if($path===$pr||$path===$pr_scoped)self::serve(['resource'=>self::resource(),'resource_name'=>'Dreminex Native MCP','authorization_servers'=>[self::issuer()],'bearer_methods_supported'=>['header'],'scopes_supported'=>self::scopes(),'dreminex_scope_revision'=>self::SCOPE_REVISION]);
  if($path===$as||$path===$as_scoped){$base=rest_url('dreminex/v1/oauth');self::serve(['issuer'=>self::issuer(),'authorization_endpoint'=>admin_url('admin.php?page=dreminex-oauth-authorize'),'token_endpoint'=>$base.'/token','registration_endpoint'=>$base.'/register','revocation_endpoint'=>$base.'/revoke','introspection_endpoint'=>$base.'/introspect','device_authorization_endpoint'=>$base.'/device','response_types_supported'=>['code'],'response_modes_supported'=>['query'],'grant_types_supported'=>['authorization_code','refresh_token',self::DEVICE_GRANT],'code_challenge_methods_supported'=>['S256'],'token_endpoint_auth_methods_supported'=>['none'],'authorization_response_iss_parameter_supported'=>true,'scopes_supported'=>self::scopes(),'dreminex_scope_revision'=>self::SCOPE_REVISION]);}
 }
 private static function serve($doc){status_header(200);nocache_headers();header('Content-Type: application/json; charset=UTF-8');echo self::json($doc);exit;}
 public static function gc(){global $wpdb;$now=self::now();foreach(['codes','tokens','refresh_tokens','device_codes'] as $suffix)$wpdb->query($wpdb->prepare('DELETE FROM '.self::table($suffix).' WHERE expires_at < %s',$now));}

 public static function clients(){global $wpdb;$rows=$wpdb->get_results('SELECT client_id,client_name,allowed_scopes,permission_mode,created_at,last_used_at,revoked FROM '.self::table('clients').' ORDER BY created_at DESC',ARRAY_A);foreach($rows as &$row){$json=$wpdb->get_var($wpdb->prepare('SELECT scopes FROM '.self::table('tokens').' WHERE client_id=%s AND revoked=0 AND expires_at >= %s ORDER BY created_at DESC LIMIT 1',$row['client_id'],self::now()));$granted=is_string($json)?json_decode($json,true):[];$granted=is_array($granted)?$granted:[];$selected=(array)json_decode($row['allowed_scopes']??'[]',true);$row=array_merge($row,self::scope_status($row['permission_mode']??'sandbox',$granted,$selected));$row['granted_scopes']=$granted;}unset($row);return $rows;}
 private static function latest_granted_scopes($client_id){global $wpdb;$json=$wpdb->get_var($wpdb->prepare('SELECT scopes FROM '.self::table('tokens').' WHERE client_id=%s AND revoked=0 AND expires_at >= %s ORDER BY created_at DESC LIMIT 1',$client_id,self::now()));$scopes=is_string($json)?json_decode($json,true):[];return array_values(array_intersect(self::scopes(),is_array($scopes)?$scopes:[]));}
 public static function set_client($client_id,$mode,$revoke=false,$selected=null,$use_profile=false){$mode=self::normalize_mode($mode);$data=['permission_mode'=>$mode,'revoked'=>$revoke?1:0];$formats=['%s','%d'];$explicit=is_array($selected)?array_values(array_unique(array_intersect(self::scopes(),$selected))):[];if($use_profile||!is_array($selected)){$selected=array_values(array_unique(array_merge(self::recommended_scopes($mode),array_intersect($explicit,self::high_risk_scopes()))));}else{$selected=$explicit;}if($mode==='read_only')$selected=array_values(array_intersect($selected,self::read_scopes()));if(!in_array('mcp:discover',$selected,true))array_unshift($selected,'mcp:discover');$data['allowed_scopes']=self::json($selected);$formats[]='%s';global $wpdb;return $wpdb->update(self::table('clients'),$data,['client_id'=>$client_id],$formats,['%s'])!==false;}
}
