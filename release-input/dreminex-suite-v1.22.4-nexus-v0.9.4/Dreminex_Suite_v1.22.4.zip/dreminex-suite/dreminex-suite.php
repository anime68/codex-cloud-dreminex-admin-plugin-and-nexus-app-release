<?php
/**
 * Plugin Name: Dreminex Suite
 * Description: Portable, individually managed store modules for WooCommerce and customer communication.
 * Version: 1.22.4
 * Requires PHP: 8.0
 * Requires Plugins: woocommerce
 * Author: Dreminex Fashion
 * Text Domain: dreminex-suite
 */
if (!defined('ABSPATH')) exit;
define('DREMINEX_SUITE_VERSION','1.22.4');
define('DREMINEX_SUITE_PATH',plugin_dir_path(__FILE__));
define('DREMINEX_SUITE_FILE',__FILE__);
add_action('before_woocommerce_init',static function() {
 if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
  \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables',__FILE__,true);
  \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks',__FILE__,false);
 }
});
try {
 foreach (['includes/class-dreminex-suite-features.php','includes/class-dreminex-suite-upgrades.php','includes/class-dreminex-suite-routing.php','includes/class-dreminex-suite-experience.php','includes/class-dreminex-suite-access.php','includes/class-dreminex-suite-cache.php','includes/class-dreminex-suite-contact-trash.php','includes/class-dreminex-suite-imports.php','includes/class-dreminex-suite-data.php','includes/class-dreminex-suite-setup.php','includes/class-dreminex-suite-control.php','includes/class-dreminex-native-oauth.php','includes/class-dreminex-mcp-registry-policy.php','includes/class-dreminex-mcp-abilities-v2.php','includes/class-dreminex-mcp-media-v2.php','includes/class-dreminex-mcp-upload.php','includes/class-dreminex-native-mcp.php','includes/class-dreminex-plugin-updater.php','modules/dreminex_flash_sale.php','includes/class-dreminex-supplier-pricing.php','includes/class-dreminex-supplier-workflow.php','includes/class-dreminex-supplier-accounts.php','modules/dreminex_supplier_visual.php','modules/class-dreminex-supplier-nexus.php','modules/dreminex_supplier_monitor.php','includes/class-dreminex-security-center.php','includes/class-dreminex-nexus-operations.php','includes/class-dreminex-nexus-app.php','includes/class-dreminex-suite.php'] as $dependency) {
  if (!is_readable(DREMINEX_SUITE_PATH.$dependency)) throw new RuntimeException('Dreminex Suite dependency is missing.');
  require_once DREMINEX_SUITE_PATH.$dependency;
 }
} catch (Throwable $error) {
 add_action('admin_notices',static function() {
  if (current_user_can('manage_options')) echo '<div class="notice notice-error"><p>Dreminex Suite could not load. Restore the complete plugin package from a trusted backup.</p></div>';
 });
 return;
}
Dreminex_Plugin_Updater::boot();
register_activation_hook(__FILE__,['Dreminex_Suite','activate']);
add_action('plugins_loaded',['Dreminex_Suite','boot'],20);
