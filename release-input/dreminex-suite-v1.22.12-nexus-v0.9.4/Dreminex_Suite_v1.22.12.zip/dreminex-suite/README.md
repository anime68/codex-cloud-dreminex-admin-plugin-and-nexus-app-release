# Dreminex Suite 1.22.12

Portable WooCommerce module suite for WordPress. Requires PHP 8.0+ and WooCommerce.

Dreminex Nexus is the mobile management console for the catalog, orders, supplier monitoring, contact requests, Checkout Protection, Delivery Advance & Wallet, Welcome Offers, notifications and Security operations. The paired app version and checksum come from the verified public release manifest. Each of up to five connected websites keeps isolated credentials, settings and cached records.

Native MCP 1.22.12 is the live-registry and access-profile baseline. It reads registered WordPress abilities at runtime, keeps internal helpers private, and exposes third-party abilities only when their provider contract or an owner policy marks them public. Permission modes remain separate from OAuth grants. Existing tokens keep their exact scopes; owners select a mode scope profile and reconnect before any additional scope becomes available. Discovery, inspection, validation and execution share one authorization decision with actionable reason codes. The Abilities Hub retains master, provider, category and individual controls; Custom abilities & skills stores reviewed metadata and bounded guidance for abilities that are already registered. Discovery also returns normalized metadata, distinct coverage counts and stable diagnostic reasons; administrators can export masked activity for approved time ranges.

Nexus 0.7 removes the app-side Preparation/Publisher source-file editor; those project abilities remain available to the external MCP projects. Contact, Checkout Protection and Welcome Offer operations are managed in Nexus. Delivery Advance & Wallet remains available in both Nexus and WordPress. Exact order notifications open the named WooCommerce order. Private contact evidence can be downloaded only through its authenticated site-bound route with a 10 MiB cap.

Android checks the signed release manifest served by its connected website. The Suite plugin does not bundle an APK, Windows installer or app manifest; it reads the latest checksum-verified Android entry from the public release repository and exposes it through the existing authenticated app-release route. Before opening Android's installer, Nexus checks the same-site HTTPS host, APK SHA-256, package ID, increasing versionCode and permanent signer certificate. Android asks the owner to confirm installation. The Windows app remains a native client and existing installations can keep using their paired websites, but this release does not include or advertise a Windows installer.

Delivery Advance & Wallet keeps customer-added cash separate from expiring promotional credit. Cash on Delivery appears only for carts whose products are explicitly marked COD-only. Product listings remain Draft by default, and the Publisher variation ceiling remains configurable from 1 to 564 rows (default 64). Workflow source files remain limited to 2 MiB; handoffs over 44 variation rows use a complete JSON file.

Direct push notifications remain optional and require Firebase app configuration plus the site's protected FCM service-account credential. Authenticated background sync remains the fallback. No staging or production site was changed while preparing this source.

Maintenance references are in the DREMINEX A-to-Z handoff files and docs/. See the versioned release notes and test report before any site update.

Version 1.13.44 pins Quick View’s gallery and product summary to their assigned desktop grid columns and lets the summary fill its column.

Version 1.13.43 fixes the desktop Quick View gallery and description widths for the site's RTWPVG gallery markup. Both now fill their assigned columns within the scrollable modal.

Version 1.13.42 corrects the ShopBuilder archive card selectors so desktop shop/category cards use the Storefront Design module’s configurable surface colour across the outer card and content panel. The controls are available in the Storefront Design module. Phone styles remain unchanged.

Version 1.13.41 adds independent Storefront Design controls for desktop Shop/related-product cards and Quick View, including card background/radius/padding and modal width/gap/image background. It matches the homepage’s existing cool grey card surface and keeps the phone styling unchanged.

Version 1.13.40 keeps the offer placement and thumbnail from 1.13.39, and corrects Supplier Monitor pricing for a dropshipping reseller: ৳15 other cost, ৳30 return reserve, ৳25 general ad budget (selected products ৳30–৳90), and 1.5% supplier payment fee on wholesale. The dropshipping platform handles delivery and COD; customer delivery advance is used only in the delivered-price cap. Existing price rules must be reviewed and saved again before proposals.

Version 1.13.30 removes a spurious empty numeric supplier-code entry when the first colour map is saved, and guides Preparation to inspect unfiltered recent originals before reporting no Media ID. On Main, enable the optional AI Product Publisher module in Suite Modules to expose its listing and media abilities.

Version 1.13.29 accepts a confirmed colour-to-supplier-SKU map with one purchasable code per colour, supports a product-specific existing global size taxonomy, exposes that choice in catalog/readback, and prevents a Women’s item from using the configured Men’s size attribute. Its bundled Preparation guidance searches suitable published Upsells and Cross-sells read-only. Existing products are not migrated automatically; a product in Trash must be deliberately restored before listing updates. A selling price is still required for purchasable variations.

Version 1.13.28 updates the Preparation workflow guide and bundled skill: ordinary preparation returns context without hand-off JSON; an explicit hand-off request returns only the complete JSON. Publisher abilities and WordPress product/media behavior are unchanged.

Version 1.13.26 added read-only Media Library candidates and screenshot-photo visual ranking for Preparation. Version 1.13.27 limits each ranking request to 40 candidates and skips oversized originals without a medium derivative to stay within staging's execution budget. Skipped images require manual inspection; ranking always requires visual confirmation. The Publisher may update an existing attachment's permalink slug, title and alt only when `update_media_metadata=true`; the physical filename and image URL do not change. Existing products and media are not migrated.

Version 1.13.25 adds verified supplier SKU handling for colour/size variations in AI Product Publisher. It includes all earlier checkout and customer-page fixes.

Version 1.13.22 keeps Checkout's order action and coupon/login notices legible despite later theme CSS. It includes all earlier 1.13.21 customer-page work.

Version 1.13.21 keeps the Cart checkout action legible against the site's later button overrides. It includes all 1.13.20 customer-page work.

Version 1.13.20 applies the Suite design to customer-facing shop, category, cart, checkout, tracking, wishlist and compare pages. It repairs legacy saved-list shortcode output through active ShopBuilder, removes a Contact theme placeholder at render time and corrects the theme's home breadcrumb label. Storefront Design includes separate switches for page headings, archive filters, cart/checkout, saved lists and Contact cleanup. WooCommerce and ShopBuilder remain responsible for product, cart, checkout and saved-list behavior.

Version 1.13.17 extends the signed-in design through native Orders, Downloads, Addresses and Account details content. The WooCommerce templates and account forms remain native; the Suite adds scoped styling and page introductions. Empty Orders has an optional web-optimized illustration.

Version 1.13.16 improves the signed-in WooCommerce My Account dashboard and navigation. The Accounts module now controls the dashboard switch and copy; native orders, addresses, profile and extension hooks remain active. The 1.13.15 sign-in and registration experience is retained.

Version 1.13.15 adds a configurable, responsive WooCommerce account registration experience inside the Registration email confirmation module. The 1.13.14 Suite admin redesign and Homepage Studio are retained. An optional account image is chosen separately from each site's Media Library; without one, the branded text panel renders.

The suite retains WordPress options, custom tables, WooCommerce orders, imported-module settings and existing module enablement during ordinary updates. Version 1.13.0 bundles AI Product Publisher as an optional module. Activate it from Suite Modules, then configure its dashboard panel; it uses the existing Novamira OAuth connection and creates Draft products.

Version 1.13.1 adds an optional Storefront Design module. It owns the product metadata, variation, description, title and mobile cart presentation formerly carried in Dreminex PWA 1.3.3. Turn it on in Suite → All Modules and configure its dashboard. This module does not require the PWA to be active.

Version 1.13.2 fills the size chart width, aligns cart variation details and rounds ShopBuilder quantity buttons. Version 1.13.3 adds category reuse/creation, direct image bytes and HTTPS URL import, attachment metadata, selective listing/variation updates, stock availability and audited publication in one call. A private ChatGPT attachment still requires access to its actual bytes before WordPress can import it.

Version 1.13.4 adds one-call batched image imports, repeat-upload reuse, default SKU/stock guidance, and type/slug inference in `draft-complete`. The optional prompt window setting is advisory to a compatible MCP App UI; a WordPress plugin cannot display a native timed prompt or grant another ChatGPT session access to private attachments.

Version 1.13.5 clarifies direct `draft-complete` inputs after a generic WooCommerce `INVALID_ARGUMENT` failure and distinguishes an existing variation from the requested standalone listing. Simple products in this module have one purchasable size; a one-color listing with several selectable sizes uses Variable product variations.

Version 1.13.6 adds a prepared-sheet `listing-apply` entry point for one-call media, category, Simple/Variable Draft/Publish/Update, variations, SEO and related products. Preparation and publishing guidance are separate and version-independent. Private Library links still require an assistant-side source transfer. Quantity styling now uses one consistent bordered group with a white value field and sized cyan controls.

This build does not implement courier live API adapters, a hosted license/update service, full English translation coverage, or comprehensive malware blocking. See the guide for limitations and the updated settings.
