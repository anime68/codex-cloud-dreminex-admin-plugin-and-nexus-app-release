<?php
$root=dirname(__DIR__);
$main=file_get_contents($root.'/dreminex-suite.php');
$nexus=file_get_contents($root.'/modules/class-dreminex-supplier-nexus.php');
$accounts=file_get_contents($root.'/includes/class-dreminex-supplier-accounts.php');
$updater=file_get_contents($root.'/includes/class-dreminex-plugin-updater.php');
function v1221($ok,$message){if(!$ok){fwrite(STDERR,"FAIL: $message\n");exit(1);}}
v1221(str_contains($main,"DREMINEX_SUITE_VERSION','1.22.1"),'Suite version');
foreach(['Overview','Accounts & Platforms','Products & Mappings','Alerts','Approvals','Scan Queue','Activities','Settings'] as $tab)v1221(str_contains($nexus,$tab),"Missing tab $tab");
v1221(str_contains($accounts,"credential_state'=>'device_protected"),'Secret-free API state');
v1221(!preg_match('/password|cookie|token/', substr($accounts,strpos($accounts,'public static function public_row'),700)),'Public account row must not expose secrets');
v1221(str_contains($accounts,"revision_conflict")&&str_contains($accounts,"action_id"),'Revision and action IDs');
v1221(str_contains($updater,'pre_set_site_transient_update_plugins')&&str_contains($updater,'upgrader_pre_download'),'WordPress updater hooks');
v1221(str_contains($updater,'hash_file')&&str_contains($updater,'codex-cloud-dreminex-admin-plugin-and-nexus-app-release'),'Verified public updater');
echo "Supplier workflow v1.22.1 contracts: PASS\n";
