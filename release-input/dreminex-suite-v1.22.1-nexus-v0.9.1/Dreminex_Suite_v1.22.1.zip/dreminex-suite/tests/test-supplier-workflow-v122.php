<?php
$root=dirname(__DIR__);$workflow=file_get_contents($root.'/includes/class-dreminex-supplier-workflow.php');$monitor=file_get_contents($root.'/modules/dreminex_supplier_monitor.php');$nexus=file_get_contents($root.'/modules/class-dreminex-supplier-nexus.php');$bootstrap=file_get_contents($root.'/dreminex-suite.php');
function ok122($v,$m){if(!$v){fwrite(STDERR,"FAIL: $m\n");exit(1);}echo "PASS: $m\n";}
ok122(str_contains($bootstrap,"Version: 1.22.1")&&str_contains($bootstrap,'class-dreminex-supplier-workflow.php'),'v1.22.1 preserves the workflow service');
ok122(str_contains($workflow,"'fixed_initial_gap'")&&str_contains($workflow,'initial_supplier_price')&&str_contains($workflow,'locked_gap'),'additive baseline schema preserves fixed-gap facts');
ok122(str_contains($workflow,'(float)$supplier_price+(float)$locked_gap'),'fixed gap adds only current supplier price and locked gap');
ok122(!preg_match('/fixed_gap_quote[^}]+(?:ad_cost|delivery|profit|packaging)/s',$workflow),'fixed-gap calculation does not recalculate costs or profit');
ok122(str_contains($workflow,"actions/preview")&&str_contains($workflow,"preview_required")&&str_contains($workflow,"read_back_verified"),'mutations require preview, confirmation and read-back');
ok122(str_contains($workflow,'idempotency_key')&&str_contains($workflow,'UNIQUE KEY idempotency'),'actions are idempotent');
ok122(str_contains($workflow,"session_expired")&&str_contains($workflow,"monitor_failed")&&str_contains($workflow,"needs_review"),'unknown and session failures remain review states');
ok122(str_contains($workflow,'sync_legacy_events')&&str_contains($workflow,"'color_image_missing'=>'image_missing'")&&str_contains($workflow,"'variant_missing'=>'variant_removed'"),'legacy color size variation events normalize without overwrite');
ok122(str_contains($monitor,"do_action('dreminex_supplier_observation_processed'") ,'accepted observations feed the shared lifecycle');
ok122(str_contains($nexus,"'accounts'=>'Accounts & Platforms'")&&str_contains($nexus,"'queue'=>'Scan Queue'"),'plugin information architecture is wired');
ok122(str_contains($workflow,"['suppliers:write','approvals:write']"),'app mutations require supplier and approval scopes');
echo "Supplier workflow fixed-gap regression contracts passed.\n";
