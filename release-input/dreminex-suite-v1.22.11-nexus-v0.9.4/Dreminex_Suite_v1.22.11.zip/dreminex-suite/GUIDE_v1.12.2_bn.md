# Dreminex Suite v1.12.2 — Required product links & search
Bundle offer-এর title-এর নিচে Required product-এর নাম এখন clickable। নির্দিষ্ট variation হলে তার color/size attributes সহ product page খুলবে। সেই page থেকে customer স্বাভাবিক catalog price-এ qualifying product cart-এ যোগ করতে পারবে। Reward product Flash Sale page থেকে যোগ করতে হবে। Cart/checkout-এর existing শর্ত একই আছে।

Module configuration-এর প্রত্যেক offer row-এ Find required product / variation-এ নাম, ID বা SKU লিখুন। Search result-এর Select required product চাপলে ID ও selected name বসবে। Variation result-এ attributes দেখা যায়। Use same product চাপলে 0 হবে। পরিবর্তন স্থায়ী করতে Save settings চাপুন। নতুন ও আগে থেকে থাকা row দুটোতেই কাজ করে। Manual ID-ও রাখা আছে।

Mobile homepage spacing-এর ভিতরের Elementor .e-con-inner padding-ও 12px করা হয়েছে। পূর্বে শুধু বাইরের padding পরিবর্তন করায় ভিতরে 60px থাকছিল। Desktop ও অন্য sections-এর layout পরিবর্তিত নয়। Current live offers ও on/off states reset করা হয়নি।
