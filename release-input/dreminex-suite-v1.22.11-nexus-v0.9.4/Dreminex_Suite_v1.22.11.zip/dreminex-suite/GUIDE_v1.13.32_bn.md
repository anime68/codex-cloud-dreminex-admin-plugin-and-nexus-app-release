# Dreminex Suite 1.13.32 — Product workflow

Preparation: exact product name দিয়ে long description-এর শুরুতে একটি ছোট `<h3>`; তারপর product paragraph ও প্রযোজ্য `<h4>` details/size guide। সব supplier screenshot SKU আলাদা evidence-এ, প্রতি sellable colour-এ একটি selected code, original Media ID-এর Title/Slug/Alt, সবচেয়ে ভালো যাচাইকৃত featured photo এবং বাকি ordered gallery-সহ handoff দেবে। তথ্য নেই এমন field অনুমান করবে না।

Publisher: handoff-এর site/ID/field হুবহু `listing-apply` বা scoped copy-র জন্য `listing-update`-এ বসাবে; image metadata, variations, SEO ও actual status readback করবে। Status-only কাজে `dreminex-products/product-lifecycle` ব্যবহার করবে: Draft, audited Publish, reversible Trash, Draft-এ Restore। Permanent Delete শুধু Trash-এ থাকা exact ID ও matching `confirm_product_id` দিয়ে স্পষ্ট নির্দেশে; media attachment মুছবে না। Response অস্পষ্ট হলে একই ID-র saved status আগে পড়বে।

Staging ও Main-এর product/media/category ID আলাদা। Project Settings-এ নিজ নিজ source package-এর প্রথম file-এর instruction বসাতে হবে; ZIP upload করলেই Project Settings পরিবর্তিত হয় না।
