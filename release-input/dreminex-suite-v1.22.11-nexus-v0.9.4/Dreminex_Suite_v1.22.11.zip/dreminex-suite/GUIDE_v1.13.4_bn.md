# Dreminex Suite 1.13.4 — দ্রুত AI প্রোডাক্ট লিস্টিং

বিদ্যমান `dreminex-suite` প্লাগইনটি Update/Replace করুন; uninstall করবেন না। আগে সাইটের backup রাখুন। PWA আলাদা। Suite → All Modules-এ **AI Product Publisher** চালু করে Product publishing controls দেখুন। পুরোনো standalone Publisher সক্রিয় থাকলে সেটি বন্ধ করে Suite মডিউল চালু করুন।

## ছবির আসল ফাইল কীভাবে যাবে

ChatGPT Work-এ মূল ছবি workspace file হিসেবে পাওয়া গেলে তার bytes `dreminex-products/media-batch-upload`-এ পাঠানো যায়। এক call-এ ১০টি পর্যন্ত ছবি, একই filename/bytes পুনরায় এলে আগের Media Library ID ফেরত, এবং আংশিক ব্যর্থ হলে সফল ID ও ব্যর্থ index ফেরত আসে। আগে থেকে সাইটে থাকা ছবি হলে তার ID, server incoming folder-এ থাকা ছবি হলে filename, ব্যবহারকারীর দেওয়া পৌঁছানো যায় এমন HTTPS URL হলে URL দিন। শুধু chat preview থাকা মানে ছবির bytes-এ access থাকা নয়। সেই client যদি মূল attachment-এ access না দেয়, WordPress plugin সেটি নিজে টেনে নিতে পারবে না।

## লিস্টিং

Novamira সংযোগে `catalog` দিয়ে duplicate ও category যাচাই করুন। দরকার হলে `category-ensure`। ছবির ID সংগ্রহের পর একটি `draft-complete` call-এ নাম, category IDs, image IDs, যাচাই করা বর্ণনা, দাম, color/HEX, sizes, আসল variation rows, SEO এবং প্রকাশের নির্দেশ দিন। `slug` ও simple/variable type না দিলে নাম ও options থেকে নির্ধারিত হয়। সব combinations বাস্তবে বিক্রি হলে তবেই `full_matrix=true`। `publish=true` কেবল ব্যবহারকারী স্পষ্টভাবে Publish বললে। অন্যথায় Draft। আংশিক ব্যর্থতায় ফেরত `product_id` দিয়ে resume করুন; একই পণ্য আবার তৈরি করবেন না। শেষে `product-read` দিয়ে যাচাই করে শুধু নাম, আসল status ও সরাসরি link জানান।

SKU না দিলে dashboard-এর auto SKU switch অনুযায়ী তৈরি বা ফাঁকা থাকবে। Stock quantity না দিলে কোনো সংখ্যা বানানো হবে না; স্টক unmanaged থাকবে। ব্যবহারকারী available বলেছেন, কিন্তু সংখ্যা দেননি—সেক্ষেত্রে `stock_status=instock` দিন।

Dashboard-এর optional prompt window ০–১০ সেকেন্ড একটি **advisory setting**; `listing-defaults` সেটি অন্য client-কে জানায়। Suite plugin নিজে ChatGPT-র native popup খুলতে বা দশ সেকেন্ড পরে উত্তর বন্ধ করতে পারে না। compatible MCP App UI না থাকলে assistant optional প্রশ্নের জন্য কাজ থামাবে না, default ব্যবহার করবে। অপরিহার্য দাম/আসল ছবি অনুপস্থিত হলে মিথ্যা তথ্য দিয়ে publish করবে না। ভিডিও থাকলে প্রোডাক্ট সম্পর্কিত যাচাইযোগ্য তথ্যের উৎস হিসেবে দেখা যায়; storefront gallery-তে ভিডিও দেখাতে আলাদা verified video integration দরকার।

Main site-এ একই ZIP update করলে মডিউলের এই abilities ও controls থাকবে। তবে main site-এর Novamira সংযোগ, অ্যাট্রিবিউট taxonomy, অনুমতি এবং AI client's file access আলাদাভাবে কার্যকর থাকতে হবে। আগে staging-এ Media Library, Draft/Publish, variations ও storefront যাচাই করুন।
