# Dreminex Suite v1.12.1 — ব্যবহার ও পরিবর্তন
Flash Sale-এর quantity/bundle/product configuration v1.12.0-এর মতোই রয়েছে।

Desktop header-এ Flash Sale button ও countdown এখন একই সারিতে। Countdown-এ আলাদা Days / Hrs / Mins / Secs unit, dark number এবং secondary brand label রয়েছে।
Mobile button ছোট করা হয়েছে ও text-এর আগে flash icon রয়েছে। Button-এর নিচে service section-এর আগে ব্যবধান 60px থেকে 12px করা হয়েছে; homepage-এর অন্য section বদলানো হয়নি। Countdown light tint ও thin cyan border-এর box-এ রয়েছে।
Scheduled হলে শুরু হওয়ার countdown, active হলে শেষ হওয়ার countdown; ended/disabled হলে clock লুকানো থাকে।
Discount badge background হালকা #CAF0F8, text dark #212529।

ZIP plugin update install করুন। পূর্বের বাংলা configuration guide ZIP-এর GUIDE_v1.12.0_bn.md-তে আছে। Current campaign, product prices ও module states অপরিবর্তিত।
