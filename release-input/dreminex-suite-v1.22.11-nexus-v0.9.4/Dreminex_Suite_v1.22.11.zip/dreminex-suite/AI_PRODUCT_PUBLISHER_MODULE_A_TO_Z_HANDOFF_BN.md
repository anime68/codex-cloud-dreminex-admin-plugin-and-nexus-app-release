# AI Product Publisher Module — A to Z Handoff, Review ও Update Workflow

সংস্করণ: Dreminex Suite 1.17.0  
মূল module: `modules/dreminex_ai_product_publisher.php`  
Workflow manager: `modules/class-dreminex-ai-workflow-projects.php`

এই ফাইলটি এমনভাবে বানানো হয়েছে যাতে পরে আমি বা অন্য কেউ AI Product Publisher module আপডেট করতে গেলে আগে বুঝতে পারি—কোন জিনিস কোথায় আছে, কেন আছে, কোন ability কী কাজ করে, কোন function-এর সঙ্গে কোন function যুক্ত, কোন setting বদলালে কী প্রভাব পড়ে এবং update শেষে কী কী পরীক্ষা করতে হবে।

## 1.17.0 app-first change

Module-এর standalone WordPress dashboard আর menu-তে নেই। Settings, Preparation/Publisher files ও project instructions Nexus app manage করে; abilities Native MCP-তে থাকে। `workflow-bootstrap` একটি task-এর live manifest/site/capacity একবারে দেয়। `handoff-execute` declared category/attribute/media prerequisite resolve করে fresh canonical preflight চালায়। WordPress description sanitization-এর আগে canonical wrapper বসায়, তাই harmless inline-style removal false mismatch নয়। Maximum variation row 564, default 64; project file 2 MB; 45+ row complete JSON file। Quick trigger-এ `sku_prefix` আছে। UI/API বদলালে `NEXUS_AI_WORKFLOW_PROJECTS_CONSOLE_A_TO_Z_HANDOFF_BN.md`-ও একই commit-এ update করতে হবে।

এই module-এর মূল কথা খুব সহজ:

> Preparation তথ্য যাচাই করে handoff বানাবে। Publisher সেই handoff অনুযায়ী WooCommerce-এ লিখবে। Create, Update, Publish, Trash বা Restore একে অন্যের সঙ্গে মিশবে না। কোনো write সফল হয়েছে কি না saved product readback দিয়ে নিশ্চিত হতে হবে।

---

## ১. Moduleটি আসলে কী কাজ করে

AI Product Publisher হলো Dreminex Suite-এর optional WooCommerce operations module। এটি পাঁচ ধরনের কাজ ম্যানেজ করে:

1. Selected site-এর category, attribute, Media Library ও existing product read-only দেখা।
2. Preparation-এর `PUBLISHER HANDOFF` write করার আগে যাচাই করা।
3. Simple বা Variable product Create/Draft/Publish/Update করা।
4. Image, image swatch, variation, SKU, stock, brand, SEO ও supplier source সংরক্ষণ করা।
5. Saved result readback, audit, partial recovery, Trash/Restore এবং workflow source management করা।

Moduleটি নিজে supplier product research করার জায়গা নয়। Research, screenshot SKU পড়া, copy/SEO প্রস্তুত করা ও exact media matching Preparation-এর কাজ। Publisher-এর কাজ হচ্ছে প্রস্তুত তথ্য সঠিক site-এ নিরাপদভাবে save করা।

---

## ২. পুরো system-এর connection

```text
Owner input / Supplier facts / Screenshots
                    ↓
          Product Preparation Project
   facts + media + taxonomy + price + SKU যাচাই
                    ↓
          Complete PUBLISHER HANDOFF
                    ↓
 dreminex-products/handoff-preflight (read-only)
                    ↓ ready=true
       dreminex-products/listing-apply
                    ↓
 WooCommerce product + media + variations + SEO
                    ↓
       saved stages + product-read readback
                    ↓
 Supplier source থাকলে Supplier Monitor link
```

এখানে `handoff-preflight` এবং `product-read` খুব গুরুত্বপূর্ণ। প্রথমটি write-এর আগের gate, দ্বিতীয়টি write-এর পরের সত্যতা যাচাই।

---

## ৩. কোন কোন file এই module-এর সঙ্গে সরাসরি যুক্ত

| File | কেন রাখা হয়েছে |
|---|---|
| `modules/dreminex_ai_product_publisher.php` | Ability registration, schema, validation, product/media/variation write এবং readback |
| `modules/class-dreminex-ai-workflow-projects.php` | Preparation ও Publisher source files, revision, proposal, private experience log ও dashboard manager |
| `workflow-profiles/preparation/*.md` | Preparation কীভাবে facts, screenshots, images, SKU, size এবং handoff তৈরি করবে |
| `workflow-profiles/publisher/*.md` | Publisher কীভাবে handoff apply, verify ও partial recovery করবে |
| `assets/ai-workflow-projects.js` | 2 MB client-side check, copy buttons এবং same-name replacement warning |
| `assets/ai-workflow-projects.css` | Dedicated Publisher dashboard ও Workflow source manager-এর responsive admin UI |
| `assets/suite-admin.css` | Module settings panel-এর সাধারণ Suite admin design |
| `docs/AI_PRODUCT_PUBLISHER_MODULE_BN.md` | পুরোনো সংক্ষিপ্ত overview |
| `docs/PREPARATION_PUBLISHER_CONNECTION_BN.md` | Preparation → Publisher → Supplier Monitor connection-এর সংক্ষিপ্ত note |
| এই file | Module-এর পূর্ণ maintenance handoff এবং update map |

ChatGPT Project Settings-এ আগে থেকে দেওয়া Instructions বা Project Files আলাদা copy। Plugin update করলেই ChatGPT Project-এর সেই copy নিজে থেকে বদলায় না। তাই workflow rule বদলালে plugin source এবং Project Settings/Files—দুই জায়গার version মিলাতে হবে।

---

## ৪. Module কখন load হয়

Suite `boot()` Native MCP enabled এবং WooCommerce available থাকলে Publisher service load করে। `Dreminex_Suite_AI_Product_Publisher::boot()` প্রথমে workflow project manager চালু করে; তারপর Publisher abilities ও storefront image swatch চালু হয়। পুরোনো `dreminex_suite_modules['ai_product_publisher']` value settings/data compatibility-এর জন্য থাকে, কিন্তু service gate নয়। পুরোনো standalone `dreminex-ai-product-publisher` plugin active থাকা যাবে না।

Standalone Publisher active থাকলে Suite module abilities register করে না। একই feature দুই জায়গা থেকে চালু হয়ে duplicate hook, duplicate ability বা conflicting write যেন না হয়, সেই জন্য এই guard রাখা হয়েছে।

মূল WordPress hooks:

| Hook | কাজ |
|---|---|
| `wp_abilities_api_categories_init` | `dreminex-products` ability category register |
| `wp_abilities_api_init` | সব Publisher ability register |
| `rtwpvs_variation_attribute_options_html` | saved image mapping থাকলে colour circle-এর জায়গায় product image দেখানো |
| `wp_enqueue_scripts` | storefront image swatch CSS |
| Nexus authenticated REST | Project files ও Publisher settings app থেকে read/write |
| `admin_post_dreminex_publisher_settings` | পুরোনো dashboard form submission-এর compatibility handler; normal management Nexus app-এ |

---

## ৫. Settings — কোনটি কেন রাখা হয়েছে

সব setting `dreminex_ai_publisher_settings` WordPress option-এ থাকে।

| Setting | Default | কেন আছে | বদলালে কী দেখব |
|---|---:|---|---|
| `color_attribute` | `pa_solid-color` | নতুন product-এ handoff নির্দিষ্ট taxonomy না দিলে fallback colour attribute | taxonomy সত্যিই global Woo attribute কি না; size attribute-এর সমান নয় |
| `size_attribute` | `pa_for-men-size` | নতুন product-এর default size taxonomy | Women/Kids product-এ handoff থেকে উপযুক্ত taxonomy দিতে হবে |
| `auto_terms` | On | Missing global colour/size term প্রয়োজন হলে তৈরি করা | ভুল spelling দিয়ে unwanted shared term তৈরি হচ্ছে কি না |
| `max_upload_mb` | 12 MB | একটি product image import-এর সর্বোচ্চ size | PHP/server upload limit এবং image memory usage |
| `max_variation_rows` | 64 | এক product handoff-এ accepted offered rows | Dashboard range 1–564; preflight ও save layer একই value ব্যবহার |
| `ability_access_mode` | Existing active install: Full; fresh inactive install: Read only | Server write policy | Read only-তে write abilities register/execute হয় না |
| `ability_states` | সব On | প্রতিটি ability আলাদা On/Off | Disabled ability discovery ও execution দুটো থেকেই বাদ |
| `auto_sku` | Off | Parent SKU না থাকলে configured prefix থেকে generate করা | collision, readable SKU এবং product identity |
| `sku_prefix` | `DRX` | Automatic parent SKU-এর prefix | 1–12 letters/numbers/hyphen |
| `brand_from_label` | On | Verified product image label-এর brand-কে supplied brand-এর আগে নেওয়া | label image ID এবং `label_verified=true` ছাড়া ব্যবহার নয় |
| `require_image_match` | On | Variation image যেন colour-এর সঙ্গে verified mapping/filename দিয়ে মিলে | renamed file হলে product colour map ঠিক আছে কি না |
| `require_stock_for_variants` | Off | Audit-এর সময় প্রতিটি variation-এর quantity বাধ্যতামূলক করা হবে কি না | stock quantity জানা না থাকলে এটি On করলে publish block হবে |
| `allow_publish` | On | Explicit publish request ও successful audit-এর পর publication permit | এটি Off থাকলে Draft তৈরি হবে, Publish block হবে |
| `optional_prompt_seconds` | legacy | আগের optional prompt system-এর compatibility field | save-এর সময় 0 করা হয়; বর্তমান flow optional প্রশ্নে write block করে না |

Settings save করতে `manage_options`, valid nonce, existing `pa_…` taxonomy এবং valid numeric/file limits লাগে।

---

## ৬. Ability registration-এর নিয়ম

Namespace: `dreminex-products`

সব ability সাধারণভাবে `manage_woocommerce` capability চায়। Media import/upload/update abilities-এর জন্য `upload_files`-ও লাগে। এর আগে `ability_access_mode` ও individual `ability_states` server-side filter হয়। Read only mode-এ শুধু discovery, preflight, audit ও readback abilities register হয়। প্রতিটি ability `readonly`, `destructive`, `idempotent` annotation প্রকাশ করে।

`schema()` MCP/Abilities API-কে input structure বলে। `abilities()` ability name, description, callback ও permission register করে। নতুন ability শুধু function বানালেই হবে না; operation list এবং schema—দুই জায়গাতেই দিতে হবে।

বর্তমানে মোট ৪২টি operation/alias আছে। Enabled access policy অনুযায়ী registered ability count কম হতে পারে।

### ৬.১ Read-only preparation ও verification abilities

| Ability | কী কাজ করে | কখন ব্যবহার হবে |
|---|---|---|
| `catalog` | Categories, configured attributes, available colour/size taxonomies, terms ও optional slug collision দেখায় | Preparation-এর catalog mapping |
| `preparation-snapshot` | Exact title/slug/SKU collision, catalog, recent media, size terms ও related candidates এক bounded response-এ দেয় | নতুন handoff প্রস্তুতের শুরুতে |
| `handoff-preflight` | Complete handoff validate ও normalized `listing_parameters` তৈরি করে; write করে না | প্রতিটি full Create/Update-এর আগে |
| `media-find` | Exact filename দিয়ে Media Library match এবং incoming folder status দেখায় | Owner upload reuse করার সময় |
| `media-candidates` | Recent/search-matched same-site image candidates দেখায় | Visual review-এর candidate list |
| `media-visual-match` | Cropped reference image/dHash-এর সঙ্গে candidate image rank করে | Candidate কমাতে; result কখনো final proof নয় |
| `listing-defaults` | Optional SKU/stock missing কি না এবং default policy বলে | Optional input নিয়ে অযথা block না করতে |
| `product-read` | Saved product, media, SEO, attributes, swatches ও raw variations পড়ে | প্রতিটি write-এর readback |
| `supplier-source-read` | Product-এর Supplier Monitor source ও scan status পড়ে | Source link verify করতে |
| `draft-audit` | Draft-এর publish readiness পরীক্ষা করে | Publish-এর আগে বা incomplete Draft diagnose করতে |
| `workflow-guide` | Legacy combined workflow response | পুরোনো client compatibility |
| `workflow-profile` | Preparation/Publisher manifest, revision ও start document দেয় | প্রতিটি নতুন workflow task-এর শুরুতে |
| `workflow-source` | Exact source file UTF-8 safe chunk-এ পড়ে | প্রয়োজনীয় live instruction পড়তে |
| `workflow-experience` | সীমিত private past outcomes পড়ে | আগের verified lesson context হিসেবে |

### ৬.২ Media write abilities

| Ability | কী কাজ করে | গুরুত্বপূর্ণ সীমা |
|---|---|---|
| `media-import` | `uploads/dreminex-ai-incoming` folder থেকে একটি image import | JPEG/PNG/WebP, real file, size/MIME match |
| `media-upload` | Accessible base64 bytes দিয়ে একটি image import | Chat preview নয়; actual bytes দরকার |
| `media-batch-upload` | এক call-এ ১–১০টি image reuse/import | প্রতি image-এ ঠিক একটি source; partial result resumable |
| `media-url-import` | Public HTTPS image URL fetch করে import | HTTP 200, safe URL, size limit |
| `media-update` | Existing attachment title, slug, alt, caption, description update | Physical filename/URL rename করে না |

`media-batch-upload` source options:

- `image_id`: existing attachment reuse।
- Same-site `url` এবং `import_external` false/absent: URL থেকে attachment resolve; fetch নয়।
- `content_base64`: bytes যাচাই করে duplicate hash থাকলে reuse, না থাকলে import।
- `incoming_path`: dedicated incoming folder থেকে import।
- External `url` + `import_external=true`: public HTTPS fetch/import।

Batch মাঝপথে fail হলে successful `image_ids`, `failed_index` ও resume instruction ফেরত আসে। সফল image আবার upload করা যাবে না; returned ID reuse করতে হবে।

### ৬.৩ Product/category/variation write abilities

| Ability | কী কাজ করে | ব্যবহার/সীমা |
|---|---|---|
| `category-ensure` | Verified parent-এর নিচে category reuse বা create | slug অন্য name/parent-এর হলে conflict |
| `listing-apply` | Full prepared listing-এর প্রধান Create/Draft/Publish/Update orchestration | নতুন implementation-এর primary write ability |
| `draft-create` | Core Draft product বানায় | Low-level; exact title/slug collision block |
| `draft-complete` | পুরোনো complete Draft workflow | Legacy; নতুন Update-এর জন্য ব্যবহার নয় |
| `variations-upsert` | Existing Variable product-এ ১–১২ explicit combination save | batch helper; offered rows ছাড়া অনুমান নয় |
| `colors-reconcile` | Draft-এর existing colours exact HEX-specific shared term-এ migrate | existing variation image safely map হতে হবে |
| `color-swatch-set` | Product-specific image swatch set/clear | image product gallery/variation-এর অংশ হতে হবে |
| `listing-update` | Exact existing product ID-তে supplied fields update | product type বদলায় না; live slug change extra flag চায় |
| `variation-update` | Exact child variation-এর image/price/SKU/stock update | child exact parent-এর হতে হবে |
| `draft-brand-set` | Verified label image থেকে brand set | Draft ও Published দুটোতেই কাজ করে |
| `brand-set` | `draft-brand-set`-এর alias | পুরোনো/current naming compatibility |
| `draft-inventory-set` | Parent/child SKU ও stock set | Variable quantity child-এ দিতে হবে |
| `inventory-set` | `draft-inventory-set`-এর alias | Published listing support বোঝাতে alias |
| `supplier-source-set` | Exact supplier URL product-এর সঙ্গে link করে | Product save-এর পরে আলাদা stage |

### ৬.৪ Status, publication ও workflow-management abilities

| Ability | কী কাজ করে | Safeguard |
|---|---|---|
| `draft-publish` | Audited Draft publish | `publish=true`, setting enabled, audit ready |
| `product-lifecycle` | Draft, Publish, Trash, Restore বা permanent Delete | exact ID; Restore সবসময় Draft; permanent Delete-এর আগে Trash + matching confirmation |
| `workflow-propose` | Evidence-backed rule proposal review queue-তে রাখে | active instructions সঙ্গে সঙ্গে বদলায় না |
| `workflow-experience-record` | Completed/partial/blocked outcome সংরক্ষণ | product facts বা new instruction নয় |

---

## ৭. `handoff-preflight` কী কী যাচাই করে

এই ability কোনো product/media write করে না। এর কাজ হলো handoff এবং live site-এর মধ্যে mismatch আগে ধরা।

মূল checks:

- `handoff_type` ঠিক `PUBLISHER HANDOFF` কি না।
- `site_url` connected WordPress site-এর exact URL কি না।
- mode শুধু `draft`, `publish` বা `update` কি না।
- Update হলে valid existing Draft/Published product এবং exact `product_id` আছে কি না।
- Create হলে existing product ID carry করছে কি না।
- Product type `simple` বা `variable` এবং conflicting duplicate type field নেই।
- নতুন Create-এ name, slug, category IDs আছে এবং live site-এ valid।
- Exact name/slug এবং parent SKU collision নেই।
- Supplier URL supported exact HTTPS product URL কি না।
- Size objects থেকে selectable name বের করা যায় এবং duplicate নেই।
- Product category-এর সঙ্গে size taxonomy সঠিক; Women product-এ Men size ঢুকছে না।
- Colour name unique এবং প্রতি option-এর image বা explicit colour fallback আছে।
- Media ID actual same-site image এবং supplied URL একই attachment-এর।
- Verified image থাকলে image swatch বাধ্যতামূলক; image না থাকলে `mode=color` + valid existing/supplied HEX।
- Variant pair listed colour/size-এর মধ্যে unique।
- Variant image একই colour-এর।
- Regular/sale price valid।
- Parent sale price থাকলে parent regular price positive ও sale-এর চেয়ে বেশি।
- Stock status canonical।
- Supplier code valid এবং normalized colour mapping-এর সঙ্গে consistent।
- Explicit child SKU internal identity ধরে supplier code safely carry করতে পারে।
- `full_matrix=true` হলে সব colour×size row সত্যিই আছে।
- Publish হলে verified media আছে।

সব ঠিক থাকলে:

```json
{
  "ready": true,
  "next_action": "apply_and_verify",
  "errors": [],
  "warnings": [],
  "listing_parameters": {},
  "normalized_variation_count": 144,
  "variation_capacity": {"configured_limit": 144, "hard_limit": 564},
  "checked_site": "https://..."
}
```

`listing_parameters` হলো live write-এর cleaned input। Preparation-এর audit-only fields যেমন raw screenshot ledger সেখানে না-ও যেতে পারে। `ready=false` হলে `listing_parameters=null`; Publisher write করবে না।

---

## ৮. `listing-apply` কীভাবে কাজ করে

এটি module-এর প্রধান orchestration function।

Raw handoff-এ `handoff_type=PUBLISHER HANDOFF` থাকলে listing-apply নিজেই preflight চালায়। Preflight fail হলে write শুরু হয় না। Preflight থেকে normalized parameters সরাসরি পাঠালেও কাজ করে।

Save stages সাধারণত এই order-এ চলে:

1. Mode/type/price/options/schema validation।
2. নতুন হলে core Draft create; Update হলে exact existing ID reuse।
3. Description, short description ও tags save।
4. SEO fields save।
5. Colour/size options extend বা preserve।
6. Supplier colour-code map save।
7. Product media reuse/import, featured/gallery order এবং optional metadata save।
8. Brand evidence/brand apply।
9. Variable হলে explicit variations save ও sync।
10. Product-specific image swatches save।
11. Upsell/Cross-sell apply।
12. Optional supplier source link।
13. Publish mode হলে audit gate; Draft mode হলে Draft status।
14. `product-read` দিয়ে saved state report।

Response-এ গুরুত্বপূর্ণ fields:

- `id` / `product_id`
- `operation`
- `status`
- `partial`
- `stages`
- `errors`
- `pending_inputs`
- `can_resume`
- `resume_product_id`, `resume_token`, `variation_offset` (variation stage partial হলে)
- `normalized_variation_count`, `processed_variation_count`, `remaining_variation_count`, `variation_capacity`
- `media`, `image_ids`
- `audit`
- `product` saved readback

কোনো stage fail করার আগে product ID তৈরি হয়ে যেতে পারে। Variation stage partial হলে নতুন Create call নয়; returned `resume_product_id`, opaque `resume_token`, exact `variation_offset` এবং একই normalized input ধরে recovery করতে হবে। Token/input/offset mismatch server block করে।

Module v1.13.66 থেকে early `listing-apply` failure structured result দেয়:

```json
{
  "success": false,
  "error_code": "invalid_product",
  "error_message": "নির্দিষ্ট কারণ",
  "product_id": null
}
```

এতে connector-এর সাধারণ `INVALID_ARGUMENT`-এর আড়ালে আসল কারণ হারিয়ে যাওয়ার সম্ভাবনা কমে।

---

## ৯. Create, Update ও lifecycle আলাদা রাখার নিয়ম

### নতুন Create/Draft

- `mode=draft`
- `product_id=null`
- Exact title/slug collision থাকলে নতুন distinct identity Preparation থেকে আসবে।
- Existing match পেলেই তাকে Update করা যাবে না।
- Parent SKU ও child SKU unique হতে হবে।

### Explicit Publish

- নতুন handoff-এ `mode=publish`, অথবা existing Draft-এ `draft-publish`।
- Owner-এর স্পষ্ট request লাগবে।
- `allow_publish` On হতে হবে।
- `draft-audit.ready=true` হতে হবে।

### Existing Update

- `mode=update`
- exact selected-site `product_id`
- existing product Draft বা Published হতে হবে।
- Supplied field-ই বদলাবে; omitted field preserve।
- Product type silent change করা যাবে না।
- Size taxonomy migration existing children থাকলে block হয়।

### Trash, Restore ও Delete

- Status-only operation-এ `product-lifecycle` ব্যবহার।
- Trash reversible এবং media delete করে না।
- Restore সবসময় Draft।
- Permanent Delete শুধু আগে Trash করা exact product-এ এবং `confirm_product_id` একই হলে।
- `expected_status` দিলে stale request/parallel change ধরা যায়।

---

## ১০. SKU system

SKU দুই ধরনের:

1. Internal catalog SKU — WooCommerce uniqueness ও merchant identity।
2. Supplier screenshot code — supplier platform-এ product option খোঁজার evidence।

Parent SKU সাধারণত owner/preparation দেয়। `auto_sku` On হলে missing parent SKU configured prefix থেকে generate হতে পারে।

Supplier code-এর বর্তমান child rule:

```text
Code নেই:
PARENT-COLOR-SIZE

Verified screenshot code আছে:
PARENT-COLOR-SIZE-SUPPLIER-CODE
```

উদাহরণ:

```text
DRX-KIDS-SET-NAVY-3-4Y
DRX-KIDS-SET-NAVY-3-4Y-00123
```

Exact supplier code আলাদাভাবে child meta `_dreminex_supplier_sku`-তেও থাকে। Colour-level resolved map parent meta `_dreminex_ai_color_supplier_sku_map`-এ থাকে।

গুরুত্বপূর্ণ নিয়ম:

- Screenshot-এ code না থাকলে অনুমান নয়।
- Design-এর printed number, price বা stock count SKU নয়।
- একই colour-এর বহু image আলাদা variation বানায় না।
- Update-এ existing internal child SKU preserve করে code suffix add/replace করতে হবে।
- SKU সর্বোচ্চ 100 characters এবং letters/digits/dot/underscore/hyphen।
- Duplicate SKU অন্য product/variation-এর হলে write block।

---

## ১১. Colour, size ও variation system

Colour এবং size অবশ্যই global WooCommerce attribute taxonomy ব্যবহার করে।

`color_taxonomy()` priority:

1. Handoff-এর explicit `color_attribute`
2. Product meta-তে saved taxonomy
3. Configured default assigned থাকলে
4. Existing product attributes থেকে একমাত্র unambiguous colour taxonomy

`size_taxonomy()` explicit input, saved product meta, assigned default বা existing size variation attribute দেখে।

Product meta-তে selected taxonomies:

- `_dreminex_ai_color_taxonomy`
- `_dreminex_ai_size_taxonomy`

`term()` existing name/slug reuse করে। Same colour name-এর global HEX ভিন্ন হলে `auto_terms` On থাকলে HEX suffix দিয়ে separate shared term বানায়, যাতে পুরোনো product-এর swatch নষ্ট না হয়।

Variation rules:

- Listing-apply dashboard-এর `max_variation_rows` পর্যন্ত offered rows নেয়; default 64, accepted setting 1–564, hard maximum 564।
- Direct `variations-upsert` internal batch helper হিসেবে প্রতি call-এ 1–12 rows। Complete handoff truncate হয় না; orchestration সব batch চালায় এবং partial হলে safe resume state দেয়।
- Pair duplicate হতে পারবে না।
- Colour/size parent options-এর মধ্যে থাকতে হবে।
- Regular price positive; sale থাকলে regular-এর চেয়ে কম।
- Variation image product gallery ও verified colour mapping-এর সঙ্গে মিলতে হবে।
- Stock quantity জানা না থাকলে guess করা যাবে না।
- Saved intended pairs `_dreminex_ai_intended_variations`-এ থাকে; audit missing pair বের করে।

---

## ১২. Image ও image swatch system

একটি product image দুইভাবে ব্যবহার হয়:

- Featured/gallery image
- নির্দিষ্ট colour variation এবং storefront swatch image

`_dreminex_ai_color_image_map` colour → verified variation image mapping রাখে।  
`_dreminex_ai_swatch_images` colour term slug → product-specific swatch image রাখে।

Image থাকলে colour circle-এর বদলে image swatch বাধ্যতামূলক। প্রতি colour/design-এর একটি representative original product image swatch হয়। একই colour-এর অন্য distinct verified views ordered gallery-তে থাকে এবং extra colour option হয় না। কোনো option-এর image সত্যিই না থাকলে explicit `mode=color` এবং verified HEX/existing term ব্যবহার করা যায়।

`color-swatch-set` শুধু সেই image নেয় যা product-এর featured image, gallery বা variation image-এর অংশ। এতে অন্য product-এর image ভুল করে swatch হওয়ার ঝুঁকি কমে।

`image_swatches_html()` active Variation Swatches plugin-এর HTML filter করে saved thumbnail বসায়। Plugin/hook না থাকলে mapping data থাকে, তবে storefront replacement render নাও হতে পারে। `swatch_styles()` shop/product/taxonomy page-এ ছোট scoped CSS যোগ করে।

---

## ১৩. Price, stock, brand ও SEO

### Price

- Simple product-এর parent regular price বাধ্যতামূলক।
- Variable product-এর purchasable price variation rows-এ থাকে।
- Parent reference price থাকলে `_dreminex_ai_reference_price` meta-তে reference হিসেবে রাখা হয়।
- Sale price থাকলে regular price positive এবং sale ছোট হতে হবে।
- `selling_price` হলো explicit owner selling price-এর alias; regular price-এর সঙ্গে normalize হয়।

### Stock

- Quantity দিলে nonnegative integer হতে হবে।
- Quantity দিলে manage stock চালু হয়।
- Quantity না থাকলে `stock_status` দিয়ে unmanaged availability রাখা যায়।
- Backorders default `no`।
- Variable parent-এ quantity নয়; child variation-এ।
- `require_stock_for_variants` On হলে missing quantity audit issue।

### Brand

- WooCommerce `product_brand` taxonomy থাকতে হবে।
- Verified label brand-এর জন্য image product-এর media হতে হবে এবং `label_verified=true`।
- Evidence parent meta `_dreminex_ai_label_brand_evidence`-এ থাকে।
- Brand taxonomy term-এর পাশাপাশি visible non-variation Brand attribute-ও রাখা হয়।

### SEO

Yoast-compatible keys:

- `_yoast_wpseo_title`
- `_yoast_wpseo_metadesc`
- `_yoast_wpseo_focuskw`
- Secondary keyphrases: `_dreminex_ai_secondary_keyphrases`

---

## ১৪. Product readback-এ কী কী পাওয়া যায়

`product-read` শুধু status/link দেয় না। এটি maintenance ও verification-এর canonical response:

- ID, name, slug, type, status
- Parent SKU, stock state
- Size এবং colour taxonomy
- Categories, tags, brand
- Description ও short description
- Regular/sale price
- Featured image ও ordered gallery metadata
- Upsell/Cross-sell IDs
- Attributes ও selectable terms
- Image/color swatch mode
- SEO fields
- প্রতিটি variation-এর exact ID, attributes, raw child SKU, supplier SKU, price, stock ও explicit image

Publisher completion বলার আগে expected handoff এবং এই readback মিলাতে হবে।

---

## ১৫. Workflow source manager কেন রাখা হয়েছে

Preparation ও Publisher rules শুধু plugin code-এ hardcode না রেখে `workflow-profiles` source documents-এ রাখা হয়েছে। এতে পুরো plugin code না বদলিয়েও owner dashboard থেকে instruction file replace, restore বা remove করতে পারেন।

Limits:

- শুধু `preparation` ও `publisher` profile।
- প্রতি profile সর্বোচ্চ 20 active files।
- প্রতি file সর্বোচ্চ 2 MB; server, manifest, form এবং JavaScript একই 2,097,152-byte limit ব্যবহার করে।
- শুধু UTF-8 `.md` বা `.txt`।
- Exact filename collision-এ popup confirmation দরকার; Cancel করলে কোনো mutation হয় না এবং backend confirmation ছাড়া replacement block করে।
- Different filename নতুন source; case-only collision block।
- Built-in/custom file replace করলে previous copy রাখা হয়।
- Source manifest revision সব active filename + SHA-256 থেকে তৈরি।
- Source read সর্বোচ্চ 49,152 bytes per chunk এবং UTF-8 boundary safe।

Workflow manager options:

| Option | কাজ |
|---|---|
| `dreminex_ai_workflow_sources_v1` | File state/index |
| `dreminex_ai_wf_file_{profile}_{md5}` | Custom/replaced file content |
| `dreminex_ai_wf_previous_{profile}_{md5}` | Previous version |
| `dreminex_ai_workflow_proposals_v1` | Admin review queue |
| `dreminex_ai_workflow_experience_v1` | প্রতি profile সর্বোচ্চ 100 private events |

Proposal approve করলে rule `99_APPROVED_LEARNINGS.md`-এ যায়। Proposal নিজে active rule বদলায় না। Experience log phone/email redact করে এবং past observation হিসেবে থাকে; product fact বা instruction নয়।

---

## ১৬. Main class-এর function map

### Boot, schema ও settings

| Function | কাজ |
|---|---|
| `boot` | Module/workflow hooks ও conflict guard |
| `config` | Saved settings-এর সঙ্গে safe defaults merge |
| `category` | Ability category register |
| `abilities` | 37 abilities register এবং selected writes log |
| `schema` | Ability-specific JSON input schema |
| `product_fields` | Reusable product input fields |
| `admin_menu`, `admin_page`, `admin_assets` | Products submenu, five-tab dashboard ও scoped assets |
| `render_abilities_settings` | Per-ability On/Off ও server Read only/Full access UI |
| `render_listing_settings` | Capacity, taxonomy, SKU, media ও publish controls |
| `settings_panel` | পুরোনো Suite screen থেকে dedicated dashboard route |
| `checkbox` | Settings checkbox helper |
| `save_settings` | Capability/nonce/setting validation ও save |
| `variation_capacity`, `variation_capacity_error`, `validate_variation_capacity` | Central 1–564 capacity policy |
| `expand_variation_rows` | Confirmed full matrix write-এর আগে complete rows বানায় |
| `normalize_seo`, `exact_h3_matches_name`, `scoped_handoff_preflight` | Core SEO/content gate ও exact-ID copy recovery |
| `fail` | Consistent `WP_Error` helper |

### Taxonomy ও catalog helpers

| Function | কাজ |
|---|---|
| `taxonomy` | Configured default taxonomy |
| `color_taxonomy` | Product-specific global colour taxonomy resolve |
| `size_taxonomy` | Product-specific global size taxonomy resolve |
| `has_womens_category` | Category ancestry থেকে Women branch detect |
| `check_size_category` | Women product-এ Men size ভুল mapping block |
| `attribute_id` | Woo global attribute ID resolve |
| `is_color_taxonomy` | Taxonomy/label colour হিসেবে চেনা |
| `term` | Existing term reuse বা safe term creation |
| `base_color` | HEX-specific term থেকে original colour name |
| `catalog` | Categories/attributes/terms/slug lookup |
| `exact_product_identity_matches` | Exact name/slug matches with matched field |
| `preparation_snapshot` | Bounded read-only Preparation data |
| `category_ensure` | Category reuse/create |

### Media helpers

| Function | কাজ |
|---|---|
| `media_find` | Exact filename ও incoming state |
| `media_candidates` | Paged same-site image list |
| `media_candidate` | একটি attachment-এর compact details |
| `visual_hash` | 64-bit horizontal dHash |
| `visual_source` | Safe medium/original GD source |
| `media_visual_match` | dHash distance ranking |
| `media_import` | Incoming folder import |
| `import_bytes` | Validated bytes temp-save ও import |
| `media_upload` | Base64 single import |
| `media_batch_upload` | Multi-source batch import/reuse |
| `find_matching_image` | Exact filename + SHA-256 duplicate reuse |
| `resolve_media_url` | Same-site upload URL থেকে attachment ID resolve |
| `media_url_import` | Public HTTPS fetch/import |
| `media_update` | Attachment metadata update |
| `checked_image` | ID/file/MIME validity |
| `image_has_color` | Filename token দিয়ে colour fallback check |
| `image_for_color` | Image list থেকে matching colour image |

### SKU, stock ও brand helpers

| Function | কাজ |
|---|---|
| `sku` | Supplied/automatic SKU normalize |
| `supplier_code` | Exact supplier code character/length validation |
| `supplier_color_map` | Colour, image ও map inputs থেকে one-code-per-colour normalize |
| `variation_supplier_sku` | Internal child SKU-র শেষে supplier code append/replace-safe compose |
| `validate_sku` | Format, length ও Woo uniqueness check |
| `stock` | Managed quantity বা unmanaged stock status apply |
| `brand_evidence` | Label brand evidence verify |
| `assign_brand` | `product_brand` term create/reuse/assign |

### Product orchestration ও write functions

| Function | কাজ |
|---|---|
| `draft_create` | Core Simple/Variable Draft create |
| `draft_complete` | Legacy create/resume workflow |
| `supplier_source_read` | Supplier Monitor source read |
| `supplier_source_set` | Public exact-ID source setter |
| `apply_supplier_source` | Internal set + readback |
| `handoff_preflight` | Full no-write handoff gate |
| `listing_apply` | Main staged listing operation |
| `extend_options` | Existing/new colour-size attributes extend |
| `apply_related` | Verified IDs/SKUs থেকে upsell/cross-sell |
| `variations_upsert` | Explicit child rows save/update |
| `color_swatch_set` | Product-specific image swatch mapping |
| `image_swatches_html` | Storefront swatch HTML replacement |
| `swatch_styles` | Scoped swatch CSS |
| `colors_reconcile` | Draft colour terms exact HEX mapping |
| `draft_brand_set` | Existing product verified brand |
| `draft_inventory_set` | Existing parent/children SKU/stock |
| `draft_audit` | Publish readiness |
| `draft_publish` | Explicit audited publication |
| `product_lifecycle` | Draft/Publish/Trash/Restore/Delete |
| `listing_update` | Exact-ID selective product update |
| `variation_update` | Exact child selective update |

### Workflow ও readback functions

| Function | কাজ |
|---|---|
| `workflow_guide` | Legacy/source-backed guide response |
| `workflow_profile` | Live project manifest |
| `workflow_source` | Live source chunk |
| `workflow_propose` | Admin-review suggestion |
| `workflow_experience` | Private past outcomes |
| `workflow_experience_record` | Verified outcome record |
| `listing_defaults` | Optional field policy |
| `product_read` | Full saved product readback |

---

## ১৭. Workflow manager class-এর function map

| Function group | Functions | কাজ |
|---|---|---|
| Boot/validation | `boot`, `profiles`, `valid_profile`, `valid_name` | Admin handlers ও accepted profile/file name |
| Built-in/custom source | `defaults`, `index`, `key`, `state`, `content`, `files`, `active_files` | Disk defaults ও private WordPress override merge |
| MCP reads | `read_profile`, `read_source`, `legacy_guide` | Manifest/revision/chunk/legacy guide |
| Source write/recovery | `valid_content`, `store`, `modify` | Upload, replace, previous, reset, remove |
| Proposal/memory | `propose`, `scrub`, `remember`, `record_operation`, `record_experience`, `read_experience` | Review queue ও bounded private history |
| Admin UI | `assets`, `page_url`, `redirect`, `handle_file`, `download`, `handle_proposal`, `clear_memory`, `form_start`, `render` | Dashboard tabs, upload/download, approval ও history controls |

---

## ১৮. Product meta keys — কোন data কোথায় থাকে

| Meta key | কোথায় | কাজ |
|---|---|---|
| `_dreminex_ai_color_taxonomy` | Parent product | এই product-এর selected colour taxonomy |
| `_dreminex_ai_size_taxonomy` | Parent product | selected size taxonomy |
| `_dreminex_ai_color_image_map` | Parent product | colour → verified variation/gallery image |
| `_dreminex_ai_swatch_images` | Parent product | colour term slug → storefront swatch image |
| `_dreminex_ai_color_supplier_sku_map` | Parent product | colour → resolved supplier code |
| `_dreminex_ai_intended_variations` | Parent product | confirmed offered pair list |
| `_dreminex_ai_reference_price` | Variable parent | supplied parent/reference regular-sale pair |
| `_dreminex_ai_label_brand_evidence` | Parent product | verified label brand + image ID |
| `_dreminex_ai_secondary_keyphrases` | Parent product | extra SEO keyphrases |
| `_dreminex_ai_listing_resume` | Parent Draft | hashed resume token, normalized input hash, next offset ও total rows; completion-এ delete |
| `_dreminex_ai_base_color_name` | Colour term | HEX-specific term-এর original colour name |
| `_dreminex_supplier_sku` | Variation | exact supplier code |
| `_wp_attachment_image_alt` | Attachment | image alt text |
| Yoast meta keys | Parent product | SEO title, meta description, focus keyphrase |

এই meta key rename করলে migration, backward read এবং existing product compatibility ছাড়া সরাসরি replace করা যাবে না।

---

## ১৯. Error ও partial result বোঝার নিয়ম

Common blockers:

| Error/code | সাধারণ কারণ | কী ঠিক করতে হবে |
|---|---|---|
| `handoff_preflight_failed` | Full handoff live checks pass করেনি | Returned errors Preparation-এ ঠিক |
| `variation_capacity_exceeded` | Row count configured capacity-এর বেশি | Dashboard capacity বাড়ান (সর্বোচ্চ 564) বা confirmed offering ঠিক করুন; zero write |
| `missing_listing_content` | Full listing description/SEO incomplete | Preparation-এ customer-ready copy ও core SEO পূর্ণ করুন |
| `invalid_resume` / `resume_mismatch` | Wrong ID/token/offset বা বদলানো input | একই partial response-এর exact values ও normalized input দিন |
| `ability_disabled` | Mode বা individual switch ability block করেছে | Dashboard policy review; permission bypass নয় |
| `duplicate_product_identity` | Exact name বা slug আছে | Distinct Create identity; silent Update নয় |
| `duplicate_sku` | SKU অন্য product/child-এর | Unique parent/child SKU |
| `missing_parent_sku` | Variable child SKU compose করা যাচ্ছে না | Parent SKU দিন |
| `supplier_sku_color_conflict` | Same colour-এর competing live code | Preparation resolution ঠিক |
| `invalid_supplier_sku` | Code format/length invalid | Exact visible valid code |
| `image_color_mismatch` | Variation image colour verify হয়নি | Correct image mapping/filename |
| `invalid_image_index` | Featured/variation index resolved media-তে নেই | Image array/order ঠিক |
| `invalid_size_attribute` | Global size taxonomy নয় বা colour-এর সমান | Live catalog taxonomy দিন |
| `size_attribute_required` | Women product-এ Men size | Women/general size taxonomy |
| `missing_variant_price` | Purchasable rows-এ valid price নেই | Regular/sale pair দিন |
| `audit_failed` | Publish readiness incomplete | Audit issues fix করে same Draft |
| `status_conflict` | Product status readback-এর পর বদলেছে | আবার read করে নতুন expected status |
| `publication_disabled` | Dashboard publish switch Off | Owner decision অনুযায়ী setting |
| `media_url_not_in_target_library` | Same-site reuse URL ওই site-এর attachment নয় | Exact ID বা import source |
| `ambiguous_media_url` | একাধিক attachment candidate | Exact `image_id` |

`partial=true` মানে কিছু stage save হয়েছে। Product ID থাকলে সেটিই recovery target। পুরো listing আবার Create করলে duplicate হওয়ার ঝুঁকি আছে।

---

## ২০. নতুন feature বা ability add করতে হলে

ধরুন নতুন field `material_code` add করতে হবে। তখন শুধু schema-তে field দিলেই কাজ শেষ নয়।

এই order অনুসরণ করতে হবে:

1. Owner rule ঠিক করুন—field source fact, handoff audit, live product field নাকি internal meta।
2. Preparation source/template-এ field কখন ও কী evidence-এ আসবে লিখুন।
3. `schema()` বা `product_fields()`-এ type/description দিন।
4. `handoff_preflight()` allowlist, validation ও normalization দিন।
5. `listing_apply()`-এর সঠিক stage-এ save করুন।
6. Update-এ omitted field preserve এবং supplied field replace rule দিন।
7. `product_read()`-এ saved value ফেরত দিন।
8. Publisher source-এ expected readback লিখুন।
9. Error code/message specific করুন।
10. Staging-এ read-only invalid/valid preflight test চালান।
11. Isolated Draft mutation, readback ও recovery test চালান।
12. Version, changelog, package, checksum ও rollback note update করুন।

নতুন ability add করলে আরও লাগবে:

- `abilities()` operation entry
- `schema()` entry
- Public callback function
- Correct capability
- Mutation হলে experience/logging policy
- Skill/Project source update
- Live discovery ও `get_ability_info` verification

---

## ২১. Existing function update বা replace করলে impact map

| যে জায়গা বদলাচ্ছেন | সঙ্গে আর কী review করবেন |
|---|---|
| Handoff field/schema | Preparation template, preflight, listing-apply, readback, Publisher instruction |
| SKU composition | Preflight expected SKU, variations-upsert, Update behavior, product-read, collision tests |
| Colour taxonomy | catalog, preflight, extend_options, swatch, audit, readback |
| Size taxonomy | category/garment rules, migration block, variations, audit |
| Media source | schema, batch source count, MIME/size validation, reuse/import, metadata, partial resume |
| Price rule | preflight, draft-create, variation save, listing-update, audit |
| Stock rule | stock helper, inventory abilities, variation save, audit |
| Publish rule | setting, audit, draft-publish, lifecycle, Project instruction |
| Product meta key | existing product backward read, migration, readback |
| Workflow file manager | limits, WordPress options, dashboard UI, workflow-profile/source schema |
| Error response | MCP connector behavior, structured error, Publisher reporting |

যে validation preflight-এ আছে, একই rule save function-এও শেষ guard হিসেবে থাকা উচিত। তবে দুই জায়গার message ও accepted shape যেন conflict না করে।

---

## ২২. Testing checklist

### Static/source

- সব PHP file parse/lint।
- Ability operation-এর callback function আছে।
- সব schema valid JSON-schema shape।
- Version constant ও plugin header একই।
- Workflow sources UTF-8 এবং 2 MB file limit-এর মধ্যে।
- Changed files-এর checksum।

### Live discovery

- Module enabled, standalone Publisher inactive।
- `dreminex-products` abilities discover হয়।
- Ability count/expected new ability মিলে।
- `get_ability_info`-তে field/schema/description মিলে।
- WordPress, PHP, WooCommerce ও Suite version record।

### Read-only behavior

- Catalog ও available taxonomies।
- Preparation snapshot collision/media pagination।
- Wrong site, wrong category, wrong size taxonomy, wrong price, wrong matrix, wrong image mapping → `ready=false`।
- Valid 64-row ও configured 144-row full handoff → normalized `ready=true` এবং exact count।
- Configured limit-এর এক row বেশি → `ready=false`, exact count/capacity error এবং zero product write।
- Full handoff missing description/core SEO → blocker; exact-ID scoped description update → allowed।
- Product readback existing fixture-এ complete।

### Isolated staged mutation

- Simple Draft।
- Variable Draft 64 rows এবং 144 rows; readback-এ exact count।
- Boundary settings 1, 64, 144, 564 accepted; 0 ও 565 rejected।
- Supplier code ছাড়া internal child SKU।
- Supplier code সহ internal SKU + suffix এবং separate supplier meta।
- Image-first swatch ও fallback colour mode।
- Price/stock/SEO/media metadata।
- Explicit Update একই parent/child ID ধরে।
- Partial variation stage হলে same ID + token + offset recovery; changed input/token block।
- Per-ability Off discovery/execution block; Read only write registration block; শেষে staging Full access restore।
- Same-name workflow file Cancel/confirm/previous-version এবং different-name new-file tests।
- 44 rows inline handoff, 45 rows attached JSON receipt/hash tests।
- Audit/Publish শুধু explicit request।
- Trash ও Restore exact ID।
- QA product শেষে Trash; shared media delete নয়।

### Regression

- Existing published product accidental Update নয়।
- Create collision old product বদলায় না।
- Omitted Update fields survive।
- Women/Kids size mapping Men default নেয় না।
- Same colour-এর gallery views extra variations বানায় না।
- Supplier source fail হলেও saved product নতুন করে Create হয় না।
- Project source update product data বদলায় না।

---

## ২৩. Release ও rollback workflow

1. Current staging plugin-এর backup web root-এর বাইরে রাখুন।
2. Changed source file list ও SHA-256 বানান।
3. Staging-এ package/patch syntax verify করুন।
4. Atomic file replacement বা standard plugin upgrade করুন।
5. Opcache invalidate এবং live Suite version verify করুন।
6. Installed files-এর digest local package-এর সঙ্গে মিলান।
7. Ability discover/schema/read-only checks।
8. Isolated QA Draft + readback + Trash।
9. Project Settings/Files, exact trigger files, 44-row delivery rule ও 2 MB source limit-এর replacement bundle দিন।
10. Staging result owner-কে দেখিয়ে Main approval নিন।
11. Main-এর আগে Main backup এবং site-specific IDs পুনরায় resolve করুন।

Rollback-এর সময় পুরো পুরোনো trusted plugin package অথবা exact changed-file backup restore করতে হবে। Database/meta migration থাকলে file rollback একা যথেষ্ট নয়; reverse migration plan লাগবে।

---

## ২৪. কোন জিনিসগুলো ইচ্ছা করে আলাদা রাখা হয়েছে

- Preparation এবং Publisher আলাদা role।
- Raw screenshot evidence এবং live supplier code আলাদা field।
- Product create এবং exact-ID update আলাদা mode।
- Product listing save এবং supplier source scan আলাদা stage।
- Global colour term এবং product-specific image swatch আলাদা storage।
- Workflow proposal এবং active instruction আলাদা।
- Past experience এবং current product fact আলাদা।
- WordPress plugin source এবং ChatGPT Project copy আলাদা।

এই separation সরিয়ে এক জায়গায় সব auto করলে সময় কম মনে হতে পারে, কিন্তু ভুল product update, fabricated SKU, wrong image, duplicate Draft এবং silent instruction change-এর ঝুঁকি বেড়ে যায়।

---

## ২৫. শেষ review করার সহজ নিয়ম

Module update শেষ হওয়ার পর নিজেকে এই প্রশ্নগুলো করুন:

1. Preparation কি এখনও read-only?
2. Publisher কি শুধু complete handoff ব্যবহার করছে?
3. Create কি existing product-কে accidental Update করছে না?
4. Update কি exact site + exact ID ছাড়া হচ্ছে না?
5. Preflight যেটাকে ready বলছে, save layer সেটাকে একইভাবে গ্রহণ করছে?
6. Save response-এ আসল error message এবং partial product ID আছে?
7. Supplier code থাকলে child SKU-র internal identity অক্ষত আছে?
8. Code না থাকলে কিছু অনুমান করা হয়নি?
9. Image থাকলে image swatch, image না থাকলে verified fallback?
10. Saved product readback handoff-এর সঙ্গে মিলেছে?
11. QA product ও temporary state পরিষ্কার করা হয়েছে?
12. Source, Project files, version, changelog, ZIP, checksum ও rollback সব update হয়েছে?

এই ১২টির উত্তর পরিষ্কারভাবে “হ্যাঁ” না হলে release complete বলা যাবে না।

---

## ২৬. v1.13.68 dashboard, content gate ও Project Instructions system

Dedicated dashboard এখন **WooCommerce Products → AI Product Publisher**। পুরোনো Dreminex Suite module link একই page-এ route করে। পাঁচটি tab:

1. **Overview** — module state, available ability count, variation capacity এবং safe workflow।
2. **Workflow Projects** — Preparation/Publisher source, 2 MB upload, replace warning, previous version, proposal ও experience log।
3. **Abilities & Access** — 37টি ability-র individual On/Off এবং server Read only/Full access।
4. **Listing Controls** — capacity, taxonomy, image size, SKU, inventory, swatch ও publication rules।
5. **Help & Release** — mandatory maintenance/release sequence।

`Default` এবং `Auto-review` ChatGPT/Codex client-side permission behavior; WordPress plugin এগুলো enforce করতে পারে না। Dashboard সত্যি কথাটি দেখায়। Server-side enforce হয় `Read only` ও `Full access`, individual switches, WordPress capability এবং media capability।

Workflow tab দুই ধরনের copy block দেয়:

- Direct one-time Project instruction — Project Settings-এ paste-ready।
- Valid JSON setup prompt — connected assistant live `workflow-profile`/`workflow-source` পড়ে current files অনুযায়ী নতুন complete Project Instructions বানাবে। এতে site URL, MCP collection, product ID, credential বা পুরোনো release hardcode হবে না।

Full handoff content gate:

- Final name, slug, at least one tag।
- Professional nonempty short/long descriptions।
- Long description-এর প্রথম element exact product name-এর একটি H3।
- SEO title, meta description, focus keyphrase। Alias `meta_title`, `meta_description`, `keyphrase` canonical field-এ normalize হয়।
- Customer copy-তে internal variation limit, deferred-size implementation note বা supplier verification log block।
- `scope=short_description_and_description_only` exact-ID recovery শুধু দুই description field update করে; price/media/SEO/variation untouched।

Preparation delivery:

- 1–44 rows: one complete inline JSON block।
- 45+ rows: one complete attached UTF-8 JSON file, সঙ্গে minimal JSON receipt (filename, SHA-256, row count, site, mode)।
- File export unavailable: `FILE_EXPORT_UNAVAILABLE`; কখনো truncated handoff নয়।
- Site capacity আলাদা; 564-এর বেশি কখনো accepted নয় এবং configured limit-এর বেশি zero-write blocker।

---

## ২৭. ভবিষ্যতের প্রতিটি update-এ বাধ্যতামূলক একই workflow

এই file ব্যবহার করে আমি বা অন্য কেউ module update করলে নিচের কাজগুলো **একই release-এর মধ্যে** শেষ করবে। Code বদলে documentation/test/package বাদ রেখে release complete বলা যাবে না।

1. আগে current plugin ZIP/file checksum, live Suite/WP/Woo/PHP version, active ability list ও affected settings record করবে।
2. User request কোন role-এর rule বদলায়—Preparation, Publisher, plugin server, dashboard না connector—impact map লিখবে।
3. Source code, ability schema/annotations, runtime validation এবং matching workflow source একসঙ্গে update করবে। একই rule preflight ও write layer-এ একই central source থেকে enforce করবে।
4. New/changed setting-এর safe default, accepted range, existing-install behavior, fresh-install behavior এবং invalid input test করবে।
5. Project instruction/direct setup prompt/trigger template affected হলে bundled files ও dashboard generator একই release-এ update করবে।
6. A-to-Z function map, settings table, error table, meta keys, test matrix ও rollback note update করবে।
7. সব PHP lint, static stale-limit search, JSON validity, UTF-8, ZIP root structure এবং asset load যাচাই করবে।
8. Staging-এ read-only invalid/valid tests আগে; তারপর authorized isolated Draft mutation। Create, Update, partial resume, readback ও cleanup test করবে।
9. Variation change হলে 64, configured target (যেমন 144), configured+1, hard boundaries 1/564 এবং invalid 0/565 test করবে। Save-এর normalized rows ও readback rows exact compare করবে।
10. Per-child SKU, supplier SKU, prices, stock, image IDs, one swatch per colour, full gallery, content, SEO ও product status compare না করে success বলবে না।
11. Ability switch/access change হলে discovery, direct execution denial এবং restore-to-intended-policy test করবে। Client Default/Auto-review-কে server guarantee বলবে না।
12. Workflow file change হলে under/over 2 MB, same-name Cancel, confirmed replace, previous version, different name এবং case collision test করবে।
13. Full release ZIP, changed-files patch ZIP, current Project files/instructions, validation evidence, rollback steps ও `SHA256SUMS.txt` বানাবে।
14. Staging validated package ও deployed files-এর hash মিলাবে। Temporary QA product Trash করবে; shared media delete করবে না।
15. Production/Main-এ নিজে থেকে deploy করবে না। Owner-এর আলাদা production approval ও production-specific backup/IDs ছাড়া staging result production authorization নয়।

### Release-complete receipt

প্রতিটি release শেষে কমপক্ষে এই evidence থাকবে:

```json
{
  "release": "Dreminex Suite x.y.z",
  "changed_files": [],
  "local_checks": [],
  "staging_checks": [],
  "known_limits": [],
  "rollback_package": "",
  "artifacts": [],
  "sha256_manifest": "SHA256SUMS.txt",
  "production_deployed": false
}
```

এই receipt-এর কোনো required অংশ অসম্পূর্ণ হলে status হবে `partial` বা `blocked`; `complete` নয়।
