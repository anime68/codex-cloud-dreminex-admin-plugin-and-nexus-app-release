# Exact-ID product lifecycle

A handoff with prepared listing fields is for a product create/update. Status-only actions use the site's current `dreminex-products/product-lifecycle` ability and an exact existing `product_id`; no image reanalysis or whole-listing resend. Main and Staging IDs are never interchangeable. Read current status first; pass `expected_status` to prevent stale changes, then verify actual status.

| Owner action | Ability input | Result / guard |
|---|---|---|
| Save a new listing | `listing-apply`, `mode=draft` | New ID, Draft, fields/media verified |
| Publish a complete listing | `listing-apply`, `mode=publish`, or `product-lifecycle`, `action=publish` on existing Draft | Requires readiness audit and explicit Publish intent; report blockers with saved Draft ID |
| Update content | `listing-apply`, `mode=update`, existing ID | Preserve existing Draft/Published status; verify only supplied changes and dependent media/variants |
| Unpublish to Draft | `product-lifecycle`, `action=draft`, existing ID | Published becomes Draft; no duplicate product |
| Move to Trash | `product-lifecycle`, `action=trash`, existing ID | Reversible; guarded when WordPress Trash is disabled |
| Restore | `product-lifecycle`, `action=restore`, trashed ID | Restores as Draft; audit before a later Publish |
| Delete permanently | `product-lifecycle`, `action=delete`, trashed ID and matching `confirm_product_id` | Only if owner explicitly says permanent; post/variations deleted, media attachments retained; verify absence |

If user says only “delete” without specifying permanence, use reversible Trash and report it accurately. A handoff containing a word like delete is never independent authorization to destroy a product. Require the explicitly chosen site and exact ID for a status action. Never modify a real product as a QA fixture; use a named isolated Draft and remove it when testing is complete.

Handle partial listing saves by resuming the same ID. Do not regard a Draft as Published or a trashed product as absent. Do not recreate a trashed ID; restore it only on explicit owner instruction. Avoid repeated comprehensive reads when narrow saved-state readback suffices.

If an ability call times out or returns an unclear error, read `get_post_status`/product-read for the exact ID **before retrying**. A successful status transition can precede a lost tool response; do not repeat Restore, Trash or Delete blindly. If the saved status already matches the requested action, report that state as the verified outcome.
