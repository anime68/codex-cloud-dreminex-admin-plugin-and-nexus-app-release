# Publisher: Original Media, Variation Mapping, and Prepared Fields

## Media source of truth
- Preparation's self-contained `PUBLISHER HANDOFF` is the source. It records the screenshot reference and the visually confirmed **original** attachment ID and URL on one named site. The Publisher receives this as text; supplier screenshots are never supplied to or used by it as gallery images.
- Follow the prepared site/ID/URL mapping. Do not visually recheck or search the library again. Main and Staging IDs differ; technical invalid-ID errors are reported, never repaired with a guessed substitute.
- The handoff contains both ID and URL for audit, but the live `listing-apply` image entry accepts **exactly one** media source. Pass the prepared `image_id` and omit `url` in the live entry. If the ID fails, stop that image and report the technical blocker; do not initiate a new image search.
- Use only the handoff's verified WordPress attachment IDs **on the target site**. If an ID is invalid, return the technical failure to Preparation/the owner; do not fetch, upload, or select another image in Publisher.
- Maintain image order, unique descriptive attachment slugs, alt text/title, visual color HEX, and correct `image_index` mapping. Apply the hand-off's `featured_image_index` for a verified hero photo while retaining all other originals in the gallery; on an existing product preserve unrelated fields and variation image associations. Raw per-screenshot SKU evidence is audit-only, never a competing live `images[].supplier_sku`. Prepared final Title/Alt/attachment slug are Publisher write fields during an authorized listing action when shared use is safe. Use `update_media_metadata=true` with the live listing schema or the exact-ID media-update ability, then read back all metadata. A contradictory false flag must be resolved from the owner’s current instruction or reported pending; it must not silently skip the write. Attachment slug is not the physical filename or URL. Product slug is separate. Partial media import: keep successful image IDs and retry missing indexes only.
- Apply `06_IMAGE_METADATA_EXECUTION.md` and `07_ADDITIONAL_MEDIA_METADATA.md` to **every distinct prepared Media ID across both hand-off arrays**, not only the featured image or a single colour. The hand-off's `metadata_write` controls safe per-ID action but is never forwarded to Suite. In one Publisher run, write Title/Slug/Alt and the product listing, then compare all saved attachment fields by ID; exact-ID fallback repairs any missing bulk metadata without redoing the product.

## Listing details
- Preserve final title, HTML short and long descriptions (including the exact product name as the first compact H3), provided SEO fields, category path, color names and image-matched HEX, tags and category mappings. Do not rewrite prepared copy or alter the featured-image choice; apply its verified index and keep the complete ordered gallery.
- Preserve brand only if verified in the final preparation sheet; store/merchant name must not be substituted as garment label.
- **Simple:** one purchasable product option with no selectable variations.
- **Variable:** only the offered size/color combinations supplied in prepared sheet; even one color with selectable sizes counts as Variable.
- Set `full_matrix` only with explicit full-combination instructions. A confirmed every-colour/every-size statement suffices. With missing supplier codes, create unique internal `<parent>-<COLOR-SLUG>-<SIZE>` child SKUs and omit supplier_sku, retaining all offered variants.
- Carry prepared image swatch indexes; when absent, `listing-apply` maps verified `images[].color` to the corresponding choice. Verify `color_swatches` readback and flag missing image modes as partial.
- Use one chosen supplier code per sellable colour/design option from `color_supplier_skus`; `color_sku_resolution` and `color_sku_conflicts` explain how the code was chosen and preserve alternate photo codes. Publisher does not choose among these. Do not omit the chosen code while creating offered child SKUs, and do not silently report blank child SKUs as done. On a partial existing Draft, update the exact affected variation IDs without creating duplicates; read back raw child SKUs.
- Preserve regular price and *real* sale price exactly as finalized. Never manufacture discount or recompute price at publish time.
- No unknown numerical stock; use owner-provided status or unmanaged stock where applicable.
- Upsell/cross-sell only from exact IDs/SKUs provided; no speculative related products.

## Source separation
Cost research, shipping pricing experiments, supplier comparison, marketing variants and title/SKU-uniqueness debates belong to **Preparation**, not this project. Publisher sees only the finished listing and exact user action.

## v1.13.68 capacity and swatch execution

Preflight is authoritative for the configured 1–564 row capacity. Never take the first N rows, split one product into silent partial offerings or omit rows to satisfy a limit. The orchestration layer internally saves batches of 12 and returns exact processed/remaining counts; a partial variation stage resumes on the same Draft with its opaque token and offset.

For every colour/design, save one representative original product image as the swatch. Keep every other verified view in the gallery. Multiple gallery views never create duplicate colour options or extra variation rows. If no product image exists for that option, preserve the prepared verified HEX fallback.
