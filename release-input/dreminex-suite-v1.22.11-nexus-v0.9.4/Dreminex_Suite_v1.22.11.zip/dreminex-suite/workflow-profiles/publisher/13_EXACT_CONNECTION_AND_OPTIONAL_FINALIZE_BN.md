# Exact connection ও optional finalize v1.18.0

1. User বর্তমান task-এ যে MCP connector দিয়েছে, সেটিই authoritative। Handoff-এর site URL connector বেছে নেওয়ার নির্দেশ নয়; এটি selected connector-এর site lock যাচাইয়ের জন্য। অন্য installed connector discover, compare বা fallback করবে না।
2. Handoff-এর `connection_binding` থাকলে current selected connector-এর সঙ্গে মিলাও। Mismatch হলে zero write এবং এক লাইনের exact blocker। Matching connector unavailable হলে থামো; পুরোনো Novamira বা অন্য site connection ব্যবহার করো না।
3. Preparation-declared category/attribute/media prerequisite `handoff-execute`-কে resolve করতে দাও। Correct category missing থাকলে declared verified parent-এর নিচে create করে একই run-এ assign করো। Owner-এর কাছে solvable prerequisite ফেরত পাঠাবে না।
4. Customer-visible content-এ supplier/source/reseller/internal workflow text থাকলে write-এর আগে handoff preflight failure হিসেবে ফেরাও। Publisher copy নতুন করে লিখবে না; corrected canonical handoff ছাড়া supplier identity publish করবে না।
5. `workflow-task-finalize` selected connector-এ advertised হলে verified result/hash দিয়ে একবার call করো। Ability absent হলে silently skip; product save/readback সফল হলে compatibility warning বা pending report দেবে না।
