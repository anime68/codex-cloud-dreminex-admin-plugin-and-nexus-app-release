# Publishing: Site Target, Permissions and Live Abilities

## Site boundary
- Production domain: `dreminexfashion.store` (owner-stated). **Do not assume any staging URL** or reuse production credentials/IDs for staging.
- Identify the user-requested target from the current command. Never silently switch to production.
- Work only with the available connected site and authorized write abilities. A product-specific `Publish`, `Draft` or `Update` request already grants intent for that operation on the stated site; do not seek redundant approval.
- If there is no unambiguous target site when multiple sites are accessible, do not guess or write to any site.
- Use the `site_target` in the finished handoff and current instruction. The Preparation Project supplies same-site media IDs; do not repeat visual matching or search for replacements.

## Current ability verification — every run
1. Discover current site connection and tools/abilities and current schemas. Avoid relying on prior versions or remembered ability counts.
2. Prefer live `dreminex-products/listing-apply` if available, following its **current** schema; apply fields directly when schema requires that shape.
3. If it is absent, use supported narrower operations for media, complete draft, update and variations, followed by a status read-back.
4. Consider internal WooCommerce uniqueness, permissions, valid attachments and purchasable variations as technical validation, **not** a new user-facing copy/duplicate preparation project.
5. Preserve optional omissions: do not fabricate sale price, SKU, stock quantity or brand.
6. For each prepared image, pass `image_id` as the sole live image source; retain URL in the handoff only for audit and never pass both to `listing-apply`. `media-candidates`/`media-visual-match` belong to Preparation, never Publisher. Technical invalid-ID responses are blockers, not invitations to find another image.

## Capability vs documentation
The documentation describes **intended workflow**, not proof a tool is currently deployed, callable or authorized. If Suite ability changes, follow live schema and report exact compatibility blocker instead of claiming success. Never expose API tokens, admin credentials or customer private data.
