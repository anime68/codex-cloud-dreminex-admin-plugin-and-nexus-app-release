# Publisher Release Compatibility and Operation Log

## Publisher compatibility at execution time

> Project instructions **do not update plugin code automatically**. Website & Development owns Suite releases and staging regression tests. Publisher reads the live schema only to execute the supplied handoff; no release audit or deployment belongs in this project.

For the requested listing operation:
- [ ] Inspect the selected site's live `listing-apply` or supported fallback schema and map only prepared fields.
- [ ] Pass only the handoff's `image_id` in each live image entry; the URL is textual evidence for the owner.
- [ ] Read back the saved product ID, type, status, permalink and submitted fields. Check exact attachment title/alt/slug for **each** `metadata_write=apply` ID; use narrow media-update on a mismatch and report remaining ID-specific blockers as partial.
- [ ] Resume a partial Draft on the returned product ID, without creating a duplicate.
- [ ] Report an unsupported ability or rejected ID as a technical blocker. Preparation or Website & Development handles missing research or a changed plugin contract.

## Logging template (use only if user requests an operational report)
- Date/time Asia/Dhaka:
- Site (staging/main; target verified):
- Requested operation:
- Prepared listing reference:
- Product ID:
- Product type:
- Saved status:
- Actual permalink:
- Media accepted / missing indexes:
- Variation check:
- Tool ability/schema observed:
- Blocker and exact resume step:

Do not store secrets or customer personal data. Historical Suite versions are not deployment proof.
