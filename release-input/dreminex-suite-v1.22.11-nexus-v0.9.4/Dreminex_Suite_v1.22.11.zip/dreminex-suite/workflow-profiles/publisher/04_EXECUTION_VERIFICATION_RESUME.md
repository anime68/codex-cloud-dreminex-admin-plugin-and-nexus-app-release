# Draft / Publish / Update — Execute, Verify, Resume

## Before calling a write ability
- For a complete JSON hand-off, run `handoff-preflight` on the **selected site**. Its `errors[]` are Preparation blockers; no new Draft is created. Use its `listing_parameters` only when `ready=true`. The same guard runs when the raw hand-off is passed to updated `listing-apply`.
- Resolve Create/Update using `09_OPERATION_SELECTION.md`. Only explicit `mode=update` with the exact selected-site ID updates an existing listing; a null/Draft/Publish mode creates, and an incidental old `product_id` is ignored. An explicit Update without an exact target is blocked. Resume only the same partial Create/Update operation returned by `listing-apply`.
- Have the complete prepared text handoff with same-site attachment IDs. Use current tool schemas and capabilities.
- Respect the Preparation handoff's `match_status=VISUALLY_VERIFIED` and its prepared attachment ID. Do not inspect screenshots or search/rank media again. Carry only one source field in each live image entry; the Suite performs technical ID validation.
- On update, use the owner-specified product ID and **preserve current published/draft status** unless the owner explicitly requested a state change.

## Scoped copy handoff
A `scope=short_description_and_description_only` handoff updates exactly the two HTML fields on an **existing** product. Resolve both `site_target` and exact `product_id` from the handoff or explicit current owner instruction; a product title alone does not identify a safe write target. Read the ID/status, use `listing-update` with only `product_id`, `short_description` and `description`, preserve current status, then read back both fields and the exact H3/name. Do not create a product or overwrite price, images, gallery, SEO, variations or relationships from a copy-only handoff. If site or ID is absent, return the corrected HTML for transfer while leaving WordPress unchanged.

## Apply
- New: `mode=draft` or `mode=publish` if these are accepted by current schema.
- Update: `mode=update` with specified `product_id` if supported.
- Favor one complete operation when available; avoid repeated incomplete product-create calls that lose SEO, variations or images.
- When `listing-apply` reports a partial variation stage, resend the exact same normalized input and original mode with returned `resume_product_id`, opaque `resume_token` and `variation_offset`. This works for the same Create or Update operation and continues at the saved batch boundary. A changed input, token or offset is rejected. For legacy `draft-complete`, send `operation=resume` and the exact partial Create Draft ID. Never create a second product as an automatic retry unless explicitly requested.

## Optional Supplier Monitor source
- On full Add/Update only, pass a non-empty exact handoff `supplier_source_url` inline. Missing, null or blank means skip the source ability and continue.
- After product save, use `supplier-source-read` on the same site and returned product ID to verify the exact URL. If source linking fails, report that stage as partial while preserving the successful product save; retry only `supplier-source-set` for that ID, then read back. Never replay the complete create/update to repair a source link.

## Read-back requirements
- Confirm actual saved product ID, type, status, permalink and all explicitly supplied required fields. Compare the exact product `name` with the text of the first small H3 in long description; Publisher must preserve Preparation copy, never silently author a different heading. For status-only work use exact-ID `product-lifecycle` without resubmitting a full listing.
- Verify variation count/selected combinations, matching images, prices, selected colour supplier code and **each raw child SKU**, metadata, featured attachment ID/gallery count and visibility using supported reads. A parent SKU or inherited `get_sku()` does not prove child SKU persistence. If a selected colour code was supplied but any affected child raw SKU is blank, retry that exact same-ID variation or report the blocker; do not mark the listing complete.
- Whenever the hand-off contains final attachment metadata, verify saved Title, Alt and attachment slug for every image independently. If the write was skipped or one image failed, retry that exact ID and report pending until readback matches; a changed attachment slug does not rename its image file or URL. Preserve shared-media use when editing metadata.
- Compare the number of distinct `metadata_write=apply` hand-off IDs across `images[]` and `additional_media_metadata[]` to the number of exact-ID Title/Slug/Alt matches. All safe images supplied for this product, including originals outside the gallery, are part of the same operation. Report saved product status even if some media writes failed, but label the overall work partial and give exact failed IDs; resume those IDs and the existing product, never create a duplicate.
- Narrowly fix missing fields only; avoid repricing, recopywriting, duplicate-preparation or unrelated site edits.
- A successful HTTP call by itself is not proof every field saved. A draft is **not** published. An error/timeout is not proof that a status write failed: read the exact saved ID before retrying or recreating anything.

## Failure / partial response
- Preserve working draft/product ID where available and report precise missing media, permission or variation reason.
- If essential price/media/variations block safe publication, don't fabricate. Report exact blocker and continuation step; where possible safely retain a draft.
- Site access denied or user action impossible → no claim of product creation.

## End response format
Success: `Product name — Draft/Published/Updated — actual saved status (if updated) — actual product link`.
Partial: `Product ID — Draft/current status — exact blocker — how to resume`.
Avoid unnecessary audits, paragraphs or second approvals in the **publishing execution response**.
