# Product Operation Selection — Explicit Update Only

Apply this rule before any product write. The hand-off's `mode` and the owner's current instruction determine the operation; product similarity never does.

## Create or Update

- Run an existing-product **Update** only when the owner explicitly requested an Update or the current hand-off explicitly identifies itself as an Update hand-off. Require `mode: "update"` and the exact `product_id` for the selected site. Apply only the requested/prepared fields and preserve other fields and the saved Draft/Published status.
- Otherwise run a **Create**. Use `mode: "draft"` by default, or `mode: "publish"` only for an explicitly requested Publish of a new listing. Send `product_id: null` or omit it. Never reuse an ID from an older hand-off or conversation.
- A name, slug, category, photo, SKU, SKU prefix, colour, or design match is not an Update instruction. If an old hand-off has a non-null ID but no explicit Update mode, clear the ID and keep the Create operation. The current `listing-apply` schema defaults to Create and ignores a supplied ID unless `mode: "update"` is explicit.
- If the owner explicitly requests Update but the target ID is missing or ambiguous, do not create or update anything. Return the exact identity blocker and ask Preparation for a corrected hand-off.

## Exact name/slug collision on Create

- Preparation checks the selected site's exact product title and slug and supplies a distinct name/slug for a new product with a collision. Use the prepared `name` and `slug` unchanged; do not convert a Create into an Update or copy fields from the matching listing.
- If `listing-apply` returns `duplicate_product_identity`, no product write was made. Keep the operation as Create and return the collision blocker so Preparation can supply a unique, evidence-based title/slug. Do not retry against the matching product ID.
- If `pending_inputs` contains `unique_name_slug_unverified`, stop before the product write. Resolve the selected-site exact title/slug check and obtain a distinct Create hand-off first.

## Partial Create recovery

A partial result from a Create is resumed on the same site and the exact `resume_product_id` returned by that very run. This is continuation of that Create, not a new Update request. Use `listing-apply` with `mode: "update"` and that ID, or the legacy `draft-complete` with `operation: "resume"` and that ID; never substitute another existing product. If there is no saved product ID, restart Create only when the earlier response confirms nothing was created.
