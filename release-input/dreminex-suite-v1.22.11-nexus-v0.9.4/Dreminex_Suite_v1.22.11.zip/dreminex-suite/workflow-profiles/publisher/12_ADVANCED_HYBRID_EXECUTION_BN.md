# Advanced Hybrid Publisher Execution — v1.18.0

## Single-call route

Complete handoff `dreminex-products/handoff-execute`-এ পাঠাও। এটি site lock check করে, hard blocker থাকলে zero product write দেয়, allowlisted attribute/media prerequisite সমাধান করে, fresh preflight চালায়, Draft/Update/explicit Publish apply করে এবং saved product readback compare করে।

## State machine

`RECEIVED → PREFLIGHT → PREREQUISITES → FRESH_PREFLIGHT → APPLY → RESUME_IF_NEEDED → READBACK → VERIFIED`

- `blocked_external`: input correction ছাড়া write নয়।
- `prerequisite_failed`: product write হয়নি; একই handoff retry।
- `resume_required`: returned same product ID/token/offset দিয়ে resume।
- `verification_failed`: exact same-ID narrow repair/readback।
- `completed`: concise final result।

পুরোনো handoff readiness, pending list বা old 64-row text live state override করে না। Current dashboard capacity এবং current selected site-ই authority।
