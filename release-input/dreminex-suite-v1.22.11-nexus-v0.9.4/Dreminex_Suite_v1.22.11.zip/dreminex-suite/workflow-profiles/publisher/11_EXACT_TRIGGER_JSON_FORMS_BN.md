# Publisher exact triggers ও minimal JSON form (v1.13.68)

Owner-এর **সম্পূর্ণ message** trim ও case-normalize করার পর exact trigger মিললেই শুধু নিচের সংশ্লিষ্ট valid `json` block দেবে। বাক্যের মধ্যে trigger শব্দ থাকলে form চালাবে না। Form response-এর বাইরে ব্যাখ্যা নয়। Publisher form পূরণ হওয়ার পরও Preparation-এর complete handoff ছাড়া product content, SEO, media বা variations নিজে বানাবে না।

## `help`

```json
{
  "available_triggers": ["draft", "publish", "update", "verify", "resume", "trash", "restore", "delete"],
  "usage": "Exact trigger-টি একা পাঠিয়ে পাওয়া JSON form পূরণ করুন। Full listing operation-এ complete Preparation handoff দিন।"
}
```

## `draft`

```json
{
  "request_type": "APPLY_PREPARED_HANDOFF",
  "mode": "draft",
  "site_url": "",
  "site_mcp_server": "",
  "handoff_or_attached_json_file": ""
}
```

## `publish`

```json
{
  "request_type": "APPLY_PREPARED_HANDOFF",
  "mode": "publish",
  "site_url": "",
  "site_mcp_server": "",
  "handoff_or_attached_json_file": ""
}
```

## `update`

```json
{
  "request_type": "APPLY_PREPARED_HANDOFF",
  "mode": "update",
  "site_url": "",
  "site_mcp_server": "",
  "product_id": null,
  "handoff_or_attached_json_file": ""
}
```

## `verify`

```json
{
  "request_type": "VERIFY_SAVED_PRODUCT",
  "site_url": "",
  "site_mcp_server": "",
  "product_id": null,
  "compare_with_handoff_or_file": ""
}
```

## `resume`

```json
{
  "request_type": "RESUME_PARTIAL_LISTING_APPLY",
  "site_url": "",
  "site_mcp_server": "",
  "resume_product_id": null,
  "resume_token": "",
  "variation_offset": null,
  "same_normalized_listing_parameters_or_handoff_file": ""
}
```

## `trash`

```json
{
  "request_type": "PRODUCT_LIFECYCLE",
  "action": "trash",
  "site_url": "",
  "site_mcp_server": "",
  "product_id": null,
  "expected_status": "draft|publish"
}
```

## `restore`

```json
{
  "request_type": "PRODUCT_LIFECYCLE",
  "action": "restore",
  "site_url": "",
  "site_mcp_server": "",
  "product_id": null,
  "expected_status": "trash"
}
```

## `delete`

```json
{
  "request_type": "PRODUCT_LIFECYCLE",
  "action": "delete",
  "site_url": "",
  "site_mcp_server": "",
  "product_id": null,
  "confirm_product_id": null,
  "expected_status": "trash"
}
```

## Execution rules

- Inline JSON বা attached `.json` file—দুটির root complete handoff হতে হবে। Receipt block apply করবে না।
- Full handoff প্রথমে `handoff-preflight`; `ready=false` হলে zero write। `normalized_variation_count` এবং configured capacity report করবে।
- `ready=true` হলে returned `listing_parameters` apply করবে। Internal batch 12 হলেও user handoff split/truncate করবে না।
- Partial variation save হলে exact returned `resume_product_id`, `resume_token`, `variation_offset` এবং একই normalized input দিয়ে resume; নতুন product create নয়।
- Save শেষে exact variation count, raw child SKU, supplier SKU, prices, stock, variation image, one swatch per colour, gallery order, content, SEO ও status readback করবে।
