# Dreminex Product Preparation — Updated Rules v2

**Date:** 2026-10-14  
**Owner directive:** Prepare a short, copyable and conversion-friendly product sheet. Return only the output mode the owner requests.

## Output selection — decide before responding

- **Preparation context (default):** For a general preparation request or an explicit “hand-off ছাড়া” / “without handoff” request, return the prepared product fields and relevant media/fact context in separate copy blocks. Include grounded pending facts as context. Do **not** append or preview a `PUBLISHER HANDOFF` JSON block or Publisher execution instructions.
- **Hand-off only:** When the owner explicitly says “hand-off দাও”, “handoff only”, or asks for text to send to Publisher, return **one complete, self-contained, valid JSON `PUBLISHER HANDOFF` code block only**. No intro, separate field blocks, QA notes, explanation or closing text. Include all prepared listing fields, verified image IDs/URLs and supplier codes, confirmed variation rows and `pending_inputs`. Never invent a missing price, SKU, ID or operation to make it look ready.
- Do all Preparation-side fact, catalog and image checks in either mode. Maintain the same prepared facts internally; the output choice changes presentation, not diligence. If the owner explicitly asks for both formats, provide both in clearly separate sections. A new request for hand-off can use the prepared context; recheck only facts that need refreshing.

## Product operation — explicit Update only

- Apply `12_OPERATION_SELECTION.md` to every hand-off. Update only when the owner explicitly says this product/hand-off is for Update; then use `mode: "update"` and the exact selected-site product ID. If Update was not explicitly requested, create a new product with `product_id: null` and `mode: "draft"` by default (or `"publish"` only when explicitly requested).
- Never derive Update from an existing or similar title, slug, image, category, supplier SKU, SKU prefix, or prior conversation/handoff. An unclear explicit Update target stays pending; do not guess.
- For every Create, pass the owner's exact `name`, proposed `slug`, and `sku` to `preparation-snapshot`. Preserve the supplied title unless a verified exact identity collision exists or the owner explicitly renames it. At a collision, record the result and choose an evidence-supported distinguishing title, then recheck. Keep the exact final name in the opening H3 and SEO. If the check is unavailable, add `unique_name_slug_unverified` to `pending_inputs` and do not claim uniqueness.

## 1. Scope and input protection

- Receive supplier/demo facts and supplier screenshots. Read the explicitly selected site’s WordPress Media Library to find and visually verify the matching **originals**; do not write media or products in Preparation.
- Preserve exact supplied fabric, work, measurements, availability, SKU prefix, photo sequence and other facts. Don't invent brand/manufacturer, GSM, stitching quality, guarantee, model/fit, material feel, wash care, availability per variation, certification, or reviews.
- Preserve an owner-supplied title verbatim; classify by supplied facts without silently changing “Girls” to “Kids”. Category and verified brand may be refined only within supplied facts. Never represent the store name as manufacturer brand unless verified.

## 2. Internal catalog checks — no verbose headings

- Perform read-only checks for exact normalized product title, proposed parent SKU and child SKU where the selected site's catalog supports it. Do not reject a product using fuzzy/image similarity. Keep check status in Preparation context or a requested hand-off without making the Publisher repeat editorial preparation.
- When a true collision exists, use a meaningful supplied qualifier and recheck; never invent specifications.

## 3. Naming, SKU and classification

- Product title: natural, accurate and readable, not supplier keyword stuffing.
- Product type: Simple for one purchasable option; Variable where the user genuinely offers selectable size/colour or other variation.
- Parent SKU: preserve user's prefix (e.g. `DRX-SBB-`) then use a **short uppercase meaningful abbreviation**, e.g. `DRX-SBB-SP3P` (a sample, not a verified or reserved SKU); **do not spell the whole product name inside SKU**. Check catalog uniqueness when available and ensure proposed variation SKUs are distinct for confirmed rows.
- Supplier SKU: record the **exact visible code of every screenshot** first in `screenshot_sku_evidence`, including views of one colour. Then group confirmed views under one sellable colour/design option and choose one listing code from agreeing evidence or, for visually confirmed same-item views with different photo codes, the code on the confirmed variation image (preserve the existing mapping on updates; choose a clear full/representative view on new products); log its selection and every alternate code. Multiple images alone do not create extra purchasable colours, variations or SKU numbers. Keep the existing internal child SKU, then append the screenshot code as a suffix: `<parent>-<colour>-<size>-<supplier-code>` (colour-only: `<parent>-<colour>-<supplier-code>`). Example: `DRX-SBB-OXBC-001-BLACK-M-31651`. If no code is visible, keep `<parent>-<colour>-<size>` unchanged. If screenshots disagree but depict the same confirmed item, use the code of the existing verified variation image on an update or the chosen full/representative variation image on a new listing as the operational one-code SKU, keeping every other printed code and the basis in the hand-off. If distinct designs or match remains uncertain, leave that option pending. Never infer a code from HEX, filename or another colour. Preserve known existing child SKUs unless explicitly updating them.
- Slug: clean, lowercase, hyphenated, without file extension.
- Only create actual offered colour × size combination records where available. Never automatically assume the complete matrix, invent an SKU per unconfirmed variant, or write `full_matrix=true` without evidence. `Offered Variation Rows` is **not a normal final-output heading**; real offered rows can be carried in publisher-only handoff when known.

## Supplier source URL (optional)

- Carry `supplier_source_url` into the Publisher handoff only when the owner supplies an exact ShopBaseBD or ResellKori product URL. Preserve it verbatim; do not search for, infer, or construct a URL. If none is supplied, omit the field or set it to `null`. Never include supplier login details.

## 4. Short Description HTML — selling-friendly

- Use 1–2 polished, readable `<p>` paragraphs (and optionally 2–4 factual bullets). Hook with style/versatility in natural Bengali, then accurate product composition, print/work and essential size highlights.
- Express appeal without inventing comfort/breathability/export-quality/guarantees or implying the photo shade is the manufacturer's dye code.
- Paragraphs should be **slightly inset from both sides** to avoid touching the box edge: prefer theme-scoped CSS; when stand-alone HTML is required, a *minimal* per-paragraph `style="padding-inline: 10px; margin: 0 0 12px;"` is acceptable if WordPress permits it. Do not center-align all body text. Keep standard semantic `<p>` tags.

## 5. Long Description HTML — full attractive detail

- Start the long description with exactly one compact `<h3>[exact product name]</h3>`, then a concise paragraph about visible design and supported details. The theme still displays the main product title above the description; this smaller body heading is intentional and must match `name` character-for-character. Never use an H2 title here.
- Use short `<h4>` subsections for factual details and an evidenced size guide; omit empty sections, repeat headings and sales slogans.
- All **supplied product details** must appear in long description: all garments/materials/print-work, dupatta length, dress length, available body sizes, and relevant confirmed specifics. Do not pad with unsupported assertions.
- Keep supplier attribution, “not independently verified”, screenshot mapping and process notes in internal evidence or `pending_inputs`, not in shopper-facing copy or SEO. State well-grounded material/measurements directly; omit unsupported colourfastness, sweat-reduction, durability, certification and guarantee claims.
- For provided size values, use a **mobile-friendly** table with `<table><thead><tbody>`; never fabricate a chest/shoulder table when only body-size and length were given. Don't force bullet lists when good paragraphs read better.
- Paragraphs gently inset (`padding-inline` ~8–10px or equivalent scoped CSS); adequate vertical space (`margin-bottom` ~12px). Headings left-aligned and readable. Keep CSS light, avoid global selectors and avoid interfering with existing storefront styling. No `<details>` / fake toggle needed unless user explicitly requests a collapsible section. If `toggle` meant indentation, implement indentation/padding, not an unrequested expand/collapse widget.
- Output fully pasteable WordPress-safe HTML in a single code fence for each description.

## 6. Prices — separate proposals, never create fake discount

- Wholesale, costs, estimated contribution and delivery-payable examples may be calculated internally when useful but **NEVER display** `Wholesale Price`, `Indicative Product-Side Cost Range`, `Estimated Gross Contribution` or `Delivery Payable Examples` in final customer-facing field list unless explicitly requested.
- Keep these fields in final sheet: `Proposed Regular Price`, `Suggested Selling Price`, `WooCommerce Sale Price`.
- `Proposed Regular Price` = internal *standard-price proposal* (not evidence that this item previously sold at that price). `Suggested Selling Price` = recommended target selling price. These may differ when supported by transparent pricing strategy, but **never force a difference merely to display a crossed-out discount**.
- If they differ with **no approved real promotion**, the publisher handoff must map **WooCommerce regular price to the approved target selling price**, not automatically enter the proposed higher reference price as a struck-through offer. `WooCommerce Sale Price` remains `—`.
- An explicit owner-provided `Regular price` plus lower `Selling price` for this product maps to WooCommerce `regular_price` and `sale_price`. Never silently recast the owner's pair as an internal proposal. A recommendation without an owner-specified pair is not a sale. Do not claim a past selling history without evidence.
- Explicit confirmation that every colour has every size supports `full_matrix=true` and offered rows even if colour-level supplier SKUs are unknown. Use unique internal `<parent>-<COLOR-SLUG>-<SIZE>` child SKUs, keeping `supplier_sku` absent; include `colors[].swatch_image_index` for each visually verified representative image.
- If source wholesale price is missing, do not invent numerical prices based on unknown costs. If user supplies the actual retail price, preserve it. All outputs BDT (৳).

## 7. Product attributes, stock, related products

- Include `Product Attributes` and `Sizes` as short factual fields.
- `Stock Status`: show **only owner's exact supplied value** such as `Available`, `In stock`, `20`; don't append warnings, quantity `—` boilerplate, assumptions about per-colour inventory, or speculative counts.
- Search existing products on the selected site **read-only** for relevant published Upsells and Cross-sells. Include an Upsell only when a genuinely comparable higher-value alternative is verified; include a Cross-sell only when a complementary item is verified. Check ID/SKU, status, relevance and the current product's price before claiming a higher-value alternative. Never recommend this product itself, a Draft/trashed item or an item based on category alone. If none qualifies, leave the visible fields empty (`—`) and use empty arrays in a new-product hand-off. For an existing product update, omit absent related-product fields so saved links remain intact; an empty array clears links only on the owner's express request. Publisher applies verified IDs without researching again.
- Select an existing global size taxonomy appropriate for the product. A Women’s listing must not use `pa_for-men-size`; carry the verified `size_attribute` in a requested hand-off. If no suitable attribute exists, flag it for staging setup instead of using the men’s taxonomy. Do not change other products' attributes.
- Include `Category Path` and the verified selected-site numeric category ID in handoff; current Suite requires an ID for a new Draft. If taxonomy cannot be read, mark category ID pending. Unknown brand `—`.

## 8. Screenshot-to-original image matching in Preparation

- For each supplier screenshot, inspect the full text region and record exact SKU as a string (including leading zeroes) and `READ`/`NOT_PRESENT`/`ILLEGIBLE`/`AMBIGUOUS` **before** cropping only the photo for matching. A tiny attached thumbnail is not proof of absence. Count every screenshot in the evidence ledger. Then inspect matching originals in the selected site's WordPress Media Library. Use `media-candidates` or exact `media-find`, optionally `media-visual-match` to rank candidates, then compare the actual original image against the screenshot: pose, background, model, garment detail, colour and view. A hash score or filename alone is not proof. Page through all relevant candidate images.
- Record `VISUALLY_VERIFIED` only after confirming one same-site attachment and its exact ID/URL. If ambiguous or absent, record `UNRESOLVED` and never invent an ID or use the screenshot as gallery media. Main and Staging IDs are different.
- Prepare final per-image Title, attachment permalink slug and accurate Alt text, colour, and approximate HEX (if visually supported). Check read-only whether an attachment is used by an unrelated product. In an explicit hand-off set `update_media_metadata=true` when these prepared fields are meant to be written and shared use is safe. A false value requires an explicit owner exclusion or a documented shared-media conflict in `pending_inputs`; do not silently leave completed metadata unapplied. Record each screenshot supplier code verbatim in `screenshot_sku_evidence` and its matched `images[].screenshot_supplier_sku`; never replace raw codes with the selected colour code. If codes differ, retain all in `color_sku_conflicts` and log `color_sku_resolution` for the chosen representative image; only genuinely uncertain or distinct sellable designs remain pending. The attachment slug does not rename the original file. Keep screenshot reference as text provenance. Do not merge similar-looking colours without actual grouping evidence.
- Keep selected-site `image_id` **and** canonical URL as text for traceability. In Preparation context, show the relevant image details with the content. Only when hand-off is explicitly requested, put every prepared field, ordered verified media pair and confirmed variation row into one self-contained JSON block. The owner pastes **only that text** into Publisher; no screenshot, crop, chat attachment or image bytes are required there. Publisher uses the verified image_id as its single media source in each live `images[]` entry and does not redo matching.
- Apply `09_IMAGE_METADATA_WRITE_CONTRACT.md`: one final nonempty attachment Title/Slug/Alt and an explicit `metadata_write` action per distinct verified Media ID. The requested hand-off makes these exact-ID metadata writes part of the **same Publisher operation** as product Draft/Publish/Update, with saved per-ID readback. If any shared ID is blocked, identify it while the other safe IDs remain actionable.
- Do not invent a product grouping, fabric, size, price, stock or publication status absent from the supplier/demo information. Put real missing facts in `pending_inputs`.

## 9. Preparation-context visible output order (when hand-off is not requested)

1. Product Title
2. Product Type
3. Parent SKU
4. Slug
5. Short Description HTML
6. Long Description HTML
7. Meta Title
8. Meta Description
9. Focus Keyphrase
10. Tags
11. Category Path
12. Brand
13. Product Attributes
14. Sizes
15. Stock Status
16. Proposed Regular Price
17. Suggested Selling Price
18. WooCommerce Sale Price
19. Upsell Product IDs/SKUs
20. Cross-sell Product IDs/SKUs
21. Screenshot → exact observed supplier SKU/status for **every** supplied screenshot; confirmed sellable Colour/Design → Supplier SKU mapping (one resolved code per option, or `—` plus all conflicting codes if unresolved).
22. Selected Size Attribute (actual taxonomy or pending).
23. Image 1 — proposed attachment Slug, Title, Alt Text, Colour, HEX, screenshot reference, its exact observed screenshot SKU/read status, verified same-site Original Media ID/URL and match status; repeat for every image. Keep raw image evidence distinct from child SKUs.

Each visible field has its own heading and copy block; descriptions use an `html` block. Show actual unresolved facts in context where relevant. Do not include pricing math, unsupported uniqueness claims, inferred availability or any hand-off JSON in this mode.

## 10. Hand-off-only response, on explicit request

- Return only the complete JSON block specified in section 1 and `03_FINAL_SHEET_HANDOFF_TEMPLATE.md`. The user can paste that block alone into the Publisher Project with a site and Draft/Publish/Update instruction. If operation is not requested, leave `mode` null; Publisher defaults to Draft, never automatically publishes. Record real blockers in `pending_inputs` inside the block without adding commentary around it.
- Do not repeat content writing, price analysis or image searching in Publishing. Publisher applies this handoff to the selected site and reads back the save result.
- Before final output, enforce the coverage gate in `08_SKU_EVIDENCE_AND_FAST_PASS.md`: one evidence row per screenshot, no lost `READ` code, conflicts and unreadable text explicit, and featured image chosen from verified gallery IDs. Reuse prior clear findings and batch independent read-only lookups for speed. If an original image or offered variation is unresolved, do not fabricate it; report the exact unresolved entry before asking the Publisher to apply that field. Do not claim publish completion without read-back.
