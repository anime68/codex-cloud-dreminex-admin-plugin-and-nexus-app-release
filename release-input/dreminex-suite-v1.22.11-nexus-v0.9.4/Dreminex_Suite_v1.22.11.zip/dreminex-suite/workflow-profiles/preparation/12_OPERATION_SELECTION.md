# Product Operation Selection — Create by Default

This file is the authoritative operation rule for every product hand-off. Decide Create or Update from the owner's current instruction before preparing the final JSON.

## Choose the operation

- Choose **Update** only when the owner explicitly says that this product or hand-off is for updating an existing product. Set `mode` to `update` and include that exact product's ID from the selected site. Update only the requested fields and preserve the other saved fields and current status.
- If the owner did not explicitly request Update, choose **Create**. Set `product_id` to `null`; use `mode: "draft"` unless the owner explicitly requested Publish, in which case use `mode: "publish"`. A missing or null `mode` is also a new Draft in Publisher.
- Never infer Update from a matching or similar name, slug, category, photo, SKU, SKU prefix, design, or an earlier hand-off/conversation. Never carry a prior product ID, slug, parent SKU, variation ID, or image ID into a new product unless it is independently verified as part of this product's current same-site evidence.
- If Update was explicit but the selected-site product ID/identity cannot be resolved unambiguously, do not prepare an Update payload. Put the missing exact target in `pending_inputs`.

## Keep a Create distinct when a name already exists

- For every Create, call `preparation-snapshot` with the proposed `name`, `slug`, and `sku`. Read `product_identity_matches`, `catalog.duplicate`, and `exact_parent_sku_product_id`. These are exact identity checks, not permission to Update the matched product.
- If an active product already has the exact proposed title or slug, keep `product_id: null` and the Create mode. Make the new visible title and slug distinct. Prefer a differentiator directly supported by the current product evidence; if none is available, add the next neutral suffix such as `Design 2`, `Design 3`, and so on. Do not invent a fabric, feature, or colour.
- Recheck the revised title and slug with `preparation-snapshot`. Ensure the product `name`, slug, long-description opening H3, short/long copy references, and SEO title agree with the final name. Do not change `mode` to `update` to solve a collision.
- If the exact title/slug check cannot be completed, keep the operation as Create and add `unique_name_slug_unverified` to `pending_inputs`. Publisher must not write that Create until the name/slug check is resolved.

## Handoff values

| Owner's instruction | `mode` | `product_id` |
|---|---|---|
| No explicit Update; new listing | `draft` or `null` | `null` |
| Explicit Publish for a new listing | `publish` | `null` |
| Explicit Update of an identified existing listing | `update` | Exact selected-site product ID |

The product ID returned after a successful Create belongs to Publisher's same-run recovery only. It is not evidence that a later, separate product request is an Update.
