# Fashion category ও measurement decision map

এই তালিকা coverage reminder; WooCommerce category/attribute/term-এর নাম বা ID নয়। নির্বাচিত সাইটের `catalog` ও product evidence দেখে existing child category নির্বাচন করতে হবে। একই পণ্যে একাধিক branch অনুমান নয়।

| Main branch | সম্ভাব্য product type | প্রয়োজন হলে supplied measurements |
|---|---|---|
| Men's Fashion | T-shirt, polo, shirt, panjabi/kurta, sweatshirt, jacket, blazer, knitwear, jeans, trousers, shorts, tracksuit, set, footwear, fashion accessory | Top: chest/body width, shoulder, sleeve, length; bottom: waist, hip, rise, inseam/outseam; footwear: supplied foot length/size system; set: প্রতিটি piece আলাদা |
| Women's Fashion | top, blouse, shirt, kurti, kameez, dress, saree, abaya, outerwear, knitwear, jeans, trousers, skirt, co-ord/set, footwear, fashion accessory | প্রাসঙ্গিক bust, waist, hip, shoulder, sleeve, garment length; bottom-এর rise/inseam; saree/dupatta/set-এর প্রতিটি piece-এর supplied মাপ |
| Kid's Fashion | babywear, top, shirt, dress, frock, hoodie, jacket, trouser, shorts, set, school/casual fashion, footwear, accessory | Age label কেবল source-এ থাকলে; top-এর chest/length, bottom-এর waist/length, set-এর প্রতিটি piece আলাদা; height/foot length কেবল supplied হলে |

Size chart product type, brand/supplier এবং site taxonomy অনুযায়ী আলাদা হতে পারে। Adult M/L/XL অথবা Kids 3–12M, 1–2Y থেকে 7–8Y কেবল input উদাহরণ। Supplier-এর offered size label ও actual measurements হুবহু রাখো। Men/Women/Kids size attribute একে অন্যের জায়গায় বসিও না। Fit বা বয়স দাবি মাপ থেকে অনুমান করো না।

প্রতিটি নতুন product type-এ checklist: verified subcategory, exact taxonomy/terms, selectable colour/size evidence, সব offered pair, distinct SKU, same-site original media, representative image swatch, full factual measurements, prices, stock scope, content/SEO এবং read-only preflight। Category না থাকলে নিজে WordPress write করবে না; owner/development-কে exact missing category/term জানাবে।
