# Product Preparation v2 — Decision Log

**2026-10-11 | Format revision (owner request)**

- Retained: Product Title/Type, Parent SKU, Slug, Short/Long HTML, Meta Title/Description, Focus Keyphrase, Tags, Category, Brand, Attributes, Sizes, Stock Status, Proposed Regular Price, Suggested Selling Price, WooCommerce Sale Price, Upsell/Cross-sell, and 4 metadata fields per photo.
- Removed from **visible** response: title/SKU uniqueness headings, full-length SKUs, wholesale, estimated costs/margins, shipping payable examples, offered variation rows, combined color names and HEX headings, original image filenames, media titles and variant mapping explanations.
- Improved: polished selling-friendly copy, full factual long description, gently inset paragraphs, mobile-friendly measurements table, reduced output clutter.
- Preserved **internally**: exact duplicate checks, actual variant combinations where supplied, original image transfer references, truthful price mapping and progress/verification requirements.

**2026-10-14 | Supplier SKU correction (owner request)**

- Each image gains an optional Supplier SKU field when its exact colour code is legible or supplied. The four base image fields remain.
- Keep the parent SKU. For supplier code `31651`, colour-only variation may use `DRX-SBB-OXBC-001-31651`; M/L/XL rows must use distinct `...-31651-M`, `...-31651-L`, `...-31651-XL`.
- If no code is available, create no supplier-linked child SKU. Preserve image–colour–supplier-code mapping in Publisher handoff.

## Future per-product log (fill only after real work)

**2026-10-14 | Screenshot → existing WordPress original workflow**

- Preparation may read the selected site's Media Library and visually verify screenshot crops against originals; it may not write media/products.
- Preparation records each same-site attachment ID/URL, screenshot reference and match status. The Publisher passes only one image source to `listing-apply` after receiving a requested self-contained hand-off.
- Suite 1.13.26 adds read-only, paginated media candidates and bounded perceptual-hash ranking. A top result requires human visual confirmation. Existing attachment slug/title/alt application requires `update_media_metadata=true`; slug never renames the media file.
- Six staging screenshot/original matches were validated; product grouping, measurements and selling price were not supplied, so no listing was created.

**2026-10-14 | Conditional output (owner request)**

- Default or explicit “hand-off ছাড়া” output is preparation context with separate copy blocks and no hand-off JSON.
- On an explicit hand-off request, output only one complete JSON block with all prepared facts and pending inputs. A hand-off is no longer appended to every preparation response.
- The research, checks and screenshot-to-original matching stay within Preparation in either output mode; Publisher receives only the hand-off the owner chooses to send.

**2026-10-14 | Colour-level SKU, related products and size taxonomy (owner request)**

- Multiple photos of the same confirmed colour use one authoritative supplier code. Conflicting screenshot codes stay pending until an authoritative product mapping is known; size-specific child SKUs remain unique.
- Preparation searches the selected site read-only for relevant published Upsells and Cross-sells, includes verified IDs in context or requested hand-off, and leaves them empty when none qualify.
- Women’s sizes must use an appropriate global attribute rather than the store’s current `pa_for-men-size` default. Keep the product and price pending when the owner has not provided a selling price.

| Date | Product | Confirmed facts | Price strategy | Source/variant availability | Status |
|---|---|---|---|---|---|
| — | — | — | — | — | Pending |

**2026-10-15 | Screenshot SKU coverage and fast hand-off**

- Record exact supplier code/read status on every screenshot before cropping and matching; preserve per-image raw evidence and a separate conflict ledger in both output modes. Resolve one purchasable SKU per confirmed sellable colour/design option only when evidence allows; never silently drop printed codes.
- Select one strong verified original as the featured image and retain all other matches in the gallery. Batch read-only candidate/catalog queries, reuse findings on explicit hand-off follow-up, and run a screenshot-count coverage gate.
