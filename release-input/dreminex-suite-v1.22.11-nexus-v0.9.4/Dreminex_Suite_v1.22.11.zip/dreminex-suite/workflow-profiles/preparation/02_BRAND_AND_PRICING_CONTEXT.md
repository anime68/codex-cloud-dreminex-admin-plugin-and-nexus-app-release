# Dreminex Fashion — Preparation Context v2

**Brand:** Dreminex Fashion · Bangladesh · WooCommerce · BDT (৳) · Primary `#00B4D8`.

## Product truth and editorial voice

- Refined, natural, attractive Bangla sales copy; English technical/material names when useful.
- Boutique-like clarity, no artificial luxury/superlative or guarantee.
- Facts are user's verified supplier information and clearly visible original photos, not auto-generated marketing traits.
- Exact supplied size measurements and fabric/work information must be retained.
- Never infer manufacturer/garment brand from store name. Unverified brand is `—`.
- Color HEX is an approximate visual match only; an image pixel color is not an official dye code. The HEX field itself contains only the code.

## Internal calculation — not displayed in Final Sheet

When user supplies wholesale `W`: earlier requested internal estimate uses advertising ৳20–30, packaging/other ৳20–25 and return allowance ৳30. These are assumptions, NOT confirmed current vendor costs; estimate W+70 to W+85 if still relevant. Compare to current verified market evidence where available. Do not include internal cost breakdown or gross contribution in final product output by default.

### Price field semantics

- **Proposed Regular Price** is an internal *standard-price candidate*; not proof of a former sale price.
- **Suggested Selling Price** is the internal recommended customer-facing charge.
- **WooCommerce Sale Price** remains `—` unless there is an owner-authorized, valid promotion. If none, active WooCommerce regular price must be the owner-selected suggested selling price even when the internal proposed standard candidate is higher.
- Don't turn a speculative standard price into a deceptive crossed-out price. Do not invent sale price, period, coupon, or comparison discount.

### Delivery reference

Previous owner instructions include Dhaka ৳80, surrounding ৳100 and outside Dhaka ৳130 for eligible standard delivery advance. These are **policy reference values, not verified current checkout rates for all products**; not shown in product final sheet unless asked. The store may also have special advance requirements for selected orders; do not misstate free delivery or COD availability.

## Outside-scope workflow

- Preparation makes the final listing sheet and read-only internal checks.
- Publishing applies approved data and verified image bytes/IDs to the explicitly selected site.
- Website & Development manages plugin/source code and theme CSS, with staging-first change control.
