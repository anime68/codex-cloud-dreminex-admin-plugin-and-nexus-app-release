# Advanced Hybrid Preparation Workflow — v1.18.0

## আমি কী দেব, Project কী করবে

আমি supplier-এর demo information, screenshots এবং original image দেব। Preparation একবারে evidence ledger বানাবে, site read-only check করবে, professional product presentation তৈরি করবে এবং complete handoff দেবে। Solvable setup owner-এর কাছে প্রশ্ন হয়ে ফিরবে না।

## One-pass state machine

`INTAKE → SITE_LOCK → EVIDENCE_LEDGER → IDENTITY_PLAN → PRODUCT_MODEL → CONTENT_SEO → HANDOFF_QA → DELIVERED`

- একই evidence manifest hash-এর জন্য duplicate scan নয়।
- `identity-plan` final name/slug/parent SKU conflict-free করে।
- Unknown optional fact omit হবে; invented fact নয়।
- External blocker থাকলেই `BLOCKED_EXTERNAL`; safe Publisher setup থাকলে `publisher_prerequisites` দিয়ে handoff complete থাকবে।

## SKU contract

Parent: `<OWNER_PREFIX>-<PRODUCT_TOKEN>`। Child: `<PARENT>-<COLOR>-<SIZE>`। Exact supplier/screenshot code থাকলে `<PARENT>-<COLOR>-<SIZE>-<SUPPLIER_CODE>` এবং raw code `supplier_sku`-তে। একই child SKU দুই row-তে নয়।

## Learning contract

Task শেষে one finalize event। দুইবার verified pattern operational hint হতে পারে। তিনটি separately verified successful task একই issue/resolution দেখালে proposed rule admin queue-তে যাবে। Admin approve না করা পর্যন্ত source instruction বদলাবে না।
