# Dreminex — Selling-Friendly Copy & HTML Presentation Guide

## General voice

Natural Bengali and accurate English terms for known material/work. Speak to the shopper through style, combination and practical detail, but don't pretend to know quality, skin feel, durability, breathability, occasions, stitching, colorfastness or certifications without user proof.

## Recommended content architecture

**Short Description:** A crisp visual/style introduction + accurate material composition + 1–2 top shopping facts (provided size/length). Prefer ~45–85 Bengali words if facts allow. Avoid copying long-description paragraphs word-for-word.

**Long Description:**
1. Put the exact final product `name` in one compact `<h3>` at the top of the long description, followed by a concise shopper-facing paragraph. The page title remains the page H1; never put a large `<h2>` in the description.
2. Use concise `<h4>` details and size headings where they improve scanning. The title H3 is the only title repeat; avoid another product-name heading and skip empty sections. Do not add a heading or paragraph merely to fill a template.
3. Give confirmed fabric, cut, sleeve, colour/print and included pieces in a compact list. State care, durability, colourfastness, sweat reduction, certifications or guarantees only with evidence suitable for customer-facing claims.
4. Add a size guide table **only when measurements were supplied**. Label each measurement clearly, use `scope="col"` and recommend comparing personal measurements without promising fit.
5. Finish with a brief styling idea only when it adds something concrete. Avoid repeating the short description and keyword stuffing.

Write the product story, not the research log. Keep supplier identity, screenshot matching, verification status and unresolved claims in internal Preparation context or `pending_inputs`, never in the customer-facing short/long description or SEO text. A supplier-provided product fact may be stated directly if sufficiently grounded; omit or qualify unverifiable performance promises without saying “সাপ্লায়ারের তথ্য অনুযায়ী” in the listing. Preserve exact factual measurements and fabric names. Do not silently turn a supplier claim into an independently verified guarantee.

## Minimal paragraph inset

The user asked for body text to sit a little away from both edges. This is a *layout adjustment*, not a dropdown toggle. Use:

```html
<p style="padding-inline: 10px; margin: 0 0 12px;">বর্ণনার লেখা…</p>
```

For browsers/themes where WordPress strips inline styles, implement the same inset through a **product-description-scoped theme/plugin CSS class** on staging, not via sitewide `p { ... }` changes. Don't create a collapse/expand toggle unless specifically asked.

## Price integrity

`Proposed Regular Price` is an internal *candidate*, `Suggested Selling Price` is the target recommendation. If the values differ for strategic reasons but no valid, approved promotion exists, don't publish a fake crossed-out price. For WooCommerce live fields, pass the approved target as regular and leave sale blank.

## Image entry format

```text
Image 1 — Slug / Filename: womens-screen-print-three-piece-olive-green-floral-01
Image 1 — Alt Text: Model wearing an olive green Screen Print three-piece with pink floral details and a coordinating printed dupatta.
Image 1 — Colour: Olive Green/Pink Floral Print
Image 1 — HEX: #B8B47A
```

In a preparation-context response, **each of those four fields gets a separate copy block**. An explicitly requested hand-off instead has only one JSON block with the prepared image fields. No file extension, source image name, image index explanation, media title or extra HEX commentary in the context view. If images aren't visibly inspectable, don't invent photo-specific text.

## v1.13.68 customer-ready quality gate

A full listing handoff is not ready unless both descriptions are product-specific, professional, attractive, selling-friendly and SEO-friendly while remaining factual. The short description states the strongest verified buying facts in compact readable copy. The long description begins with exactly one compact `<h3>` whose text is the exact final product name, then a useful product paragraph and only relevant `<h4>` sections (features, included pieces, measurements/size guidance, care only when supplied). Do not expose supplier attribution, research logs, MCP/ability names, variation capacity, implementation phases, missing-row notes or “more sizes will be added later” in customer content.

Core SEO is one connected set: product title, slug, relevant tags, SEO/meta title, meta description and focus keyphrase. Use distinct attachment title/slug/alt for each image. Physical media filename can only be planned before upload; for an existing WordPress attachment prepare its title/permalink slug/alt without claiming the file URL was renamed.
