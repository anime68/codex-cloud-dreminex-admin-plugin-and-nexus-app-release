# Product Preparation v2 — Internal QA (never dump in normal final output)

- [ ] Verifiable original product facts only; no unsupported fabric/quality/fit/certification/stock claims.
- [ ] Short and long description use fluent, attractive, convincing and factual Bengali; long contains *all* supplied product details.
- [ ] Long description opens with exactly one small `<h3>` whose text matches the final `name` exactly, followed by the product paragraph. Details/size headings are `<h4>` when useful; no large H2, supplier attribution, research log or unsupported performance promise in customer copy/SEO. Short description has no repeated title.
- [ ] No generic seller fluff, unsupported claims, huge heading stacks or repetitive copy.
- [ ] Parent SKU is short relevant code and user-provided prefix preserved.
- [ ] Preserve an owner-supplied product title exactly (including Girls/Kids wording); change it only on the owner's instruction or a verified exact selected-site identity collision, and record that change in `pending_inputs`.
- [ ] Count every supplier screenshot. Inspect its full SKU text before a photo-only crop. One `screenshot_sku_evidence` row each, with exact raw code/leading zeroes or explicit `NOT_PRESENT` / `ILLEGIBLE` / `AMBIGUOUS`; OCR guesses are not facts.
- [ ] Inspect the selected site's recent original uploads without a title/filename filter through the relevant upload window. Do not mark originals missing from a product-keyword search or absent ability; record candidate IDs and inspect likely full images before `images: []`.
- [ ] Group alternate gallery images by confirmed sellable colour/design. Keep **every** image-level code in the ledger and matched image record; map exactly one resolved supplier code per option. Differing codes stay in `color_sku_conflicts` with screenshot references, even when the selected variation image determines one operational listing code; record the basis in `color_sku_resolution`. Distinct designs lacking a suitable option remain pending. No duplicate purchasable rows from extra photos.
- [ ] Each selectable size using a verified supplier code has unique `parent-colour-size-supplier` SKU. When ResellKori gives no colour-specific supplier code, use a unique **internal** `parent-colour-size` SKU; keep `supplier_sku:null` and never present the internal code as supplier evidence.
- [ ] Read-only exact-normalized title and exact SKU collision checks if available; status **not printed** as separate final fields.
- [ ] No invented colour×size combinations; handoff contains only confirmed offered rows. Distinct supplier codes for apparently identical colour remain separate until product grouping is confirmed.
- [ ] Final stock exactly matches user input, without extra commentary or missing quantity guess.
- [ ] Handoff `sizes[]` contains selectable strings; put exact measurements in the long-description table. Handoff stock uses `instock`, `outofstock` or `onbackorder`; preserve the owner's stated meaning.
- [ ] No visible Wholesale Price, Internal Cost Range, Gross Contribution, Delivery Payable Examples, Offered Variation Rows, combined Color Names/HEX headings or original filename.
- [ ] Read-only selected-site search for published, relevant Upsells/Cross-sells. Verify ID/SKU, status and product relationship; omit if none. Never use an unknown selling price to claim an item is a higher-value alternative.
- [ ] For Women’s sizes, verify a suitable global size taxonomy. Do not map them to `pa_for-men-size`; mark `size_attribute` pending if unavailable. Existing Men’s variation attributes remain untouched.
- [ ] Distinguish proposed standard-price candidate from suggested selling price; no fake promo / fabricated crossed-out regular price.
- [ ] Pick the best representative verified full product photo as `featured_image_index`; keep other selected originals in the gallery; log verified same-product upload IDs deliberately omitted from the gallery in `additional_media_metadata[]` and index all variation images against that order.
- [ ] Per image: filename/attachment slug (extension-free), alt, colour, HEX, optional supplier SKU, screenshot reference, visually verified same-site original attachment ID and URL or an explicit UNRESOLVED state.
- [ ] Output mode matches the owner's request: preparation context by default/when “hand-off ছাড়া” is requested; a hand-off only on an explicit request.
- [ ] In preparation-context mode, each visible field has its own fenced copy box; unresolved facts are clear; no `PUBLISHER HANDOFF` JSON or Publisher execution notes appear.
- [ ] Prefer one bounded read-only `preparation-snapshot` for selected-site catalog, SKU collision, media and related candidates; fall back to batched reads. Continue visual verification, page older uploads if needed, reuse same-product findings and revisit only unresolved/changed facts.
- [ ] In hand-off-only mode, the entire response is one self-contained valid JSON `PUBLISHER HANDOFF` code block. It has actual IDs/URLs, one resolved supplier code per sellable option plus lossless screenshot-code ledger and conflicts, relevant related IDs only when found, the selected size taxonomy, listing fields, image order, only confirmed variation rows and `pending_inputs`; no separate fields, commentary, invented links or bytes.
- [ ] Before handing off, call the selected site's read-only `dreminex-products/handoff-preflight` with the whole JSON. Resolve every `errors[]` item, compare normalized variation count/prices/image indices, and hand off only if `ready=true`. Missing original gallery images or an invalid taxonomy is a preparation blocker, even for a Draft. If preflight is unavailable, say validation is unverified rather than calling it ready.
- [ ] If a requested hand-off contains final image Title/slug/Alt and a safe shared-use finding, `update_media_metadata=true`; false is explained in `pending_inputs` as owner exclusion or shared-media conflict. Publisher owns the write and readback.
- [ ] Each distinct verified same-product upload ID appears once across `images[]` (listing) and `additional_media_metadata[]` (uploaded originals omitted from the gallery) with nonempty final `title`, `slug`, `alt`, and `metadata_write=apply` or an exact-ID documented block. No duplicate attachment IDs/slugs; image Title is separate from product name. Rebuild this ID inventory for every product; never reuse an earlier product's IDs. Publisher can execute all safe image metadata writes and the product operation in one run, then compare saved values per ID.
- [ ] No WordPress write in preparation phase.

On missing required facts, mark `—` where appropriate and keep preparing what can be grounded; publisher must be informed of actual blockers, not silently invent data.

## v1.13.68 release gate additions

- [ ] Full handoff has nonempty professional short description and complete factual long description.
- [ ] Long description starts with one exact-name H3 and contains no internal variation-limit/deferred-work note.
- [ ] Final title, slug, relevant tags, SEO title, meta description and focus keyphrase are present.
- [ ] Each colour/design appears once in `colors[]`; one representative original image is its swatch and alternate same-colour views remain in `images[]`.
- [ ] Variation rows are counted after full-matrix expansion and are within the selected site's current configured capacity.
- [ ] 44 rows or fewer use complete inline JSON; 45 or more use one complete attached JSON file and verified SHA-256 receipt.
