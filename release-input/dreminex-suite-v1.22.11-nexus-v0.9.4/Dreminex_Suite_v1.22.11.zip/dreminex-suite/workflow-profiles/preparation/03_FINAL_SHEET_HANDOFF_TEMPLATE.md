# Final Product Preparation — Conditional Output Template v2.8

> For Preparation context (default, including “hand-off ছাড়া”), use the separate fields below and omit the JSON section entirely. Copy each visible field into its **own code box**. Do not print placeholders when actual facts are missing; use `—`. No extra intro/conclusion. For an explicit hand-off request, skip every separate field below and return only the complete JSON block in the final section.

### Product Title
```text
[Final visible title]
```

### Product Type
```text
[Simple or Variable]
```

### Parent SKU
```text
[Exact prefix + short meaningful uppercase code, collision checked if accessible]
```

### Slug
```text
[lowercase-product-slug]
```

### Short Description HTML
```html
<p style="padding-inline: 10px; margin: 0 0 12px;">[Selling-friendly truthful concise product pitch]</p>
```

### Long Description HTML
```html
<h3>[Exact Product Title]</h3>
<p style="padding-inline: 10px; margin: 0 0 12px;">[Engaging truthful overview]</p>
<h4>পণ্যের বিস্তারিত</h4>
<ul><li>[Exact supplied fact]</li></ul>
<h4>সাইজ গাইড</h4>
<table><thead><tr><th scope="col">[Provided measurement]</th></tr></thead><tbody><tr><td>[Actual value]</td></tr></tbody></table>
```

### Meta Title
```text
[SEO title]
```

### Meta Description
```text
[Accurate concise SEO description]
```

### Focus Keyphrase
```text
[One natural focus keyword]
```

### Tags
```text
[Comma-separated relevant tags]
```

### Category Path
```text
[Verified taxonomy path]
```

### Brand
```text
[Verified manufacturer/garment brand or —]
```

### Product Attributes
```text
[Supplied facts only]
```

### Sizes
```text
[Supplied sizes and exact measurements]
```

### Stock Status
```text
[Exactly as supplied; e.g. Available, In stock, 20]
```

### Proposed Regular Price
```text
[Internal standard-price candidate / exact user regular]
```

### Suggested Selling Price
```text
[Recommended customer-facing price, distinct only if defensible]
```

### WooCommerce Sale Price
```text
[Owner-authorized actual sale price or —]
```

### Upsell Product IDs/SKUs
```text
[Exact verified IDs/SKUs or —]
```

### Cross-sell Product IDs/SKUs
```text
[Exact verified IDs/SKUs or —]
```

### Screenshot → Observed Supplier SKU / Read Status
```text
[Every screenshot filename: exact visible code, or NOT_PRESENT / ILLEGIBLE / AMBIGUOUS]
```

### Confirmed Colour → Supplier SKU
```text
[One resolved exact code per confirmed sellable colour/design option; list every alternate code separately and give the chosen representative image’s selection basis]
```

### Selected Size Attribute
```text
[Verified appropriate global taxonomy, e.g. pa_size, or — if none exists]
```

### Image 1 — Attachment Slug (original file name unchanged)
```text
[descriptive-hyphenated-slug-01]
```
### Image 1 — Attachment Title
```text
[Accurate image-specific media title]
```
### Image 1 — Alt Text
```text
[Image-specific accurate descriptive sentence]
```
### Image 1 — Colour
```text
[Concise visual colour/design]
```
### Image 1 — HEX
```text
#RRGGBB
```

Record every screenshot’s raw supplier SKU separately, then one resolved purchasable SKU per confirmed sellable colour/design option. Multiple views do not multiply child variations. Preserve every differing raw code and its screenshot; when views are visually confirmed as one sellable item, choose the code of the confirmed variation image (preserve the existing mapping on updates; choose a clear full/representative view on new products) and record why. If distinct designs cannot be represented, leave the mapping pending.

### Image 1 — Original Media ID (selected site)
```text
[Verified WordPress attachment ID or UNRESOLVED]
```
### Image 1 — Original Media URL
```text
[Verified same-site full URL or UNRESOLVED]
```
### Image 1 — Exact Screenshot Supplier SKU / Read Status
```text
[Exact visible code + READ, or NOT_PRESENT / ILLEGIBLE / AMBIGUOUS]
```
### Image 1 — Screenshot Reference
```text
[Input screenshot filename or sequence number with supplier code]
```
### Image 1 — Match Status
```text
[VISUALLY VERIFIED / UNRESOLVED; never infer from hash score alone]
```

Repeat for every screenshot/original. The screenshot supplies matching evidence and supplier code; the original WordPress attachment supplies listing media. Include the final Title, attachment slug and Alt text for every verified image in both normal context and an explicit hand-off. Preparation does not change them in WordPress.

### Other Supplied Original Media IDs (outside the listing gallery)
```text
[For each verified same-product upload not selected for the gallery: exact image ID and URL, final attachment Title, Slug and Alt, metadata_write action, evidence and omission reason. Use — when none.]
```

Each product starts with a fresh upload set. Reconcile **that product's supplied Media IDs**, not the ID numbers of an earlier product. Include safe gallery IDs in `images[]` and verified same-product originals omitted from the gallery in `additional_media_metadata[]`. A matching filename alone is not proof of product identity.

---

## `PUBLISHER HANDOFF` — only when explicitly requested

Give this as one valid JSON code block **instead of** the human-readable fields. Do not precede or follow it with explanatory text, headings, QA notes or extra code blocks in the actual hand-off-only response. Preparation fills the exact same-site Media IDs/URLs after visual confirmation, replaces placeholders with real values or null and records missing requirements in `pending_inputs`. The owner pastes **only this text** into Publisher; no screenshot or image file is needed. Publisher maps to the live schema without repeating research.

**Operation fields:** If the owner explicitly requested Update, set `mode` to `update` and include the exact selected-site `product_id`. For every other product hand-off, keep `product_id` null and use `mode` `draft` by default or `publish` only for an explicitly requested new-product Publish. Before a Create, check exact title and slug with `preparation-snapshot`; a verified collision requires a distinct new-product title/slug and a recorded reason, never an operation change. Keep the long-description H3 and SEO title in sync with the final name. If the check is unavailable, record `unique_name_slug_unverified` in `pending_inputs`.

Preserve the owner's supplied title unless that exact selected-site title collides or the owner requests a rename; a change to “Girls Stylish Sweatshirt Set” must not be inferred merely from the size range. Use selectable size **strings** in `sizes[]`, with measurements in the HTML table. When a supplier shows no colour-specific code, use unique internal child SKUs and `supplier_sku:null`; never invent a supplier code. Before returning the JSON, run the selected site's read-only `dreminex-products/handoff-preflight` on it. Repair every error and compare the normalized price, stock, image and variation map. If source originals cannot be found after an unfiltered recent-upload search, return the precise unresolved media state for review; do not describe a 30-row, image-less variable listing as ready.

```json
{
  "handoff_type": "PUBLISHER HANDOFF",
  "site_target": "staging",
  "site_url": "https://EXACT-SELECTED-SITE.example",
  "mode": null,
  "product_id": null,
  "supplier_source_url": null,
  "product_type": null,
  "name": null,
  "slug": null,
  "sku": null,
  "size_attribute": null,
  "color_attribute": null,
  "short_description": null,
  "description": null,
  "seo": {"title": null, "description": null, "focus_keyphrase": null},
  "category_ids": [],
  "category_names": [],
  "tags": [],
  "upsell_ids": [],
  "cross_sell_ids": [],
  "regular_price": null,
  "sale_price": null,
  "colors": [],
  "color_supplier_skus": {},
  "screenshot_sku_evidence": [],
  "color_sku_conflicts": [],
  "color_sku_resolution": {},
  "sizes": [],
  "images": [],
  "additional_media_metadata": [],
  "featured_image_index": null,
  "update_media_metadata": true,
  "variants": [],
  "full_matrix": false,
  "stock_status": null,
  "pending_inputs": ["replace this empty template with verified product facts and media IDs before publishing"]
}
```

`additional_media_metadata` contains verified product-related uploaded IDs intentionally omitted from the listing gallery, each as `{"image_id": 123, "url": "VERIFIED_SAME_SITE_URL", "title": "Final attachment title", "slug": "unique-final-attachment-slug", "alt": "Accurate image-specific description", "metadata_write": "apply", "evidence_reference": "screenshot or matching gallery ID", "omission_reason": "duplicate_upload_not_in_gallery"}`. An empty array means the supplied upload set has no verified extras. Publisher writes safe extra IDs by exact-ID `media-update` during the same requested product operation; these entries are **never** forwarded to the listing gallery. See `10_ADDITIONAL_ORIGINAL_MEDIA.md`.

Populate `images` with ordered objects such as `{"image_id": VERIFIED_ID, "url": "VERIFIED_SAME_SITE_URL", "title": "Final attachment title", "slug": "final-attachment-permalink-slug", "alt": "Accurate final image alt text", "metadata_write": "apply", "color": "Confirmed colour", "screenshot_reference": "screenshot-name", "screenshot_supplier_sku": "exact-raw-code-or-null", "sku_read_status": "READ", "match_status": "VISUALLY_VERIFIED"}`; these symbolic tokens are explanatory, not a literal JSON value. `screenshot_sku_evidence` has **exactly one row for every supplied screenshot**, even when no original matched: `{ "screenshot_reference": "01.jpg", "sku_read_status": "READ", "observed_supplier_sku": "00123", "color": "Mustard", "image_id": 123, "note": null }`. The four statuses are `READ`, `NOT_PRESENT`, `ILLEGIBLE`, `AMBIGUOUS`; `NOT_PRESENT` is used only after inspecting a readable whole screenshot. `color_sku_conflicts` preserves every differing code and screenshot whether selection was resolved or remains pending; example: `[{"color":"Mustard","codes":["21483","21492"],"screenshot_references":["1000099986.jpg","1000099995.jpg"],"resolution":"SELECTED_EXISTING_VARIATION_IMAGE","selected_supplier_sku":"21483"}]`. `color_sku_resolution` records `{ "Mustard": { "selected_supplier_sku": "21483", "selection_basis": "EXISTING_VARIATION_IMAGE_CODE", "variation_image_id": 3195, "screenshot_reference": "1000099986.jpg", "alternate_codes": ["21492"] } }` only after verifying the views show the same item. `color_supplier_skus` contains exactly one grounded choice per sellable option; differently coded images remain distinct evidence and are not sent as competing live image-level SKUs. When Publisher maps to a live schema that accepts only `images[].supplier_sku`, it repeats the **same confirmed code** for every gallery view of that colour; never send conflicting photo codes. Keep `size_attribute` pending until an appropriate global attribute is verified on the selected site. Preparation supplies actual category IDs because current Suite new Draft creation requires them. Every distinct verified Media ID has exactly one entry with nonempty final Title/Slug/Alt and `metadata_write=apply`, unless an explicit owner exclusion or unrelated shared-media conflict is documented for that ID in `pending_inputs`. These are exact attachment write values for the **same** Publisher run as the product operation, not optional suggestions. Set `update_media_metadata=true` when all IDs are safe. If one is blocked, set the bulk flag false and use exact-ID media-update for the remaining safe IDs; a bare stale false flag does not skip prepared metadata. See `09_IMAGE_METADATA_WRITE_CONTRACT.md`. Preparation itself never writes metadata. The Publisher must flag any contradictory false value rather than silently omitting supplied final metadata. The Publisher passes only **image_id**, never both ID and URL, in each live image entry. It performs technical save/readback without content or media research. Choose `featured_image_index` from the verified gallery for a clear representative full product view; retain the remaining originals in the gallery. Before output, compare the evidence count with the screenshot count and ensure **all** legible codes survive verbatim. Raw screenshot SKU/audit fields belong to the hand-off only; Publisher must not pass them as contradictory live image-level supplier codes. Only confirmed offered rows with grounded SKU resolution go into `variants`; an unresolved option remains a precise Draft blocker rather than a silently blank child SKU. With selectable sizes, unique child SKUs are the existing internal `parent-colour-size` plus `-supplier-code` when a verified screenshot code exists; without a verified code, do not invent a supplier-linked child SKU. For existing product updates, omit `upsell_ids` and `cross_sell_ids` if none were verified so saved links survive; on new listings empty arrays are fine. Preparation never writes to the site.

### Optional Supplier Monitor source

If the owner supplied an exact ShopBaseBD or ResellKori product URL, include it as `supplier_source_url`. Otherwise use `null` or omit it. Publisher connects it after the listing save and verifies the exact product ID; source-link errors are reported separately and do not block the product listing. Never include supplier credentials.

### Scoped description-only handoff
When the owner explicitly asks to revise only the descriptions of an existing listing, a compact `PUBLISHER HANDOFF` with `scope: "short_description_and_description_only"` can contain `site_target`, `product_id`, `product_name`, `short_description` and `description`. Include exact site and ID if WordPress execution is requested; if unknown, keep them null, return the corrected copy and state the missing target in `pending_inputs`. The long description begins with `<h3>[exact product_name]</h3>` and uses H4 subheadings. Publisher performs only an exact-ID `listing-update` of those two HTML fields; it must not treat the scoped handoff as a full product create/publish.
