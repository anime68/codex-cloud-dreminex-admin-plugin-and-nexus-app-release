# Handoff capacity, JSON file delivery ও lossless variation rule

## দুইটি আলাদা limit

1. **Preparation chat delivery:** 44 variation row পর্যন্ত inline JSON; 44-এর বেশি হলে attached `.json` file। এটি chat truncation এড়ানোর নিয়ম।
2. **Selected WordPress site capacity:** `dreminex-products/listing-defaults` বা `handoff-preflight` থেকে current `variation_capacity.configured_limit` পড়বে। Default 64, dashboard থেকে 1–564, hard maximum 564। এটি product save capacity।

File বানালেই site capacity bypass হয় না। যেমন attached handoff-এ 200 row থাকলেও selected site limit 144 হলে Preparation `pending_inputs`-এ exact capacity blocker রাখবে এবং Publisher preflight `ready=false` দেবে।

## JSON file contract

- UTF-8, extension `.json`, one complete root object, valid JSON syntax।
- Root-এ `handoff_type: "PUBLISHER HANDOFF"`, exact `site_url`, `mode`, `product_id`, complete listing fields ও all rows থাকবে।
- File receipt-এ SHA-256, exact row count, site এবং mode থাকবে।
- Publisher attached file-এর content parse করে একই read-only preflight চালাবে; receipt-কে handoff হিসেবে apply করবে না।
- 44-row boundary tests: 44 inline, 45 file।

## Image swatch rule

প্রতি confirmed colour/design-এর `colors[]` entry একটিই হবে এবং তার `swatch_image_index` একই colour-এর একটি representative original product image-এ যাবে। একই colour-এর অন্য verified views বাদ যাবে না; ordered `images[]` gallery-তে থাকবে। Screenshot/SKU panel swatch হবে না। Image না থাকলেই verified HEX `mode: "color"` fallback।
