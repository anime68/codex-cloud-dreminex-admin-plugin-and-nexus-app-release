# Dreminex Suite 1.13.5 — আলাদা প্রোডাক্ট লিস্টিং

বিদ্যমান Suite plugin Update/Replace করুন; uninstall করবেন না। আগে backup রাখুন। Staging-এ মডিউল চালু ও abilities যাচাই করুন, তারপর একই ZIP main site-এ ব্যবহার করতে পারবেন। PWA আলাদা।

**ChatGPT-তে পূর্ণ product listing:** Novamira connection থেকে `dreminex-products/catalog` দিয়ে exact slug/SKU যাচাই, `media-find` বা `media-batch-upload` দিয়ে আসল ছবির ID, তারপর populated fields সহ `dreminex-products/draft-complete`। `name`, category ID, image ID, price, description, color/HEX, size এবং প্রয়োজনীয় variation rows দিন। Product তৈরির পর `product-read` দিয়ে প্রকৃত status/link যাচাই করুন। সম্পূর্ণ listing-এর জন্য generic `woocommerce/product-create`-এ `payload` wrapper বা খালি completion request পাঠাবেন না; সেই tool-এর schema category/media/variation নেয় না। `INVALID_ARGUMENT` হলে সঠিক ability ও schema দিয়ে কাজ চালিয়ে যান।

একই রঙ/সাইজের existing variation আলাদা product URL নয়। ব্যবহারকারী আলাদা listing চাইলে exact requested name/SKU/slug-এর product post আছে কি না যাচাই করুন; existing variation-এর image ID ও verified facts পুনর্ব্যবহার করা যায়, কিন্তু variation-কে নতুন listing বলে রিপোর্ট করা যায় না।

একটি রঙের S–XXL প্রতিটি সাইজ গ্রাহককে বেছে নিতে দিতে হলে WooCommerce-এ সেটি **Variable product**, পাঁচটি real size variation সহ। এই Suite-এ **Simple product** একটি রঙ ও একটি purchasable size নেয়। ব্যবহারকারী Simple এবং একাধিক selectable size একসাথে চাইলে কোনো ধরনের ভুল checkout/publish না করে একবার এই অপরিহার্য সিদ্ধান্তটি জানতে হবে। সাইজ কেবল বর্ণনামূলক হলে একটি নির্দিষ্ট purchasable size দিয়ে Simple করা যায়।

SKU বা stock সংখ্যা না দিলে default অনুযায়ী এগোন; মিথ্যা সংখ্যা বানাবেন না। সফল হলে শুধু product name, প্রকৃত Draft/Published status এবং সরাসরি link জানান। মূল ছবির bytes না থাকলে private chat preview নিজে থেকে Media Library-তে যায় না। ChatGPT popup timeout সেটিংটি compatible MCP App UI-এর জন্য advisory।
