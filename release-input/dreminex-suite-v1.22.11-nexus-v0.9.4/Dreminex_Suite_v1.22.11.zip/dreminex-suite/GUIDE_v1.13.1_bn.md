# Dreminex Suite 1.13.1 — Storefront Design

## ইনস্টল

Staging-এ backup রেখে বিদ্যমান Dreminex Suite আপডেট করুন। পুরোনো plugin uninstall করবেন না। **Dreminex Suite → All Modules → Storefront Design → Turn on module** চালু করুন। তারপর ওই মডিউলের dashboard-এ Categories/Tags/Brand, Colour/Size, Descriptions, Titles এবং Mobile cart আলাদাভাবে চালু/বন্ধ ও পরিমাপ সেট করে Save করুন। ডিফল্টে প্রথম ৪টি tag দেখা যায়; বাকিগুলো Show more tags-এ থাকে।

Suite 1.13.1 চালু করে যাচাই করার পর Dreminex PWA 1.3.4 আপডেট করুন। PWA-তে শুধু app install, standalone zoom setting ও notification থাকে; storefront-এর design Suite মডিউল থেকে আসে। PWA না থাকলেও Suite-এর style browser ও Quick View-এ কাজ করে।

## যাচাই ও main site

একটি variable product-এর single page এবং Quick View-তে category, tag, brand, colour, size, add-to-cart দেখুন। Mobile cart-এ একাধিক পণ্য রেখে quantity, line total, shipping ও grand total স্ক্রিনের মধ্যে আছে কি না যাচাই করুন। CSS/JS cache purge করুন। যদি main site-এর Additional CSS-এ পুরোনো তিনটি `Dreminex single product full description scroll panel`, `Dreminex Quick View short description card`, `Dreminex product title typography` ব্লক থাকে, Suite-এর ফল যাচাই করে কেবল ওই duplicate ব্লকগুলো সরান। অন্য CSS স্পর্শ করবেন না।

এই আপডেট পণ্যের data বা Elementor template সংরক্ষিত JSON বদলায় না। পুরোনো short-description widget-যুক্ত product template-এ render-এর সময় full-description widget ব্যবহৃত হয়, যদি product-এর long description থাকে। Style module বন্ধ করলে rendering replacement ও style দুটোই বন্ধ হয়। পৃথক feature switch বন্ধ করলে ওই অংশের CSS/JS বন্ধ হয়। WooCommerce cart/ShopBuilder markup ভিন্ন হলে মোবাইলে আবার যাচাই দরকার।
