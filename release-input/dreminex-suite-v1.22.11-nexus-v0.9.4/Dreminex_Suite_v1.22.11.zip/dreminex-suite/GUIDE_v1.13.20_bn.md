# Dreminex Suite 1.13.20 — Customer pages

## পরিবর্তন

- `Dreminex Suite → All Modules → Storefront Design → Customer pages`-এ page heading, archive filter, cart/checkout/tracking, wishlist/compare ও Contact placeholder-এর আলাদা switch আছে। বিদ্যমান setting ও module state update-এর সময় বজায় থাকে।
- Shop ও product category-তে ফাঁকা Size এবং শূন্য-result rating filter লুকায়; data থাকলে filter স্বাভাবিকভাবে দেখা যায়। Product list ও breadcrumb-এর presentation সাজানো হয়েছে। Theme-এর demo “Shop Page” heading-কে Shop করা যায়।
- Cart-এর empty state, native notice, totals, Checkout field ও order tracking form-এ responsive design। Cart/checkout data ও form action WooCommerce/ShopBuilder-এরই থাকে।
- পুরোনো Elementor `[dreminex_saved_lists]` page-এ active ShopBuilder wishlist/compare content render হয়। Contact page-এর নির্দিষ্ট theme demo phrase output থেকে সরানো হয়; page content database-এ অপরিবর্তিত।

## Update ও পরীক্ষা

আগের `dreminex-suite` plugin-এর উপর ZIP update দিন; uninstall/delete করবেন না। আগে backup রাখুন। Staging-এ Shop, product category, product, Wishlist, Compare, Contact, Cart (খালি ও product সহ), Checkout, Track order এবং signed-in My Account পরীক্ষা করুন। ফোন ও desktop-এ horizontal overflow, button action, filter ফলাফল, cart calculation এবং checkout validation দেখুন। Test payment ছাড়া live order submit করবেন না।

Main site-এর বর্তমান WooCommerce/ShopBuilder/theme version staging-এর সঙ্গে মিললেও site data, cache ও payment setup আলাদা। Production update ও smoke test আলাদা release ধাপ।
