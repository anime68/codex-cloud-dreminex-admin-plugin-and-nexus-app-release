# Dreminex Suite 1.14.0 + Dreminex Nexus 0.1.0 — Install ও ব্যবহার

## Update করার আগে

1. বর্তমান `dreminex-suite` plugin এবং database backup রাখুন।
2. Plugin delete/uninstall করবেন না; ZIP দিয়ে existing plugin replace/update করুন।
3. প্রথমে staging-এ করুন। Production আলাদা approval ছাড়া update করবেন না।

## Suite setup

1. **Dreminex Suite → All Modules** থেকে `Native MCP` এবং `Supplier Monitor` On করুন।
2. **Dreminex Suite → Native MCP**-এ endpoint, HTTPS ও diagnostics দেখুন।
3. Connections-এর নতুন external client default Sandbox। দরকার অনুযায়ী scopes consent এবং permission mode দিন।
4. **Products → Supplier Monitor**-এ built-in platforms, mappings, jobs, results, devices এবং settings দেখুন।

## Nexus phone pairing

1. APK Android 8.0/API 26 বা নতুন ফোনে install করুন।
2. App-এ exact staging HTTPS URL দিন।
3. দেখানো code-এর **Open approval page** চাপুন, WordPress account-এ login করে code approve করুন।
4. App connected হলে Platforms থেকে supplier credentials encryptedভাবে save করুন বা Browser login ব্যবহার করুন।
5. Settings থেকে `Any`, `Wi-Fi only` বা `Mobile Data only` ঠিক করুন। Required network না থাকলে scan অন্য network-এ যাবে না।

## Product mapping ও scan

1. Supplier Monitor → Product mappings থেকে WooCommerce product ID, platform ও exact supplier product URL save করুন।
2. `Queue phone scan` বা app-এর `Queue due products & scan` ব্যবহার করুন।
3. Phone online হলে job claim করবে। Activity এবং WordPress Jobs/Results-এ result দেখুন।
4. Supplier change শুধু review alert/proposal তৈরি করবে। Existing approval ছাড়া WooCommerce price, stock, colour বা size বদলাবে না।

## Login protection

Valid session থাকলে Nexus আবার login করবে না। Session expire হলে due scan-এর মধ্যে একবার login করবে। Failed login-এর পরে ২৪ ঘণ্টা cooldown; restricted account owner Resume না করা পর্যন্ত বন্ধ। Credential/cookie WordPress-এ পাঠানো হয় না।

## Custom platform

Platforms tab-এ custom ID, name, exact domains, product URL regex, login URL/mode এবং CSS selectors দিন। প্রথমে inactive রেখে Nexus phone-এ login ও test করুন, তারপর active ও product mapping করুন। Arbitrary code paste করবেন না।

## Rollback

1. Supplier/Nexus manual scans pause করুন।
2. Pre-update Suite ZIP দিয়ে plugin replace করুন; plugin uninstall করবেন না।
3. 1.14.0-এর additive Nexus/OAuth tables রেখে দিলেও পুরোনো code ব্যবহার করবে না। Delete দরকার হলে verified backup-এর পরে আলাদা cleanup procedure নিন।
4. Product/order data ও existing module options readback করুন।

পূর্ণ maintenance rules চারটি A-to-Z reference file-এ আছে।
