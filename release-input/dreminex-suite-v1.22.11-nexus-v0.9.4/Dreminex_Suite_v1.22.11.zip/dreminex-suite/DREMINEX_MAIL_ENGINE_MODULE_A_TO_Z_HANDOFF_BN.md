# Dreminex Mail Engine — A to Z Reference

**Suite version:** 1.19.0  
**Module location:** `modules/dreminex_mail_engine.php`  
**Admin location:** `Dreminex Suite → Mail Engine`

## এই module কেন আছে

এই module WordPress-এর mail delivery-কে একটি controlled জায়গা থেকে দেখার ও চালানোর জন্য। শুরুতে এটি **off** থাকে এবং চালু করলেও default mode **Monitor only**। তাই install বা update হওয়ার পরে কোনো customer mail route বদলে যায় না।

এটি Nexus Android বা Windows app-এর feature না। Mail provider, queue, test এবং bot control শুধু WordPress admin থেকেই manage হবে।

## চালু হওয়ার আগে যা লাগবে

`wp-config.php`-এ server-side একটি 32+ character secret দিতে হবে:

```php
define('DREMINEX_MAIL_ENGINE_KEY', 'replace-with-a-unique-server-side-secret');
```

এই key database-এ রাখা হয় না। Key না থাকলে transport password/API key encrypt করা যায় না এবং queue/immediate delivery সক্রিয় হবে না। উদাহরণের secret ব্যবহার করা যাবে না।

Recognized SMTP plugin যেমন Easy WP SMTP, WP Mail SMTP, Post SMTP, FluentSMTP অথবা Gmail SMTP চালু থাকলে Mail Engine সেটি বন্ধ বা বদলাবে না। Queue/immediate takeover আটকে থাকবে। আগে administrator নিজে একটি delivery owner বেছে নেবেন।

## Mode কীভাবে কাজ করে

| Mode | কী হয় |
| --- | --- |
| Disabled | module settings থাকে, কোনো capture হয় না |
| Monitor only | configuration/diagnostic দেখা যায়, কোনো mail payload capture বা delivery takeover হয় না |
| Encrypted queue | eligible WordPress mail encrypted queue-তে যায়; worker retry policy দিয়ে পাঠায় |
| Immediate transport | eligible mail explicit transport দিয়ে পাঠানো হয় |

Provider response `accepted` মানে provider request গ্রহণ করেছে। এটি inbox delivery, open বা customer পড়েছে এমন প্রমাণ নয়।

## Transport

- **WordPress mail:** current WordPress mailer ব্যবহার করে।
- **SMTP:** host, port, TLS/SSL choice, username এবং password দিয়ে explicit PHPMailer transport। Username/password encrypted থাকে।
- **Resend / Brevo / SMTP2GO:** API key write-only encrypted value হিসেবে রাখা হয়।

Transport ID একই দিলে সেটির configuration replace হবে। Password/API key বা SMTP username ফাঁকা রাখলে আগে encrypted value থাকলে সেটিই থাকে। Dashboard কখনও saved secret দেখায় না।

## Queue ও retry

প্রতিটি message UUID, recipient hash, encrypted payload, transport, attempt count এবং status পায়। Worker lease নিয়ে কাজ করে; crash হলে expired lease queue-তে ফেরত যায়। Retry delay bounded exponential backoff। maximum attempts শেষ হলে message `failed` হয়।

Recipient suppression record থাকলে সেই recipient queue-তে যায় না। এটি promotional/complaint suppression integration-এর জন্য table-ready design; provider webhook যোগ করলে event/suppression source আলাদা adapter-এ যোগ করতে হবে।

## Contact form bot control

Contact request write হওয়ার আগে Mail Engine adapter honeypot, minimum completion time, IP 10-minute/24-hour rate, email hourly rate এবং duplicate message rate দেখে। Module enabled হলে legacy contact limiter আর দ্বিতীয়বার hit করে না। Block হলে request database-এ লেখা হয় না।

`dme_bot_events`-এ raw IP/email নয়, keyed hashes রাখা হয়। retention period admin settings থেকে বদলানো যায়।

## Tables

- `dme_messages` — encrypted queue status ও lease
- `dme_recipients` — hashed/masked recipients
- `dme_events` — queue and transport events
- `dme_suppressions` — no-send records
- `dme_rate_limits` — bot/rate buckets
- `dme_bot_events` — contact guard decisions
- `dme_daily_stats` — future aggregate reporting

সব table additive migration-এ তৈরি হয়। Module off করলে existing ledger/queue delete হয় না।

## Admin workflow

1. Existing mail owner/conflict check করুন।
2. Server key set হয়েছে নিশ্চিত করুন।
3. From email/domain ঠিক করুন।
4. এক transport add করুন কিন্তু mode আগে Monitor রাখুন।
5. Explicit test recipient দিয়ে test করুন।
6. Accepted result ও provider dashboard verify করুন।
7. তারপর প্রয়োজন হলে Queue বা Immediate mode চালু করুন।

## Update করার নিয়ম

1. `mail_engine.php` পরিবর্তনের আগে current module mode ও queue status note করুন।
2. New provider add করলে secret plaintext response, logs, REST বা diagnostics-এ কখনও দেবেন না।
3. Queue schema বদলালে additive migration দিন; old queued item decrypt/read করা যায় কিনা test করুন।
4. `pre_wp_mail` hook পরিবর্তন করলে conflict guard, dispatch recursion guard এবং attachment fallback রাখুন।
5. Contact guard বদলালে contact module-এর legacy limiter একবারের বেশি run করছে না verify করুন।
6. PHP lint, focused queue/guard contract test, staging Monitor-mode validation চালান। Provider secret ছাড়া actual provider delivery test claim করা যাবে না।

## Rollback

Mode `Monitor only` অথবা `Disabled` করলে নতুন capture বন্ধ হয়। Existing queue inspection-এর জন্য রেখে দেওয়া যায়; mailbox provider বা unrelated SMTP plugin পরিবর্তন হয় না.
