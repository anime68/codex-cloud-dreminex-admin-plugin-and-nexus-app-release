# Dreminex Security Center — A to Z Handoff, Review ও Update Workflow

Suite 1.20.0-এর Security Center হলো সবসময় লোড হওয়া site protection service। এর dashboard Dreminex Nexus app-এর Security tab-এ। WordPress-এ আলাদা module toggle লাগে না; contact form bot protection এবং login rate limit default-এ চালু থাকে।

## এটি কী আটকায়

1. **Contact form spam:** honeypot field পূরণ, খুব দ্রুত submit, বেশি URL/link, একই email-এর সীমা, একই network-এর burst/daily limit এবং একই email-এর একই message পুনরাবৃত্তি। Mail Engine চালু থাকুক বা বন্ধ থাকুক, Security Center form submit আটকে দেয়। Mail Engine চালু থাকলে তার নিজস্ব দ্বিতীয় guard-ও চলতে পারে।
2. **WordPress login brute force:** নির্দিষ্ট সময়ের মধ্যে ব্যর্থ login threshold পার হলে সেই network-এর login সাময়িক lock হয়। Valid user password, order বা customer record-এ কোনো পরিবর্তন হয় না।
3. **ঐচ্ছিক XML-RPC block:** XML-RPC endpoint বন্ধ করে। Jetpack বা পুরোনো WordPress client ব্যবহার করলে এই switch Off রাখুন।
4. **Response headers:** `X-Content-Type-Options` এবং `Referrer-Policy` যোগ করে। CSP বা HSTS জোর করে না, কারণ এগুলো payment/embedded page ভাঙতে পারে বা hosting HTTPS setup দরকার হতে পারে।

## Nexus app-এ কী দেখা যায় ও কী করা যায়

- Protection state এবং HTTPS/contact/login/headers check.
- গত ২৪ ঘণ্টায় blocked contact request এবং login event-এর মোট attempt.
- সাম্প্রতিক ৫০টি event-এর source, কারণ, সময় এবং একই event bucket-এর occurrence count.
- Contact form timing/rate/link limit, login threshold/lock duration, XML-RPC switch এবং event retention.
- আগের Daily Action Center-এর order queue, inventory attention, supplier alerts, নতুন contacts ও incomplete checkout count একই Security screen-এ দেখা যায়। প্রতিটি card চাপলে সংশ্লিষ্ট Orders, Products, Supplier, Contacts বা Checkout workspace খুলে সেখানকার record review/update করা যায়। আলাদা Action Center tab, feature switch বা Native MCP ability আর নেই।
- Security activity থাকলে app notification একেক event-type-এর জন্য সর্বোচ্চ ১৫ মিনিটে একবার পাঠানো হয়। সব event history dashboard-এ থাকে।

Security tab app-এর আগের Projects navigation slot-এ। Notifications আলাদা alert হিসেবে header bell এবং More → Alerts-এ পাওয়া যায়। প্রতিটি setting শুধু নির্বাচিত connected site-এর জন্য সেভ হয়।

## Settings-এর default ও সীমানা

| Setting | Default | Allowed range | কী করে |
|---|---:|---:|---|
| Contact bot protection | On | On/Off | Contact submission-এর সব anti-bot check চালায় |
| Minimum form time | 3 sec | 1–15 sec | এর আগে submit এলে block করে |
| Contact burst limit | 5 / 10 min | 1–20 | একই network-এর ছোট সময়ে repeated submit সীমা |
| Contact daily limit | 20 / day | 1–100 | একই network-এর দৈনিক form submit সীমা |
| Per-email limit | 3 / hour | 1–10 | একই normalized email-এর repeated request সীমা |
| Message links | 1 | 0–10 | এর বেশি URL থাকলে block করে |
| WordPress login protection | On | On/Off | `wp-login.php` sign-in এ rate limit প্রয়োগ করে |
| Failed login threshold | 10 / 15 min | 3–30 | threshold-এ temporary lock তৈরি হয় |
| Login lock | 15 min | 5–120 min | threshold-এর পর ঐ network-এর login বিরতি |
| XML-RPC protection | Off | On/Off | On করলে XML-RPC access বন্ধ হয় |
| Security response headers | On | On/Off | দুটি safe response header যোগ করে |
| Event retention | 30 days | 7–90 days | Cron cleanup event এবং stale rate bucket সরায় |

Network বলতে web server-এর নির্ভরযোগ্য `REMOTE_ADDR` বোঝায়। Reverse proxy/CDN-এর সামনে server proxy address দিলে সেটি বহু customer-এর একই address হতে পারে; তখন Nexus-এ per-network limits বাড়িয়ে দিন অথবা hosting-এর trusted-proxy/client-IP setup ঠিক করুন। App arbitrary `X-Forwarded-For` header-কে বিশ্বাস করে না, কারণ client সেটি spoof করতে পারে।

## Data ও privacy

- Table: `{prefix}dreminex_security_events` এবং `{prefix}dreminex_security_rates`.
- IP ও email value salted HMAC করে rate bucket বানানো হয়; raw IP, raw email, password, submitted contact message বা arbitrary request body event log-এ লেখা হয় না।
- একই event type/source/reason/pseudonymous source প্রতি ১৫ মিনিটে এক row হয়, occurrence count বাড়ে। Dashboard event list-এ pseudonymous actor hash ফেরত যায় না।
- Daily cleanup setting অনুযায়ী event row মুছে; rate buckets দুই দিনের বেশি থাকলে মুছে।
- Security Center event table 30-day default retention-এর বেশি নিজে ধরে রাখে না।

## REST, authorization ও Native MCP

- `GET /wp-json/dreminex/v1/nexus/security`: status, checks, bounded settings, recent events এবং `operations_summary` (pending/on-hold/ready-to-ship order count, supplier alerts, new contacts, inventory attention, partial checkout).
- `PUT /wp-json/dreminex/v1/nexus/security`: bounded settings সেভ করে এবং readback ফেরত দেয়.
- পুরোনো installed Nexus build-এর জন্য authenticated `GET /wp-json/dreminex/v1/nexus/action-center` route রাখা হয়েছে; এটি একই summary দেয়। নতুন app এই route ব্যবহার করে না।
- Schema 2 migration পুরোনো `action_center` notification category ও `operations/action-center` screen route-কে `security`-এ বদলায়; notification row বা order/customer data delete করে না।
- Suite schema 5 migration পুরোনো Action Center on/off switch সরায়, যাতে module status-এ আর retired module না আসে। পুরোনো module settings/activity record রেখে দেয়; order, supplier, contact ও checkout data স্পর্শ করে না।
- `dreminex-system/module-status-read` কেবল `Dreminex_Suite::catalog()`-এর বর্তমান module list ফেরায়, raw legacy option নয়।
- Nexus device OAuth-এর existing `settings:read` / `settings:write` scope ব্যবহার করে; site token-এ নতুন scope যোগ বা reconnect দরকার হয় না। Site/device binding এবং capability enforcement আগের Nexus authorization layer-এ থাকে।
- Native MCP abilities: `dreminex-security/dashboard-read` এবং `dreminex-security/policy-update`. Registry policy read-এর জন্য `settings:read`, write-এর জন্য `settings:write` এবং `manage_options` capability চায়। নতুন ability JSON policy-তে থাকবে এবং default-deny নিয়মে explicitly enable না করলে Native MCP-তে expose হবে না।

## Code map

| Path | দায়িত্ব |
|---|---|
| `includes/class-dreminex-security-center.php` | schema, defaults, contact/login guards, XML-RPC/header controls, event summary, MCP abilities |
| `modules/dreminex_contact_requests.php` | form submit-এ shared contact guard call; security class থাকলে legacy raw-IP fallback এড়িয়ে যায় |
| `includes/class-dreminex-suite.php` | Security Center সবসময় boot করা |
| `includes/class-dreminex-nexus-app.php` | authenticated Nexus API, Security-এর integrated operations summary, legacy read-only API alias, notification migration/deep links |
| `includes/class-dreminex-mcp-registry-policy.php` | security abilities-এর scope/capability mapping |
| `data/native-mcp-abilities-v2.json` | default-deny Native MCP ability contract |
| Android `data/Models.kt`, `network/NexusApi.kt`, `NexusViewModel.kt` | typed Security + operations API, per-site state, refresh/save, old notification routing |
| Android `MainActivity.kt` | Security dashboard, operation queue cards/deep links, settings form, event cards, alerts filter; no standalone Action Center panel |
| `tests/test-security-center.php` | honeypot, timing, link, contact burst, login lock এবং settings bound regression |

## Update workflow

1. `Security Center`, Suite full-plugin, Nexus Android এবং Native MCP reference আগে পড়ুন।
2. Defaults পরিবর্তন করলে false positive/shared-IP scenario এবং Contact Requests-এর customer message flow পরীক্ষা করুন।
3. Event বা notification schema বদলালে `SCHEMA` বাড়িয়ে `dbDelta` migration additive ও repeat-safe রাখুন; raw IP/content যোগ করবেন না।
4. REST schema বদলালে PHP route, `Models.kt`, `NexusApi.kt`, Android UI, OAuth scope and Native MCP allowlist একসাথে update করুন। Existing `settings:*` scope পুনঃব্যবহার করতে নতুন scope/app reconnect তৈরি করবেন না।
5. PHP lint, সব PHP tests, cross-project contracts, Android unit tests/debug build চালান।
6. Release ZIP root structure/checksums update করুন। Staging test করতে হলে active Suite version, Security `operations_summary` readback বনাম Orders/Contacts/Supplier/Checkout views, settings save/readback, legacy notification migration, contact guard এবং login lock evidence capture করুন।
7. App-এর 360–420dp phone width-এ Security top-to-bottom scroll, seven operation cards, tap destinations, event list, slider/save state এবং bottom navigation screenshot/visual QA করুন।
8. Staging deployment বা production rollout আলাদা অনুমোদন ছাড়া করবেন না; source build pass-কে live-site proof হিসেবে লিখবেন না।

## Scope limit ও rollback

এটি WordPress application-layer protection। Distributed volumetric DoS, hosting exploit, stolen admin credential, malware cleanup বা CDN/WAF configuration এর মধ্যে নেই। Large attack-এর জন্য host/CDN firewall লাগতে পারে। False positive হলে app-এ contact/login limits tune করুন বা relevant protection toggle Off করুন। Plugin issue হলে আগের Suite ZIP ফিরিয়ে দিন; এই update existing contact rows delete করে না।
