# Dreminex Suite 1.13.43 — Storefront desktop UI

এই রিলিজে কেবল **Dreminex Suite → Storefront Design** মডিউলে ডেস্কটপ পণ্যের কার্ড ও Quick View-এর নিয়ন্ত্রণ যোগ হয়েছে। Newsletter & Offers এবং Supplier Monitor আলাদা মডিউল; এই পরিবর্তনে তাদের কোনো সেটিং, ডেটা বা আচরণ বদলায় না। WooCommerce পণ্য, মূল্য, অর্ডার, checkout ও delivery settings-ও অপরিবর্তিত।

## Storefront Design-এ কী পাওয়া যাবে

- **Shop and related product cards**: Shop, category এবং product recommendation grid-এ ডেস্কটপ কার্ডের সূক্ষ্ম ধূসর ব্যাকগ্রাউন্ড। এটি হোমপেজে দেখা `#DEE2E6` রঙের সঙ্গে মেলে।
- **Desktop Quick View layout**: পণ্যের ছবি ও বিবরণ দুই কলামে দেখায়; জানালার উচ্চতা ছাড়িয়ে গেলে মডালের ভেতরে স্ক্রল হয়।
- **Desktop product surfaces**: কার্ডের রঙ, corner radius, ভেতরের spacing, Quick View-এর সর্বোচ্চ প্রস্থ ও কলামের gap এবং ছবির চারপাশের পটভূমি পরিবর্তন করা যায়। রঙের ইনপুট HEX-এ সীমাবদ্ধ, আর সংখ্যাগত মান নির্দিষ্ট নিরাপদ সীমায় সীমাবদ্ধ।
- দুইটি বৈশিষ্ট্য আলাদা checkbox দিয়ে বন্ধ/চালু করা যায়। 768px-এর কম স্ক্রিনে নতুন CSS কোনো পরিবর্তন করে না।
- 1.13.42-এ ShopBuilder-এর আসল archive card structure (`rtsb-grid-item`) লক্ষ্য করে selector ঠিক করা হয়েছে। এতে card-এর content panel আর plugin-এর আগের white override দিয়ে configurable card colour ঢেকে রাখে না।
- 1.13.43-এ Quick View-এর RTWPVG gallery এবং description-এর ভেতরের wrapper-গুলোকে তাদের দুই কলামের পুরো জায়গা দেওয়া হয়েছে; ছবির gallery ও লেখা আর সরু কলামে আটকে থাকবে না।

## প্রস্তাবিত মান

| সেটিং | ডিফল্ট |
|---|---:|
| Product card background | `#DEE2E6` |
| Product card corners | 16px |
| Product card inner space | 14px |
| Quick View maximum width | 1200px |
| Quick View column gap | 24px |
| Quick View image ground | `#F8F9FA` |

## Release / rollback

- প্রথমে staging-এ Suite 1.13.43 update করে shop/category archive, product-detail recommendation এবং Quick View পরীক্ষা করুন। এরপর production-এ একই ZIP install করুন। Plugin মুছে নতুন করে install করবেন না; এতে বর্তমান WordPress options ও module state সংরক্ষিত থাকে।
- ব্যবহারকারী জানান restore point নেওয়া আছে। কোনো অসঙ্গতি হলে আগের Suite package/restore point ব্যবহার করে rollback করুন। PWA 1.3.7, Newsletter & Offers, Supplier Monitor settings এবং কোনো পণ্যের মূল্য বদলানোর প্রয়োজন নেই।

