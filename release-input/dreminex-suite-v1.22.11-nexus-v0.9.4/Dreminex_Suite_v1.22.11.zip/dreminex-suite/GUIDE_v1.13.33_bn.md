# Dreminex Suite 1.13.33 — Storefront colour code

WordPress Admin → Dreminex Suite → All Modules → Storefront Design → Appearance → **Storefront accent colour**।

এখন code box-এ যেকোনো বৈধ opaque HEX রং লিখতে পারবেন: যেমন `#00B4D7`, `#252525`, `#ABC`। `#` ছাড়া লিখলেও সেভের সময় যোগ হবে। পাশের colour picker দিয়েও বেছে নেওয়া যায়। ভুল code দিলে সেটিংস সেভ হবে না; আগের রং বজায় থাকবে।

সেভ করলে Storefront Design module চালু থাকা অবস্থায় product-এর swatch/size/quantity accent, module-এর link/focus, Shop hover, description scrollbar, Cart/Checkout/tracking action ও saved-list action একই accent অনুসরণ করবে। উজ্জ্বল ও গাঢ় রঙে button text এবং link-এর readable shade স্বয়ংক্রিয়ভাবে নেওয়া হয়। Theme, Elementor, PWA ও Homepage Studio-র নিজস্ব colour setting এই control পরিবর্তন করে না। সাইটে cache থাকলে purge করে product, Shop, Cart ও Checkout আবার দেখুন।

Plugin update আগের Suite-এর ওপর দিন; plugin uninstall করবেন না। এই release-এ database বা product data migration নেই। প্রয়োজনে আগের 1.13.32 ZIP দিয়ে rollback করুন।
