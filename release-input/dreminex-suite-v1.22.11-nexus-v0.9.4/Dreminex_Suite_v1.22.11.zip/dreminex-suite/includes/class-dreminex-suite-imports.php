<?php
if(!defined('ABSPATH'))exit;
final class Dreminex_Suite_Imports {
 private static $loading='';
 public static function all(){return (array)get_option('dreminex_suite_imported_modules',[]);}
 public static function root(){
  $document=realpath($_SERVER['DOCUMENT_ROOT']??'');$install=realpath(ABSPATH);
  $base=$document&&$install&&($install===$document||str_starts_with($install,$document.'/'))?dirname($document):dirname(ABSPATH);
  return $base.'/dreminex-suite-imports/'.substr(hash('sha256',ABSPATH),0,12);
 }
 public static function boot() {
  add_action('admin_menu',[__CLASS__,'menu'],34);
  add_action('admin_post_dreminex_suite_import',[__CLASS__,'upload']);
  add_action('admin_post_dreminex_suite_import_control',[__CLASS__,'control']);
  add_action('wp_ajax_dreminex_import_asset',[__CLASS__,'asset']);
  add_action('wp_ajax_nopriv_dreminex_import_asset',[__CLASS__,'asset']);
  register_shutdown_function([__CLASS__,'fatal']);
  foreach(self::all() as $key=>$item) {
   if(empty($item['enabled']))continue;
   $bad=false;foreach($item['hashes'] as $file=>$hash){$path=$item['path'].'/'.$file;if(!is_file($path)||is_link($path)||hash_file('sha256',$path)!==$hash){$bad=true;break;}}
   if($bad){self::fail($key,'Imported module files changed or are missing. Reimport a reviewed package.');continue;}
   if(!class_exists('WooCommerce'))continue;
   try {
    self::$loading=$key;$factory=require $item['path'].'/'.$item['manifest']['entry'];
    if(!is_callable($factory))throw new RuntimeException('Entry must return a callable module factory.');
    $defaults=[];foreach($item['manifest']['settings']??[] as $name=>$field)$defaults[$name]=$field['default']??'';
    $before=(array)($GLOBALS['shortcode_tags']??[]);
    $factory(['cache_get'=>static fn($name)=>Dreminex_Suite_Cache::get($key,$name),'cache_set'=>static fn($name,$value,$ttl=300)=>Dreminex_Suite_Cache::set($key,$name,$value,$ttl),'cache_changed'=>static fn($public=false)=>Dreminex_Suite_Cache::changed($key,$public),'nocache'=>[Dreminex_Suite_Cache::class,'nocache'],'id'=>$key,'settings'=>array_merge($defaults,(array)get_option('dreminex_import_settings_'.$key,[])),'path'=>$item['path'],'store_name'=>Dreminex_Suite_Setup::brand(),'accent'=>Dreminex_Suite_Setup::accent()]);foreach((array)($GLOBALS['shortcode_tags']??[]) as $tag=>$callback)if(!isset($before[$tag])||$before[$tag]!==$callback){Dreminex_Suite_Cache::register_shortcode($tag);Dreminex_Suite_Experience::register_owner($tag,$key);}self::$loading='';
   } catch(Throwable $error) {self::$loading='';self::fail($key,'Module loading failed: '.get_class($error).'. Review its code on staging.');}
  }
 }
 public static function fail($key,$message){$all=self::all();if(isset($all[$key])){$all[$key]['enabled']=false;$all[$key]['last_error']=$message;update_option('dreminex_suite_imported_modules',$all,false);}}
 public static function fatal(){if(self::$loading){$e=error_get_last();if($e&&in_array($e['type'],[E_ERROR,E_PARSE,E_COMPILE_ERROR,E_USER_ERROR],true))self::fail(self::$loading,'Fatal error while loading. Module disabled for the next request.');}}
 public static function menu(){add_submenu_page('dreminex-suite','Imported modules','Imported modules','manage_options','dreminex-suite-imports',[__CLASS__,'page']);}
 public static function install($archive) {
  if(!class_exists('ZipArchive'))return new WP_Error('zip','ZIP support is missing.');$zip=new ZipArchive();if($zip->open($archive)!==true)return new WP_Error('zip','Invalid ZIP.');
  try {
   if($zip->numFiles>30)return new WP_Error('limit','Maximum 30 package entries.');$files=[];$hashes=[];$seen=[];$total=0;
   for($i=0;$i<$zip->numFiles;$i++) {
    $stat=$zip->statIndex($i);if(!is_array($stat))return new WP_Error('zip','Invalid ZIP entry.');$name=$stat['name'];if(isset($seen[strtolower($name)]))return new WP_Error('path','Duplicate package path.');$seen[strtolower($name)]=true;
    if(!preg_match('~^[a-zA-Z0-9_./-]+$~D',$name)||str_contains($name,'..')||str_starts_with($name,'/')||isset($files[$name]))return new WP_Error('path','Unsafe or duplicate ZIP path.');
    $opsys=0;$attr=0;$zip->getExternalAttributesIndex($i,$opsys,$attr);if(($attr>>16&0170000)===0120000)return new WP_Error('symlink','Symlinks are not allowed.');
    if(str_ends_with($name,'/'))continue;
    if(!in_array(strtolower(pathinfo($name,PATHINFO_EXTENSION)),['php','json','css','js','md','txt'],true))return new WP_Error('type','Only PHP, JSON, CSS, JS and documentation files are supported.');
    $total+=(int)$stat['size'];if($stat['size']>1048576||$total>4194304)return new WP_Error('size','Expanded package exceeds limits.');
    $content=$zip->getFromIndex($i);if($content===false)return new WP_Error('read','Could not read ZIP entry.');
    if(strtolower(pathinfo($name,PATHINFO_EXTENSION))==='php') {
     try{$tokens=token_get_all($content,TOKEN_PARSE);}catch(Throwable $e){return new WP_Error('syntax','PHP syntax incompatible: '.$name);}
     $code='';foreach($tokens as $token)$code.=is_array($token)?(in_array($token[0],[T_COMMENT,T_DOC_COMMENT,T_CONSTANT_ENCAPSED_STRING],true)?' ':$token[1]):$token;
     if(preg_match('/eval\s*\(|(?:shell_exec|passthru|system|exec|popen|proc_open)\s*\(/i',$code))return new WP_Error('risk','Executable evaluation or shell commands are not allowed in imported modules.');
    }
    $files[$name]=$content;$hashes[$name]=hash('sha256',$content);
   }
   $manifest=json_decode($files['manifest.json']??'',true);
   if(!is_array($manifest)||($manifest['format']??'')!=='dreminex-suite-module'||($manifest['api_version']??0)!==1)return new WP_Error('manifest','Manifest format/API version is invalid.');
   $slug=$manifest['id']??'';$entry=$manifest['entry']??'';
   if(!is_string($slug)||!preg_match('/^[a-z][a-z0-9-]{1,39}$/D',$slug)||!is_string($entry)||!isset($files[$entry])||pathinfo($entry,PATHINFO_EXTENSION)!=='php')return new WP_Error('entry','Valid module ID and PHP entry are required.');
   foreach(['name','version','description','instructions'] as $field)if(!is_string($manifest[$field]??null)||strlen($manifest[$field])>5000||$manifest[$field]==='')return new WP_Error('metadata','Manifest '.$field.' is required.');
   $schema=$manifest['settings']??[];if(!is_array($schema)||count($schema)>20)return new WP_Error('schema','Invalid settings schema.');
   foreach($schema as $name=>$field)if(!is_string($name)||sanitize_key($name)!==$name||preg_match('/secret|password|token|key|credential/i',$name)||!is_array($field)||!in_array($field['type']??'',['text','email','url','number','boolean'],true)||!is_string($field['label']??null)||(isset($field['default'])&&!is_scalar($field['default'])))return new WP_Error('schema','Unsupported setting. Credentials must use a dedicated secure integration; never put them in text fields.');
   if(isset($manifest['dashboard_slug'])&&(!is_string($manifest['dashboard_slug'])||!preg_match('/^dreminex-[a-z0-9-]{1,60}$/D',$manifest['dashboard_slug'])))return new WP_Error('dashboard','Use a safe dreminex-prefixed dashboard slug.');
   $key='addon-'.$slug;$all=self::all();if(!empty($all[$key]['enabled']))return new WP_Error('enabled','Disable the imported module before updating its package.');
   $directory=self::root().'/'.$slug.'-'.bin2hex(random_bytes(6));if(!wp_mkdir_p($directory))return new WP_Error('storage','Private module storage is not writable.');
   foreach($files as $name=>$content){$path=$directory.'/'.$name;if(!wp_mkdir_p(dirname($path))||file_put_contents($path,$content)!==strlen($content)){self::remove_directory($directory);return new WP_Error('write','Could not stage module files.');}}
   $old=$all[$key]['path']??null;$all[$key]=['manifest'=>$manifest,'path'=>$directory,'hashes'=>$hashes,'enabled'=>false,'last_error'=>'','installed_at'=>gmdate('c'),'previous_path'=>$old];
   if(!update_option('dreminex_suite_imported_modules',$all,false)){self::remove_directory($directory);return new WP_Error('save','Could not register imported module.');}
   return $key;
  } finally {$zip->close();}
 }
 public static function remove_directory($path) {
  $root=realpath(self::root());$real=realpath($path);if(!$root||!$real||dirname($real)!==$root||is_link($path))return false;
  $iterator=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($real,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);foreach($iterator as $file){if($file->isDir()&&!$file->isLink())rmdir($file->getPathname());else unlink($file->getPathname());}return rmdir($real);
 }
 public static function upload() {
  if(!current_user_can('manage_options')||!current_user_can('install_plugins'))wp_die('Access denied.',403);check_admin_referer('dreminex_suite_import');
  $url=admin_url('admin.php?page=dreminex-suite-settings&section=imports');
  if(empty($_POST['trusted_source']))self::upload_result('trust',$url);
  $file=$_FILES['module_zip']??[];
  if(($file['error']??1)!==UPLOAD_ERR_OK||($file['size']??0)>2097152||!is_uploaded_file($file['tmp_name']??''))self::upload_result(($file['size']??0)>2097152?'size':'upload',$url);
  if(strtolower(pathinfo((string)($file['name']??''),PATHINFO_EXTENSION))!=='zip')self::upload_result('type',$url);
  try{$result=self::install($file['tmp_name']);}catch(Throwable $error){self::upload_result('invalid',$url);}
  if(is_wp_error($result)){$code=$result->get_error_code();$known=['zip','limit','path','symlink','type','size','read','syntax','risk','manifest','entry','metadata','schema','dashboard','enabled','storage','write','save'];self::upload_result(in_array($code,$known,true)?$code:'invalid',$url);}
  wp_safe_redirect(add_query_arg('imported',1,$url));exit;
 }
 private static function upload_result($code,$url){wp_safe_redirect(add_query_arg('import_error',sanitize_key($code),$url));exit;}
 public static function control() {
  if(!current_user_can('manage_options')||!current_user_can('install_plugins'))wp_die('Access denied.',403);
  $key=sanitize_key(wp_unslash($_POST['module']??''));check_admin_referer('dreminex_suite_import_control_'.$key);$all=self::all();if(!isset($all[$key]))wp_die('Unknown imported module.',400);
  $action=sanitize_key(wp_unslash($_POST['operation']??''));
  if($action==='enable'){if(empty($_POST['trust_execution']))wp_die('Review and trust the module before allowing PHP execution.',400);$all[$key]['enabled']=true;$all[$key]['last_error']='';}
  elseif($action==='disable')$all[$key]['enabled']=false;
  elseif($action==='remove') {
   if($all[$key]['enabled']||empty($_POST['confirm_remove']))wp_die('Disable the module and confirm package removal. Data is kept.',400);
   if(!self::remove_directory($all[$key]['path']))wp_die('Package could not be removed.',500);if(!empty($all[$key]['previous_path']))self::remove_directory($all[$key]['previous_path']);unset($all[$key]);
  } elseif($action==='settings') {
   $values=[];$input=is_array($_POST['settings']??null)?wp_unslash($_POST['settings']):[];
   foreach($all[$key]['manifest']['settings']??[] as $name=>$field){$v=$input[$name]??'';if(!is_scalar($v))wp_die('Invalid setting.',400);switch($field['type']){case 'boolean':$v=$v==='1';break;case 'number':if(!is_numeric($v))wp_die('Enter a number.',400);$v=(float)$v;break;case 'email':$v=sanitize_email($v);if(!is_email($v))wp_die('Invalid email.',400);break;case 'url':$v=esc_url_raw($v,['https']);if(!$v)wp_die('Use an HTTPS URL.',400);break;default:$v=sanitize_text_field($v);} $values[$name]=$v;}
   update_option('dreminex_import_settings_'.$key,$values,false);
  } else wp_die('Unknown action.',400);
  update_option('dreminex_suite_imported_modules',$all,false);wp_safe_redirect(admin_url('admin.php?page=dreminex-suite-settings&section=imports'));exit;
 }
 public static function asset_url($key,$file){$item=self::all()[$key]??null;if(!$item||!isset($item['hashes'][$file])||!in_array(pathinfo($file,PATHINFO_EXTENSION),['css','js'],true))return '';return add_query_arg(['action'=>'dreminex_import_asset','module'=>$key,'file'=>$file,'ver'=>$item['hashes'][$file]],admin_url('admin-ajax.php'));}
 public static function asset(){
  $key=sanitize_key(wp_unslash($_GET['module']??''));$file=wp_unslash($_GET['file']??'');$item=self::all()[$key]??null;
  if(!is_string($file)||!$item||empty($item['enabled'])||!isset($item['hashes'][$file])||!in_array(pathinfo($file,PATHINFO_EXTENSION),['css','js'],true))wp_die('Asset unavailable.',404);
  $path=$item['path'].'/'.$file;if(!is_file($path)||is_link($path)||hash_file('sha256',$path)!==$item['hashes'][$file])wp_die('Asset unavailable.',404);
  while(ob_get_level())ob_end_clean();header('X-Content-Type-Options: nosniff');header('Content-Type: '.(pathinfo($file,PATHINFO_EXTENSION)==='css'?'text/css':'application/javascript').'; charset=UTF-8');nocache_headers();readfile($path);exit;
 }
 public static function data($key,$value=null) {if(!isset(self::all()[$key]))return new WP_Error('unknown','Unknown module.');if(func_num_args()>1){update_option('dreminex_import_data_'.$key,$value,false);return true;}return get_option('dreminex_import_data_'.$key,[]);}
 public static function form($key,$operation,$label) {
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_suite_import_control"><input type="hidden" name="module" value="'.esc_attr($key).'"><input type="hidden" name="operation" value="'.esc_attr($operation).'">';wp_nonce_field('dreminex_suite_import_control_'.$key);
  if($operation==='enable')echo '<label><input required type="checkbox" name="trust_execution" value="1"> I trust this PHP module and tested it on staging</label> ';
  if($operation==='remove')echo '<label><input required type="checkbox" name="confirm_remove" value="1"> Remove package only; keep module data</label> ';submit_button($label,'secondary','submit',false);echo '</form>';
 }
 public static function page() {
  if(!current_user_can('manage_options'))return;
  echo '<div class="wrap dreminex-suite"><h1>Imported modules</h1>';
  if(isset($_GET['imported']))echo '<div class="notice notice-success is-dismissible"><p>Module package imported and registered as Off. Open it below to review settings and enable it.</p></div>';
  if(isset($_GET['import_error'])){$code=sanitize_key(wp_unslash($_GET['import_error']));$messages=['trust'=>'Confirm that you reviewed and trust the package source.','upload'=>'The upload did not complete. Check the file and hosting upload limits, then retry.','size'=>'Package exceeds the 2 MB import limit.','type'=>'Choose a .zip package.','zip'=>'Server ZIP support is missing or the archive is invalid.','limit'=>'Package has too many files or exceeds the expanded size limit.','path'=>'The archive contains an unsafe or duplicate path.','symlink'=>'Symbolic links are not allowed in module packages.','read'=>'A ZIP file could not be read.','syntax'=>'A PHP file failed syntax validation.','manifest'=>'Package manifest is invalid.','entry'=>'Package entry file is invalid.','metadata'=>'Package metadata is invalid.','schema'=>'Package settings are unsupported.','dashboard'=>'Dashboard slug is invalid.','risk'=>'Package contains a prohibited execution pattern.','storage'=>'Private module storage is not writable.','write'=>'Could not stage package files.','save'=>'Could not register the package.','enabled'=>'Turn off the installed module before replacing its package.','invalid'=>'Import failed safely. Review the package structure and server limits, then retry.'];$message=$messages[$code]??'Import failed validation. Review the package structure, PHP compatibility and server limits.';echo '<div class="notice notice-error is-dismissible"><p>'.esc_html($message).'</p></div>'; }
  echo '<p>Separate from built-in modules. Only trusted administrators with plugin-install permission can import or run packages. Static checks cannot prove code is safe. New imports start Off; loading failures disable them. Packages and owned data survive Suite upgrades.</p>';
  foreach(self::all() as $key=>$item) {
   $m=$item['manifest'];echo '<div class="card" style="max-width:100%"><h2>'.esc_html($m['name']).' '.esc_html($m['version']).'</h2><p>'.esc_html($m['description']).'</p><p><strong>'.(!empty($item['enabled'])?'On: configured to load':'Off').'</strong></p><p>'.nl2br(esc_html($m['instructions'])).'</p>';
   if($item['last_error'])echo '<p class="notice notice-error">'.esc_html($item['last_error']).'</p>';
   self::form($key,!empty($item['enabled'])?'disable':'enable',!empty($item['enabled'])?'Turn off':'Turn on');
   if(empty($item['enabled']))self::form($key,'remove','Remove imported package');
   if(!empty($item['enabled'])&&!empty($m['dashboard_slug']))echo '<p><a class="button button-primary" href="'.esc_url(admin_url('admin.php?page='.$m['dashboard_slug'])).'">Open module dashboard</a></p>';
   if(!empty($m['settings'])) {echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_suite_import_control"><input type="hidden" name="module" value="'.esc_attr($key).'"><input type="hidden" name="operation" value="settings">';wp_nonce_field('dreminex_suite_import_control_'.$key);$saved=(array)get_option('dreminex_import_settings_'.$key,[]);foreach($m['settings'] as $name=>$field){$type=$field['type']==='boolean'?'checkbox':$field['type'];$value=$saved[$name]??($field['default']??'');echo '<p><label>'.esc_html($field['label']).' <input name="settings['.esc_attr($name).']" type="'.esc_attr($type).'" value="'.esc_attr($type==='checkbox'?'1':$value).'" '.($type==='checkbox'?checked($value,true,false):'').'></label></p>';}submit_button('Save settings');echo '</form>';}
   Dreminex_Suite_Data::panel($key);echo '</div>';
  }
  echo '<h2>Import module ZIP</h2><form id="dreminex-suite-import-form" enctype="multipart/form-data" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_suite_import">';wp_nonce_field('dreminex_suite_import');echo '<p><input required type="file" name="module_zip" accept=".zip,application/zip" data-max-bytes="2097152"></p><p class="description">Maximum 2 MB. The hosting PHP upload limit can be lower; if so, increase it or upload a smaller ZIP.</p><p><label><input required type="checkbox" name="trusted_source" value="1"> I reviewed this developer package and trust its source</label></p>';submit_button('Import (starts Off)');echo '<p id="dreminex-suite-import-progress" class="description" hidden>Uploading and checking the package… Keep this page open.</p></form><script>(function(){var f=document.getElementById("dreminex-suite-import-form");if(!f)return;f.addEventListener("submit",function(e){var i=f.querySelector("input[type=file]"),b=f.querySelector("button[type=submit]"),m=document.getElementById("dreminex-suite-import-progress");if(!i.files.length||i.files[0].size>Number(i.dataset.maxBytes)){e.preventDefault();alert(i.files.length?"ZIP must be 2 MB or smaller.":"Choose a ZIP file first.");return;}if(!/\.zip$/i.test(i.files[0].name)){e.preventDefault();alert("Choose a .zip package.");return;}if(m)m.hidden=false;if(b){b.disabled=true;b.textContent="Importing…";}});})();</script><p>Use a package made for the Suite Developer API. Imported PHP has normal plugin privileges; it is not sandboxed.</p></div>';
 }
}
