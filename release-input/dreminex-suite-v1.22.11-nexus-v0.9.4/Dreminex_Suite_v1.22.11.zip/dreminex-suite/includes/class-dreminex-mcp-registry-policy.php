<?php
if (!defined('ABSPATH')) exit;

/** Automatic, profile-aware policy for the WordPress Abilities registry. */
final class Dreminex_MCP_Registry_Policy {
    private static $specs = null;
    private static $owned = [];

    public static function mark_owned($name) { self::$owned[(string) $name] = true; }
    public static function specs() {
        if (is_array(self::$specs)) return self::$specs;
        self::$specs = [];
        foreach (['native-mcp-abilities-v2.json','native-mcp-abilities-v3.json'] as $file) {
            $path = DREMINEX_SUITE_PATH . 'data/' . $file;
            $data = is_readable($path) ? json_decode((string) file_get_contents($path), true) : null;
            foreach ((array) ($data['abilities'] ?? []) as $spec) if (!empty($spec['name']) && is_array($spec)) self::$specs[$spec['name']] = $spec;
        }
        return self::$specs;
    }
    public static function spec($name) { $specs = self::specs(); return $specs[$name] ?? null; }

    /** Stable public diagnostics are additive; reason_code remains the legacy compatibility value. */
    public static function stable_reason_code($reason) {
        $reason = (string) $reason;
        $map = [
            'authorized' => 'enabled',
            'enabled' => 'enabled',
            'client_scope_not_allowed' => 'missing_scope',
            'insufficient_scope' => 'missing_scope',
            'wordpress_capability_denied' => 'missing_wp_capability',
            'permission_mode_denied' => 'policy_blocked',
            'abilities_master_disabled' => 'policy_blocked',
            'provider_disabled' => 'policy_blocked',
            'category_disabled' => 'policy_blocked',
            'ability_disabled' => 'user_disabled',
            'custom_ability_disabled' => 'user_disabled',
            'production_guard' => 'critical_action_protected',
            'approval_required' => 'approval_required',
            'scope_unmapped' => 'invalid_metadata',
            'provider_unknown' => 'invalid_metadata',
            'ability_missing' => 'schema_incompatible',
            'ability_not_registered' => 'schema_incompatible',
            'invalid_metadata' => 'invalid_metadata',
            'rate_limited' => 'rate_limited',
            'temporary_circuit_breaker' => 'temporary_circuit_breaker',
            'provider_unavailable' => 'provider_unavailable',
            'not_public' => 'not_public',
            'internal_helper' => 'internal_helper',
        ];
        return $map[$reason] ?? ($reason !== '' ? $reason : 'schema_incompatible');
    }

    private static function with_stable_reason($decision) {
        $decision['stable_reason_code'] = self::stable_reason_code($decision['reason_code'] ?? '');
        return $decision;
    }

    private static function normalized_category($name, $ability = null) {
        $raw = self::category($name, $ability);
        if (str_contains($raw, 'media')) return 'media';
        if (str_contains($raw, 'product') || str_contains($raw, 'commerce') || str_contains($raw, 'order') || str_contains($raw, 'supplier') || $raw === 'woocommerce' || $raw === 'wc') return 'commerce';
        if (str_contains($raw, 'setting') || str_contains($raw, 'security') || str_contains($raw, 'admin') || str_contains($raw, 'plugin') || str_contains($raw, 'user')) return 'settings';
        if (str_contains($raw, 'diagnostic') || str_contains($raw, 'system') || str_contains($raw, 'operation')) return 'diagnostics';
        if (str_contains($raw, 'developer') || str_contains($raw, 'file') || str_contains($raw, 'skill')) return 'developer';
        return 'content';
    }

    private static function normalized_operation($name, $ability = null, $risk = '') {
        $spec = self::spec($name);
        $operation = (string) ($spec['operation'] ?? '');
        if (in_array($operation, ['read','preview','create','update','publish','restore','trash','delete','execute'], true)) return $operation;
        if ($risk === 'read') return 'read';
        $lower = strtolower((string) $name);
        if (str_contains($lower, 'preview') || str_contains($lower, 'dry-run')) return 'preview';
        if (preg_match('/(?:^|[-_\/])(?:create|add|upload|register)/', $lower)) return 'create';
        if (preg_match('/(?:update|save|edit|activate|enable|disable|set|queue)/', $lower)) return 'update';
        if (str_contains($lower, 'publish')) return 'publish';
        if (str_contains($lower, 'restore')) return 'restore';
        if (preg_match('/(?:trash|cancel)/', $lower)) return 'trash';
        if (str_contains($lower, 'delete')) return 'delete';
        return 'execute';
    }

    /** Return the full v1.0 agent-facing metadata contract without trusting third-party guesses. */
    public static function normalized_metadata($name, $ability = null, $decision = null) {
        $decision = is_array($decision) ? $decision : self::decision($name, $ability);
        $meta = is_object($ability) && method_exists($ability, 'get_meta') ? (array) $ability->get_meta() : [];
        $annotations = is_object($ability) && method_exists($ability, 'get_annotations') ? (array) $ability->get_annotations() : [];
        $annotations = array_replace($annotations, (array) ($meta['annotations'] ?? []));
        $risk = (string) ($decision['risk'] ?? '');
        if (!in_array($risk, ['read','low_write','write','high_write','destructive','critical'], true)) $risk = 'critical';
        $scope = (string) ($decision['required_scope'] ?? '');
        $capability = (string) ($decision['capability'] ?? self::required_capability($name));
        $operation = self::normalized_operation($name, $ability, $risk);
        $lower = strtolower((string) $name);
        $privacy = 'site_internal';
        if (preg_match('/password|secret|token|credential|otp|auth|cookie/i', $lower)) $privacy = 'credential_sensitive';
        elseif (preg_match('/customer|order|payment|conversation|contact/i', $lower)) $privacy = 'customer_sensitive';
        elseif (preg_match('/public|catalog|product|media/i', $lower)) $privacy = 'public';
        $approval = 'none';
        if ($risk === 'critical') $approval = 'owner_only';
        elseif (in_array($risk, ['destructive','high_write'], true)) $approval = 'user_confirmation';
        elseif ($risk !== 'read') $approval = 'approval_queue';
        $label = is_object($ability) && method_exists($ability, 'get_label') ? (string) $ability->get_label() : (string) $name;
        return [
            'name' => (string) $name,
            'label' => $label,
            'provider' => (string) ($decision['provider'] ?? self::provider($name, $ability)),
            'category' => self::normalized_category($name, $ability),
            'operation' => $operation,
            'risk' => $risk,
            'required_scopes' => $scope !== '' ? [$scope] : [],
            'required_wp_capabilities' => $capability !== '' ? [$capability] : [],
            'approval' => $approval,
            'supports_dry_run' => $risk !== 'read',
            'reversible' => !in_array($risk, ['destructive','critical'], true) && !in_array($operation, ['delete','trash'], true),
            'idempotent' => !empty($annotations['idempotent']),
            'privacy_class' => $privacy,
            'environment_neutral_label' => true,
            'public' => !empty($decision['public_exposure']) && ($decision['stable_reason_code'] ?? self::stable_reason_code($decision['reason_code'] ?? '')) !== 'internal_helper',
            'internal_helper' => ($decision['reason_code'] ?? '') === 'internal_helper',
            'schema_version' => '1.0',
        ];
    }

    public static function metadata_valid($metadata) {
        if (!is_array($metadata)) return false;
        foreach (['name','label','provider','category','operation','risk','schema_version'] as $key) if (empty($metadata[$key]) || !is_string($metadata[$key])) return false;
        if (!in_array($metadata['risk'], ['read','low_write','write','high_write','destructive','critical'], true)) return false;
        if (!in_array($metadata['operation'], ['read','preview','create','update','publish','restore','trash','delete','execute'], true)) return false;
        if (!is_array($metadata['required_scopes']) || !is_array($metadata['required_wp_capabilities'])) return false;
        if (!array_key_exists('public', $metadata) || !array_key_exists('internal_helper', $metadata)) return false;
        return $metadata['provider'] !== 'unknown' && $metadata['required_scopes'] !== [];
    }

    /** Transport helpers and skill prompt resources are never agent-executable abilities. */
    public static function is_internal($name) {
        if (in_array($name, ['core/get-environment-info','core/get-site-info','core/get-user-info'], true)) return true;
        if (in_array($name, ['novamira-mcp-adapter/get-ability-info','novamira-mcp-adapter/execute-ability'], true)) return true;
        return str_starts_with($name, 'novamira/skill-prompt-');
    }

    public static function provider($name, $ability = null) {
        $custom = self::custom_policy($name);
        if (!empty($custom['provider'])) return sanitize_key((string) $custom['provider']);
        $meta = is_object($ability) && method_exists($ability, 'get_meta') ? (array) $ability->get_meta() : [];
        $declared = sanitize_key((string) ($meta['provider_plugin'] ?? $meta['provider'] ?? ''));
        // Exact contract membership identifies first-party abilities without trusting a namespace prefix.
        if (!empty(self::$owned[$name]) || self::spec($name)) return 'dreminex-suite';
        if ($declared !== '') return $declared;
        $namespace = strtolower((string) strtok($name, '/'));
        $known = [
            'woocommerce' => 'woocommerce', 'wc' => 'woocommerce',
            'wordpress-seo' => 'yoast-seo', 'yoast-seo' => 'yoast-seo',
            'jetpack' => 'jetpack', 'jetpack-forms' => 'jetpack',
            'pixelyoursite' => 'pixelyoursite', 'pys' => 'pixelyoursite',
            'elementor' => 'elementor', 'wpvivid' => 'wpvivid',
            'novamira' => 'novamira', 'novamira-mcp-adapter' => 'novamira-mcp-adapter',
        ];
        if (isset($known[$namespace])) return $known[$namespace];
        return preg_match('/^[a-z0-9][a-z0-9-]{0,62}$/', $namespace) ? 'external-' . sanitize_key($namespace) : 'unknown';
    }

    public static function category($name, $ability = null) {
        $custom = self::custom_policy($name);
        if (!empty($custom['category'])) return sanitize_key((string) $custom['category']);
        if (is_object($ability) && method_exists($ability, 'get_category')) {
            $category = sanitize_key((string) $ability->get_category());
            if ($category !== '') return $category;
        }
        return sanitize_key((string) strtok($name, '/'));
    }

    /**
     * Owner-managed metadata for already registered WordPress abilities.
     * This is deliberately a policy layer: it cannot register PHP, upload
     * code, or create an executable ability that is absent from the registry.
     */
    public static function custom_policy($name) {
        $all = function_exists('get_option') ? get_option('dreminex_native_mcp_custom_abilities', []) : [];
        $row = is_array($all) ? ($all[(string) $name] ?? []) : [];
        return is_array($row) ? $row : [];
    }

    public static function custom_skills() {
        $skills = function_exists('get_option') ? get_option('dreminex_native_mcp_custom_skills', []) : [];
        return is_array($skills) ? $skills : [];
    }

    public static function custom_skill($slug) {
        $skills = self::custom_skills();
        return is_array($skills[$slug] ?? null) ? $skills[$slug] : null;
    }

    /**
     * Read the provider's declared MCP contract without trusting arbitrary
     * top-level metadata.  Third-party abilities can opt into discovery by
     * declaring mcp.public=true and may provide their own reviewed scope,
     * risk and WordPress capability.  The registry remains the source of
     * truth; this only normalizes optional metadata for the Native MCP layer.
     */
    private static function mcp_meta($ability) {
        if (!is_object($ability) || !method_exists($ability, 'get_meta')) return [];
        $meta = (array) $ability->get_meta();
        return is_array($meta['mcp'] ?? null) ? (array) $meta['mcp'] : [];
    }

    private static function declared_scope($ability) {
        $meta = is_object($ability) && method_exists($ability, 'get_meta') ? (array) $ability->get_meta() : [];
        $mcp = self::mcp_meta($ability);
        foreach (['required_scope', 'scope', 'oauth_scope'] as $key) {
            $value = $mcp[$key] ?? ($meta[$key] ?? '');
            if (is_string($value) && $value !== '') return self::normalize_scope_value($value);
        }
        return '';
    }

    private static function declared_risk($ability) {
        $meta = is_object($ability) && method_exists($ability, 'get_meta') ? (array) $ability->get_meta() : [];
        $mcp = self::mcp_meta($ability);
        $value = $mcp['risk'] ?? ($meta['risk'] ?? '');
        $value = is_string($value) ? sanitize_key($value) : '';
        return in_array($value, ['read','low_write','write','high_write','destructive','critical'], true) ? $value : '';
    }

    private static function declared_capability($ability) {
        $meta = is_object($ability) && method_exists($ability, 'get_meta') ? (array) $ability->get_meta() : [];
        $mcp = self::mcp_meta($ability);
        foreach (['required_capability', 'capability', 'wp_capability'] as $key) {
            $value = $mcp[$key] ?? ($meta[$key] ?? '');
            if (is_string($value) && $value !== '') return sanitize_key($value);
        }
        return '';
    }

    private static function supported_scope($scope) {
        if ($scope === '') return false;
        if (class_exists('Dreminex_Native_OAuth') && method_exists('Dreminex_Native_OAuth', 'scopes')) {
            return in_array($scope, Dreminex_Native_OAuth::scopes(), true);
        }
        return (bool) preg_match('/^(?:mcp|site|catalog|orders|suppliers|workflow|operations|notifications|analytics|settings|contacts|checkout|payments|approvals|devices|media|content|editor|files|security|seo|forms|design|skills|users|plugins):(?:read|write)$/', $scope);
    }

    /** Scope names contain a colon, so sanitize_key() must not be used. */
    private static function normalize_scope_value($scope) {
        $scope = strtolower(trim((string) $scope));
        return preg_match('/^[a-z0-9_-]+:(?:read|write)$/', $scope) ? $scope : '';
    }

    /** Explicit first-party contracts and curated providers are public; unknown providers must opt in. */
    public static function public_exposure($name, $ability = null) {
        if (self::is_internal($name)) return false;
        $custom = self::custom_policy($name);
        if (array_key_exists('public', $custom)) return !empty($custom['public']);
        if (!empty(self::$owned[$name]) || self::spec($name)) return true;
        $meta = is_object($ability) && method_exists($ability, 'get_meta') ? (array) $ability->get_meta() : [];
        $mcp = is_array($meta['mcp'] ?? null) ? $meta['mcp'] : [];
        if (array_key_exists('public', $mcp)) return !empty($mcp['public']);
        return in_array(self::provider($name, $ability), ['woocommerce','yoast-seo','jetpack','pixelyoursite','elementor','novamira','novamira-mcp-adapter'], true);
    }

    private static function novamira_scope($name) {
        if ($name === 'novamira-mcp-adapter/discover-abilities') return 'mcp:discover';
        if ($name === 'novamira/agent-context') return 'site:read';
        if (preg_match('#^novamira/(?:read-file|list-directory)$#', $name)) return 'files:read';
        if (preg_match('#^novamira/(?:write-file|edit-file|delete-file|create-upload-link|disable-file|enable-file)$#', $name)) return 'files:write';
        if ($name === 'novamira/execute-php' || $name === 'novamira/create-admin-access-link') return 'security:write';
        if ($name === 'novamira/skill-get') return 'skills:read';
        if (str_starts_with($name, 'novamira/skill-')) return 'skills:write';
        if (preg_match('#^novamira/(?:list-design-library|get-active-design|get-design|check-design)$#', $name)) return 'design:read';
        if (preg_match('#^novamira/(?:activate-design|save-design|delete-design)$#', $name)) return 'design:write';
        if (str_starts_with($name, 'novamira/gutenberg-')) return preg_match('/(?:write|create|add|enable|delete)/', $name) ? 'editor:write' : 'editor:read';
        return '';
    }

    public static function required_scope($name, $readonly = true, $ability = null) {
        $custom = self::custom_policy($name);
        $custom_scope = is_string($custom['scope'] ?? null) ? self::normalize_scope_value($custom['scope']) : '';
        if (self::supported_scope($custom_scope)) return $custom_scope;
        $declared = self::declared_scope($ability);
        if (self::supported_scope($declared)) return $declared;
        $spec = self::spec($name);
        if ($spec) {
            $group = (string) ($spec['functional_group'] ?? '');
            $write = ($spec['operation'] ?? 'read') !== 'read';
            if (str_contains($name, 'ability-coverage-read')) return 'mcp:discover';
            if (str_starts_with($name, 'dreminex-media/')) return 'media:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-files/')) return 'files:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-editor/')) return 'editor:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-admin/') || str_starts_with($name, 'dreminex-developer/')) return 'security:write';
            if (str_starts_with($name, 'dreminex-core/settings-')) return 'settings:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-core/users-')) return 'users:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-core/plugins-')) return 'plugins:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-workflow/')) return 'skills:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-design/')) return 'design:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-suppliers/')) return 'suppliers:' . ($write ? 'write' : 'read');
            if (str_starts_with($name, 'dreminex-core/')) return 'content:' . ($write ? 'write' : 'read');
            if ($group === 'MCP Gateway & Diagnostics') return 'site:read';
        }
        $namespace = strtolower((string) strtok($name, '/'));
        $write = !$readonly;
        if ($namespace === 'dreminex-products') return str_contains($name, '/workflow-') ? 'workflow:' . ($write ? 'write' : 'read') : 'catalog:' . ($write ? 'write' : 'read');
        if ($namespace === 'dreminex-operations') {
            if (str_contains($name, 'notification')) return 'notifications:' . ($write ? 'write' : 'read');
            if (str_contains($name, 'contact')) return 'contacts:' . ($write ? 'write' : 'read');
            if (str_contains($name, 'checkout')) return 'checkout:' . ($write ? 'write' : 'read');
            if (str_contains($name, 'payment') || str_contains($name, 'wallet') || str_contains($name, 'delivery-advance')) return 'payments:' . ($write ? 'write' : 'read');
            if (str_contains($name, 'supplier')) return 'suppliers:' . ($write ? 'write' : 'read');
            if (str_contains($name, 'order')) return 'orders:' . ($write ? 'write' : 'read');
            return 'operations:read';
        }
        if ($namespace === 'dreminex-security') return 'security:' . ($write ? 'write' : 'read');
        if ($namespace === 'dreminex-suppliers') return 'suppliers:' . ($write ? 'write' : 'read');
        if ($namespace === 'dreminex-system') return str_contains($name, 'coverage') ? 'mcp:discover' : 'site:read';
        if ($namespace === 'novamira' || $namespace === 'novamira-mcp-adapter') return self::novamira_scope($name);
        if (in_array($namespace, ['woocommerce','wc'], true)) return (str_contains($name, 'order') ? 'orders:' : 'catalog:') . ($write ? 'write' : 'read');
        if (in_array($namespace, ['wordpress-seo','yoast-seo'], true)) return 'seo:' . ($write ? 'write' : 'read');
        if (in_array($namespace, ['jetpack','jetpack-forms'], true)) return 'forms:' . ($write ? 'write' : 'read');
        if (in_array($namespace, ['pixelyoursite','pys'], true)) return 'settings:' . ($write ? 'write' : 'read');
        if ($namespace === 'elementor') return 'design:' . ($write ? 'write' : 'read');
        // An external WordPress ability that explicitly opts into MCP
        // exposure receives a bounded content scope when its provider does
        // not declare a narrower scope.  The ability's own permission
        // callback still runs at execution time, and write policy/approvals
        // are enforced by Native MCP.  Untrusted abilities without
        // mcp.public=true never reach this fallback because decision() fails
        // closed with not_public.
        if (self::public_exposure($name, $ability)) return 'content:' . ($write ? 'write' : 'read');
        return '';
    }

    public static function required_capability($name, $ability = null) {
        $custom = self::custom_policy($name);
        if (!empty($custom['capability'])) return sanitize_key((string) $custom['capability']);
        $declared = self::declared_capability($ability);
        if ($declared !== '') return $declared;
        if (str_starts_with($name, 'dreminex-media/')) return 'upload_files';
        if (str_starts_with($name, 'dreminex-files/') || str_starts_with($name, 'dreminex-admin/') || str_starts_with($name, 'dreminex-developer/')) return 'manage_options';
        if (str_starts_with($name, 'dreminex-editor/')) return 'edit_posts';
        if (str_starts_with($name, 'dreminex-core/settings-') || str_starts_with($name, 'dreminex-core/plugins-') || str_starts_with($name, 'dreminex-core/themes-')) return 'manage_options';
        if (str_starts_with($name, 'dreminex-core/users-')) return 'list_users';
        if (str_starts_with($name, 'dreminex-core/comments-')) return 'moderate_comments';
        if (str_starts_with($name, 'dreminex-core/menus-')) return 'edit_theme_options';
        if (str_starts_with($name, 'dreminex-workflow/') || str_starts_with($name, 'dreminex-design/') || str_starts_with($name, 'dreminex-security/')) return 'manage_options';
        if (str_starts_with($name, 'dreminex-suppliers/')) return 'manage_woocommerce';
        if (str_starts_with($name, 'dreminex-core/')) return 'edit_posts';
        if (str_starts_with($name, 'novamira/')) return 'manage_options';
        return '';
    }

    public static function risk($name, $ability = null) {
        $custom = self::custom_policy($name);
        $spec = self::spec($name);
        if ($spec) return (string) ($spec['operation'] ?? 'high_write');
        $annotations = is_object($ability) && method_exists($ability, 'get_annotations') ? (array) $ability->get_annotations() : [];
        $meta = is_object($ability) && method_exists($ability, 'get_meta') ? (array) $ability->get_meta() : [];
        $annotations = array_replace($annotations, (array) ($meta['annotations'] ?? []));
        if (!empty($annotations['destructive'])) return 'destructive';
        if (!empty($annotations['readonly'])) return 'read';
        if (in_array(($custom['risk'] ?? ''), ['low_write','write','high_write','destructive','critical'], true)) return $custom['risk'];
        $declared = self::declared_risk($ability);
        if ($declared !== '' && $declared !== 'read') return $declared;
        $scope = self::required_scope($name, false, $ability);
        if (in_array($scope, ['files:write','security:write','plugins:write','users:write'], true)) return 'high_write';
        // Public, non-destructive provider abilities are ordinary writes by
        // default.  Their own WordPress permission callback still applies;
        // only destructive/high-risk metadata escalates to owner approval.
        return 'write';
    }

    private static function environment_block($name) {
        if (!class_exists('Dreminex_Native_MCP') || Dreminex_Native_MCP::environment() !== 'production') return false;
        if (str_starts_with($name, 'dreminex-developer/') || str_starts_with($name, 'dreminex-admin/')) return true;
        if (in_array($name, ['novamira/execute-php','novamira/create-admin-access-link'], true)) return true;
        return (bool) preg_match('#^novamira/(?:read-file|write-file|edit-file|delete-file|create-upload-link|disable-file|enable-file|list-directory)$#', $name);
    }

    public static function decision($name, $ability = null) {
        if (!$ability) return self::with_stable_reason(['registered' => false, 'enabled' => false, 'reason_code' => 'ability_missing', 'provider' => 'unknown', 'category' => '', 'required_scope' => '']);
        $provider = self::provider($name, $ability);
        $category = self::category($name, $ability);
        $custom = self::custom_policy($name);
        $settings = self::settings();
        $required = self::required_scope($name, self::risk($name, $ability) === 'read', $ability);
        $base = ['registered' => true, 'enabled' => false, 'provider_enabled' => true, 'category_enabled' => true, 'ability_enabled' => true, 'public_exposure' => self::public_exposure($name, $ability), 'provider' => $provider, 'category' => $category, 'required_scope' => $required, 'risk' => self::risk($name, $ability), 'capability' => self::required_capability($name, $ability), 'override' => 'automatic'];
        if (self::is_internal($name)) return self::with_stable_reason($base + ['reason_code' => 'internal_helper']);
        if (empty($settings['abilities_enabled'])) return self::with_stable_reason($base + ['reason_code' => 'abilities_master_disabled']);
        if ($provider === 'unknown') return self::with_stable_reason($base + ['reason_code' => 'provider_unknown']);
        if (array_key_exists($provider, (array) $settings['provider_states']) && empty($settings['provider_states'][$provider])) return self::with_stable_reason(array_replace($base, ['provider_enabled' => false, 'reason_code' => 'provider_disabled', 'override' => 'provider']));
        if (array_key_exists($category, (array) $settings['category_states']) && empty($settings['category_states'][$category])) return self::with_stable_reason(array_replace($base, ['category_enabled' => false, 'reason_code' => 'category_disabled', 'override' => 'category']));
        if (array_key_exists($name, (array) $settings['ability_states']) && empty($settings['ability_states'][$name])) return self::with_stable_reason(array_replace($base, ['ability_enabled' => false, 'reason_code' => 'ability_disabled', 'override' => 'ability']));
        if (array_key_exists('enabled', $custom) && empty($custom['enabled'])) return self::with_stable_reason(array_replace($base, ['ability_enabled' => false, 'reason_code' => 'custom_ability_disabled', 'override' => 'custom']));
        if (!self::public_exposure($name, $ability)) return self::with_stable_reason($base + ['reason_code' => 'not_public']);
        if ($required === '') return self::with_stable_reason($base + ['reason_code' => 'scope_unmapped']);
        if (self::environment_block($name)) return self::with_stable_reason($base + ['reason_code' => 'production_guard']);
        return self::with_stable_reason(array_replace($base, ['enabled' => true, 'reason_code' => 'enabled', 'capability' => self::required_capability($name, $ability)]));
    }

    public static function settings() {
        $settings = Dreminex_Native_MCP::settings();
        foreach (['provider_states','category_states','ability_states'] as $key) $settings[$key] = is_array($settings[$key] ?? null) ? $settings[$key] : [];
        return $settings;
    }

    public static function coverage($filter = []) {
        $rows = [];
        $provider_summary = [];
        $category_summary = [];
        $blocked_reasons = [];
        foreach ((array) (function_exists('wp_get_abilities') ? wp_get_abilities() : []) as $key => $ability) {
            $name = is_object($ability) && method_exists($ability, 'get_name') ? $ability->get_name() : (string) $key;
            $provider = self::provider($name, $ability);
            if (!empty($filter['provider']) && $filter['provider'] !== $provider) continue;
            if (!empty($filter['namespace']) && !str_starts_with($name, $filter['namespace'] . '/')) continue;
            $decision = self::decision($name, $ability);
            $metadata = self::normalized_metadata($name, $ability, $decision);
            $metadata_valid = self::metadata_valid($metadata);
            $row_reason = (string) ($decision['reason_code'] ?? 'ability_not_registered');
            if (!$metadata_valid && $row_reason === 'enabled') $row_reason = 'invalid_metadata';
            $row_exposed = !empty($decision['enabled']) && $metadata_valid;
            $row = ['name' => $name, 'provider' => $provider, 'category' => $decision['category'], 'registered' => true, 'exposed' => $row_exposed, 'reason_code' => $row_reason, 'stable_reason_code' => self::stable_reason_code($row_reason), 'required_scope' => $decision['required_scope'], 'risk' => $decision['risk'] ?? 'blocked', 'metadata_valid' => $metadata_valid, 'metadata' => $metadata];
            $rows[] = $row;
            $provider_summary[$provider] = $provider_summary[$provider] ?? ['registered_count'=>0,'internal_count'=>0,'exposed_count'=>0,'blocked_count'=>0];
            $provider_summary[$provider]['registered_count']++;
            if ($row_reason === 'internal_helper') $provider_summary[$provider]['internal_count']++;
            if ($row_exposed) $provider_summary[$provider]['exposed_count']++; elseif ($row_reason !== 'internal_helper') $provider_summary[$provider]['blocked_count']++;
            $category_key = (string) ($metadata['category'] ?? 'content');
            $category_summary[$category_key] = $category_summary[$category_key] ?? ['registered_count'=>0,'internal_count'=>0,'exposed_count'=>0,'blocked_count'=>0];
            $category_summary[$category_key]['registered_count']++;
            if ($row_reason === 'internal_helper') $category_summary[$category_key]['internal_count']++;
            if ($row_exposed) $category_summary[$category_key]['exposed_count']++; elseif ($row_reason !== 'internal_helper') $category_summary[$category_key]['blocked_count']++;
            $stable = $row['stable_reason_code']; if ($stable !== 'enabled') $blocked_reasons[$stable] = ($blocked_reasons[$stable] ?? 0) + 1;
        }
        usort($rows, static fn($a, $b) => strcmp($a['name'], $b['name']));
        $page = max(1, absint($filter['page'] ?? 1));
        $registered = count($rows); $internal = count(array_filter($rows, static fn($row) => $row['reason_code'] === 'internal_helper')); $exposed = count(array_filter($rows, static fn($row) => $row['exposed']));
        return ['schema_version'=>'2','registered_count'=>$registered,'internal_count'=>$internal,'eligible_count'=>$exposed,'exposed_count'=>$exposed,'discoverable_count'=>null,'discoverable_requires_client_context'=>true,'blocked_count'=>max(0,$registered-$internal-$exposed),'not_public_count'=>count(array_filter($rows, static fn($row) => $row['reason_code'] === 'not_public')),'blocked_reasons'=>$blocked_reasons,'provider_summaries'=>$provider_summary,'category_summaries'=>$category_summary,'page' => $page, 'per_page' => 100, 'has_more'=>($page*100)<$registered, 'abilities' => array_slice($rows, ($page - 1) * 100, 100)];
    }

    public static function effective_count($mode, $scopes, $selected = null) {
        $count = 0; $scopes = (array) $scopes; $selected = is_array($selected) ? $selected : $scopes;
        foreach ((array) (function_exists('wp_get_abilities') ? wp_get_abilities() : []) as $key => $ability) {
            $name = is_object($ability) && method_exists($ability, 'get_name') ? $ability->get_name() : (string) $key;
            $decision = self::decision($name, $ability);
            if (empty($decision['enabled'])) continue;
            if (!self::metadata_valid(self::normalized_metadata($name, $ability, $decision))) continue;
            if ($mode === 'read_only' && ($decision['risk'] ?? 'read') !== 'read') continue;
            $required = $decision['required_scope'] ?? '';
            if (in_array($required, $selected, true) && in_array($required, $scopes, true)) $count++;
        }
        return $count;
    }
}
