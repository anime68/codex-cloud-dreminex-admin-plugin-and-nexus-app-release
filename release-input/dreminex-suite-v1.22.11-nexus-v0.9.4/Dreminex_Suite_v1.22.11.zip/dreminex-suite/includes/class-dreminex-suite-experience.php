<?php
if(!defined('ABSPATH'))exit;
/** Automatic placements and one Suite control centre; does not edit page-builder content. */
final class Dreminex_Suite_Experience {
 private static $seen=[];
 private const TAGS=['dreminex_newsletter_heading'=>'newsletter_offers','dreminex_newsletter_signup'=>'newsletter_offers','dreminex_active_offers'=>'newsletter_offers','dreminex_contact_evidence_form'=>'contact_requests','show_ip'=>'checkout_protection'];
 public static function boot(){
  self::fallbacks();
  add_action('init',[__CLASS__,'fallbacks'],0);
  add_filter('do_shortcode_tag',[__CLASS__,'observe'],99,2);
  // Sbmart closes #content inside footer.php; get_footer runs just before it.
  add_action('get_footer',[__CLASS__,'automatic_offers'],5);
  add_action('wp_footer',[__CLASS__,'automatic'],5);
  add_filter('the_content',[__CLASS__,'classic_checkout'],8);
  add_filter('the_content',[__CLASS__,'remove_disabled_shortcodes'],99);
  add_filter('widget_text', 'do_shortcode', 11);
  add_filter('widget_text_content', 'do_shortcode', 11);
  add_filter('elementor/widget/render_content', [__CLASS__,'builder_shortcodes'], 10, 2);
  add_filter('widget_text_content',[__CLASS__,'remove_disabled_shortcodes'],99);
  add_filter('elementor/frontend/the_content',[__CLASS__,'remove_disabled_shortcodes'],99);
  add_filter('bcn_breadcrumb_template',[__CLASS__,'brand_home_breadcrumb'],20,3);
  add_action('updated_option',[__CLASS__,'changed'],15,3);
  add_action('admin_menu',[__CLASS__,'menu'],40);
  add_action('admin_post_dreminex_suite_experience',[__CLASS__,'save']);
  add_action('dreminex_suite_module_panel',[__CLASS__,'panel'],4);
 }
 public static function on($key){return Dreminex_Suite_Routing::enabled($key);}
 public static function offer_seen(){return !empty(self::$seen['dreminex_active_offers']);}
 public static function fallbacks(){
  foreach(array_merge(self::TAGS,(array)get_option('dreminex_suite_shortcode_owners',[])) as $tag=>$module)if(!shortcode_exists($tag))add_shortcode($tag,static fn()=>'');
  // Legacy Elementor pages may still contain this shortcode after the old
  // Store Builder is disabled. Render the active ShopBuilder lists instead.
  if(!shortcode_exists('dreminex_saved_lists'))add_shortcode('dreminex_saved_lists',[__CLASS__,'saved_lists']);
 }
 public static function saved_lists($atts=[]){
  $atts=shortcode_atts(['type'=>''],is_array($atts)?$atts:[],'dreminex_saved_lists');
  $kind=sanitize_key($atts['type']);
  if(!in_array($kind,['wishlist','compare'],true))$kind=is_page('compare-2')?'compare':'wishlist';
  $tag=$kind==='compare'?'rtsb_compare_list':'rtsb_wishlist';
  $html=shortcode_exists($tag)?do_shortcode('['.$tag.']'):'';
  $shop=function_exists('wc_get_page_permalink')?wc_get_page_permalink('shop'):home_url('/');
  if($html==='')$html='<div class="dreminex-saved-empty"><p>Your saved products will appear here.</p></div>';
  if(($kind==='wishlist' && strpos($html,'rtsb-wl-empty-text')!==false) || strpos($html,'dreminex-saved-empty')!==false){
   $html.='<p class="dreminex-saved-shop"><a class="button" href="'.esc_url($shop).'">Browse products</a></p>';
  }
  return '<section class="dreminex-saved-list dreminex-saved-list-'.esc_attr($kind).'" aria-label="'.esc_attr($kind==='compare'?'Compare products':'Wishlist products').'">'.$html.'</section>';
 }
 public static function brand_home_breadcrumb($template,$types,$id){
  if(in_array('home',(array)$types,true))return str_replace('>Sbmart<','>Home<',$template);
  return $template;
 }
 public static function builder_shortcodes($content,$widget){
  if(!is_string($content)||$content===''||is_admin())return $content;
  if(!preg_match('/\[(?:dreminex_newsletter_heading|dreminex_newsletter_signup|dreminex_active_offers|dreminex_contact_evidence_form|show_ip)(?:\s|\]|\/)/',$content))return $content;
  return do_shortcode($content);
 }
 public static function register_owner($tag,$module){$map=(array)get_option('dreminex_suite_shortcode_owners',[]);if(($map[$tag]??'')!==$module){$map[$tag]=$module;update_option('dreminex_suite_shortcode_owners',$map,false);}}
 public static function observe($html,$tag){
  if(in_array($tag,['dreminex_newsletter_heading','dreminex_newsletter_signup','dreminex_active_offers','dreminex_contact_evidence_form','woocommerce_order_tracking'],true)){
   if(!wp_doing_ajax()&&!defined('DREMINEX_NEWS_RENDER_PRIVATE')&&in_array($tag,['dreminex_newsletter_heading','dreminex_newsletter_signup'],true)&&!empty(self::$seen[$tag]))return '';
   if($html!=='')self::$seen[$tag]=true;
  }return $html;
 }
 public static function automatic(){
  if(is_admin()||wp_doing_ajax()||is_feed())return;
  if(self::on('newsletter_offers')&&Dreminex_Suite_Features::enabled('newsletter_offers','newsletter')&&function_exists('dreminex_news_live_placeholder')&&get_option('dreminex_suite_auto_newsletter',1)){
   $html='';foreach(['dreminex_newsletter_heading','dreminex_newsletter_signup'] as $tag)if(empty(self::$seen[$tag]))$html.=do_shortcode('['.$tag.']');
   if($html!=='')echo '<section class="dreminex-auto-newsletter" aria-label="Newsletter" style="max-width:1200px;margin:24px auto;padding:24px">'.$html.'</section>';
  }
  foreach(['contact'=>['contact_requests','dreminex_contact_evidence_form'],'tracking'=>['order_management','woocommerce_order_tracking']] as $kind=>$pair){$page=(int)get_option('dreminex_suite_'.$kind.'_page',0);$feature=$kind!=='tracking'||Dreminex_Suite_Control::setting('order_management','tracking_enabled',1);if($feature&&self::on($pair[0])&&$page>0&&is_page($page)&&empty(self::$seen[$pair[1]])&&shortcode_exists($pair[1]))echo '<section class="dreminex-auto-feature" style="max-width:1000px;margin:24px auto;padding:24px">'.do_shortcode('['.$pair[1].']').'</section>';}
 }
 public static function automatic_offers(){
  if(is_admin()||wp_doing_ajax()||is_feed()||!self::on('newsletter_offers')||!get_option('dreminex_suite_auto_newsletter',1)||!function_exists('dreminex_news_live_placeholder')||!empty(self::$seen['dreminex_active_offers']))return;
  $html=dreminex_news_live_placeholder('offers');
  if($html!=='')echo '<section class="dreminex-auto-offers" aria-label="Current offers" style="max-width:1200px;margin:28px auto;padding:16px 24px">'.$html.'</section>';
 }
 public static function remove_disabled_shortcodes($content){
  if(!is_string($content)||$content==='')return $content;
  $off=[];if(!self::on('newsletter_offers'))$off[]='dreminex_newsletter_heading|dreminex_newsletter_signup|dreminex_active_offers';
  if(!self::on('contact_requests'))$off[]='dreminex_contact_evidence_form';
  if(!$off)return $content;return preg_replace('/\[(?:'.implode('|',$off).')(?:\s[^\]]*)?\](?:.*?\[\/(?:'.implode('|',$off).')\])?/is','',$content);
 }
 public static function classic_checkout($content){
  if(is_admin()||!get_option('dreminex_suite_classic_bridge',1)||!function_exists('is_checkout')||!is_checkout()||is_order_received_page()||(int)get_the_ID()!==(int)wc_get_page_id('checkout')||!has_block('woocommerce/checkout',$content))return $content;
  $active=false;foreach(['delivery_advance','mobile_payment','checkout_protection','checkout_experience'] as $id)if(self::on($id)){$active=true;break;}if(!$active)return $content;
  $replace=static function($blocks)use(&$replace){foreach($blocks as &$block){if(($block['blockName']??'')==='woocommerce/checkout')$block=['blockName'=>'core/shortcode','attrs'=>[],'innerBlocks'=>[],'innerHTML'=>'[woocommerce_checkout]','innerContent'=>['[woocommerce_checkout]']];elseif(!empty($block['innerBlocks']))$block['innerBlocks']=$replace($block['innerBlocks']);}return $blocks;};
  return serialize_blocks($replace(parse_blocks($content)));
 }
 public static function changed($name,$old,$new){if($name!=='dreminex_suite_modules'||!is_array($new))return;foreach(['contact_requests'=>'contact','order_management'=>'tracking'] as $id=>$kind)if(!empty($new[$id])&&empty($old[$id]))self::ensure_page($kind);}
 public static function ensure_page($kind){
  if(!in_array($kind,['contact','tracking'],true))return new WP_Error('kind','Unknown page kind.');
  $id=(int)get_option('dreminex_suite_'.$kind.'_page',0);if($id&&get_post_status($id)==='publish')return $id;
  $existing=get_posts(['post_type'=>'page','post_status'=>'publish','meta_key'=>'_dreminex_auto_page','meta_value'=>$kind,'numberposts'=>1]);
  if($existing)$id=$existing[0]->ID;else{$id=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>$kind==='contact'?'Support request':'Track your order','post_content'=>$kind==='contact'?'[dreminex_contact_evidence_form]':'[woocommerce_order_tracking]','meta_input'=>['_dreminex_auto_page'=>$kind]],true);}
  if(!is_wp_error($id))update_option('dreminex_suite_'.$kind.'_page',$id,false);return $id;
 }
 public static function menu(){
  add_submenu_page('dreminex-suite','Module control centre','Module control centre','manage_options','dreminex-suite-centre',[__CLASS__,'page']);
 }
 public static function panel($id){echo '<p><a class="button" href="'.esc_url(admin_url('admin.php?page=dreminex-suite-centre#module-'.$id)).'">Placement & all controls</a></p>';}
 public static function save(){
  if(!current_user_can('manage_options'))wp_die('Access denied.',403);check_admin_referer('dreminex_suite_experience');
  update_option('dreminex_suite_auto_newsletter',isset($_POST['auto_newsletter'])?1:0,false);update_option('dreminex_suite_classic_bridge',isset($_POST['classic_bridge'])?1:0,false);
  foreach(['contact','tracking'] as $kind)if(isset($_POST['prepare_'.$kind]))self::ensure_page($kind);
  if(class_exists('Dreminex_WC_Gateway_Mobile_Payment')){$s=(array)get_option('woocommerce_dreminex_mobile_payment_settings',[]);$s['enabled']=isset($_POST['api_enabled'])?'yes':'no';$s['title']=sanitize_text_field(wp_unslash($_POST['api_title']??'Mobile payment'));foreach(['full','delivery_advance','fixed_advance','percentage_advance'] as $mode)$s[$mode]=isset($_POST['api_mode_'.$mode])?'yes':'no';$s['fixed_advance_amount']=wc_format_decimal(max(0,(float)wp_unslash($_POST['api_fixed']??0)));$s['advance_percentage']=min(100,max(0,(float)wp_unslash($_POST['api_percent']??0)));update_option('woocommerce_dreminex_mobile_payment_settings',$s,false);}
  Dreminex_Suite_Cache::changed('all',true);wp_safe_redirect(admin_url('admin.php?page=dreminex-suite-centre&saved=1'));exit;
 }
 public static function page(){
  if(!current_user_can('manage_options'))return;echo '<div class="wrap dreminex-suite"><div class="ds-section-head"><div><span class="ds-eyebrow">SUITE SETTINGS</span><h1>Module control center</h1><p>Choose automatic placements and review the route used by store features.</p></div></div><div class="ds-route-note"><strong>Checkout route: '.esc_html(Dreminex_Suite_Routing::route()).'</strong><span>Live connections run on production; staging uses configured sandbox connections. If the API is unconfigured, Delivery advance can use its manual route.</span></div>';
  echo '<form class="ds-control-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_suite_experience">';wp_nonce_field('dreminex_suite_experience');
  echo '<div class="ds-control-grid"><fieldset><legend>Automatic placement</legend>';
  foreach(['auto_newsletter'=>'Place newsletter when the theme has no Suite placement','classic_bridge'=>'Use classic checkout when Suite checkout modules need it'] as $name=>$label)echo '<label class="ds-option"><input type="checkbox" name="'.$name.'" value="1" '.checked(get_option('dreminex_suite_'.$name,1),1,false).'> <span>'.esc_html($label).'</span></label>';
  echo '</fieldset><fieldset><legend>Useful pages</legend>';
  foreach(['contact'=>'Support','tracking'=>'Tracking'] as $kind=>$label)echo '<div class="ds-option-line"><label class="ds-option"><input type="checkbox" name="prepare_'.$kind.'" value="1"> <span>Prepare '.esc_html($label).' page if needed</span></label><a href="'.esc_url(Dreminex_Suite_Setup::page_url($kind)).'">View page ↗</a></div>';
  echo '<p class="description">Existing page content is preserved.</p></fieldset></div>';
  if(class_exists('Dreminex_WC_Gateway_Mobile_Payment')){$s=(array)get_option('woocommerce_dreminex_mobile_payment_settings',[]);echo '<fieldset class="ds-payment-control"><legend>Payment gateway</legend><label class="ds-option"><input type="checkbox" name="api_enabled" value="1" '.checked($s['enabled']??'yes','yes',false).'> <span>Enable configured API gateway</span></label><label class="ds-control-label">API checkout title <input name="api_title" value="'.esc_attr($s['title']??'Mobile payment').'"></label><p class="description">When Delivery advance is On, the API collects shipping and shipping tax; the product balance is due at delivery. Saved standalone modes apply when Delivery advance is Off.</p><div class="ds-payment-modes">';
   foreach(['full','delivery_advance','fixed_advance','percentage_advance'] as $mode)echo '<label class="ds-option"><input type="checkbox" name="api_mode_'.$mode.'" value="1" '.checked($s[$mode]??($mode==='full'?'yes':'no'),'yes',false).'> <span>'.esc_html(ucwords(str_replace('_',' ',$mode))).'</span></label>';
   echo '</div><div class="ds-control-grid"><label class="ds-control-label">Fixed advance <input type="number" name="api_fixed" min="0" step="0.01" value="'.esc_attr($s['fixed_advance_amount']??0).'"></label><label class="ds-control-label">Advance percentage <input type="number" name="api_percent" min="0" max="100" step="0.01" value="'.esc_attr($s['advance_percentage']??30).'"></label></div></fieldset>';
  }
  submit_button('Save setup');echo '</form><details class="ds-activity"><summary>Update protection <span>Show details</span></summary><p>Updates replace code and keep saved settings, module states, connections and business data. New defaults are added when absent. Fresh reset is a separate explicit action.</p><p>Last upgrade: '.esc_html(get_option('dreminex_suite_version',DREMINEX_SUITE_VERSION)).' · Schema '.esc_html((string)get_option('dreminex_suite_schema_version',0)).'</p></details><div class="ds-section-head"><div><h2>Feature placement</h2><p>Find each module’s state and its settings.</p></div></div><div class="ds-table-scroll"><table class="widefat striped"><thead><tr><th>Module</th><th>State / placement</th><th>Controls</th></tr></thead><tbody>';
  foreach(Dreminex_Suite::catalog() as $id=>$m){echo '<tr id="module-'.esc_attr($id).'"><td>'.esc_html($m[0]).'</td><td>'.(self::on($id)?'On':'Off').'<br>'.esc_html(self::placement($id)).'</td><td><a href="'.esc_url(admin_url('admin.php?page=dreminex-suite&module='.$id)).'">Settings & On/Off</a> | <a href="'.esc_url(admin_url('admin.php?page=dreminex-suite-settings&section=backup&module='.$id)).'">Backup / Reset</a>';if(!empty($m[5])&&self::on($id))echo ' | <a href="'.esc_url(admin_url('admin.php?page='.$m[5])).'">Manage records</a>';echo '</td></tr>';}
  echo '</tbody></table></div><p><a class="button" href="'.esc_url(admin_url('admin.php?page=dreminex-suite-settings&section=imports')).'">Imported modules</a></p><p class="description">Payment credentials, shipping rates and email-provider access are set by the store owner. Custom checkout replacements require compatibility checks.</p></div>';
 }
 public static function placement($id){if($id==='newsletter_offers')return 'Offers before footer; newsletter in existing placement or automatic footer';if($id==='contact_requests')return 'Assigned support page; prepared automatically on enable';if($id==='order_management')return 'WooCommerce Orders, email, dashboard and assigned tracking page';if($id==='mobile_payment'||$id==='delivery_advance')return 'Checkout; one API/manual delivery-advance route';return 'Native WooCommerce / WordPress hooks; module tab shows required setup';}
}
