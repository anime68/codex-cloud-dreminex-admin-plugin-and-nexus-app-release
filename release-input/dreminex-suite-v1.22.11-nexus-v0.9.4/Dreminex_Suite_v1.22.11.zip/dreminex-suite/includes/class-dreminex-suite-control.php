<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Administrative diagnostics and validated module controls. */
final class Dreminex_Suite_Control {
    private const CACHE = 'dreminex_suite_health_v2';

    public static function boot() {
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
        add_filter( 'admin_body_class', array( __CLASS__, 'admin_body_class' ) );
        add_action( 'admin_notices', array( __CLASS__, 'admin_navigation' ), 1 );
        add_action( 'admin_menu', array( __CLASS__, 'menu' ), 31 );
        add_action( 'admin_post_dreminex_suite_scan', array( __CLASS__, 'scan_action' ) );
        add_action( 'admin_post_dreminex_suite_setting', array( __CLASS__, 'save_setting' ) );
        add_action( 'admin_post_dreminex_suite_security', array( __CLASS__, 'save_security' ) );
        add_action( 'admin_post_dreminex_suite_notice', array( __CLASS__, 'dismiss' ) );
        add_action( 'admin_notices', array( __CLASS__, 'admin_notices' ) );
        add_action( 'dreminex_suite_health_scan', array( __CLASS__, 'scan' ) );
        add_action( 'upgrader_process_complete', array( __CLASS__, 'after_upgrade' ), 10, 2 );
        add_action( 'activated_plugin', array( __CLASS__, 'queue_scan' ) );
        add_action( 'deactivated_plugin', array( __CLASS__, 'queue_scan' ) );
        add_action( 'init', array( __CLASS__, 'schedule' ) );
        register_shutdown_function(array(__CLASS__, 'record_fatal'));
        add_action('woocommerce_checkout_order_processed',array(__CLASS__,'observe_checkout'));
        add_action('woocommerce_store_api_checkout_order_processed',array(__CLASS__,'observe_checkout'));
        add_filter('do_shortcode_tag',array(__CLASS__,'observe_shortcode'),10,2); 
        add_action( 'dreminex_suite_module_panel', array( __CLASS__, 'module_panel' ) );
    }

    private static function observe($keys) {
        $enabled=(array)get_option('dreminex_suite_modules',array());
        $activity=(array)get_option('dreminex_suite_activity',array()); $changed=false;
        foreach($keys as $key) if(!empty($enabled[$key]) && ($activity[$key] ?? 0)<time()-HOUR_IN_SECONDS) { $activity[$key]=time(); $changed=true; }
        if($changed) update_option('dreminex_suite_activity',$activity,false);
    }
    public static function observe_checkout() { self::observe(array('delivery_advance','checkout_protection','checkout_experience','order_management')); }
    public static function observe_shortcode($output,$tag) {
        $map=array('show_ip'=>'checkout_protection','dreminex_newsletter_heading'=>'newsletter_offers','dreminex_newsletter_signup'=>'newsletter_offers','dreminex_active_offers'=>'newsletter_offers','dreminex_contact_evidence_form'=>'contact_requests');
        if(isset($map[$tag])) self::observe(array($map[$tag])); return $output;
    }

    public static function record_fatal() {
        $error = error_get_last();
        if (!$error || !in_array($error['type'], array(E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR), true)) return;
        $file = wp_normalize_path($error['file']);
        $content = wp_normalize_path(WP_CONTENT_DIR) . '/';
        $component = strpos($file,$content) === 0 ? substr($file,strlen($content)) : 'WordPress/core or server';
        // Store component evidence only; raw error messages can contain customer data or secrets.
        update_option('dreminex_suite_last_fatal', array('time'=>time(),'component'=>substr($component,0,250),'line'=>(int)$error['line'],'type'=>(int)$error['type']), false);
        delete_option(self::CACHE);
    }

    public static function admin_assets() {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ( ! self::is_dreminex_admin_screen( $screen ) ) return;
        wp_enqueue_style('dreminex-suite-admin', plugins_url('../assets/suite-admin.css', __FILE__), array(), DREMINEX_SUITE_VERSION . '-ui4');
        wp_enqueue_script('dreminex-suite-admin', plugins_url('../assets/suite-admin.js', __FILE__), array(), DREMINEX_SUITE_VERSION . '-ui3', true);
        if(isset($_GET['page']) && sanitize_key(wp_unslash($_GET['page']))==='dreminex-supplier-monitor')
            wp_enqueue_style('dreminex-supplier-monitor',plugins_url('../assets/supplier-monitor.css',__FILE__),array('dreminex-suite-admin'),DREMINEX_SUITE_VERSION);
        if ( isset( $_GET['page'], $_GET['module'] ) &&
             sanitize_key( wp_unslash( $_GET['page'] ) ) === 'dreminex-suite' &&
             sanitize_key( wp_unslash( $_GET['module'] ) ) === 'registration_email' ) wp_enqueue_media();
    }

    /** Keep the Suite design system limited to screens owned by this plugin. */
    private static function is_dreminex_admin_screen( $screen ) {
        if ( ! is_object( $screen ) ) return false;
        if ( strpos( (string) ( $screen->id ?? '' ), 'dreminex' ) !== false ) return true;
        if ( strpos( (string) ( $screen->post_type ?? '' ), 'dreminex' ) === 0 ) return true;
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        return strpos( $page, 'dreminex' ) === 0;
    }

    public static function admin_body_class( $classes ) {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ( self::is_dreminex_admin_screen( $screen ) ) $classes .= ' dreminex-plugin-admin';
        return $classes;
    }

    /** Consistent way home from the independently registered Suite admin pages. */
    public static function admin_navigation() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        if ( ! self::is_dreminex_admin_screen( $screen ) ) return;
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( in_array( $page, array( 'dreminex-suite', 'dreminex-suite-modules' ), true ) ) return;
        $links = array(
            'dreminex-suite' => 'Overview',
            'dreminex-suite-modules' => 'Modules',
            'dreminex-suite&module=storefront_design' => 'Storefront design',
            'dreminex-suite-centre' => 'Control center',
            'dreminex-suite-settings' => 'Settings',
        );
        echo '<nav class="ds-global-nav" aria-label="Dreminex Suite navigation"><strong>Dreminex Suite</strong>';
        foreach ( $links as $route => $label ) {
            $selected = $page !== '' && $page === $route;
            echo '<a' . ( $selected ? ' aria-current="page"' : '' ) . ' href="' . esc_url( admin_url( 'admin.php?page=' . $route ) ) . '">' . esc_html( $label ) . '</a>';
        }
        echo '</nav>';
    }

    public static function tr( $en, $bn ) {
        return $en;
    }

    public static function module_label( $key, $en ) {
        $bn = array(
            'delivery_advance' => 'Delivery Advance & Wallet', 'phone_validation' => 'Phone number validation',
            'duplicate_checkout' => 'দুই ঘণ্টার IP বিরতি', 'receipt_message' => 'Thank-you বার্তা',
            'receipt_ip_warning' => 'রসিদের IP বার্তা', 'customer_history' => 'Customer history',
            'partial_checkout' => 'অসম্পূর্ণ checkout', 'admin_order_alert' => 'ড্যাশবোর্ডে order alert',
            'order_email_notification' => 'মালিকের order email', 'order_statuses' => 'Order status ও bulk actions',
            'customer_order_limit' => 'Browser order limit', 'checkout_error_popup' => 'Checkout error popup',
            'order_tracking' => 'Courier tracking', 'newsletter_offers' => 'Newsletter ও offers',
            'contact_requests' => 'Contact request ও media',
            'password_reset' => 'অন্য account-এর password reset', 'registration_email' => 'Account ডিজাইন ও registration',
            'advanced_optimizations' => 'Advanced Optimizations', 'ai_product_publisher' => 'AI Product Publisher', 'storefront_design' => 'স্টোরফ্রন্ট ডিজাইন',
            'supplier_monitor' => 'Supplier Monitor', 'checkout_protection'=>'Checkout নিরাপত্তা ও recovery',
            'checkout_experience'=>'Checkout experience', 'order_management'=>'Order management',
        );
        return self::tr( $en, $bn[ $key ] ?? $en );
    }

    public static function module_summary( $key, $en ) {
        $bn = array(
            'delivery_advance' => 'Advance/full payment, customer wallet, promotional credit, withdrawals and product-only COD',
            'phone_validation' => 'বাংলাদেশি মোবাইল নম্বর যাচাই', 'duplicate_checkout' => 'Pending/On hold অর্ডারের IP-ভিত্তিক বিরতি',
            'receipt_message' => 'Order received পেজের বার্তা', 'receipt_ip_warning' => 'Order IP বার্তা ও shortcode',
            'customer_history' => 'Admin order history এবং completed ratio', 'partial_checkout' => 'সম্মতিসাপেক্ষে ৪৮ ঘণ্টার private checkout record',
            'admin_order_alert' => 'Admin-এ সাম্প্রতিক order দেখায়', 'order_email_notification' => 'নতুন অর্ডারের বিস্তারিত email',
            'order_statuses' => 'Order-এর manual status ও bulk পরিবর্তন', 'customer_order_limit' => 'দৈনিক ও আগের দিনের order যাচাই',
            'checkout_error_popup' => 'Brand অনুযায়ী checkout error dialog', 'order_tracking' => 'Courier reference ও customer tracking',
            'newsletter_offers' => 'Subscription, confirmation, coupon ও offers', 'contact_requests' => 'Contact form, private media ও reply',
            'ai_product_publisher' => 'AI দিয়ে Draft product, variation, SKU, stock ও label brand', 'password_reset' => 'অন্য account-এ login থাকলেও verified reset link',
            'registration_email' => 'Account dashboard, Orders, Downloads, Addresses, Profile ও registration', 'advanced_optimizations' => 'প্রয়োজন অনুযায়ী Suite module ও asset লোড',
            'storefront_design' => 'Homepage, shop, product, cart, checkout এবং customer page ডিজাইন',
            'checkout_protection'=>'Phone, IP, browser limit, receipt privacy এবং consented unfinished checkout এক জায়গায়',
            'checkout_experience'=>'Thank-you content এবং accessible error popup একসাথে',
            'order_management'=>'Customer history, alert, email, status ও courier tracking একসাথে',
        );
        return self::tr( $en, $bn[ $key ] ?? $en );
    }

    public static function module_instructions( $key, $en ) {
        $bn = array(
            'delivery_advance' => 'Configure an official provider profile for automatic verification or use the manual-review fallback. A TXID alone is never proof of payment.',
            'phone_validation' => 'WooCommerce checkout চালু রেখে সঠিক ও ভুল বাংলাদেশি নম্বর দিয়ে staging-এ পরীক্ষা করুন।',
            'duplicate_checkout' => 'Pending/On hold অর্ডারে একই IP-র cooldown পরীক্ষা করুন; shared network-এ ভিন্ন গ্রাহকও প্রভাবিত হতে পারেন।',
            'receipt_message' => 'Test order-এর thank-you পেজে বার্তার অবস্থান যাচাই করুন।',
            'receipt_ip_warning' => 'Privacy notice দেখে order receipt ও [show_ip] shortcode পরীক্ষা করুন।',
            'customer_history' => 'WooCommerce Orders-এ কলাম দেখুন; এটি শুধু আপনার দোকানের billing phone অনুযায়ী হিসাব।',
            'partial_checkout' => 'Checkout-এ consent On/Off পরীক্ষা করুন; নাম, ফোন, ঠিকানা ও IP ৪৮ ঘণ্টা পরে cleanup হচ্ছে কি না দেখুন।',
            'admin_order_alert' => 'Dashboard-এ সাম্প্রতিক নতুন order দেখুন; test order ছাড়া delivery নিশ্চিত ধরে নেবেন না।',
            'order_email_notification' => 'Recipient ও SMTP পরীক্ষা করুন; test order-এ email এসেছে কি না নিশ্চিত করুন।',
            'order_statuses' => 'WooCommerce Orders-এ test order-এর bulk status পরিবর্তন পরীক্ষা করুন।',
            'customer_order_limit' => 'Browser cookie বদলালে সীমা এড়ানো সম্ভব; staging-এ daily rule পরীক্ষা করুন।',
            'checkout_error_popup' => 'Validation error দিয়ে mobile ও keyboard-এ popup পরীক্ষা করুন।',
            'order_tracking' => 'Real consignment reference দিয়ে tracking page ও email পরীক্ষা করুন।',
            'newsletter_offers' => 'Consent, email confirmation, coupon claim ও expiry disposable account-এ পরীক্ষা করুন।',
            'contact_requests' => 'Form, private media access ও reply email পরীক্ষা করুন।',
            'ai_product_publisher' => 'Novamira OAuth চালু রাখুন। আগে catalog ও media যাচাই করে Draft তৈরি করুন, তারপর variation ও draft-audit চালান।',
            'password_reset' => 'Disposable account-এ valid/invalid reset link পরীক্ষা করুন।',
            'registration_email' => 'Staging-এ লগইন করা account-এর Dashboard, Orders, Downloads, Addresses ও Profile content দেখুন। Disposable account register করে mail, confirmation এবং expiry পরীক্ষা করুন।',
            'advanced_optimizations' => 'Production-এ asset optimization On রাখুন; সমস্যা খুঁজতে Off করুন। অন্য plugin-এর asset সরানো হয় না।',
            'checkout_protection'=>'প্রতিটি protection আলাদাভাবে On/Off করে staging checkout-এ valid ও blocked দুই অবস্থাই পরীক্ষা করুন।',
            'checkout_experience'=>'Thank-you page এবং keyboard/mobile checkout error dialog staging-এ পরীক্ষা করুন।',
            'order_management'=>'Test order দিয়ে history, dashboard alert, owner email, status ও tracking আলাদাভাবে যাচাই করুন।',
        );
        return self::tr( $en, $bn[ $key ] ?? $en );
    }

    public static function menu() {
        add_submenu_page( 'dreminex-suite', 'Suite Site Health', 'Site Health', 'manage_options', 'dreminex-suite-health', array( __CLASS__, 'health_page' ) );
        add_submenu_page( 'dreminex-suite', 'Settings', 'Settings', 'manage_options', 'dreminex-suite-settings', array( 'Dreminex_Suite', 'settings_hub_page' ) );
    }

    public static function schedule() {
        if ( ! wp_next_scheduled( 'dreminex_suite_health_scan' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'dreminex_suite_health_scan' );
        }
    }

    public static function queue_scan() {
        delete_option( self::CACHE );
        if ( ! wp_next_scheduled( 'dreminex_suite_health_scan_once' ) ) {
            wp_schedule_single_event( time() + 30, 'dreminex_suite_health_scan_once' );
        }
    }

    public static function after_upgrade( $upgrader, $extra ) {
        if ( in_array( $extra['type'] ?? '', array( 'plugin', 'theme', 'core' ), true ) ) self::queue_scan();
    }

    public static function scan() {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $inventory = get_plugins();
        $active = (array) get_option( 'active_plugins', array() );
        if ( is_multisite() ) $active = array_unique( array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) ) );
        $findings = array();
        $add = static function ( $id, $severity, $title, $fix ) use ( &$findings ) {
            $findings[ $id ] = array( 'severity' => $severity, 'title' => $title, 'fix' => $fix );
        };
        foreach ( $active as $entry ) {
            if ( ! isset( $inventory[ $entry ] ) || ! is_file( WP_PLUGIN_DIR . '/' . $entry ) ) {
                $add( 'missing_plugin_' . md5( $entry ), 'critical', 'Active plugin entry file missing: ' . $entry, 'Restore the plugin from a trusted backup, then review Plugins.' );
            }
        }
        $updates = get_site_transient( 'update_plugins' );
        $available = is_object( $updates ) && isset( $updates->response ) && is_array( $updates->response ) ? $updates->response : array();
        foreach ( $available as $entry => $info ) {
            $name = $inventory[ $entry ]['Name'] ?? $entry;
            $add( 'plugin_update_' . md5( $entry ), 'warning', 'Plugin update available: ' . $name, 'Review the changelog and update from Plugins after a backup.' );
        }
        if ( ! is_object( $updates ) || empty( $updates->last_checked ) || time() - (int) $updates->last_checked > 3 * DAY_IN_SECONDS ) {
            $add( 'plugin_update_unknown', 'unknown', 'Plugin update data is stale or unavailable', 'Open Dashboard → Updates and check the update connection.' );
        }
        $core=get_site_transient('update_core');
        if(is_object($core) && !empty($core->updates)) foreach($core->updates as $release) if(($release->response ?? '')==='upgrade') { $add('core_update','warning','WordPress core update available','Review Dashboard → Updates and test the upgrade after a backup.'); break; }
        if(!is_file(get_template_directory().'/style.css')) $add('theme_missing','critical','Active theme stylesheet is missing','Restore the active theme from a trusted package.');
        $memory=wp_convert_hr_to_bytes(ini_get('memory_limit'));
        if($memory>0 && $memory<128*1024*1024) $add('memory_low','warning','PHP memory limit is below 128 MB','Review hosting resources and WooCommerce system status.');
        $themes = get_site_transient( 'update_themes' );
        if ( is_object( $themes ) && isset( $themes->response ) && is_array( $themes->response ) ) {
            foreach ( $themes->response as $stylesheet => $info ) {
                $add( 'theme_update_' . md5( $stylesheet ), 'warning', 'Theme update available: ' . $stylesheet, 'Review the theme update on staging and back up before updating.' );
            }
        }
        if ( ! class_exists( 'WooCommerce' ) ) $add( 'woocommerce_missing', 'critical', 'WooCommerce is not active', 'Restore WooCommerce; Suite commerce modules require it.' );
        $fatal = get_option('dreminex_suite_last_fatal');
        if (is_array($fatal) && ($fatal['time'] ?? 0) > time() - 7*DAY_IN_SECONDS) $add('fatal_'.md5(wp_json_encode($fatal)), 'critical', 'Recent PHP fatal error: '.($fatal['component'] ?? 'Unknown component'), 'Line '.(int)($fatal['line'] ?? 0).'. Review WordPress recovery email and hosting error logs. This records errors only after Suite has loaded.');
        $values = (array) get_option( 'dreminex_suite_modules', array() );
        $since=(int)get_option('dreminex_suite_observation_since',0);
        if(!$since) { $since=time();update_option('dreminex_suite_observation_since',$since,false); }
        $activity=(array)get_option('dreminex_suite_activity',array());
        if($since<time()-30*DAY_IN_SECONDS) foreach(array('delivery_advance','checkout_protection','checkout_experience','order_management','newsletter_offers','contact_requests') as $key) if(!empty($values[$key]) && ($activity[$key] ?? $since)<time()-30*DAY_IN_SECONDS) $add('unused_'.$key,'info','No observed related workflow in 30 days: '.$key,'Review this module tab and decide whether to keep it enabled. Lack of observed activity does not prove a module is broken; it will not be disabled automatically.');
        if(!empty($values['delivery_advance']) && (!function_exists('dreminex_advance_wallets') || !dreminex_advance_wallets())) $add('wallet_not_configured','critical','No external payment receiver is configured','Add a receiver for external payments, or keep the customer wallet available for fully covered orders.');
        $checkout=function_exists('wc_get_page_id')?wc_get_page_id('checkout'):0;
        $classic=array('delivery_advance','mobile_payment','checkout_protection','checkout_experience');
        if($checkout>0 && has_block('woocommerce/checkout',$checkout) && !get_option('dreminex_suite_classic_bridge',1)) foreach($classic as $key) if(!empty($values[$key])) $add('blocks_'.$key,'warning','Classic checkout required: '.$key,'Use [woocommerce_checkout] instead of the Checkout block, or disable this module.');
        if(!empty($values['delivery_advance']) && function_exists('get_woocommerce_currency') && get_woocommerce_currency()!=='BDT') $add('manual_currency','warning','Manual wallet advance requires BDT','Disable the manual wallet module for other currencies.');
        foreach(Dreminex_Suite_Imports::all() as $key=>$item) if(!empty($item['last_error'])) $add('import_error_'.$key,'warning','Imported module disabled: '.$key,'Open Imported modules: '.$item['last_error']);
        $errors = (array) get_option( 'dreminex_suite_errors', array() );
        foreach ( $errors as $key => $error ) $add( 'module_error_' . sanitize_key( $key ), 'critical', 'Module load error: ' . $key, 'Open its Suite module tab and review the recorded PHP error. Restore the previous version if needed.' );
        if ( ! empty( $values['delivery_advance'] ) && class_exists( 'WooCommerce' ) && function_exists( 'WC' ) && WC()->payment_gateways() ) {
            $gateways = WC()->payment_gateways()->payment_gateways();
            if ( ! isset( $gateways['bacs'] ) || $gateways['bacs']->enabled !== 'yes' ) $add( 'bacs_disabled', 'critical', 'Delivery advance module is on but BACS is disabled', 'Enable the configured manual bank-transfer gateway in WooCommerce → Payments, or turn this Suite module off.' );
        }
        if(!empty($values['mobile_payment']) && class_exists('Dreminex_Payments_Config_Admin')) {
            $profiles=(new Dreminex_Payments_Connection_Profile_Repository())->all();$ready=0;
            $expected_environment=Dreminex_Payments_Connection_Profile_Repository::expected_environment();
            foreach($profiles as $id=>$profile) if(!empty($profile['enabled'])) {
                $status=Dreminex_Payments_Config_Admin::status($id,$profile);
                if(($profile['health_status']??'')==='Healthy' && ($profile['environment']??'sandbox')===$expected_environment && ($provider=Dreminex_Payments_Provider_Registry::get($profile['provider_id']??'')) && $provider->is_profile_configured($id))$ready++;
                else $add('mobile_profile_'.md5($id),'warning','Payment provider connection needs setup: '.($profile['profile_name']??$id),$status.'. Open Dreminex Payments → Edit / API keys or Test connection.');
            }
            if(!$ready)$add('mobile_not_ready','info','No authenticated payment provider is available for the '.esc_html($expected_environment).' connection','Open Dreminex Payments and configure an approved '.esc_html($expected_environment).' merchant connection. Production accepts live profiles; non-production accepts sandbox profiles.');
        }
        if ( ! empty( $values['order_management'] ) && self::setting('order_management','owner_email_enabled',1) ) {
            $recipient = self::setting( 'order_management', 'recipient', get_option( 'admin_email' ) );
            if ( ! is_email( $recipient ) ) $add( 'owner_email_invalid', 'critical', 'Owner order email recipient is invalid', 'Enter a valid address in the Owner order email module tab.' );
        }
        if ( ! empty( $values['checkout_protection'] ) && self::setting('checkout_protection','partial_checkout_enabled',1) && ! wp_next_scheduled( 'dreminex_purge_partial_checkouts' ) ) $add( 'partial_cleanup_missing', 'warning', 'Partial checkout cleanup is not scheduled', 'Open Checkout Protection and review WP-Cron; consented records may persist longer than intended.' );
        if ( ! wp_next_scheduled( 'dreminex_suite_health_scan' ) ) $add( 'cron_missing', 'warning', 'Suite health scan is not scheduled', 'Visit the Suite dashboard and review WP-Cron configuration.' );
        if ( ! is_ssl() ) $add( 'https_missing', 'critical', 'Admin request is not using HTTPS', 'Check the site URL, SSL certificate and reverse proxy configuration.' );
        if ( defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY ) $add( 'debug_display', 'warning', 'PHP debug output may be visible', 'Disable WP_DEBUG_DISPLAY on the live site after troubleshooting.' );
        $disk = @disk_free_space( WP_CONTENT_DIR );
        if ( $disk !== false && $disk < 200 * 1024 * 1024 ) $add( 'disk_low', 'warning', 'Less than 200 MB free on the content filesystem', 'Increase available disk space and check backup/storage usage.' );
        $last = get_option( 'dreminex_suite_last_scan_alert' );
        if ( is_array( $last ) && ! empty( $last['time'] ) ) $add( 'blocked_package_' . md5( wp_json_encode( $last ) ), 'warning', 'An install package was blocked by the limited pattern scanner', 'Review the package with a trusted security tool. A pattern match is not proof of malicious intent.' );
        $report = array( 'time' => time(), 'findings' => $findings, 'plugins' => count( $inventory ), 'active' => count( $active ), 'modules_on' => count( array_filter( $values ) ), 'limits' => 'Checks do not prove that installed code is safe; vulnerability intelligence is not connected.' );
        update_option( self::CACHE, $report, false );
        self::notify_critical( $report );
        return $report;
    }

    private static function notify_critical( $report ) {
        $critical = array_filter( $report['findings'], static function ( $f ) { return $f['severity'] === 'critical'; } );
        if ( ! $critical ) return;
        $fingerprint = hash( 'sha256', wp_json_encode( $critical ) );
        if ( get_transient( 'dreminex_suite_alert_' . $fingerprint ) ) return;
        set_transient( 'dreminex_suite_alert_' . $fingerprint, 1, DAY_IN_SECONDS );
        $lines = array( 'Dreminex Suite detected critical health findings:', '' );
        foreach ( $critical as $finding ) $lines[] = $finding['title'] . ' — ' . $finding['fix'];
        $lines[] = admin_url( 'admin.php?page=dreminex-suite-health' );
        wp_mail( get_option( 'admin_email' ), 'Dreminex Suite: critical site health warning', implode( "\n", $lines ) );
    }

    public static function report() {
        $report = get_option( self::CACHE );
        if ( ! is_array( $report ) || empty( $report['time'] ) || time() - $report['time'] > HOUR_IN_SECONDS ) return self::scan();
        return $report;
    }

    public static function health_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $r = self::report();
        echo '<div class="wrap dreminex-health"><h1>' . esc_html( self::tr( 'Dreminex Site Health', 'Dreminex Site Health — সাইটের অবস্থা' ) ) . '</h1><p>' . esc_html( self::tr( 'Last scan:', 'সর্বশেষ পরীক্ষা:' ) ) . ' ' . esc_html( wp_date( 'Y-m-d H:i', $r['time'] ) ) . ' · ' . esc_html( $r['plugins'] ) . ' plugins installed · ' . esc_html( $r['active'] ) . ' active · ' . esc_html( $r['modules_on'] ) . ' Suite modules enabled</p>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="dreminex_suite_scan">'; wp_nonce_field( 'dreminex_suite_scan' ); submit_button( self::tr( 'Run checks now', 'এখন পরীক্ষা করুন' ), 'primary', 'submit', false ); echo '</form>';
        echo '<p class="description">' . esc_html( self::tr( 'Installed plugin behavior and unknown vulnerabilities cannot be fully verified here. Unknown does not mean safe.', 'সব plugin-এর কাজ বা অজানা দুর্বলতা এখানে সম্পূর্ণ যাচাই করা যায় না। Unknown মানে নিরাপদ নয়।' ) ) . '</p>';
        if ( ! $r['findings'] ) echo '<div class="notice notice-success inline"><p>' . esc_html( self::tr( 'No issues detected by the available checks.', 'উপলব্ধ পরীক্ষায় কোনো সমস্যা পাওয়া যায়নি।' ) ) . '</p></div>';
        foreach ( $r['findings'] as $id => $f ) {
            if ( self::is_dismissed( $id, $f ) ) continue;
            $color = $f['severity'] === 'critical' ? '#d63638' : ( $f['severity'] === 'warning' ? '#dba617' : '#64748b' );
            echo '<div style="background:#fff;border:1px solid #c3c4c7;border-left:4px solid ' . esc_attr( $color ) . ';margin:12px 0;padding:14px;max-width:1000px"><h2>' . esc_html( strtoupper( $f['severity'] ) . ': ' . $f['title'] ) . '</h2><p>' . esc_html( $f['fix'] ) . '</p>'; self::dismiss_form( $id, $f ); echo '</div>';
        }
        echo '<p><a href="' . esc_url( admin_url( 'site-health.php' ) ) . '">WordPress Site Health →</a></p></div>';
    }

    public static function scan_action() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Access denied.' );
        check_admin_referer( 'dreminex_suite_scan' ); self::scan();
        wp_safe_redirect( admin_url( 'admin.php?page=dreminex-suite-health&scanned=1' ) ); exit;
    }

    public static function admin_notices() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $screen = get_current_screen(); if ( ! $screen || strpos( $screen->id, 'dreminex-suite' ) === false ) return;
        foreach ( self::report()['findings'] as $id => $f ) {
            if ( $f['severity'] !== 'critical' || self::is_dismissed( $id, $f ) ) continue;
            echo '<div class="notice notice-error"><p><strong>' . esc_html( $f['title'] ) . '</strong> — ' . esc_html( $f['fix'] ) . '</p>'; self::dismiss_form( $id, $f ); echo '</div>';
        }
    }

    private static function fingerprint( $id, $f ) { return substr( hash( 'sha256', $id . '|' . $f['severity'] . '|' . $f['title'] ), 0, 20 ); }
    private static function is_dismissed( $id, $f ) { return (int) get_user_meta( get_current_user_id(), 'dreminex_notice_' . self::fingerprint( $id, $f ), true ) > time() - 7 * DAY_IN_SECONDS; }
    private static function dismiss_form( $id, $f ) {
        if ( self::is_dismissed( $id, $f ) ) return;
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="dreminex_suite_notice"><input type="hidden" name="notice_id" value="' . esc_attr( $id ) . '"><input type="hidden" name="fingerprint" value="' . esc_attr( self::fingerprint( $id, $f ) ) . '">'; wp_nonce_field( 'dreminex_suite_notice_' . $id ); echo '<button class="button" type="submit" aria-label="Dismiss this notice">× ' . esc_html( self::tr( 'Dismiss', 'বন্ধ করুন' ) ) . '</button></form>';
    }
    public static function dismiss() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Access denied.' );
        $id = sanitize_key( wp_unslash( $_POST['notice_id'] ?? '' ) ); check_admin_referer( 'dreminex_suite_notice_' . $id );
        $report = self::report(); if ( isset( $report['findings'][ $id ] ) ) {
            $fp = self::fingerprint( $id, $report['findings'][ $id ] );
            if ( hash_equals( $fp, sanitize_text_field( wp_unslash( $_POST['fingerprint'] ?? '' ) ) ) ) update_user_meta( get_current_user_id(), 'dreminex_notice_' . $fp, time() );
        }
        wp_safe_redirect( wp_get_referer() ?: admin_url( 'admin.php?page=dreminex-suite-health' ) ); exit;
    }

    public static function settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        echo '<div class="wrap"><h1>Language</h1>';
        if ( isset($_GET['saved']) ) echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
        echo '<h2>Administration language</h2>';
        echo '<p><strong>English</strong></p><p>All Dreminex Suite administration and Nexus management surfaces use English. Customer-facing checkout, receipt and storefront messages keep their saved language and content.</p>';
        echo '<h2>Install safety and sign-in</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="dreminex_suite_security">'; wp_nonce_field( 'dreminex_suite_security' );
        echo '<p><label><input type="checkbox" name="scan" value="1" ' . checked( (int) get_option( 'dreminex_suite_preinstall_scan', 1 ), 1, false ) . '> ' . esc_html( self::tr( 'Screen PHP syntax and two high-risk code patterns during WordPress plugin/theme installs and upgrades', 'WordPress-এ plugin/theme install বা update করার সময় PHP syntax এবং ঝুঁকিপূর্ণ code-এর দুটি pattern পরীক্ষা করুন' ) ) . '</label></p>';
        echo '<p class="description">' . esc_html( self::tr( 'This limited check cannot determine whether a package is safe. Review false positives with a trusted security professional.', 'এই সীমিত পরীক্ষা কোনো package নিরাপদ কি না নিশ্চিত করতে পারে না। package block হলে trusted security professional-এর সঙ্গে false positive যাচাই করুন।' ) ) . '</p>';
        echo '<p><label><input type="checkbox" name="admin_signin" value="1" ' . checked((int)get_option('dreminex_suite_admin_signin',1),1,false) . '> Require the Suite administrator sign-in page for customer sessions</label></p><p><a href="'.esc_url(Dreminex_Suite_Access::login_url()).'">Administrator sign-in</a></p>';
        submit_button( 'Save safety settings' ); echo '</form></div>';
    }

    public static function save_security() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Access denied.' );
        check_admin_referer( 'dreminex_suite_security' );
        update_option( 'dreminex_suite_preinstall_scan', isset( $_POST['scan'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['scan'] ) ) ? 1 : 0, false );
        update_option('dreminex_suite_admin_signin',isset($_POST['admin_signin'])?1:0,false);
        wp_safe_redirect( admin_url( 'admin.php?page=dreminex-suite-settings&saved=security' ) ); exit;
    }

    private static function config( $key ) {
        $defs = array(
            'delivery_advance' => array(
                'wallet_bkash_number'=>array('bKash receiving number','text',''),'wallet_bkash_type'=>array('bKash account type','wallet_type','personal'),'wallet_bkash_enabled'=>array('Enable bKash','checkbox',1),
                'wallet_nagad_number'=>array('Nagad receiving number','text',''),'wallet_nagad_type'=>array('Nagad account type','wallet_type','personal'),'wallet_nagad_enabled'=>array('Enable Nagad','checkbox',1),
                'wallet_rocket_number'=>array('Rocket receiving number','text',''),'wallet_rocket_type'=>array('Rocket account type','wallet_type','personal'),'wallet_rocket_enabled'=>array('Enable Rocket','checkbox',1),
                'wallet_upay_number'=>array('Upay receiving number','text',''),'wallet_upay_type'=>array('Upay account type','wallet_type','personal'),'wallet_upay_enabled'=>array('Enable Upay','checkbox',0),
                'msg_wallet_currency'=>array('Checkout popup: currency message','textarea','Manual mobile-wallet advance requires BDT. Choose another payment method or contact the store.'),
                'msg_wallet_unconfigured'=>array('Checkout popup: wallet setup message','textarea','Manual payment is not configured. Please contact the store.'),
                'msg_method'=>array('Checkout popup: wallet selection message','textarea','Select one of the configured wallet providers for the delivery charge.'),
                'msg_txid'=>array('Checkout popup: transaction ID message','textarea','Enter the valid Payment transaction ID (5–40 letters, numbers or hyphens).'),
                'msg_shipping'=>array('Checkout popup: delivery method message','textarea','Select an available delivery method before paying its charge.'),
                'txid_unique'=>array('Reject a transaction ID already used by another order','checkbox',1),
                'gateway_title'=>array('Checkout payment title','text','Delivery Advance & Wallet'),
                'gateway_description'=>array('Checkout payment description','textarea','Pay the delivery charge now to confirm the order, then pay the product balance at delivery. You may also pay the full order now.'),
                'wallet_enabled'=>array('Customer wallet','checkbox',1),
                'wallet_min_topup'=>array('Minimum wallet top-up','number',10,1,100000),
                'wallet_min_withdrawal'=>array('Minimum withdrawal request','number',10,1,100000),
            ),
            'checkout_protection'=>array(
                'phone_enabled'=>array('Phone number validation','checkbox',1),
                'ip_cooldown_enabled'=>array('IP cooldown','checkbox',1),
                'receipt_ip_enabled'=>array('Receipt IP notice and shortcode','checkbox',1),
                'browser_limit_enabled'=>array('Browser order limit','checkbox',1),
                'partial_checkout_enabled'=>array('Consented unfinished checkout','checkbox',1),
                'cooldown_hours'=>array('IP cooldown (hours)','number',2,1,24),
                'daily_limit'=>array('Daily browser order threshold','number',2,1,5),
                'retention_hours'=>array('Unfinished checkout retention (hours)','number',48,24,168),
                'ip_display'=>array('Receipt IP display','select','masked',array('masked'=>'Masked IP (recommended)','full'=>'Full IP','hidden'=>'Notice without IP')),
                'msg_phone_invalid'=>array('Invalid phone message','textarea','Enter a valid Bangladesh mobile number (01XXXXXXXXX).'),
                'msg_ip_cooldown'=>array('Repeat order message (%s = hours)','textarea','An order was placed from this internet connection within the last %s hours. Try again after the waiting period, or contact us for help.'),
                'msg_device_missing'=>array('Browser check message','textarea','This browser could not be verified. Enable cookies, reload this page and try placing your order.'),
                'msg_previous_unfinished'=>array('Unfinished earlier order message','textarea','An order from a previous day in this browser is still not Completed. Wait until it is completed, or contact us to check its status.'),
                'msg_today_unfinished'=>array('Daily order limit message','textarea','This browser has reached its order threshold while an earlier order is unfinished. Wait for completion or contact us.'),
                'msg_ip_warning'=>array('Order IP notice ({ip} = displayed IP)','textarea','The connection IP has been recorded for order security: {ip}. We may contact you to verify your identity or payment.'),
            ),
            'checkout_experience'=>array(
                'receipt_enabled'=>array('Thank-you message','checkbox',1),
                'popup_enabled'=>array('Checkout error popup','checkbox',1),
                'msg_receipt'=>array('Thank-you message text','textarea','Your order has been received. We will verify the payment or delivery advance and contact you to confirm the order.'),
                'title'=>array('Error popup heading','text','Your order cannot be placed yet'),
                'message'=>array('Error popup intro (optional)','textarea',''),
                'button_text'=>array('Error popup close button','text','Understood'),
            ),
            'order_management'=>array(
                'history_enabled'=>array('Customer order history','checkbox',1),
                'admin_alert_enabled'=>array('Dashboard order alert','checkbox',1),
                'owner_email_enabled'=>array('Owner order email','checkbox',1),
                'statuses_enabled'=>array('Workflow statuses and bulk actions','checkbox',1),
                'tracking_enabled'=>array('Courier tracking','checkbox',1),
                'recipient'=>array('Owner alert email','email',get_option('admin_email')),
            ),
            'duplicate_checkout' => array(
                'cooldown_hours' => array( 'IP cooldown (hours)', 'number', 2 ),
                'msg_ip_cooldown' => array( 'Checkout popup: repeat order message (%s = hours)', 'textarea', 'An order was placed from this internet connection within the last %s hours. Try again after the waiting period, or contact us for help.' ),
            ),
            'phone_validation' => array(
                'msg_phone_invalid' => array( 'Checkout popup: invalid phone message', 'textarea', 'Enter a valid 11-digit Bangladesh mobile number (01XXXXXXXXX).' ),
            ),
            'customer_order_limit' => array(
                'msg_device_missing' => array( 'Checkout popup: browser check message', 'textarea', 'This browser could not be verified. Enable cookies, reload this page and try placing your order.' ),
                'msg_previous_unfinished' => array( 'Checkout popup: unfinished earlier order message', 'textarea', 'An order from a previous day in this browser is still not Completed. Wait until it is completed, or contact us to check its status.' ),
                'msg_today_unfinished' => array( 'Checkout popup: daily order limit message', 'textarea', 'At least two orders were placed today in this browser, and one is still not Completed. Wait until the earlier orders are completed, or contact us for help.' ),
            ),
            'receipt_message' => array(
                'msg_receipt' => array( 'Thank-you message', 'textarea', 'Your order has been received. We will verify the delivery advance and contact you to confirm the order. Do not send payment twice for the same order.' ),
            ),
            'receipt_ip_warning' => array(
                'msg_ip_warning' => array( 'Order IP notice ({ip} = recorded IP)', 'textarea', 'The connection IP has been recorded for order security: {ip}. We may contact you to verify your identity or payment.' ),
            ),
            'registration_email' => array(
                'msg_registered_sent' => array( 'Popup: confirmation email sent', 'textarea', 'Registration is complete. Check your email and click the confirmation link. Check Spam if it is not in your Inbox.' ),
                'msg_registered_failed' => array( 'Popup: confirmation email failed', 'textarea', 'Registration succeeded, but the confirmation email could not be sent. Contact us for help.' ),
                'msg_confirmed' => array( 'Popup: email confirmed', 'textarea', 'Your email has been confirmed. Thank you!' ),
                'msg_expired' => array( 'Popup: invalid or expired link', 'textarea', 'This link has expired or has already been used. Contact us for help.' ),
                'msg_popup_button' => array( 'Popup button label', 'text', 'OK' ),
            ),
            'order_email_notification' => array( 'recipient' => array( 'Owner alert email', 'email', get_option( 'admin_email' ) ) ),
            'advanced_optimizations' => array( 'asset_optimization' => array( 'Enable Asset Optimization?', 'checkbox', 1 ) ),
        );
        return $defs[ $key ] ?? array();
    }

    public static function setting( $key, $name, $default = null ) {
        $opts = get_option( 'dreminex_suite_module_settings', array() );
        return is_array( $opts ) && isset( $opts[ $key ] ) && array_key_exists( $name, (array) $opts[ $key ] ) ? $opts[ $key ][ $name ] : $default;
    }

    /** Return a non-empty saved override, or the existing localized message unchanged. */
    public static function message( $module, $name, $default ) {
        $override = self::setting( $module, $name, '' );
        return is_string( $override ) && trim( $override ) !== '' ? $override : $default;
    }

    public static function module_panel( $key ) {
        $fields = self::config( $key ); if ( ! $fields ) return;
        echo '<h3>' . esc_html( self::tr( 'Module settings', 'মডিউল সেটিংস' ) ) . '</h3>';
        if(in_array($key,['checkout_protection','checkout_experience','order_management'],true)){
            $copy=['checkout_protection'=>['CHECKOUT GUARD','Five related safeguards now share one dashboard. Turn each ability on only when its rule is needed.'],'checkout_experience'=>['CUSTOMER EXPERIENCE','Receipt content and the accessible validation dialog use the same customer-facing design.'],'order_management'=>['ORDER OPERATIONS','History, alerts, email, statuses and tracking share one workflow while retaining separate switches.']][$key];
            echo '<div class="ds-unified-intro"><span class="ds-eyebrow">'.esc_html($copy[0]).'</span><p>'.esc_html($copy[1]).'</p></div>';
        }
        if($key==='delivery_advance')echo '<p>Configure each provider separately. Only enabled providers with a valid receiver number appear at checkout. You can use a Personal or Merchant/Business account.</p>';
        echo '<form class="ds-module-config '.(in_array($key,['checkout_protection','checkout_experience','order_management'],true)?'is-unified':'').'" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="dreminex_suite_setting"><input type="hidden" name="module" value="' . esc_attr( $key ) . '">'; wp_nonce_field( 'dreminex_suite_setting_' . $key );
        $last_provider='';
        foreach ( $fields as $name => $spec ) {
            if(preg_match('/^wallet_(bkash|nagad|rocket|upay)_/',$name,$match)&&$match[1]!==$last_provider){$last_provider=$match[1];$title=['bkash'=>'bKash','nagad'=>'Nagad','rocket'=>'Rocket','upay'=>'Upay'][$last_provider];echo '<fieldset class="ds-wallet-setting"><legend>'.esc_html($title).'</legend>';}
            $default_value = $spec[1] === 'textarea' || $name === 'msg_popup_button' ? '' : $spec[2];
            $value = self::setting( $key, $name, $default_value );
            echo '<p><label for="dreminex-' . esc_attr( $name ) . '"><strong>' . esc_html( $spec[0] ) . '</strong></label><br>';
            if ( $spec[1] === 'textarea' ) {
                echo '<textarea class="large-text" rows="3" maxlength="500" id="dreminex-' . esc_attr( $name ) . '" name="settings[' . esc_attr( $name ) . ']" placeholder="' . esc_attr( $spec[2] ) . '">' . esc_textarea( $value ) . '</textarea><span class="description">Leave blank to keep the original default message.</span>';
            } elseif ( $spec[1] === 'select' || $spec[1] === 'wallet_type' ) {
                echo '<select id="dreminex-' . esc_attr( $name ) . '" name="settings[' . esc_attr( $name ) . ']">';
                $choices=$spec[1]==='wallet_type'?['personal'=>'Personal','merchant'=>'Merchant/Business']:(is_array($spec[3]??null)?$spec[3]:[]);
                foreach($choices as $option=>$label)echo '<option value="'.esc_attr($option).'" '.selected($value,$option,false).'>'.esc_html($label).'</option>';
                echo '</select>';
            } elseif ( $spec[1] === 'checkbox' ) {
                echo '<label class="ds-inline-toggle"><input id="dreminex-' . esc_attr( $name ) . '" type="checkbox" name="settings[' . esc_attr( $name ) . ']" value="1" ' . checked( $value, 1, false ) . '> Enable</label>';
                if($name==='choose_password')echo '<span class="description">'.esc_html(self::tr('Customers enter and confirm their password during registration.','Registration-এ নিজের password ও confirmation দিতে পারবেন।')).'</span>';
                elseif($name==='enable_registration')echo '<span class="description">'.esc_html(self::tr('Enable the WooCommerce My Account registration form when this module is on.','এই module চালু থাকলে WooCommerce My Account registration form চালু থাকবে।')).'</span>';
                elseif($name==='asset_optimization')echo '<span class="description">'.esc_html(self::tr('Load Suite assets only where needed. Disable during troubleshooting.','প্রয়োজনীয় পেজে Suite asset লোড করুন; সমস্যা খুঁজতে সাময়িক Off করুন।')).'</span>';
            } else {
                $bounds=$spec[1]==='number'?'min="'.(int)($spec[3]??1).'" max="'.(int)($spec[4]??999).'"':'';
                echo '<input class="regular-text" id="dreminex-' . esc_attr( $name ) . '" type="' . esc_attr( $spec[1] ) . '" name="settings[' . esc_attr( $name ) . ']" value="' . esc_attr( $value ) . '" ' . $bounds . ( in_array($name,['msg_popup_button','button_text'],true) ? ' maxlength="60"' : '' ) . (preg_match('/^wallet_(bkash|nagad|rocket|upay)_number$/',$name)||in_array($name,['msg_popup_button','message'],true)?'':' required') . '>';
            }
            echo '</p>';
            if($last_provider && preg_match('/^wallet_(bkash|nagad|rocket|upay)_enabled$/',$name))echo '</fieldset>';
        }
        submit_button( self::tr( 'Save module settings', 'মডিউল সেটিংস সংরক্ষণ' ), 'primary', 'submit', false ); echo '</form>';
    }

    public static function save_setting() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Access denied.' );
        $key = sanitize_key( wp_unslash( $_POST['module'] ?? '' ) ); $fields = self::config( $key );
        if ( ! $fields ) wp_die( 'Unknown module settings.', 400 );
        check_admin_referer( 'dreminex_suite_setting_' . $key );
        $input = isset( $_POST['settings'] ) && is_array( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : array();
        $data = array();
        foreach ( $fields as $name => $spec ) {
            $value = $input[ $name ] ?? '';
            if($name==='wallet_number') { $value=preg_replace('/\D/','',(string)$value);if($value!==''&&!preg_match('/^01[3-9][0-9]{8}$/D',$value))wp_die('Invalid Bangladesh wallet number.',400); }
            elseif($name==='account_type'||preg_match('/^wallet_(bkash|nagad|rocket|upay)_type$/',$name)) { $value=sanitize_key($value);if(!in_array($value,['personal','merchant'],true))wp_die('Select Personal or Merchant.',400); }
            elseif(preg_match('/^wallet_(bkash|nagad|rocket|upay)_number$/',$name)) { $value=preg_replace('/\D/','',(string)$value);if($value!==''&&!preg_match('/^01[3-9][0-9]{8}$/D',$value))wp_die('Invalid Bangladesh wallet number.',400); }
            elseif($spec[1]==='checkbox') $value=$value==='1'?1:0;
            elseif($spec[1]==='number') { $value=absint($value);$min=(int)($spec[3]??1);$max=(int)($spec[4]??999);if($value<$min||$value>$max)wp_die('Number setting is outside the allowed range.',400); }
            elseif($spec[1]==='email') { $value=sanitize_email($value);if(!is_email($value))wp_die('Invalid email address.',400); }
            elseif($spec[1]==='select') { $value=sanitize_key($value);$choices=is_array($spec[3]??null)?$spec[3]:[];if(!array_key_exists($value,$choices))wp_die('Select an available option.',400); }
            elseif($spec[1]==='textarea') { $value=sanitize_textarea_field((string)$value);if(strlen($value)>500)wp_die('Message text must be 500 characters or fewer.',400); }
            else $value=sanitize_text_field($value);
            if($name==='msg_popup_button'&&strlen($value)>60)wp_die('Popup button text must be 60 characters or fewer.',400);
            $data[ $name ] = $value;
        }
        $opts = get_option( 'dreminex_suite_module_settings', array() ); if ( ! is_array( $opts ) ) $opts = array();
        $opts[ $key ] = array_merge((array)($opts[$key]??[]),$data); update_option( 'dreminex_suite_module_settings', $opts, false );
        wp_safe_redirect( add_query_arg( array( 'page' => 'dreminex-suite', 'module' => $key, 'result' => 'saved' ), admin_url( 'admin.php' ) ) ); exit;
    }
}
add_action( 'dreminex_suite_health_scan_once', array( 'Dreminex_Suite_Control', 'scan' ) );
