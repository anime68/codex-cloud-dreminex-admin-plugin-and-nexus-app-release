<?php
if (!defined('ABSPATH')) exit;
/** Display-cache invalidation only. Never flushes security state or the global object cache. */
final class Dreminex_Suite_Cache {
 private static $queued=[];
 private static $public=false;
 private static $shortcodes=[];
 public static function register_shortcode($tag){self::$shortcodes[$tag]=true;}
 public static function boot() {
  add_action('updated_option',[__CLASS__,'option'],10,3);
  add_action('added_option',static function($key,$value){self::option($key,null,$value);},10,2);
  add_action('deleted_option',static function($key){self::option($key,null,null);});
  add_action('template_redirect',[__CLASS__,'protect'],0);
  add_action('init',[__CLASS__,'endpoint'],0);
  add_action('wp',[__CLASS__,'tag']);
  add_action('shutdown',[__CLASS__,'flush'],5);
  add_action('dreminex_suite_cache_changed',[__CLASS__,'changed'],10,2);
  add_action('woocommerce_order_status_changed',static function(){if(!get_option('dreminex_suite_cache_auto',1))return;self::changed('order_management');},10,0);
  add_action('admin_menu',static function(){add_submenu_page('dreminex-suite','Cache Management','Cache Management','manage_options','dreminex-suite-cache',[__CLASS__,'page']);},35);
  add_action('dreminex_suite_module_panel',[__CLASS__,'panel'],25);
  add_action('admin_post_dreminex_suite_cache',[__CLASS__,'action']);
  add_filter('do_shortcode_tag',[__CLASS__,'shortcode'],10,2);
 }
 public static function valid($id){return isset(Dreminex_Suite::catalog()[$id])||isset(Dreminex_Suite_Imports::all()[$id]);}
 public static function option($key,$old,$new) {
  if(!get_option('dreminex_suite_cache_auto',1))return;
  if(in_array($key,['dreminex_suite_modules','dreminex_suite_module_settings','dreminex_suite_language','dreminex_suite_imported_modules','dreminex_suite_version'],true)) {self::changed('all',true);return;}
  foreach(Dreminex_Suite::catalog() as $id=>$unused){$spec=Dreminex_Suite_Data::spec($id);if(in_array($key,$spec['options']??[],true)){self::changed($id,true);return;}}
  foreach(Dreminex_Suite_Imports::all() as $id=>$unused)if($key==='dreminex_import_settings_'.$id||$key==='dreminex_import_data_'.$id){self::changed($id,true);return;}
 }
 public static function changed($id='all',$public=false) {
  if($id!=='all'&&!self::valid($id))return false;
  self::$queued[$id]=true;self::$public=self::$public||(bool)$public;return true;
 }
 public static function token($id) {
  $v=(array)get_option('dreminex_suite_cache_generations',[]);
  return ($v['all']??'0').':'.($v[$id]??'0');
 }
 private static function key($id,$key){return 'ds_display_'.substr(hash('sha256',$id.'|'.self::token($id).'|'.$key),0,40);}
 public static function get($id,$key){if(!self::valid($id)||isset(self::$queued['all'])||isset(self::$queued[$id]))return false;return get_transient(self::key($id,$key));}
 public static function set($id,$key,$value,$ttl=300){if(!self::valid($id)||isset(self::$queued['all'])||isset(self::$queued[$id]))return false;return set_transient(self::key($id,$key),$value,max(1,min(3600,(int)$ttl)));}
 public static function flush() {
  if(!self::$queued)return;
  $ids=array_keys(self::$queued);$public=self::$public;self::$queued=[];self::$public=false;
  $v=(array)get_option('dreminex_suite_cache_generations',[]);
  foreach($ids as $id)$v[$id]=wp_generate_uuid4();
  update_option('dreminex_suite_cache_generations',$v,false);
  delete_option('dreminex_suite_health_v2');
  $dispatched=false;$error='';
  if($public) {
   try {if(has_action('litespeed_purge')){do_action('litespeed_purge','DREMINEX_SUITE');$dispatched=true;}
    if(has_action('litespeed_purge_url')){foreach([home_url('/'),function_exists('wc_get_page_permalink')?wc_get_page_permalink('myaccount'):'',function_exists('wc_get_checkout_url')?wc_get_checkout_url():''] as $url)if($url)do_action('litespeed_purge_url',$url);$dispatched=true;}
    do_action('dreminex_suite_cache_purged',$ids,$public);
   }catch(Throwable $e){$error='A cache adapter failed. Check the cache plugin logs.';}
  }
  update_option('dreminex_suite_cache_last',['time'=>time(),'modules'=>$ids,'public_requested'=>$public,'adapter_dispatched'=>$dispatched,'error'=>$error],false);
 }
 public static function nocache(){if(!defined('DONOTCACHEPAGE'))define('DONOTCACHEPAGE',true);nocache_headers();do_action('litespeed_control_set_nocache','Dreminex Suite personalized response');}
 public static function endpoint(){if(wp_doing_ajax()){$a=is_string($_REQUEST['action']??null)?sanitize_key(wp_unslash($_REQUEST['action'])):'';if(str_starts_with($a,'dreminex_'))self::nocache();}}
 public static function protect(){if(!get_option('dreminex_suite_cache_private',1))return;if(is_user_logged_in()||(function_exists('is_account_page')&&is_account_page())||(function_exists('is_checkout')&&is_checkout())||(function_exists('is_cart')&&is_cart()))self::nocache();}
 public static function tag(){if(!is_admin())do_action('litespeed_tag_add','DREMINEX_SUITE');}
 public static function shortcode($output,$tag){if((isset(self::$shortcodes[$tag])||str_starts_with($tag,'dreminex_'))&&!in_array($tag,['dreminex_newsletter_heading','dreminex_newsletter_signup'],true))self::nocache();return $output;}
 public static function panel($id){echo '<p><a href="'.esc_url(admin_url('admin.php?page=dreminex-suite-settings&section=cache&module='.$id)).'">'.esc_html(Dreminex_Suite_Control::tr('Cache settings & clear module cache','Cache settings ও module cache পরিষ্কার')).'</a></p>';}
 public static function action(){if(!current_user_can('manage_options'))wp_die('Access denied.');check_admin_referer('dreminex_suite_cache');$mode=sanitize_key(wp_unslash($_POST['mode']??''));
  if($mode==='settings'){update_option('dreminex_suite_cache_auto',isset($_POST['auto'])?1:0,false);update_option('dreminex_suite_cache_private',isset($_POST['private'])?1:0,false);}
  elseif($mode==='clear'){$id=sanitize_key(wp_unslash($_POST['module']??'all'));if(!self::changed($id,true))wp_die('Unknown module.');self::flush();}
  wp_safe_redirect(admin_url('admin.php?page=dreminex-suite-settings&section=cache&saved=1'));exit;
 }
 public static function page(){if(!current_user_can('manage_options'))return;$tr=[Dreminex_Suite_Control::class,'tr'];echo '<div class="wrap"><h1>'.esc_html($tr('Cache Management','Cache ব্যবস্থাপনা')).'</h1><p>'.esc_html($tr('Refresh Suite display caches after changes. Security locks, OTP limits, orders and customer records are retained.','পরিবর্তনের পরে Suite display cache refresh হয়। Security lock, OTP limit, order ও customer records অক্ষত থাকে।')).'</p>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_suite_cache"><input type="hidden" name="mode" value="settings">';wp_nonce_field('dreminex_suite_cache');
  foreach(['auto'=>'Automatically invalidate after settings/package changes','private'=>'Keep account, checkout and logged-in pages uncached'] as $name=>$label)echo '<p><label><input type="checkbox" name="'.$name.'" value="1" '.checked(get_option('dreminex_suite_cache_'.$name,1),1,false).'> '.esc_html($label).'</label></p>';submit_button('Save settings');echo '</form>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_suite_cache"><input type="hidden" name="mode" value="clear">';wp_nonce_field('dreminex_suite_cache');echo '<select name="module"><option value="all">All Suite modules</option>';
  $picked=sanitize_key(wp_unslash($_GET['module']??''));foreach(Dreminex_Suite::catalog() as $id=>$m)echo '<option value="'.esc_attr($id).'" '.selected($picked,$id,false).'>'.esc_html($m[0]).'</option>';foreach(Dreminex_Suite_Imports::all() as $id=>$m)echo '<option value="'.esc_attr($id).'" '.selected($picked,$id,false).'>Imported: '.esc_html($m['manifest']['name']??$id).'</option>';echo '</select>';submit_button('Clear display cache now');echo '</form>';
  $last=(array)get_option('dreminex_suite_cache_last',[]);echo '<h2>Last cache refresh</h2><p>'.esc_html(!empty($last['time'])?wp_date('Y-m-d H:i:s',$last['time']):'Not yet requested').'</p><p>'.esc_html('LiteSpeed adapter: '.(has_action('litespeed_purge')?'available':'not available — Suite namespace refresh still works')).'</p><p>'.esc_html($last['error']??'').'</p><p>External CDN/host caches need their own adapter. Imported modules must use the Suite display-cache API or register their own invalidation hook. No full-site object-cache flush is performed.</p></div>';
 }
}
