<?php
if(!defined('ABSPATH')) exit;
final class Dreminex_Suite_Contact_Trash {
 public static function boot() {
  add_action('admin_menu',[__CLASS__,'menu'],99);
  add_action('admin_post_dreminex_contact_bulk',[__CLASS__,'submit']);
  foreach(['dreminex_contact_manage','dreminex_contact_reply'] as $action) add_action('admin_post_'.$action,[__CLASS__,'guard'],0);
 }
 public static function private_dir(){return dirname(ABSPATH).'/dreminex-contact-evidence';}
 public static function replies(){global $wpdb;return $wpdb->prefix.'dreminex_contact_replies';}
 public static function table() { global $wpdb;return $wpdb->prefix.'dreminex_contact_requests'; }
 public static function menu() {
  $hook=get_plugin_page_hookname('dreminex-contact-requests','');
  remove_action($hook,'dreminex_contact_admin_page');add_action($hook,[__CLASS__,'page']);
 }
 public static function guard() {
  global $wpdb;$id=absint($_POST['request_id']??0);
  if($wpdb->get_var($wpdb->prepare('SELECT request_status FROM '.self::table().' WHERE id=%d',$id))==='trash')wp_die('Restore this request before sending a reply or changing its status.',400);
 }
 public static function operate($ids,$action) {
  global $wpdb;$done=0;$errors=[];
  if(!in_array($action,['trash','restore','delete'],true))return new WP_Error('invalid_action','Unknown bulk action.');
  $ids=array_values(array_unique(array_filter(array_map('absint',(array)$ids))));
  if(count($ids)>100)return new WP_Error('too_many','Select up to 100 requests per action.');
  foreach($ids as $id) {
   $row=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::table().' WHERE id=%d',$id));if(!$row)continue;
   if($action==='trash' && $row->request_status!=='trash') {
    $ok=$wpdb->update(self::table(),['request_status'=>'trash','status_before_trash'=>$row->request_status,'trashed_at'=>current_time('mysql')],['id'=>$id]);
   } elseif($action==='restore' && $row->request_status==='trash') {
    $state=in_array($row->status_before_trash,['new','in_progress','resolved'],true)?$row->status_before_trash:'new';
    $ok=$wpdb->update(self::table(),['request_status'=>$state,'status_before_trash'=>'','trashed_at'=>null],['id'=>$id]);
   } elseif($action==='delete' && $row->request_status==='trash') {
    if($row->stored_name) {
     $base=realpath(self::private_dir());$path=$base?realpath($base.'/'.$row->stored_name):false;
     if(basename($row->stored_name)!==$row->stored_name || ($path&&(!$base||dirname($path)!==$base||is_link($base.'/'.$row->stored_name)))){$errors[]=$id;continue;}
     if($path&&is_file($path)&&!unlink($path)){$errors[]=$id;continue;}
    }
    if($wpdb->delete(self::replies(),['request_id'=>$id],['%d'])===false){$errors[]=$id;continue;}
    $ok=$wpdb->delete(self::table(),['id'=>$id],['%d']);
   } else continue;
   if($ok===false)$errors[]=$id;else $done++;
  }
  return ['changed'=>$done,'failed_ids'=>$errors];
 }
 public static function submit() {
  if(!current_user_can('manage_options'))wp_die('Access denied.',403);check_admin_referer('dreminex_contact_bulk');
  $action=sanitize_key(wp_unslash($_POST['bulk_action']??''));
  if($action==='delete'&&empty($_POST['confirm_delete']))wp_die('Confirm permanent deletion.',400);
  $result=self::operate($_POST['request_ids']??[],$action);if(is_wp_error($result))wp_die(esc_html($result->get_error_message()),400);
  wp_safe_redirect(add_query_arg(['page'=>'dreminex-contact-requests','view'=>$action==='delete'||$action==='restore'?'trash':'active','changed'=>$result['changed'],'failed'=>count($result['failed_ids'])],admin_url('admin.php')));exit;
 }
 public static function page() {
  if(!current_user_can('manage_options'))return;global $wpdb;
  $id=absint($_GET['request_id']??0);
  if($id){$state=$wpdb->get_var($wpdb->prepare('SELECT request_status FROM '.self::table().' WHERE id=%d',$id));if($state!=='trash'){dreminex_contact_admin_page();return;}}
  $trash=($_GET['view']??'')==='trash'||$id>0;$where=$trash?"request_status='trash'":"request_status<>'trash'";
  $page=max(1,absint($_GET['paged']??1));$total=(int)$wpdb->get_var('SELECT COUNT(*) FROM '.self::table().' WHERE '.$where);
  $items=$wpdb->get_results($wpdb->prepare('SELECT id,created_at,customer_name,customer_email,request_status FROM '.self::table().' WHERE '.$where.' ORDER BY id DESC LIMIT 20 OFFSET %d',($page-1)*20));
  echo '<div class="wrap"><h1>Contact Requests'.($trash?' — Trash':'').'</h1><p><a href="'.esc_url(admin_url('admin.php?page=dreminex-contact-requests')).'">Active</a> | <a href="'.esc_url(admin_url('admin.php?page=dreminex-contact-requests&view=trash')).'">Trash</a></p>';
  if(isset($_GET['changed']))echo '<p>'.esc_html(absint($_GET['changed'])).' request(s) updated. Failed: '.esc_html(absint($_GET['failed']??0)).'.</p>';
  echo '<p>Trash keeps messages, replies and files. Permanent deletion is available only in Trash. <a href="'.esc_url(admin_url('admin.php?page=dreminex-suite-settings&section=backup&module=contact_requests')).'">Backup module data</a></p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_contact_bulk">';wp_nonce_field('dreminex_contact_bulk');
  echo '<select name="bulk_action">'.($trash?'<option value="restore">Restore</option><option value="delete">Delete permanently</option>':'<option value="trash">Move to Trash</option>').'</select> ';submit_button('Apply','secondary','submit',false);
  if($trash)echo ' <label><input type="checkbox" name="confirm_delete" value="1"> Confirm permanent deletion of selected requests and their files</label>';
  echo '<table class="widefat striped"><thead><tr><th><input type="checkbox" aria-label="Select all" onclick="this.closest(\'form\').querySelectorAll(\'tbody input[type=checkbox]\').forEach(function(x){x.checked=this.checked},this)"></th><th>ID</th><th>Date</th><th>Name</th><th>Email</th><th>Status</th></tr></thead><tbody>';
  foreach($items as $row)echo '<tr><td><input type="checkbox" name="request_ids[]" value="'.esc_attr($row->id).'"></td><td><a href="'.esc_url(admin_url('admin.php?page=dreminex-contact-requests&request_id='.$row->id)).'">#'.esc_html($row->id).'</a></td><td>'.esc_html($row->created_at).'</td><td>'.esc_html($row->customer_name).'</td><td>'.esc_html($row->customer_email).'</td><td>'.esc_html($row->request_status).'</td></tr>';
  if(!$items)echo '<tr><td colspan="6">No requests in this view.</td></tr>';echo '</tbody></table></form>';
  if($total>20)echo wp_kses_post(paginate_links(['base'=>add_query_arg('paged','%#%'),'current'=>$page,'total'=>(int)ceil($total/20)]));echo '</div>';
 }
}
