<?php
if(!defined('ABSPATH'))exit;
/** Gives a customer session an administrator sign-in route; never grants capabilities. */
final class Dreminex_Suite_Access {
 public static function boot(){
  add_action('admin_init',[__CLASS__,'guard'],1);
  add_action('login_init',[__CLASS__,'nocache']);
  add_filter('login_message',[__CLASS__,'message']);
  add_filter('woocommerce_prevent_admin_access',[__CLASS__,'allow_staff'],99);
  add_filter('login_redirect',[__CLASS__,'redirect'],99,3);
  add_action('woocommerce_login_form',[__CLASS__,'remember_control']);
  add_action('wp_login',[__CLASS__,'remember_customer_session'],99,2);
 }
 public static function staff($user=null){$user=$user?:wp_get_current_user();return $user instanceof WP_User&&($user->has_cap('manage_options')||$user->has_cap('manage_woocommerce')||$user->has_cap('edit_posts')||$user->has_cap('view_admin_dashboard'));}
 public static function login_url(){return add_query_arg(['reauth'=>1,'dreminex_admin_access'=>1],wp_login_url(admin_url()));}
 public static function allow_staff($prevent){return get_option('dreminex_suite_admin_signin',1)&&self::staff()?false:$prevent;}
 public static function nocache(){Dreminex_Suite_Cache::nocache();}
 /** Default WooCommerce customer sign-ins to a persistent session, with an opt-out checkbox. */
 public static function remember_control(){
  echo '<input type="hidden" id="dreminex-suite-remember" name="dreminex_suite_remember" value="1"><script>document.addEventListener("DOMContentLoaded",function(){var c=document.getElementById("rememberme"),h=document.getElementById("dreminex-suite-remember");if(!c||!h)return;c.checked=true;c.addEventListener("change",function(){h.value=c.checked?"1":"0";});});</script>';
 }
 /** WooCommerce's shipped login template leaves Remember me unchecked, creating a browser-session cookie. */
 public static function remember_customer_session($username,$user){
  if(!$user instanceof WP_User||empty($_POST['woocommerce-login-nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['woocommerce-login-nonce'])),'woocommerce-login'))return;
  $remember=isset($_POST['rememberme'])||($_POST['dreminex_suite_remember']??'')==='1';
  if($remember)wp_set_auth_cookie($user->ID,true,is_ssl());
 }
 public static function guard(){
  self::nocache();
  if(!get_option('dreminex_suite_admin_signin',1)||wp_doing_ajax()||wp_doing_cron()||in_array(basename($_SERVER['SCRIPT_FILENAME']??''),['admin-post.php','admin-ajax.php'],true))return;
  if(is_user_logged_in()&&!self::staff()){wp_safe_redirect(self::login_url(),302);exit;}
 }
 public static function message($html){if(empty($_GET['dreminex_admin_access']))return $html;return $html.'<div class="message"><p>'.esc_html(Dreminex_Suite_Control::tr('Administrator sign-in: your current customer account does not have dashboard access. Sign in with your administrator account. Customer passwords cannot grant administrator access.','Admin sign-in: বর্তমান customer account-এর dashboard permission নেই। আপনার administrator account দিয়ে লগইন করুন।')).'</p></div>';}
 public static function redirect($url,$requested,$user){
  if(!get_option('dreminex_suite_admin_signin',1)||!self::staff($user)||!is_string($requested))return $url;
  $validated=wp_validate_redirect($requested,'');$admin=wp_parse_url(admin_url());$target=wp_parse_url($validated);
  if($validated&&($target['host']??'')===($admin['host']??'')&&str_starts_with($target['path']??'',$admin['path']??'/wp-admin/'))return $validated;
  return $url;
 }
}
