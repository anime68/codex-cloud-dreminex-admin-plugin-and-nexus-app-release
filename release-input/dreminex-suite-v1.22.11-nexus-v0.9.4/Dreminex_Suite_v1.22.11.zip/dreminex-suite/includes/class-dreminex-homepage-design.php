<?php
defined('ABSPATH') || exit;

/** Homepage controls for the existing Elementor page. Never writes _elementor_data. */
final class Dreminex_Homepage_Design {
    private const KEY = 'homepage';
    private const TYPES = [
        'rt-image-box' => 'Banner', 'rt-title' => 'Section heading',
        'rtsb-shopbuilder-button' => 'Section button', 'rt-info-box' => 'Service item',
        'rt-marquee' => 'Moving text', 'rt-contact-info' => 'Feature copy',
        'rt-image' => 'Feature image', 'rtsb-countdown-addon' => 'Countdown',
        'container' => 'Banner background',
    ];

    public static function boot() {
        add_action('admin_post_dreminex_home_save', [__CLASS__, 'save']);
        add_filter('elementor/frontend/the_content', [__CLASS__, 'render_html'], 30);
        add_action('wp_enqueue_scripts', [__CLASS__, 'styles'], 40);
        add_action('admin_enqueue_scripts', [__CLASS__, 'admin_assets']);
    }

    private static function page_id() {
        return (int) get_option('page_on_front');
    }

    private static function source() {
        $id = self::page_id();
        if (!$id || get_post_meta($id, '_elementor_edit_mode', true) !== 'builder') return [];
        $data = json_decode((string) get_post_meta($id, '_elementor_data', true), true);
        return is_array($data) ? $data : [];
    }

    private static function widgets() {
        $out = [];
        $walk = static function ($nodes) use (&$walk, &$out) {
            foreach ((array) $nodes as $node) {
                $type = $node['widgetType'] ?? (($node['elType'] ?? '') === 'container' && !empty($node['settings']['background_image']['id']) ? 'container' : '');
                $id = $node['id'] ?? '';
                if (isset(self::TYPES[$type]) && preg_match('/^[a-f0-9]{7,12}$/', $id)) {
                    $out[$id] = ['type' => $type, 'settings' => (array) ($node['settings'] ?? [])];
                }
                if (!empty($node['elements'])) $walk($node['elements']);
            }
        };
        $walk(self::source());
        return $out;
    }

    private static function saved() {
        $all = get_option('dreminex_suite_module_settings', []);
        return is_array($all) && isset($all['storefront_design'][self::KEY]) && is_array($all['storefront_design'][self::KEY])
            ? $all['storefront_design'][self::KEY] : [];
    }

    private static function fields($type) {
        $shared = ['hidden' => 'hide'];
        if ($type === 'rt-image-box') return $shared + [
            'image_id' => 'image', 'title' => 'text', 'sub_title' => 'text',
            'button_text' => 'text', 'link' => 'url', 'title_color' => 'color',
            'sub_title_color' => 'color', 'title_size' => 'size', 'title_mobile' => 'size',
            'sub_title_size' => 'size', 'button_color' => 'color', 'button_bg' => 'color',
            'button_font' => 'size', 'button_width' => 'width', 'button_height' => 'dimension',
            'button_radius' => 'radius', 'content_horizontal' => 'align',
            'content_vertical' => 'vertical', 'button_align' => 'align',
            'text_animation' => 'motion', 'image_animation' => 'motion',
            'button_animation' => 'motion', 'duration' => 'duration',
        ];
        if ($type === 'rt-marquee') return $shared + ['items' => 'lines', 'title_color' => 'color', 'title_size' => 'size', 'direction' => 'direction', 'speed' => 'speed'];
        if ($type === 'rtsb-countdown-addon') return $shared + ['countdown_date_time' => 'date'];
        if ($type === 'rt-image') return $shared + ['image_id' => 'image', 'image_animation' => 'motion', 'duration' => 'duration'];
        if ($type === 'container') return $shared + ['image_id' => 'image'];
        if ($type === 'rt-contact-info') return $shared + ['title' => 'text', 'items' => 'contact', 'title_color' => 'color', 'title_size' => 'size'];
        if ($type === 'rtsb-shopbuilder-button') return $shared + ['button_text' => 'text', 'link' => 'url', 'button_color' => 'color', 'button_bg' => 'color', 'button_font' => 'size', 'button_align' => 'align', 'button_animation' => 'motion', 'duration' => 'duration'];
        return $shared + ['title' => 'text', 'sub_title' => 'text', 'title_color' => 'color', 'title_size' => 'size'];
    }

    private static function clean($value, $kind) {
        if ($kind === 'hide') return empty($value) ? '' : '1';
        if (!is_scalar($value) || trim((string) $value) === '') return '';
        $value = trim((string) $value);
        if ($kind === 'text') return sanitize_text_field(mb_substr($value, 0, 250));
        if ($kind === 'lines') return implode("\n", array_slice(array_filter(array_map('sanitize_text_field', explode("\n", str_replace("\r", '', $value)))), 0, 8));
        if ($kind === 'contact') return sanitize_text_field(mb_substr($value, 0, 300));
        if ($kind === 'color') return sanitize_hex_color($value) ?: '';
        if ($kind === 'url') return preg_match('~^https?://~i', $value) ? esc_url_raw($value, ['http', 'https']) : (str_starts_with($value, '/') && !str_starts_with($value, '//') ? esc_url_raw(home_url($value)) : '');
        if ($kind === 'image') return wp_attachment_is_image(absint($value)) ? (string) absint($value) : '';
        if ($kind === 'date') return preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $value) && strtotime($value) ? $value : '';
        $ranges = ['size' => [10, 90], 'width' => [90, 500], 'dimension' => [30, 100], 'radius' => [0, 50], 'duration' => [200, 2500], 'speed' => [5, 90]];
        if (isset($ranges[$kind])) return (string) min($ranges[$kind][1], max($ranges[$kind][0], absint($value)));
        $values = ['align' => ['left', 'center', 'right'], 'vertical' => ['top', 'center', 'bottom'], 'motion' => ['none', 'fade', 'slide-left', 'slide-right', 'zoom'], 'direction' => ['left', 'right']];
        return in_array($value, $values[$kind] ?? [], true) ? $value : '';
    }

    public static function save() {
        if (!current_user_can('manage_options')) wp_die('Access denied.', 403);
        check_admin_referer('dreminex_home_save');
        $widgets = self::widgets();
        $posted = isset($_POST['home']) && is_array($_POST['home']) ? wp_unslash($_POST['home']) : [];
        $clean = [];
        foreach ($widgets as $id => $widget) {
            $input = isset($posted[$id]) && is_array($posted[$id]) ? $posted[$id] : [];
            foreach (self::fields($widget['type']) as $key => $kind) {
                $value = self::clean($input[$key] ?? '', $kind);
                if ($value !== '') $clean[$id][$key] = $value;
            }
        }
        $all = get_option('dreminex_suite_module_settings', []);
        if (!is_array($all)) $all = [];
        if (!isset($all['storefront_design']) || !is_array($all['storefront_design'])) $all['storefront_design'] = [];
        $all['storefront_design'][self::KEY] = ['page_id' => self::page_id(), 'widgets' => $clean];
        update_option('dreminex_suite_module_settings', $all, false);
        Dreminex_Suite_Cache::changed('storefront_design', true);
        wp_safe_redirect(admin_url('admin.php?page=dreminex-suite&module=storefront_design&saved=homepage#ds-homepage'), 303);
        exit;
    }

    private static function overrides() {
        $saved = self::saved();
        return (int) ($saved['page_id'] ?? 0) === self::page_id() ? (array) ($saved['widgets'] ?? []) : [];
    }

    /** Elementor caches its document HTML, so customize the final HTML after its cache. */
    public static function render_html($html) {
        if (!Dreminex_Storefront_Design::enabled() || !is_front_page() || !is_string($html)) return $html;
        $widgets = self::widgets();
        foreach (self::overrides() as $id => $values) {
            if (!isset($widgets[$id]) || !$values || $widgets[$id]['type'] === 'container') continue;
            $type = $widgets[$id]['type'];
            if (array_keys($values) === ['hidden']) continue;
            $fragment = self::fragment($html, $id);
            if (!$fragment) continue;
            [$start, $length] = $fragment;
            $before = substr($html, $start, $length);
            $after = self::edit_fragment($before, $type, $values);
            if ($after !== $before) $html = substr_replace($html, $after, $start, $length);
        }
        return $html;
    }

    private static function fragment($html, $id) {
        if (!preg_match('/<div\\b[^>]*\\bdata-id="' . preg_quote($id, '/') . '"[^>]*>/i', $html, $hit, PREG_OFFSET_CAPTURE)) return null;
        $start = $hit[0][1];
        preg_match_all('~</?div\\b[^>]*>~i', substr($html, $start), $tags, PREG_OFFSET_CAPTURE);
        $level = 0;
        foreach ($tags[0] as [$tag, $offset]) {
            $level += stripos($tag, '</div') === 0 ? -1 : 1;
            if ($level === 0) return [$start, $offset + strlen($tag)];
        }
        return null;
    }

    private static function text_class($html, $class, $value) {
        $pattern = '~(<(h[1-6]|div|span|p)\\b[^>]*class="[^"]*\\b' . preg_quote($class, '~') . '\\b[^"]*"[^>]*>).*?(</\\2>)~is';
        return preg_replace_callback($pattern, static fn($m) => $m[1] . esc_html($value) . $m[3], $html, 1);
    }

    private static function edit_fragment($html, $type, $v) {
        $heading = ['rt-image-box'=>'rt-title','rt-title'=>'main-title','rt-contact-info'=>'info-title','rt-info-box'=>'info-title'];
        if (isset($v['title'], $heading[$type])) $html = self::text_class($html, $heading[$type], $v['title']);
        if (isset($v['sub_title'])) {
            if ($type === 'rt-info-box') $html = preg_replace_callback('~(<div class="content-holder"[^>]*>\\s*<p>).*?(</p>)~s', static fn($m) => $m[1] . esc_html($v['sub_title']) . $m[2], $html, 1);
            else $html = self::text_class($html, 'rt-sub-title', $v['sub_title']);
        }
        if (isset($v['button_text'])) {
            $html = self::text_class($html, 'text', $v['button_text']);
            $html = self::text_class($html, 'hover-text', $v['button_text']);
        }
        if (isset($v['link'])) $html = preg_replace_callback('~(<a\\b[^>]*\\bhref=)(?:"[^"]*"|[^\\s>]+)~i', static fn($m) => $m[1] . '"' . esc_url($v['link']) . '"', $html, 1);
        if (isset($v['image_id'])) {
            $url = wp_get_attachment_image_url((int) $v['image_id'], 'full');
            if ($url) {
                if ($type === 'rt-image-box') $html = preg_replace('/\\bdata-bg-image="[^"]*"/', 'data-bg-image="' . esc_url($url) . '"', $html, 1);
                if ($type === 'rt-image') {
                    $html = preg_replace('/(<img\\b[^>]*\\bsrc=")[^"]*/i', '$1' . esc_url($url), $html, 1);
                    $html = preg_replace('/\\s(?:srcset|sizes)="[^"]*"/i', '', $html);
                }
            }
        }
        if ($type === 'rt-marquee' && isset($v['items'])) {
            $lines = explode("\n", $v['items']);
            $html = preg_replace_callback('~(<div class="rt-marquee-item"[^>]*>)(.*?)(</div>)~s', static function($m) use ($lines) {
                if (!preg_match('~<h3\\b[^>]*>.*?</h3>~s', $m[2], $first)) return $m[0];
                $items = '';
                foreach ($lines as $line) {
                    $item = preg_replace('/\\bdata-per="[^"]*"/', 'data-per="' . esc_attr($line) . '"', $first[0], 1);
                    $item = preg_replace('~(<h3\\b[^>]*>).*?(</h3>)~s', '$1' . esc_html($line) . '$2', $item, 1);
                    $items .= $item;
                }
                return $m[1] . $items . $m[3];
            }, $html);
        }
        if ($type === 'rt-marquee' && isset($v['direction'])) $html = str_replace($v['direction'] === 'right' ? 'marquee-left' : 'marquee-right', $v['direction'] === 'right' ? 'marquee-right' : 'marquee-left', $html);
        if ($type === 'rt-contact-info' && isset($v['items'])) $html = preg_replace_callback('~(<li\\b[^>]*class="[^"]*\\blist\\b[^"]*"[^>]*>).*?(</li>)~s', static fn($m) => $m[1] . esc_html($v['items']) . $m[2], $html, 1);
        if ($type === 'rtsb-countdown-addon' && isset($v['countdown_date_time'])) {
            $date = DateTimeImmutable::createFromFormat('!Y-m-d H:i', $v['countdown_date_time'], wp_timezone());
            if ($date) $html = preg_replace('/\\bdata-deadline-date-time="[^"]*"/', 'data-deadline-date-time="' . ($date->getTimestamp() * 1000) . '"', $html, 1);
        }
        return $html;
    }

    private static function rule($selector, $declarations) {
        return $selector . '{' . implode(';', $declarations) . '}';
    }

    public static function styles() {
        if (!Dreminex_Storefront_Design::enabled() || !is_front_page()) return;
        $widgets = self::widgets();
        $css = '';
        foreach (self::overrides() as $id => $v) {
            if (!isset($widgets[$id])) continue;
            $base = '.elementor-element-' . $id;
            if (!empty($v['hidden'])) $css .= self::rule($base, ['display:none!important']);
            if (isset($v['title_color'])) $css .= self::rule($base . ' :is(.rt-title,.main-title,.entry-title,.info-title)', ['color:' . $v['title_color'] . '!important']);
            if (isset($v['title_size'])) $css .= self::rule($base . ' :is(.rt-title,.main-title,.entry-title,.info-title)', ['font-size:' . (int)$v['title_size'] . 'px!important']);
            if (isset($v['title_mobile'])) $css .= '@media(max-width:767px){' . self::rule($base . ' .rt-title', ['font-size:' . (int)$v['title_mobile'] . 'px!important']) . '}';
            if (isset($v['sub_title_color'])) $css .= self::rule($base . ' .rt-sub-title', ['color:' . $v['sub_title_color'] . '!important']);
            if (isset($v['sub_title_size'])) $css .= self::rule($base . ' .rt-sub-title', ['font-size:' . (int)$v['sub_title_size'] . 'px!important']);
            if ($widgets[$id]['type'] === 'container' && isset($v['image_id'])) {
                $url = wp_get_attachment_image_url((int)$v['image_id'], 'full');
                if ($url) $css .= self::rule($base, ['background-image:url("' . esc_url($url) . '")!important']);
            }
            if ($widgets[$id]['type'] === 'rt-image-box') {
                $props = [];
                if (isset($v['content_horizontal'])) $props[] = 'text-align:' . $v['content_horizontal'] . '!important';
                if (isset($v['content_vertical'])) $props[] = 'justify-content:' . ['top'=>'flex-start','center'=>'center','bottom'=>'flex-end'][$v['content_vertical']] . '!important';
                if ($props || isset($v['button_align'])) $css .= self::rule($base . ' .rt-image-box', array_merge(['display:flex!important','flex-direction:column!important'], $props));
                if (isset($v['button_align'])) $css .= self::rule($base . ' .rt-button', ['align-self:' . ['left'=>'flex-start','center'=>'center','right'=>'flex-end'][$v['button_align']] . '!important']);
            } elseif (isset($v['button_align'])) $css .= self::rule($base, ['text-align:' . $v['button_align'] . '!important']);
            $btn = $base . ' :is(.rt-button a,.rtsb-sb-button-layout1 a)';
            $props = [];
            foreach (['button_color'=>'color','button_bg'=>'background-color'] as $k=>$p) if (isset($v[$k])) $props[] = $p . ':' . $v[$k] . '!important';
            foreach (['button_font'=>'font-size','button_width'=>'min-width','button_height'=>'min-height','button_radius'=>'border-radius'] as $k=>$p) if (isset($v[$k])) $props[] = $p . ':' . (int)$v[$k] . 'px!important';
            if ($props) $css .= self::rule($btn . ',' . $btn . ' :is(.text,.hover-text)', $props);
            if (isset($v['button_color'], $v['button_bg'])) $css .= self::rule($btn . ':hover,' . $btn . ':focus-visible', ['color:' . $v['button_color'] . '!important','background-color:' . $v['button_bg'] . '!important']);
            foreach (['text_animation'=>'.rt-content','button_animation'=>'.rt-button','image_animation'=>'.rt-image-box'] as $k=>$target) {
                if (!isset($v[$k]) || $v[$k] === 'none') continue;
                $duration = (int)($v['duration'] ?? 650);
                $name = 'ds-' . $v[$k];
                if ($k === 'image_animation' && $widgets[$id]['type'] === 'rt-image') $target = ' img';
                if ($k === 'image_animation' && $widgets[$id]['type'] === 'rt-image-box') {
                    $url = isset($v['image_id']) ? wp_get_attachment_image_url((int)$v['image_id'], 'full') : ($widgets[$id]['settings']['main_image']['url'] ?? '');
                    if ($url) {
                        $css .= self::rule($base . ' .rt-image-box', ['position:relative!important','overflow:hidden!important','background-image:none!important']);
                        $css .= self::rule($base . ' .rt-image-box::before', ['content:""','position:absolute','inset:0','background-image:url("' . esc_url($url) . '")','background-position:center','background-size:cover','pointer-events:none']);
                        $css .= self::rule($base . ' .rt-image-box :is(.rt-content,.rt-button)', ['position:relative','z-index:1']);
                    }
                    $target = ' .rt-image-box::before';
                }
                $css .= self::rule($base . ' ' . $target, ['animation:' . $name . ' ' . $duration . 'ms ease-out both!important']);
            }
            if (isset($v['speed'])) $css .= self::rule($base . ' .rt-marquee-item', ['animation-duration:' . (int)$v['speed'] . 's!important']);
        }
        if (!$css) return;
        $css .= '@keyframes ds-fade{from{opacity:0}to{opacity:1}}@keyframes ds-slide-left{from{opacity:0;transform:translateX(24px)}to{opacity:1;transform:translateX(0)}}@keyframes ds-slide-right{from{opacity:0;transform:translateX(-24px)}to{opacity:1;transform:translateX(0)}}@keyframes ds-zoom{from{opacity:0;transform:scale(.96)}to{opacity:1;transform:scale(1)}}@media(prefers-reduced-motion:reduce){[class*=elementor-element-] :is(.rt-content,.rt-button,.rt-image-box,.rt-image-box::before,.rt-marquee-item){animation:none!important}}';
        wp_register_style('dreminex-homepage-design', false, [], DREMINEX_SUITE_VERSION);
        wp_enqueue_style('dreminex-homepage-design');
        wp_add_inline_style('dreminex-homepage-design', $css);
    }

    public static function admin_assets($hook) {
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        $module = isset($_GET['module']) ? sanitize_key(wp_unslash($_GET['module'])) : '';
        if (!current_user_can('manage_options') || $page !== 'dreminex-suite' || $module !== 'storefront_design') return;
        wp_enqueue_media();
        wp_enqueue_script('dreminex-home-admin', plugins_url('../assets/home-admin.js', __FILE__), ['jquery'], DREMINEX_SUITE_VERSION, true);
        wp_enqueue_style('dreminex-home-admin', plugins_url('../assets/home-admin.css', __FILE__), [], DREMINEX_SUITE_VERSION);
    }

    public static function panel() {
        $widgets = self::widgets();
        echo '<section id="ds-homepage" class="ds-home"><div class="ds-home-head"><div><span class="ds-home-kicker">HOME PAGE</span><h2>Homepage studio</h2><p>Choose a section, then edit its image, copy, colours, placement and motion. Empty fields keep the current design. Changes appear while Storefront Design is On.</p></div><a class="button button-secondary" target="_blank" rel="noopener" href="' . esc_url(home_url('/')) . '">View homepage ↗</a></div>';
        if (!$widgets) { echo '<p>Set an Elementor page as the static homepage to see its controls here.</p></section>'; return; }
        $saved = self::overrides();
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="dreminex_home_save">';
        echo str_replace(' id="_wpnonce"', '', wp_nonce_field('dreminex_home_save', '_wpnonce', true, false));
        $groups = ['rt-image-box'=>'Banners', 'container'=>'Banner backgrounds', 'rt-marquee'=>'Moving message', 'rt-contact-info'=>'Feature copy', 'rt-image'=>'Feature images', 'rt-title'=>'Section headings', 'rtsb-shopbuilder-button'=>'Section links', 'rt-info-box'=>'Service cards', 'rtsb-countdown-addon'=>'Countdown'];
        foreach ($groups as $type=>$group) {
            $subset = array_filter($widgets, static fn($w)=>$w['type']===$type);
            if (!$subset) continue;
            echo '<div class="ds-home-group"><h3>' . esc_html($group) . ' <span>' . count($subset) . '</span></h3>';
            foreach ($subset as $id=>$widget) {
                $s = $widget['settings']; $v = (array)($saved[$id] ?? []);
                $label = $s['title'] ?? $s['_title'] ?? $s['button_text'] ?? $s['sb_button__content'] ?? $s['sub_title'] ?? self::TYPES[$type];
                $label = is_scalar($label) ? wp_strip_all_tags((string)$label) : self::TYPES[$type];
                $preview = $s[$type === 'container' ? 'background_image' : 'main_image']['url'] ?? '';
                echo '<details class="ds-home-card"><summary><span class="ds-home-card-label">';
                if ($preview) echo '<img class="ds-home-thumb" src="' . esc_url($preview) . '" width="96" height="64" alt="">';
                echo '<span><strong>' . esc_html($label) . '</strong><small>' . esc_html(self::TYPES[$type]) . ' · ' . esc_html($id) . '</small></span></span><span class="ds-home-edit">Edit <span aria-hidden="true">⌄</span></span></summary><div class="ds-home-body">';
                $fields = self::fields($type);
                $sections = [
                    'Content & image' => ['hidden','image_id','title','sub_title','items','countdown_date_time'],
                    'Text appearance' => ['title_color','sub_title_color','title_size','title_mobile','sub_title_size'],
                    'Button' => ['button_text','link','button_color','button_bg','button_font','button_width','button_height','button_radius','button_align'],
                    'Placement & motion' => ['content_horizontal','content_vertical','text_animation','image_animation','button_animation','duration','direction','speed'],
                ];
                foreach ($sections as $heading=>$keys) {
                    $present = array_intersect_key($fields, array_flip($keys));
                    if (!$present) continue;
                    echo '<fieldset class="ds-home-section"><legend>' . esc_html($heading) . '</legend><div class="ds-home-fields">';
                    foreach ($present as $key=>$kind) self::field($id,$key,$kind,$v[$key]??'', $s);
                    echo '</div></fieldset>';
                }
                echo '</div></details>';
            }
            echo '</div>';
        }
        echo '<div class="ds-home-save"><span>Your original Elementor content is kept. Empty fields use its current values.</span>';
        submit_button('Save homepage changes', 'primary', 'ds_save_homepage', false);
        echo '</div></form></section>';
    }

    private static function field($id,$key,$kind,$value,$source) {
        $labels = ['hidden'=>'Hide this item','image_id'=>'Replace image','title'=>'Heading','sub_title'=>'Supporting text','button_text'=>'Button text','link'=>'Button link','title_color'=>'Heading colour','sub_title_color'=>'Supporting text colour','title_size'=>'Heading size (px)','title_mobile'=>'Mobile heading size (px)','sub_title_size'=>'Supporting text size (px)','button_color'=>'Button text colour','button_bg'=>'Button colour','button_font'=>'Button text size (px)','button_width'=>'Button minimum width (px)','button_height'=>'Button minimum height (px)','button_radius'=>'Button corners (px)','content_horizontal'=>'Text position','content_vertical'=>'Vertical position','button_align'=>'Button position','text_animation'=>'Text animation','image_animation'=>'Image animation','button_animation'=>'Button animation','duration'=>'Animation duration (ms)','items'=>'Message lines','direction'=>'Direction','speed'=>'Motion duration (seconds)','countdown_date_time'=>'End date and time (site time)'];
        $name = 'home[' . esc_attr($id) . '][' . esc_attr($key) . ']';
        $caption = $labels[$key] ?? $key;
        $input_id = 'ds-home-' . $id . '-' . $key;
        echo '<div class="ds-home-field' . ($kind === 'hide' ? ' ds-home-field-check' : '') . '">';
        if ($kind === 'hide') {
            echo '<label for="' . esc_attr($input_id) . '"><input id="' . esc_attr($input_id) . '" type="checkbox" name="' . $name . '" value="1" ' . checked($value,'1',false) . '> ' . esc_html($caption) . '</label></div>';
            return;
        }
        echo '<label for="' . esc_attr($input_id) . '">' . esc_html($caption) . '</label>';
        if ($kind === 'image') {
            echo '<span class="ds-media-row"><input id="' . esc_attr($input_id) . '" class="ds-media-id" type="number" min="1" name="' . $name . '" value="' . esc_attr($value) . '" placeholder="Media ID"><button type="button" class="button ds-pick-media">Choose image</button><button type="button" class="button ds-clear-media">Clear</button></span>';
        } elseif ($kind === 'lines') {
            $placeholder = implode("\n", array_column((array)($source['items']??[]),'title'));
            echo '<textarea id="' . esc_attr($input_id) . '" rows="5" name="' . $name . '" placeholder="' . esc_attr($placeholder) . '">' . esc_textarea($value) . '</textarea>';
        } elseif (in_array($kind,['align','vertical','motion','direction'],true)) {
            $lists = ['align'=>['left'=>'Left','center'=>'Centre','right'=>'Right'],'vertical'=>['top'=>'Top','center'=>'Middle','bottom'=>'Bottom'],'motion'=>['none'=>'None','fade'=>'Fade','slide-left'=>'Slide from right','slide-right'=>'Slide from left','zoom'=>'Zoom'],'direction'=>['left'=>'Right to left','right'=>'Left to right']];
            echo '<select id="' . esc_attr($input_id) . '" name="' . $name . '"><option value="">Keep current</option>';
            foreach ($lists[$kind] as $option=>$text) echo '<option value="' . esc_attr($option) . '" ' . selected($value,$option,false) . '>' . esc_html($text) . '</option>';
            echo '</select>';
        } else {
            $type = in_array($kind,['size','width','dimension','radius','duration','speed'],true) ? 'number' : 'text';
            $placeholder = '';
            if ($key === 'link') $placeholder = $source['link']['url'] ?? $source['sb_button_link']['url'] ?? '';
            elseif (in_array($key,['title','sub_title','button_text'],true)) $placeholder = $source[$key] ?? ($key === 'button_text' ? ($source['sb_button__content']??'') : '');
            elseif ($kind === 'date') $placeholder = $source['countdown_date_time'] ?? 'YYYY-MM-DD HH:MM';
            $min = in_array($kind,['size','width','dimension','duration','speed'],true) ? ' min="1"' : ($kind === 'radius' ? ' min="0"' : '');
            echo '<input id="' . esc_attr($input_id) . '" type="' . $type . '"' . $min . ' name="' . $name . '" value="' . esc_attr($value) . '" placeholder="' . esc_attr(is_scalar($placeholder)?$placeholder:'') . '">';
            if ($kind === 'color') echo '<input class="ds-home-color" type="color" value="' . esc_attr(sanitize_hex_color($value) ?: '#00b4d8') . '" aria-label="Choose ' . esc_attr($caption) . '">';
        }
        echo '</div>';
    }
}
