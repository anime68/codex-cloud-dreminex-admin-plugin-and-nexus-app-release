<?php
if (!defined('ABSPATH')) exit;

/** Store-local onboarding. Never imports another merchant's identity or secrets. */
final class Dreminex_Suite_Setup {
 public static function boot() {
  add_action('admin_menu',[__CLASS__,'menu'],32);
  add_action('admin_post_dreminex_suite_setup',[__CLASS__,'save']);
  add_action('wp_footer',[__CLASS__,'styles'],99);
  add_action('dreminex_suite_module_panel',[__CLASS__,'panel'],5);
 }
 public static function styles() {
  echo '<style id="dreminex-suite-brand">#dreminex-checkout-dialog .dreminex-dialog-box,.dreminex-receipt-note{border-color:'.esc_attr(self::accent()).'}.dreminex-contact-form input:focus,.dreminex-contact-form textarea:focus{outline-color:'.esc_attr(self::accent()).'}</style>';
 }
 public static function brand() { return sanitize_text_field(get_option('dreminex_suite_store_name',get_bloginfo('name'))); }
 public static function page_url($kind) {
  $id=(int)get_option('dreminex_suite_'.$kind.'_page',0);
  if($id>0 && get_post_status($id)==='publish') return get_permalink($id);
  if($kind==='contact') { $page=get_page_by_path('contact'); if($page && $page->post_status==='publish') return get_permalink($page); }
  return home_url('/');
 }
 public static function email() { return (string)get_option('dreminex_suite_support_email',get_option('admin_email')); }
 public static function text($text) {
  return str_ireplace(['Dreminex Fashion','hello@dreminexfashion.store','#00B4D8'],[self::brand(),self::email(),self::accent()],$text);
 }
 public static function accent() { return sanitize_hex_color(get_option('dreminex_suite_accent','#00B4D8')) ?: '#00B4D8'; }
 public static function menu() { add_submenu_page('dreminex-suite','Store setup','Store setup','manage_options','dreminex-suite-setup',[__CLASS__,'page']); }
 public static function modules() { return Dreminex_Suite::catalog(); }
 public static function readiness($key) {
  $messages=[];
  if(!class_exists('WooCommerce')) $messages[]='Activate WooCommerce before enabling commerce modules.';
  $checkout=function_exists('wc_get_page_id')?wc_get_page_id('checkout'):0;
  $classic=['delivery_advance','mobile_payment','checkout_protection','checkout_experience'];
  if(in_array($key,$classic,true)) {
   if($checkout<=0 || get_post_status($checkout)!=='publish') $messages[]='Publish a checkout page and assign it in WooCommerce → Settings → Advanced.';
   elseif(has_block('woocommerce/checkout',$checkout)&&!get_option('dreminex_suite_classic_bridge',1)) $messages[]='This module uses classic checkout hooks. Replace the Checkout block with [woocommerce_checkout] before relying on it.';
  }
  if($key==='delivery_advance') {
   $configured=function_exists('dreminex_advance_wallets')?(bool)dreminex_advance_wallets():false;
   if(!$configured) $messages[]='Add at least one valid bKash, Nagad, Rocket or Upay receiver number and account type in this module. No merchant number is supplied on a fresh installation.';
   if((get_option('woocommerce_bacs_settings',[])['enabled']??'no')!=='yes') $messages[]='Enable Direct bank transfer (BACS) in WooCommerce Payments and label it for manual delivery advance.';
   if(function_exists('get_woocommerce_currency')&&get_woocommerce_currency()!=='BDT') $messages[]='Manual bKash/Nagad/Rocket advance requires BDT. Keep this module off for other currencies.';
  }
  if($key==='checkout_protection' && Dreminex_Suite_Control::setting('checkout_protection','phone_enabled',1) && function_exists('WC') && WC()->countries && WC()->countries->get_base_country()!=='BD') $messages[]='Bangladesh phone validation is On. Turn that feature off if your store accepts other countries’ phone formats.';
  if($key==='mobile_payment') $messages[]='Open Dreminex Payments: add your own merchant connection, save credentials, test authentication, and configure the gateway. Production accepts only live profiles; staging/development/local accepts only sandbox profiles. Nagad/Rocket require a registered official provider adapter.';
  if($key==='newsletter_offers') $messages[]='Newsletter appears in the existing template or automatic footer when enabled. Configure coupons/offers from Suite controls and verify confirmation mail with a test account.';
  if($key==='contact_requests') $messages[]='The assigned support page receives the form automatically when enabled. Use Module control centre to prepare or open it. Check private attachments and receipt/reply mail.';
  if($key==='order_management') $messages[]='Enable Courier tracking to prepare the tracking page. Enter each real courier and consignment reference in the order; statuses do not automatically synchronize with courier APIs.';
  if(in_array($key,['order_management','registration_email','newsletter_offers','contact_requests'],true)) $messages[]='Configure authenticated SMTP or your mail service and verify delivery. Loaded PHP alone does not prove email delivery.';
  return $messages;
 }
 public static function panel($key) {
  echo '<h3>'.esc_html(Dreminex_Suite_Control::tr('Setup and verification','সেটআপ ও যাচাই')).'</h3><p><a href="'.esc_url(admin_url('admin.php?page=dreminex-suite-settings&section=setup')).'">Store setup & all module instructions</a></p>';
  foreach(self::readiness($key) as $message) echo '<p class="description">'.esc_html($message).'</p>';
  $guide=self::guides(); if(isset($guide[$key])) echo '<p>'.esc_html($guide[$key]).'</p>';
  echo '<p class="description">Enable only after configuration. Test on staging and confirm the expected customer/admin result; “loaded” is a loader status, not an end-to-end test.</p>';
 }
 public static function guides() {
  return [
   'delivery_advance'=>'Collect shipping advance using wallet + TXID; manually verify the transfer before processing. Configure shipping zones/rates; product balance is collected at delivery. No automatic wallet verification.',
   'checkout_protection'=>'Configure phone normalization, IP cooldown, browser threshold, masked receipt IP and consented unfinished-checkout retention. Each feature has its own switch; test shared-network and privacy cases.',
   'checkout_experience'=>'Configure the thank-you message and accessible error dialog. Test classic checkout, mobile, keyboard focus and screen-reader labels.',
   'order_management'=>'Configure customer history, admin alerts, owner email, workflow statuses and courier tracking. Each part has its own switch and keeps existing order evidence.',
   'newsletter_offers'=>'Use the subscription shortcodes, confirmation email, welcome coupon and published offers. Unused unexpired claimed coupons remain visible; expired/used coupons disappear. Test logged-in and logged-out pages without personalized cache.',
   'contact_requests'=>'Collect support messages with private media; manage status and replies in Contact Requests. Configure support email in Store setup.',
   'registration_email'=>'Configure account pages, registration/email confirmation and cross-account password recovery from one module. Test valid and expired links with disposable accounts.',
   'store_email_branding'=>'Set the customer email logo, sender name/address, colors and WooCommerce notification switches here. Use WooCommerce email preview before relying on changes; existing templates remain unchanged.',
   'advanced_optimizations'=>'Load assets on relevant screens only. Off modules do not load their PHP/hooks or assets. Turning optimization off is for troubleshooting; it never enables disabled modules or removes third-party assets.',
   'mobile_payment'=>'API-backed verified payment and partial/full balance. Configure in Dreminex Payments. Keep active while pending payments need callbacks/reconciliation; never add personal Send Money numbers as merchant API credentials.'
  ];
 }
 public static function checklist(){
  $checks=['WooCommerce available'=>class_exists('WooCommerce'),'ZIP backup / import support'=>class_exists('ZipArchive'),'HTTPS site'=>str_starts_with(home_url('/'),'https://'),'Auto cache refresh On'=>(bool)get_option('dreminex_suite_cache_auto',1),'Administrator sign-in guard On'=>(bool)get_option('dreminex_suite_admin_signin',1)];
  foreach(['myaccount','checkout','cart'] as $page){$id=function_exists('wc_get_page_id')?wc_get_page_id($page):0;$checks[ucfirst($page).' page published']=$id>0&&get_post_status($id)==='publish';}
  echo '<h2>Setup checklist</h2><ul>';foreach($checks as $label=>$ok)echo '<li>'.esc_html(($ok?'Ready: ':'Needs attention: ').$label).'</li>';echo '</ul><p>These are configuration checks. SMTP delivery, courier/provider verification and actual checkout need separate end-to-end tests.</p><p><a class="button" href="'.esc_url(admin_url('admin.php?page=dreminex-suite-health')).'">Site Health</a> <a class="button" href="'.esc_url(admin_url('admin.php?page=dreminex-suite-settings&section=backup')).'">Backup & fresh reset</a> <a class="button" href="'.esc_url(admin_url('admin.php?page=dreminex-suite-settings&section=cache')).'">Cache Management</a></p>';
 }
 public static function page() {
  if(!current_user_can('manage_options')) return;
  echo '<div class="wrap"><h1>Store setup</h1><p>1. Configure your store identity. 2. Check WooCommerce pages, currency, shipping and mail. 3. Configure each module, enable it individually, then test its result.</p>';
  self::checklist();
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_suite_setup">';wp_nonce_field('dreminex_suite_setup');
  foreach(['store_name'=>['Store name',self::brand(),'text'],'whatsapp_number'=>['WhatsApp number (international digits)',get_option('dreminex_suite_whatsapp_number',''),'text'],'support_email'=>['Support / reply email',self::email(),'email'],'accent'=>['Brand accent',self::accent(),'color'],'order_timezone'=>['Order-rule timezone (e.g. Asia/Dhaka or UTC)',get_option('dreminex_suite_order_timezone',wp_timezone_string()),'text']] as $name=>$field) echo '<p><label>'.esc_html($field[0]).'<br><input required class="regular-text" type="'.esc_attr($field[2]).'" name="'.esc_attr($name).'" value="'.esc_attr($field[1]).'"></label></p>';
  foreach(['newsletter','contact','tracking'] as $kind) {
   echo '<p><label>'.esc_html(ucfirst($kind).' page').' ';
   wp_dropdown_pages(['name'=>$kind.'_page','selected'=>(int)get_option('dreminex_suite_'.$kind.'_page',0),'show_option_none'=>'Use existing default / homepage','option_none_value'=>0]);
   echo '</label> <label><input type="checkbox" name="create_'.$kind.'" value="1"> Create a dedicated page if none is selected</label></p>';
  }
  echo '<p>No credentials or original merchant data are shipped. Existing settings, orders and coupons are retained on updates. Fresh installs start with modules off.</p>';submit_button('Save store settings');echo '</form><h2>All modules: purpose, setup and testing</h2>';
  foreach(self::modules() as $key=>$module) { echo '<div class="card" style="max-width:100%"><h3><a href="'.esc_url(add_query_arg(['page'=>'dreminex-suite','module'=>$key],admin_url('admin.php'))).'">'.esc_html($module[0]).'</a></h3><p>'.esc_html(self::guides()[$key]??$module[4]).'</p>';foreach(self::readiness($key) as $message) echo '<p>'.esc_html($message).'</p>';echo '</div>'; }
  echo '</div>';
 }
 public static function save() {
  if(!current_user_can('manage_options')) wp_die('Access denied.');check_admin_referer('dreminex_suite_setup');
  $name=sanitize_text_field(wp_unslash($_POST['store_name']??''));$email=sanitize_email(wp_unslash($_POST['support_email']??''));$accent=sanitize_hex_color(wp_unslash($_POST['accent']??''));
  $timezone=sanitize_text_field(wp_unslash($_POST['order_timezone']??wp_timezone_string()));
  try { new DateTimeZone($timezone); } catch(Throwable $error) { wp_die('Use a valid timezone, e.g. Asia/Dhaka or UTC.',400); }
  if(!$name||!is_email($email)||!$accent) wp_die('Valid store name, email and hex colour are required.',400);
  $phone=preg_replace('/\D/','',wp_unslash($_POST['whatsapp_number']??''));
  if($phone && !preg_match('/^[1-9][0-9]{7,14}$/D',$phone)) wp_die('Use an international WhatsApp number with country code.',400);
  update_option('dreminex_suite_whatsapp_number',$phone,false);
  update_option('dreminex_suite_order_timezone',$timezone,false);
  update_option('dreminex_suite_store_name',$name,false);update_option('dreminex_suite_support_email',$email,false);update_option('dreminex_suite_accent',$accent,false);
  foreach(['newsletter'=>['Newsletter','[dreminex_newsletter_heading] [dreminex_newsletter_signup]'],'contact'=>['Contact','[dreminex_contact_evidence_form]'],'tracking'=>['Track Your Order','[woocommerce_order_tracking]']] as $kind=>$spec) {
   $id=absint($_POST[$kind.'_page']??0);
   if($id && (get_post_type($id)!=='page'||get_post_status($id)!=='publish')) wp_die('Choose a published page.',400);
   if(!$id && !empty($_POST['create_'.$kind])) {
    $existing=get_page_by_path('suite-'.$kind);
    if($existing && $existing->post_status==='publish') $id=$existing->ID;
    else { $result=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>$spec[0],'post_name'=>'suite-'.$kind,'post_content'=>$spec[1]],true); if(is_wp_error($result)) wp_die('Page creation failed. Create it manually and select it.',400);$id=$result; }
   }
   update_option('dreminex_suite_'.$kind.'_page',$id,false);
  }
  wp_safe_redirect(admin_url('admin.php?page=dreminex-suite-settings&section=setup&saved=1'));exit;
 }
}
