<?php
if (!defined('ABSPATH')) exit;

/**
 * Site-level protections for public contact forms, WordPress sign-in and response headers.
 * Event records contain reasons and salted IP hashes only; submitted content and raw IPs are never stored.
 */
final class Dreminex_Security_Center {
 const SCHEMA = 2;
 const OPTION = 'dreminex_security_center_settings';

 private static function events_table() { global $wpdb; return $wpdb->prefix . 'dreminex_security_events'; }
 private static function rates_table() { global $wpdb; return $wpdb->prefix . 'dreminex_security_rates'; }
 private static function now() { return gmdate('Y-m-d H:i:s'); }

 public static function defaults() {
  return [
   'contact_protection'=>true,
   'contact_min_seconds'=>3,
   'contact_max_per_10_minutes'=>5,
   'contact_max_per_day'=>20,
   'contact_email_max_per_hour'=>3,
   'contact_max_links'=>1,
   'login_protection'=>true,
   'login_max_failures'=>10,
   'login_lock_minutes'=>15,
   'xmlrpc_protection'=>false,
   'security_headers'=>true,
   'event_retention_days'=>30,
  ];
 }

 public static function settings() { return array_replace(self::defaults(), (array)get_option(self::OPTION, [])); }

 public static function boot() {
  self::install();
  add_filter('dreminex_mail_engine_guard_contact', [__CLASS__, 'guard_contact'], 1, 2);
  add_filter('authenticate', [__CLASS__, 'guard_login'], 1, 3);
  add_action('wp_login_failed', [__CLASS__, 'record_login_failure'], 10, 2);
  add_filter('xmlrpc_enabled', [__CLASS__, 'filter_xmlrpc'], 999);
  add_action('send_headers', [__CLASS__, 'send_security_headers'], 1);
  add_action('dreminex_security_center_cleanup', [__CLASS__, 'cleanup']);
  if (!wp_next_scheduled('dreminex_security_center_cleanup')) wp_schedule_event(time()+HOUR_IN_SECONDS, 'daily', 'dreminex_security_center_cleanup');
  add_action('wp_abilities_api_categories_init', [__CLASS__, 'ability_category'], 48);
  add_action('wp_abilities_api_init', [__CLASS__, 'abilities'], 48);
 }

 private static function install() {
  if ((int)get_option('dreminex_security_center_schema', 0) >= self::SCHEMA) return;
  require_once ABSPATH . 'wp-admin/includes/upgrade.php';
  global $wpdb; $charset=$wpdb->get_charset_collate();
  $events=self::events_table(); $rates=self::rates_table();
  dbDelta("CREATE TABLE {$events} (
   id bigint unsigned NOT NULL AUTO_INCREMENT,
   event_type varchar(48) NOT NULL,
   severity varchar(16) NOT NULL DEFAULT 'medium',
   source varchar(32) NOT NULL,
   reason varchar(48) NOT NULL,
   actor_hash char(64) NOT NULL DEFAULT '',
   event_key char(64) NOT NULL,
   occurrences int unsigned NOT NULL DEFAULT 1,
   created_at datetime NOT NULL,
   PRIMARY KEY (id),
   UNIQUE KEY event_key (event_key),
   KEY type_created (event_type,created_at),
   KEY created_at (created_at)
  ) {$charset};");
  dbDelta("CREATE TABLE {$rates} (
   bucket char(64) NOT NULL,
   window_start datetime NOT NULL,
   hits int unsigned NOT NULL DEFAULT 0,
   PRIMARY KEY (bucket),
   KEY window_start (window_start)
  ) {$charset};");
  update_option('dreminex_security_center_schema', self::SCHEMA, false);
 }

 private static function remote_ip() {
  $ip=trim((string)($_SERVER['REMOTE_ADDR']??''));
  return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '';
 }

 private static function identity_hash($value) {
  return hash_hmac('sha256', strtolower(trim((string)$value)), wp_salt('auth'));
 }

 private static function event($type, $source, $reason, $severity='medium', $actor_hash='') {
  global $wpdb;
  $type=sanitize_key($type); $source=sanitize_key($source); $reason=sanitize_key($reason);
  $actor_hash=preg_match('/^[a-f0-9]{64}$/',(string)$actor_hash)?$actor_hash:'';
  $bucket=intdiv(time(),15*MINUTE_IN_SECONDS);
  $key=hash('sha256',$type.'|'.$source.'|'.$reason.'|'.$actor_hash.'|'.$bucket);
  $table=self::events_table();
  $wpdb->query($wpdb->prepare(
   "INSERT INTO {$table} (event_type,severity,source,reason,actor_hash,event_key,occurrences,created_at) VALUES (%s,%s,%s,%s,%s,%s,1,%s) ON DUPLICATE KEY UPDATE occurrences=occurrences+1,created_at=VALUES(created_at)",
   $type,sanitize_key($severity),$source,$reason,$actor_hash,$key,self::now()
  ));
 }

 /** Atomically count one pseudonymous actor in a fixed-duration bucket. */
 private static function hit($kind, $actor_hash, $window_seconds) {
  global $wpdb;
  $bucket=hash_hmac('sha256', $kind.'|'.$actor_hash, wp_salt('auth'));
  $period=max(60, absint($window_seconds));
  $window=gmdate('Y-m-d H:i:s', intdiv(time(), $period)*$period);
  $table=self::rates_table();
  $sql=$wpdb->prepare(
   "INSERT INTO {$table} (bucket,window_start,hits) VALUES (%s,%s,1) ON DUPLICATE KEY UPDATE hits=IF(window_start<%s,1,hits+1),window_start=IF(window_start<%s,%s,window_start)",
   $bucket,$window,$window,$window,$window
  );
  if ($wpdb->query($sql) === false) {
   $fallback='dreminex_sec_rate_'.substr($bucket,0,40);
   $count=(int)get_transient($fallback)+1;
   set_transient($fallback,$count,$period);
   return $count;
  }
  return (int)$wpdb->get_var($wpdb->prepare("SELECT hits FROM {$table} WHERE bucket=%s",$bucket));
 }

 private static function current_hits($kind, $actor_hash, $window_seconds) {
  global $wpdb;
  $bucket=hash_hmac('sha256', $kind.'|'.$actor_hash, wp_salt('auth'));
  $period=max(60, absint($window_seconds));
  $window=gmdate('Y-m-d H:i:s', intdiv(time(), $period)*$period);
  $value=$wpdb->get_var($wpdb->prepare('SELECT hits FROM '.self::rates_table().' WHERE bucket=%s AND window_start=%s',$bucket,$window));
  return $value===null ? (int)get_transient('dreminex_sec_rate_'.substr($bucket,0,40)) : (int)$value;
 }

 /** The contact-form guard runs even when Mail Engine is disabled. */
 public static function guard_contact($result, $input=[]) {
  if (is_wp_error($result)) return $result;
  $settings=self::settings();
  if (empty($settings['contact_protection'])) return $result;
  $input=is_array($input)?$input:[];
  $ip=self::remote_ip(); $actor=$ip!==''?self::identity_hash($ip):''; $reason='';
  $started=absint($input['started_at']??0);
  $minimum=max(1,min(15,absint($settings['contact_min_seconds'])));
  $body=(string)($input['message']??'');
  $max_links=max(0,min(10,absint($settings['contact_max_links'])));
  preg_match_all('~(?:https?://|www\.)[^\s<>()]+~iu',$body,$matches);
  if (!empty($input['honeypot'])) $reason='honeypot';
  elseif ($started && time()-$started<$minimum) $reason='form_timing';
  elseif (count($matches[0]??[])>$max_links) $reason='excess_links';
  elseif ($actor!=='' && self::hit('contact_10m',$actor,10*MINUTE_IN_SECONDS)>max(1,min(20,absint($settings['contact_max_per_10_minutes'])))) $reason='contact_burst_limit';
  elseif ($actor!=='' && self::hit('contact_daily',$actor,DAY_IN_SECONDS)>max(1,min(100,absint($settings['contact_max_per_day'])))) $reason='contact_daily_limit';
  elseif (!empty($input['email']) && self::hit('contact_email',self::identity_hash(sanitize_email((string)$input['email'])),HOUR_IN_SECONDS)>max(1,min(10,absint($settings['contact_email_max_per_hour'])))) $reason='contact_email_limit';
  elseif ($body!=='' && !empty($input['email']) && self::hit('contact_duplicate',self::identity_hash(sanitize_email((string)$input['email']).'|'.$body),10*MINUTE_IN_SECONDS)>2) $reason='duplicate_message';
  if ($reason!=='') {
   self::event('contact_spam','contact_form',$reason,'high',$actor);
   do_action('dreminex_security_event_recorded',['event_type'=>'contact_spam','severity'=>'high','source'=>'contact_form','reason'=>$reason]);
   return new WP_Error('contact_blocked','Please wait a while before sending another message.');
  }
  return true;
 }

 private static function login_lock_key($actor_hash) { return 'dreminex_sec_login_'.substr($actor_hash,0,40); }
 private static function is_login_post() {
  return strtoupper((string)($_SERVER['REQUEST_METHOD']??''))==='POST'
   && basename((string)($_SERVER['SCRIPT_NAME']??''))==='wp-login.php';
 }

 public static function guard_login($user, $username='', $password='') {
  $settings=self::settings(); $ip=self::remote_ip();
  if (empty($settings['login_protection']) || !$ip || !self::is_login_post()) return $user;
  $actor=self::identity_hash($ip);
  if (!get_transient(self::login_lock_key($actor))) return $user;
  $logged_key=self::login_lock_key($actor).'_logged';
  if (!get_transient($logged_key)) {
   self::event('login_rate_limited','wp_login','temporary_lockout','high',$actor);
   set_transient($logged_key,1,10*MINUTE_IN_SECONDS);
  }
  return new WP_Error('dreminex_login_rate_limited','Too many sign-in attempts. Please try again later.');
 }

 public static function record_login_failure($username='', $error=null) {
  $settings=self::settings(); $ip=self::remote_ip();
  if (empty($settings['login_protection']) || !$ip) return;
  $actor=self::identity_hash($ip); $period=15*MINUTE_IN_SECONDS;
  $hits=self::hit('login_failures',$actor,$period);
  self::event('login_failure','wp_login','invalid_credentials','medium',$actor);
  $limit=max(3,min(30,absint($settings['login_max_failures'])));
  if ($hits >= $limit) {
   set_transient(self::login_lock_key($actor),1,max(5,min(120,absint($settings['login_lock_minutes'])))*MINUTE_IN_SECONDS);
   self::event('login_rate_limited','wp_login','failure_threshold_reached','high',$actor);
   do_action('dreminex_security_event_recorded',['event_type'=>'login_rate_limited','severity'=>'high','source'=>'wp_login','reason'=>'failure_threshold_reached']);
  }
 }

 public static function filter_xmlrpc($enabled) {
  if (empty(self::settings()['xmlrpc_protection'])) return $enabled;
  if (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST) {
   $ip=self::remote_ip(); self::event('xmlrpc_blocked','xmlrpc','xmlrpc_disabled','medium',$ip?self::identity_hash($ip):'');
  }
  return false;
 }

 public static function send_security_headers() {
  if (empty(self::settings()['security_headers']) || headers_sent()) return;
  header('X-Content-Type-Options: nosniff', true);
  header('Referrer-Policy: strict-origin-when-cross-origin', true);
 }

 public static function update_settings($input) {
  $input=is_array($input)?$input:[]; $settings=self::settings();
  foreach (['contact_protection','login_protection','xmlrpc_protection','security_headers'] as $key) {
   if (array_key_exists($key,$input)) $settings[$key]=in_array($input[$key],[true,1,'1','true','yes','on'],true);
  }
  $bounds=[
   'contact_min_seconds'=>[1,15], 'contact_max_per_10_minutes'=>[1,20],
   'contact_max_per_day'=>[1,100], 'contact_email_max_per_hour'=>[1,10],
   'contact_max_links'=>[0,10], 'login_max_failures'=>[3,30],
   'login_lock_minutes'=>[5,120], 'event_retention_days'=>[7,90],
  ];
  foreach($bounds as $key=>$range) if(array_key_exists($key,$input)) $settings[$key]=max($range[0],min($range[1],absint($input[$key])));
  update_option(self::OPTION,$settings,false);
  return $settings;
 }

 public static function dashboard() {
  global $wpdb; $events=self::events_table(); $settings=self::settings();
  $since=gmdate('Y-m-d H:i:s',time()-DAY_IN_SECONDS);
  $contacts=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(occurrences),0) FROM {$events} WHERE event_type='contact_spam' AND created_at >= %s",$since));
  $logins=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(occurrences),0) FROM {$events} WHERE event_type IN ('login_failure','login_rate_limited') AND created_at >= %s",$since));
  $rows=$wpdb->get_results($wpdb->prepare("SELECT id,event_type,severity,source,reason,occurrences,created_at FROM {$events} ORDER BY id DESC LIMIT %d",50),ARRAY_A);
  $recent=[];
  foreach((array)$rows as $row) $recent[]=[
   'id'=>(int)$row['id'], 'event_type'=>(string)$row['event_type'],
   'severity'=>(string)$row['severity'], 'source'=>(string)$row['source'],
   'reason'=>(string)$row['reason'], 'occurrences'=>(int)($row['occurrences']??1), 'created_at'=>(string)$row['created_at'],
  ];
  $checks=[
   ['id'=>'https','label'=>'HTTPS site URL','status'=>strtolower((string)wp_parse_url(home_url('/'),PHP_URL_SCHEME))==='https'],
   ['id'=>'contact','label'=>'Contact form protection','status'=>!empty($settings['contact_protection'])],
   ['id'=>'login','label'=>'Login rate limiting','status'=>!empty($settings['login_protection'])],
   ['id'=>'headers','label'=>'Security response headers','status'=>!empty($settings['security_headers'])],
  ];
  $operations=class_exists('Dreminex_Nexus_App')?Dreminex_Nexus_App::operations_summary():[];
  $active=0; foreach($checks as $check) if($check['status'])$active++;
  return [
   'schema_version'=>1, 'site_id'=>hash('sha256',home_url('/')), 'generated_at'=>gmdate('c'),
   'protection_state'=>$active===count($checks)?'protected':'attention',
   'checks'=>$checks, 'contact_blocks_24h'=>$contacts, 'login_events_24h'=>$logins,
   'operations_summary'=>$operations, 'events'=>$recent, 'settings'=>$settings, 'event_retention_days'=>(int)$settings['event_retention_days'],
  ];
 }

 public static function cleanup() {
  global $wpdb; $days=max(7,min(90,absint(self::settings()['event_retention_days'])));
  $wpdb->query($wpdb->prepare('DELETE FROM '.self::events_table().' WHERE created_at < %s',gmdate('Y-m-d H:i:s',time()-$days*DAY_IN_SECONDS)));
  $wpdb->query($wpdb->prepare('DELETE FROM '.self::rates_table().' WHERE window_start < %s',gmdate('Y-m-d H:i:s',time()-2*DAY_IN_SECONDS)));
 }

 public static function ability_category() {
  if(function_exists('wp_register_ability_category')) wp_register_ability_category('dreminex-security',['label'=>'Dreminex Security Center','description'=>'Site protection status, privacy-safe security events and bounded security policy controls.']);
 }

 public static function abilities() {
  if (!function_exists('wp_register_ability')) return;
  $schema=['type'=>'object','additionalProperties'=>false];
  wp_register_ability('dreminex-security/dashboard-read',[
   'label'=>'Read Security Center dashboard', 'description'=>'Review site security checks, recent privacy-safe events and the integrated read-only store operations summary.',
   'category'=>'dreminex-security','input_schema'=>$schema,
   'output_schema'=>['type'=>'object','additionalProperties'=>true], 'execute_callback'=>static fn()=>self::dashboard(),
   'permission_callback'=>static fn()=>current_user_can('manage_options'),
   'annotations'=>['readonly'=>true,'destructive'=>false,'idempotent'=>true],
   'meta'=>['annotations'=>['readonly'=>true,'destructive'=>false,'idempotent'=>true],'mcp'=>['public'=>true]],
  ]);
  wp_register_ability('dreminex-security/policy-update',[
   'label'=>'Update Security Center protections', 'description'=>'Update bounded contact spam, sign-in rate limit, XML-RPC and security header settings.',
   'category'=>'dreminex-security',
   'input_schema'=>['type'=>'object','properties'=>[
    'contact_protection'=>['type'=>'boolean'],'contact_min_seconds'=>['type'=>'integer','minimum'=>1,'maximum'=>15],
    'contact_max_per_10_minutes'=>['type'=>'integer','minimum'=>1,'maximum'=>20],'contact_max_per_day'=>['type'=>'integer','minimum'=>1,'maximum'=>100],
    'contact_email_max_per_hour'=>['type'=>'integer','minimum'=>1,'maximum'=>10],'contact_max_links'=>['type'=>'integer','minimum'=>0,'maximum'=>10],
    'login_protection'=>['type'=>'boolean'],'login_max_failures'=>['type'=>'integer','minimum'=>3,'maximum'=>30],
    'login_lock_minutes'=>['type'=>'integer','minimum'=>5,'maximum'=>120],'xmlrpc_protection'=>['type'=>'boolean'],
    'security_headers'=>['type'=>'boolean'],'event_retention_days'=>['type'=>'integer','minimum'=>7,'maximum'=>90],
   ],'additionalProperties'=>false],
   'output_schema'=>['type'=>'object','additionalProperties'=>true],
   'execute_callback'=>static fn($input)=>['settings'=>self::update_settings((array)$input)],
   'permission_callback'=>static fn()=>current_user_can('manage_options'),
   'annotations'=>['readonly'=>false,'destructive'=>false,'idempotent'=>true],
   'meta'=>['annotations'=>['readonly'=>false,'destructive'=>false,'idempotent'=>true],'mcp'=>['public'=>true]],
  ]);
 }
}
