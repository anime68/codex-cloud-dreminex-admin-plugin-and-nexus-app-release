<?php
if (!defined('ABSPATH')) exit;

/** Guarded v3 helpers. Remote file work is limited to explicitly configured roots outside the web root. */
final class Dreminex_MCP_Abilities_V3 {
    private const QUEUE_OPTION = 'dreminex_mcp_editor_queue_v3';
    private const MAX_FILE_BYTES = 131072;
    private const SAFE_EXTENSIONS = ['txt','md','json','csv','html','css'];

    public static function execute($name, $input) {
        switch ($name) {
            case 'dreminex-system/agent-context-read': return self::agent_context();
            case 'dreminex-editor/finalizer-status': return self::finalizer_status();
            case 'dreminex-editor/block-type-read': return self::block_type_read($input);
            case 'dreminex-editor/queue-create': return self::queue_create($input);
            case 'dreminex-editor/queue-add-change': return self::queue_add_change($input);
            case 'dreminex-editor/queue-ready': return self::queue_ready($input);
            case 'dreminex-editor/queue-read': return self::queue_read($input);
            case 'dreminex-editor/queue-list': return self::queue_list($input);
            case 'dreminex-editor/queue-cancel': return self::queue_cancel($input);
            case 'dreminex-editor/queue-cancel-change': return self::queue_cancel_change($input);
            case 'dreminex-editor/finalization-url': return self::finalization_url($input);
            case 'dreminex-files/scoped-read': return self::file_read($input);
            case 'dreminex-files/scoped-list': return self::file_list($input);
            case 'dreminex-files/scoped-write': return self::file_write($input);
            case 'dreminex-files/scoped-edit': return self::file_edit($input);
            case 'dreminex-files/scoped-trash': return self::file_trash($input);
            case 'dreminex-files/sandbox-disable':
            case 'dreminex-files/sandbox-enable': return new WP_Error('execution_sandbox_unavailable', 'This installation has no isolated executable sandbox. The request was denied without changing a file.', ['status' => 424]);
            case 'dreminex-developer/sandbox-code-task': return self::code_task($input);
            case 'dreminex-admin/access-exchange-request': return new WP_Error('access_exchange_disabled', 'Administrator access exchange is not enabled. Use the normal interactive WordPress authorization flow.', ['status' => 403]);
            case 'dreminex-workflow/skills-delete': return self::skill_trash($input);
            case 'dreminex-design/design-list': return self::design_list($input);
            case 'dreminex-design/design-activate': return self::design_activate($input);
            case 'dreminex-design/design-delete': return self::design_trash($input);
        }
        return new WP_Error('ability_not_implemented', 'No v3 handler exists for this ability.', ['status' => 501]);
    }

    private static function agent_context() {
        $abilities = function_exists('wp_get_abilities') ? (array) wp_get_abilities() : [];
        $names = [];
        foreach ($abilities as $key => $ability) {
            $name = is_object($ability) && method_exists($ability, 'get_name') ? $ability->get_name() : (string) $key;
            if (str_starts_with($name, 'dreminex-')) $names[] = $name;
        }
        sort($names);
        $roles = [];
        $user = wp_get_current_user();
        if ($user && $user->exists()) $roles = array_values(array_map('sanitize_key', (array) $user->roles));
        $skills = [];
        foreach (self::option_records('dreminex_mcp_skill_', 50) as $slug => $record) {
            if (str_starts_with($slug, 'trash_') || !is_array($record)) continue;
            $skills[] = ['slug' => sanitize_title($slug), 'revision' => sanitize_text_field((string) ($record['revision'] ?? '')), 'saved_at' => sanitize_text_field((string) ($record['saved_at'] ?? ''))];
        }
        return [
            'site' => ['home_url' => esc_url_raw(home_url('/')), 'site_id' => hash('sha256', home_url('/')), 'environment' => self::environment()],
            'runtime' => ['wordpress' => get_bloginfo('version'), 'php' => PHP_VERSION, 'suite' => defined('DREMINEX_SUITE_VERSION') ? DREMINEX_SUITE_VERSION : 'unknown', 'woocommerce' => defined('WC_VERSION') ? WC_VERSION : null],
            'actor' => ['user_id' => get_current_user_id(), 'roles' => $roles],
            'constraints' => ['no_raw_php_execution' => true, 'no_shell' => true, 'file_roots_configured' => count(self::safe_roots()), 'queue_finalization_requires_admin' => true],
            'skills' => $skills,
            'abilities' => array_slice($names, 0, 200),
        ];
    }

    private static function environment() {
        if (class_exists('Dreminex_Native_MCP') && method_exists('Dreminex_Native_MCP', 'environment')) return sanitize_key((string) Dreminex_Native_MCP::environment());
        return wp_get_environment_type();
    }

    private static function finalizer_status() {
        $queues = self::queues(); $counts = ['pending' => 0, 'ready' => 0, 'completed' => 0, 'cancelled' => 0];
        foreach ($queues as $queue) { $status = sanitize_key((string) ($queue['status'] ?? 'pending')); if (isset($counts[$status])) $counts[$status]++; }
        return ['enabled' => true, 'automatic_content_write' => false, 'browser_finalization_available' => true, 'manual_finalize_required' => true, 'queue_counts' => $counts, 'note' => 'Staged Gutenberg changes are not written until an administrator reviews and saves the post in WordPress.'];
    }

    private static function block_type_read($input) {
        $name = sanitize_text_field((string) ($input['block_name'] ?? ''));
        if (!preg_match('/^[a-z0-9-]+\/[a-z0-9-]+$/', $name) || !class_exists('WP_Block_Type_Registry')) return new WP_Error('invalid_block_name', 'Use a registered block name such as core/paragraph.');
        $type = WP_Block_Type_Registry::get_instance()->get_registered($name);
        if (!$type) return new WP_Error('block_type_not_found', 'That block type is not registered.', ['status' => 404]);
        $schema = method_exists($type, 'get_attributes') ? $type->get_attributes() : (array) ($type->attributes ?? []);
        return ['name' => $type->name, 'title' => sanitize_text_field((string) ($type->title ?? $type->name)), 'category' => sanitize_key((string) ($type->category ?? '')), 'attributes' => array_slice((array) $schema, 0, 100, true), 'supports' => array_slice((array) ($type->supports ?? []), 0, 50, true), 'api_version' => absint($type->api_version ?? 1)];
    }

    private static function queue_create($input) {
        if (!current_user_can('edit_posts')) return new WP_Error('permission_denied', 'Editor queues require edit_posts.');
        $title = sanitize_text_field((string) ($input['title'] ?? '')); if ($title === '') return new WP_Error('invalid_queue_title', 'Add a short queue title.');
        $queues = self::queues(); $cutoff = time() - 30 * DAY_IN_SECONDS;
        foreach ($queues as $old_id => $old) if (in_array(($old['status'] ?? ''), ['completed','cancelled'], true) && strtotime((string) ($old['updated_at'] ?? $old['completed_at'] ?? $old['cancelled_at'] ?? $old['created_at'] ?? '')) < $cutoff) unset($queues[$old_id]);
        if (count($queues) >= 50) return new WP_Error('queue_limit_reached', 'The editor queue has reached 50 active or recent entries. Cancel or wait for older completed queues to expire.', ['status' => 429]);
        $id = wp_generate_uuid4(); $queues[$id] = ['queue_id' => $id, 'title' => $title, 'status' => 'pending', 'changes' => [], 'created_at' => gmdate('c'), 'created_by' => get_current_user_id()];
        update_option(self::QUEUE_OPTION, $queues, false);
        return ['created' => true, 'queue_id' => $id, 'status' => 'pending', 'changes' => 0, 'applies_content' => false];
    }

    private static function queue_add_change($input) {
        $queues = self::queues(); $queue_id = sanitize_text_field((string) ($input['queue_id'] ?? '')); $queue = $queues[$queue_id] ?? null;
        if (!$queue || !self::can_manage_queue($queue) || ($queue['status'] ?? '') !== 'pending') return new WP_Error('queue_not_editable', 'A pending editor queue was not found or is not owned by this user.', ['status' => 404]);
        if (count((array) ($queue['changes'] ?? [])) >= 20) return new WP_Error('queue_limit_reached', 'An editor queue may contain at most 20 changes.', ['status' => 429]);
        $post_id = absint($input['post_id'] ?? 0); $post = get_post($post_id);
        if (!$post || !current_user_can('edit_post', $post_id)) return new WP_Error('permission_denied', 'The post is unavailable or cannot be edited.', ['status' => 403]);
        foreach ((array) ($queue['changes'] ?? []) as $staged) if ((int) ($staged['post_id'] ?? 0) === $post_id) return new WP_Error('duplicate_post_target', 'A queue can stage only one change per post so each revision remains unambiguous.', ['status' => 409]);
        $expected = strtolower((string) ($input['expected_revision'] ?? '')); $actual = self::post_revision($post);
        if ($expected === '' || !hash_equals($actual, $expected)) return new WP_Error('revision_conflict', 'The post changed since it was read. Refresh before staging a change.', ['status' => 409]);
        $candidate = (string) ($input['candidate_content'] ?? ''); if (strlen($candidate) > 50000) return new WP_Error('content_too_large', 'A staged editor change is limited to 50 KB.');
        if (!function_exists('parse_blocks') || !function_exists('serialize_blocks')) return new WP_Error('editor_unavailable', 'The Gutenberg serializer is unavailable.', ['status' => 424]);
        $candidate = wp_kses_post($candidate); $parsed = parse_blocks($candidate); $roundtrip = serialize_blocks($parsed);
        if ($roundtrip !== $candidate) return new WP_Error('invalid_block_serialization', 'The staged content did not pass the WordPress block serialization check.');
        $change_id = wp_generate_uuid4(); $queue['changes'][] = ['change_id' => $change_id, 'post_id' => $post_id, 'expected_revision' => $expected, 'candidate_content' => $candidate, 'candidate_sha256' => hash('sha256', $candidate), 'base_sha256' => hash('sha256', (string) $post->post_content), 'created_at' => gmdate('c')];
        $queues[$queue_id] = $queue; update_option(self::QUEUE_OPTION, $queues, false);
        return ['queued' => true, 'queue_id' => $queue_id, 'change_id' => $change_id, 'post_id' => $post_id, 'candidate_sha256' => hash('sha256', $candidate), 'applied' => false];
    }

    private static function queue_ready($input) {
        if (empty($input['confirm'])) return new WP_Error('confirmation_required', 'Confirm that the staged changes are ready for administrator review.', ['status' => 409]);
        $queues = self::queues(); $id = sanitize_text_field((string) ($input['queue_id'] ?? '')); $queue = $queues[$id] ?? null;
        if (!$queue || !self::can_manage_queue($queue) || ($queue['status'] ?? '') !== 'pending' || empty($queue['changes'])) return new WP_Error('queue_not_ready', 'A pending queue with at least one owned change is required.');
        foreach ($queue['changes'] as $change) { $post = get_post(absint($change['post_id'] ?? 0)); if (!$post || !current_user_can('edit_post', $post->ID) || !hash_equals((string) ($change['expected_revision'] ?? ''), self::post_revision($post))) return new WP_Error('revision_conflict', 'At least one post changed. Refresh and stage the change again.', ['status' => 409]); }
        $queue['status'] = 'ready'; $queue['ready_at'] = gmdate('c'); $queues[$id] = $queue; update_option(self::QUEUE_OPTION, $queues, false);
        return ['ready' => true, 'queue_id' => $id, 'status' => 'ready', 'change_count' => count($queue['changes']), 'automatic_finalization' => false, 'manual_finalize_required' => true];
    }

    private static function queue_read($input) {
        $id = sanitize_text_field((string) ($input['queue_id'] ?? '')); $queue = self::queues()[$id] ?? null;
        if (!$queue || !self::can_manage_queue($queue)) return new WP_Error('queue_not_found', 'The editor queue was not found or is not owned by this user.', ['status' => 404]);
        $queue['changes'] = array_map(static function ($change) { unset($change['candidate_content']); return $change; }, (array) ($queue['changes'] ?? []));
        return $queue + ['manual_finalize_required' => true];
    }

    private static function queue_list($input) {
        $rows = array_values(self::queues()); usort($rows, static fn($a, $b) => strcmp((string) ($b['created_at'] ?? ''), (string) ($a['created_at'] ?? '')));
        $page = max(1, min(100, absint($input['page'] ?? 1))); $page_size = 25;
        $rows = array_values(array_filter($rows, static fn($q) => self::can_manage_queue($q)));
        return ['queues' => array_map(static fn($q) => ['queue_id' => $q['queue_id'], 'title' => $q['title'], 'status' => $q['status'], 'change_count' => count((array) ($q['changes'] ?? [])), 'created_at' => $q['created_at']], array_slice($rows, ($page - 1) * $page_size, $page_size)), 'page' => $page, 'total' => count($rows)];
    }

    private static function queue_cancel($input) {
        if (empty($input['confirm'])) return new WP_Error('confirmation_required', 'Confirm queue cancellation.', ['status' => 409]);
        $queues = self::queues(); $id = sanitize_text_field((string) ($input['queue_id'] ?? '')); $queue = $queues[$id] ?? null;
        if (!$queue || !self::can_manage_queue($queue) || !in_array($queue['status'] ?? '', ['pending','ready'], true)) return new WP_Error('queue_not_cancellable', 'The queue is missing, already finalized or not owned by this user.');
        foreach ((array) ($queue['changes'] ?? []) as $change) if (($change['status'] ?? '') === 'applied') return new WP_Error('queue_partially_finalized', 'A queue with saved changes cannot be cancelled; remove only unfinalized changes.', ['status' => 409]);
        $queue['status'] = 'cancelled'; $queue['cancelled_at'] = gmdate('c'); $queue['updated_at'] = gmdate('c'); $queue['changes'] = []; $queues[$id] = $queue; update_option(self::QUEUE_OPTION, $queues, false);
        return ['cancelled' => true, 'queue_id' => $id, 'status' => 'cancelled', 'content_changed' => false];
    }

    private static function queue_cancel_change($input) {
        if (empty($input['confirm'])) return new WP_Error('confirmation_required', 'Confirm removal of this staged change.', ['status' => 409]);
        $queues = self::queues(); $id = sanitize_text_field((string) ($input['queue_id'] ?? '')); $queue = $queues[$id] ?? null;
        if (!$queue || !self::can_manage_queue($queue) || ($queue['status'] ?? '') !== 'pending') return new WP_Error('queue_not_editable', 'Only an owned pending editor queue can be changed.');
        $change_id = sanitize_text_field((string) ($input['change_id'] ?? '')); $before = count((array) $queue['changes']);
        $queue['changes'] = array_values(array_filter((array) $queue['changes'], static fn($row) => ($row['change_id'] ?? '') !== $change_id));
        if (count($queue['changes']) === $before) return new WP_Error('change_not_found', 'The staged change was not found.', ['status' => 404]);
        $queues[$id] = $queue; update_option(self::QUEUE_OPTION, $queues, false);
        return ['removed' => true, 'queue_id' => $id, 'remaining_changes' => count($queue['changes'])];
    }

    private static function finalization_url($input) {
        $queue_id = sanitize_text_field((string) ($input['queue_id'] ?? ''));
        if ($queue_id !== '') {
            $queue = self::queues()[$queue_id] ?? null;
            if (!$queue || !self::can_manage_queue($queue)) return new WP_Error('queue_not_found', 'The editor queue was not found or is not owned by this user.', ['status' => 404]);
            return ['url' => admin_url('admin.php?page=dreminex-native-mcp&tab=editor&queue_id=' . rawurlencode($queue_id)), 'authenticated_session_required' => true, 'access_token_in_url' => false, 'manual_save_required' => true, 'queue_status' => sanitize_key((string) ($queue['status'] ?? 'pending'))];
        }
        $post_id = absint($input['post_id'] ?? 0); if ($post_id && !current_user_can('edit_post', $post_id)) return new WP_Error('permission_denied', 'You cannot edit this post.', ['status' => 403]);
        return ['url' => $post_id ? admin_url('post.php?post=' . $post_id . '&action=edit') : admin_url('edit.php'), 'authenticated_session_required' => true, 'access_token_in_url' => false, 'manual_save_required' => true];
    }

    private static function post_revision($post) { return hash('sha256', $post->ID . '|' . get_post_field('post_modified_gmt', $post->ID) . '|' . (string) $post->post_content); }
    private static function can_manage_queue($queue) { return current_user_can('manage_options') || (int) ($queue['created_by'] ?? 0) === get_current_user_id(); }
    private static function queues() { $value = get_option(self::QUEUE_OPTION, []); return is_array($value) ? $value : []; }

    private static function option_records($prefix, $limit) {
        global $wpdb;
        if (!isset($wpdb->options)) return [];
        $pattern = $wpdb->esc_like($prefix) . '%';
        $names = $wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_name ASC LIMIT %d", $pattern, max(1, min(100, (int) $limit))));
        $records = [];
        foreach ((array) $names as $name) {
            $slug = substr((string) $name, strlen($prefix));
            if ($slug === '' || str_starts_with($slug, 'trash_')) continue;
            $record = get_option($name, null);
            if (is_array($record)) $records[$slug] = $record;
        }
        return $records;
    }

    private static function safe_roots() {
        if (!defined('DREMINEX_MCP_SAFE_ROOTS') || !is_array(DREMINEX_MCP_SAFE_ROOTS)) return [];
        $roots = [];
        foreach (array_slice(DREMINEX_MCP_SAFE_ROOTS, 0, 5, true) as $id => $path) {
            $id = sanitize_key((string) $id); $real = realpath((string) $path);
            if ($id === '' || !$real || !is_dir($real) || self::inside_path($real, ABSPATH)) continue;
            $roots[$id] = rtrim($real, DIRECTORY_SEPARATOR);
        }
        return $roots;
    }

    private static function inside_path($path, $parent) { $path = rtrim(wp_normalize_path((string) $path), '/') . '/'; $parent = rtrim(wp_normalize_path((string) $parent), '/') . '/'; return str_starts_with($path, $parent); }

    private static function target($input, $allow_missing = false) {
        $root_id = sanitize_key((string) ($input['root_id'] ?? '')); $roots = self::safe_roots(); if (empty($roots[$root_id])) return new WP_Error('safe_root_unavailable', 'No matching private safe root is configured outside the public web root.', ['status' => 424]);
        $raw = str_replace('\\', '/', trim((string) ($input['path'] ?? ''))); $parts = explode('/', $raw);
        if ($raw === '' || strlen($raw) > 512 || count($parts) > 12) return new WP_Error('invalid_path', 'Provide a relative path with at most 12 segments.');
        foreach ($parts as $part) if ($part === '' || $part === '.' || $part === '..' || str_starts_with($part, '.') || !preg_match('/^[A-Za-z0-9 _.-]{1,100}$/', $part) || preg_match('/(?:wp-config|\.env|credential|secret|private.?key|\.pem|\.key)/i', $part)) return new WP_Error('path_not_allowed', 'The path contains a protected or unsupported segment.');
        $ext = strtolower(pathinfo(end($parts), PATHINFO_EXTENSION)); if (!in_array($ext, self::SAFE_EXTENSIONS, true)) return new WP_Error('file_type_not_allowed', 'Only text, Markdown, JSON, CSV, HTML and CSS files are supported.');
        $root = $roots[$root_id]; $candidate = $root . DIRECTORY_SEPARATOR . implode(DIRECTORY_SEPARATOR, $parts); $exists = file_exists($candidate);
        if ($exists && is_link($candidate)) return new WP_Error('symlink_not_allowed', 'Symbolic links are not permitted.');
        if ($exists) { $real = realpath($candidate); if (!$real || !self::inside_path($real, $root) || !is_file($real)) return new WP_Error('path_not_allowed', 'The requested path is not a regular file inside its configured root.'); $candidate = $real; }
        elseif (!$allow_missing) return new WP_Error('file_not_found', 'The requested text file was not found.', ['status' => 404]);
        else { $parent = realpath(dirname($candidate)); if (!$parent || !self::inside_path($parent, $root)) return new WP_Error('path_not_allowed', 'The parent directory must already exist inside the configured root.'); }
        return ['root_id' => $root_id, 'root' => $root, 'path' => $candidate, 'relative' => implode('/', $parts), 'extension' => $ext, 'exists' => $exists];
    }

    private static function file_read($input) {
        $target = self::target($input); if (is_wp_error($target)) return $target; $size = (int) filesize($target['path']); $limit = max(1, min(262144, absint($input['max_bytes'] ?? 65536)));
        if ($size > $limit) return new WP_Error('file_too_large', 'The text file exceeds the requested read limit.', ['status' => 413]);
        $content = file_get_contents($target['path']); if (!is_string($content)) return new WP_Error('file_read_failed', 'The file could not be read.');
        $source_hash = hash('sha256', $content); $redacted = self::redact($content);
        return ['root_id' => $target['root_id'], 'path' => $target['relative'], 'size_bytes' => strlen($redacted), 'sha256' => $source_hash, 'content_sha256' => hash('sha256', $redacted), 'content' => $redacted, 'secrets_redacted' => true];
    }

    private static function file_list($input) {
        $roots = self::safe_roots(); $root_id = sanitize_key((string) ($input['root_id'] ?? '')); if (empty($roots[$root_id])) return new WP_Error('safe_root_unavailable', 'No matching private safe root is configured outside the public web root.', ['status' => 424]);
        $relative = trim(str_replace('\\', '/', (string) ($input['path'] ?? '')), '/'); $depth = max(0, min(2, absint($input['depth'] ?? 1))); $limit = max(1, min(100, absint($input['limit'] ?? 50))); $base = $roots[$root_id];
        if ($relative !== '') { $fake = self::target(['root_id' => $root_id, 'path' => $relative . '/placeholder.txt'], true); if (is_wp_error($fake)) return $fake; $base = dirname($fake['path']); }
        if (!is_dir($base) || is_link($base)) return new WP_Error('directory_not_found', 'The selected safe directory is unavailable.');
        $rows = []; self::walk($base, $roots[$root_id], $relative, 0, $depth, $limit, $rows);
        return ['root_id' => $root_id, 'path' => $relative, 'items' => $rows, 'limit' => $limit, 'truncated' => count($rows) >= $limit];
    }

    private static function walk($dir, $root, $relative, $level, $max_depth, $limit, &$rows) {
        if ($level > $max_depth || count($rows) >= $limit) return; $items = @scandir($dir); if (!is_array($items)) return;
        foreach ($items as $item) { if ($item === '.' || $item === '..' || str_starts_with($item, '.')) continue; $path = $dir . DIRECTORY_SEPARATOR . $item; if (is_link($path)) continue; $rel = trim($relative . '/' . $item, '/');
            if (is_dir($path)) { if ($level < $max_depth) self::walk($path, $root, $rel, $level + 1, $max_depth, $limit, $rows); continue; }
            $ext = strtolower(pathinfo($item, PATHINFO_EXTENSION)); if (!in_array($ext, self::SAFE_EXTENSIONS, true) || preg_match('/(?:wp-config|credential|secret|private.?key|\.pem|\.key)/i', $item)) continue;
            $rows[] = ['path' => $rel, 'size_bytes' => (int) filesize($path), 'sha256' => hash_file('sha256', $path)]; if (count($rows) >= $limit) break;
        }
    }

    private static function file_write($input) {
        if (empty($input['confirm'])) return new WP_Error('confirmation_required', 'Confirm creation of this scoped text file.', ['status' => 409]);
        $target = self::target($input, true); if (is_wp_error($target)) return $target; if ($target['exists']) return new WP_Error('file_exists', 'The path already exists. Use the SHA-256 guarded edit operation.');
        $content = self::safe_content($target['extension'], (string) ($input['content'] ?? '')); if (is_wp_error($content)) return $content; $result = self::atomic_write($target['path'], $content);
        if (is_wp_error($result)) return $result; return ['saved' => true, 'path' => $target['relative'], 'sha256' => hash('sha256', $content), 'size_bytes' => strlen($content)];
    }

    private static function file_edit($input) {
        if (empty($input['confirm'])) return new WP_Error('confirmation_required', 'Confirm the revision-guarded scoped file edit.', ['status' => 409]);
        $target = self::target($input); if (is_wp_error($target)) return $target; $old = file_get_contents($target['path']); if (!is_string($old)) return new WP_Error('file_read_failed', 'The current file could not be read.');
        $expected = strtolower((string) ($input['expected_sha256'] ?? '')); if ($expected === '' || !hash_equals(hash('sha256', $old), $expected)) return new WP_Error('file_revision_conflict', 'The file changed. Read it again before editing.', ['status' => 409]);
        $content = self::safe_content($target['extension'], (string) ($input['content'] ?? '')); if (is_wp_error($content)) return $content;
        $history_dir = dirname($target['path']) . DIRECTORY_SEPARATOR . '.dreminex-history'; if (!is_dir($history_dir) && !wp_mkdir_p($history_dir)) return new WP_Error('file_backup_failed', 'A private revision backup could not be created.'); @chmod($history_dir, 0700);
        $backup = $history_dir . DIRECTORY_SEPARATOR . basename($target['path']) . '.' . gmdate('YmdHis') . '.' . substr($expected, 0, 12) . '.bak'; if (!@copy($target['path'], $backup)) return new WP_Error('file_backup_failed', 'The prior file revision could not be preserved.'); @chmod($backup, 0600);
        $result = self::atomic_write($target['path'], $content); if (is_wp_error($result)) return $result;
        return ['saved' => true, 'path' => $target['relative'], 'sha256' => hash('sha256', $content), 'previous_sha256' => $expected, 'backup_created' => true];
    }

    private static function file_trash($input) {
        if (empty($input['confirm'])) return new WP_Error('confirmation_required', 'Confirm moving this file to its scoped recovery folder.', ['status' => 409]);
        $target = self::target($input); if (is_wp_error($target)) return $target; $expected = strtolower((string) ($input['expected_sha256'] ?? ''));
        if ($expected === '' || !hash_equals(hash_file('sha256', $target['path']), $expected)) return new WP_Error('file_revision_conflict', 'The file changed. Read it again before moving it to trash.', ['status' => 409]);
        $trash = $target['root'] . DIRECTORY_SEPARATOR . '.dreminex-trash'; if (!is_dir($trash) && !wp_mkdir_p($trash)) return new WP_Error('trash_unavailable', 'The private recovery folder could not be created.'); @chmod($trash, 0700);
        $dest = $trash . DIRECTORY_SEPARATOR . gmdate('YmdHis') . '-' . wp_generate_password(8, false, false) . '-' . basename($target['path']);
        if (!@rename($target['path'], $dest)) return new WP_Error('trash_failed', 'The file could not be moved.'); @chmod($dest, 0600);
        return ['trashed' => true, 'path' => $target['relative'], 'recovery_id' => basename($dest), 'recursive' => false];
    }

    private static function safe_content($extension, $content) {
        if (strlen($content) > self::MAX_FILE_BYTES || str_contains($content, "\0")) return new WP_Error('invalid_file_content', 'Text content must be under 128 KiB and cannot contain binary bytes.');
        if (in_array($extension, ['html','css'], true) && preg_match('/<\s*(?:script|iframe|object|embed)\b|\bon[a-z]+\s*=|javascript\s*:|expression\s*\(|@import\b/i', $content)) return new WP_Error('active_content_blocked', 'Active scripts, event handlers, imports and executable URLs are not allowed.');
        if ($extension === 'json' && json_decode($content, true) === null && trim($content) !== 'null') return new WP_Error('invalid_json', 'The content is not valid JSON.');
        if ($extension === 'html') $content = wp_kses_post($content);
        return $content;
    }

    private static function atomic_write($path, $content) {
        $tmp = @tempnam(dirname($path), '.dreminex-write-'); if (!$tmp) return new WP_Error('file_write_failed', 'A temporary file could not be created.');
        $written = @file_put_contents($tmp, $content, LOCK_EX); if ($written !== strlen($content)) { @unlink($tmp); return new WP_Error('file_write_failed', 'The new file content could not be written completely.'); }
        @chmod($tmp, 0640); if (!@rename($tmp, $path)) { @unlink($tmp); return new WP_Error('file_write_failed', 'The atomic file replacement failed.'); } return true;
    }

    private static function redact($content) {
        $pattern = '/("?(?:password|client_secret|consumer_secret|access_token|refresh_token|private_key|secret_key|api_key|authorization)"?\s*[:=]\s*"?)[^"\s,;}]+/i';
        $redacted = preg_replace($pattern, '$1[REDACTED]', $content);
        return substr((string) $redacted, 0, 262144);
    }

    private static function design_list($input) {
        $limit = max(1, min(100, absint($input['limit'] ?? 50))); $active = sanitize_title((string) get_option('dreminex_mcp_active_design', '')); $records = self::option_records('dreminex_mcp_design_', $limit); $rows = [];
        foreach ($records as $slug => $record) $rows[] = ['slug' => sanitize_title($slug), 'revision' => sanitize_text_field((string) ($record['revision'] ?? '')), 'saved_at' => sanitize_text_field((string) ($record['saved_at'] ?? '')), 'active' => $slug === $active];
        return ['active_slug' => $active, 'designs' => $rows, 'count' => count($rows)];
    }

    private static function design_activate($input) {
        if (empty($input['confirm']) || !current_user_can('manage_options')) return new WP_Error('permission_denied', 'Confirm design activation as an administrator.', ['status' => 403]);
        $slug = sanitize_title((string) ($input['slug'] ?? '')); $record = get_option('dreminex_mcp_design_' . $slug, []); if ($slug === '' || !is_array($record) || empty($record['tokens'])) return new WP_Error('design_not_found', 'A saved design with validated tokens was not found.', ['status' => 404]);
        $revision = (string) ($input['expected_revision'] ?? ''); if ($revision === '' || !hash_equals((string) ($record['revision'] ?? ''), $revision)) return new WP_Error('revision_conflict', 'The saved design changed. Read its current revision before activation.', ['status' => 409]);
        if (!hash_equals(hash('sha256', wp_json_encode((array) $record['tokens'])), (string) ($record['revision'] ?? ''))) return new WP_Error('invalid_design_revision', 'The saved design tokens do not match their recorded revision.', ['status' => 409]);
        $old = sanitize_title((string) get_option('dreminex_mcp_active_design', '')); $history = (array) get_option('dreminex_mcp_active_design_history', []); if ($old !== '' && $old !== $slug) $history[] = ['slug' => $old, 'changed_at' => gmdate('c')]; update_option('dreminex_mcp_active_design_history', array_slice($history, -10), false); update_option('dreminex_mcp_active_design', $slug, false);
        return ['activated' => true, 'slug' => $slug, 'previous_slug' => $old, 'reversible' => true];
    }

    private static function design_trash($input) {
        if (empty($input['confirm']) || !current_user_can('manage_options')) return new WP_Error('permission_denied', 'Confirm design removal as an administrator.', ['status' => 403]);
        $slug = sanitize_title((string) ($input['slug'] ?? '')); $key = 'dreminex_mcp_design_' . $slug; $record = get_option($key, null); if ($slug === '' || !is_array($record)) return new WP_Error('design_not_found', 'The saved design was not found.', ['status' => 404]);
        $revision = (string) ($input['expected_revision'] ?? ''); if ($revision === '' || !hash_equals((string) ($record['revision'] ?? ''), $revision)) return new WP_Error('revision_conflict', 'The saved design changed. Read it again before trashing it.', ['status' => 409]);
        $restored = '';
        if (get_option('dreminex_mcp_active_design') === $slug) {
            $history = array_values((array) get_option('dreminex_mcp_active_design_history', []));
            while ($history) { $previous = array_pop($history); $candidate = sanitize_title((string) ($previous['slug'] ?? '')); if ($candidate !== '' && $candidate !== $slug && is_array(get_option('dreminex_mcp_design_' . $candidate, null))) { $restored = $candidate; break; } }
            if ($restored !== '') update_option('dreminex_mcp_active_design', $restored, false); else delete_option('dreminex_mcp_active_design');
            update_option('dreminex_mcp_active_design_history', array_slice($history, -10), false);
        }
        update_option('dreminex_mcp_design_trash_' . $slug, ['record' => $record, 'trashed_at' => gmdate('c'), 'trashed_by' => get_current_user_id()], false); delete_option($key);
        return ['trashed' => true, 'slug' => $slug, 'restored_active_design' => $restored, 'permanently_deleted' => false];
    }

    private static function skill_trash($input) {
        if (empty($input['confirm']) || !current_user_can('manage_options')) return new WP_Error('permission_denied', 'Confirm skill removal as an administrator.', ['status' => 403]);
        $slug = sanitize_title((string) ($input['slug'] ?? '')); $key = 'dreminex_mcp_skill_' . $slug; $record = get_option($key, null); if ($slug === '' || !is_array($record)) return new WP_Error('skill_not_found', 'The saved skill was not found.', ['status' => 404]);
        $revision = (string) ($input['expected_revision'] ?? ''); if ($revision === '' || !hash_equals((string) ($record['revision'] ?? ''), $revision)) return new WP_Error('revision_conflict', 'The saved skill changed. Read its current revision before trashing it.', ['status' => 409]);
        update_option('dreminex_mcp_skill_trash_' . $slug, ['record' => $record, 'trashed_at' => gmdate('c'), 'trashed_by' => get_current_user_id()], false); delete_option($key);
        return ['trashed' => true, 'slug' => $slug, 'permanently_deleted' => false];
    }

    private static function code_task($input) {
        if (!current_user_can('manage_options') || ($input['task'] ?? '') !== 'refresh_ability_registry') return new WP_Error('task_not_allowed', 'Only the pre-registered ability registry refresh task is supported.', ['status' => 403]);
        if (!function_exists('wp_get_abilities')) return new WP_Error('abilities_api_unavailable', 'The WordPress Abilities API is unavailable.', ['status' => 424]);
        Dreminex_MCP_Abilities_V2::register(); return ['task' => 'refresh_ability_registry', 'completed' => true, 'registered_count' => count((array) wp_get_abilities()), 'php_execution' => false];
    }
}
