<?php
if (!defined('ABSPATH')) exit;

/** WordPress Media Library operations, confined to verified attachment IDs. */
final class Dreminex_MCP_Media_V2 {
    private static function attachment($input) {
        $id = absint($input['attachment_id'] ?? 0);
        if (!$id && !empty($input['media_url'])) {
            $url = self::same_site_upload_url((string) $input['media_url']);
            if (is_wp_error($url)) return $url;
            $id = attachment_url_to_postid($url);
        }
        $post = $id ? get_post($id) : null;
        if (!$post || $post->post_type !== 'attachment') return new WP_Error('attachment_not_found', 'The Media Library attachment could not be resolved.', ['status' => 404]);
        if (!current_user_can('upload_files') && !current_user_can('edit_post', $id)) return new WP_Error('permission_denied', 'The connected user cannot read or edit this attachment.');
        return $post;
    }

    private static function same_site_upload_url($url) {
        $url = esc_url_raw(trim($url)); $parts = wp_parse_url($url); $uploads = wp_get_upload_dir(); $base = wp_parse_url((string) ($uploads['baseurl'] ?? ''));
        if (!$parts || strtolower((string) ($parts['scheme'] ?? '')) !== 'https' || strtolower((string) ($parts['host'] ?? '')) !== strtolower((string) ($base['host'] ?? '')) || !empty($parts['user']) || !empty($parts['pass'])) return new WP_Error('site_lock_mismatch', 'Only a canonical HTTPS URL from this site’s WordPress uploads directory can be resolved.');
        $path = rawurldecode((string) ($parts['path'] ?? '')); $base_path = rawurldecode((string) ($base['path'] ?? ''));
        if ($base_path === '' || !str_starts_with($path, rtrim($base_path, '/') . '/') || str_contains($path, "\0") || preg_match('~(^|/)\.\.?(/|$)~', $path)) return new WP_Error('remote_url_not_allowed', 'The URL is outside the configured uploads directory.');
        return $url;
    }

    private static function canonical_metadata($post, $include_hash = false) {
        $id = (int) $post->ID; $file = get_attached_file($id); $real = is_string($file) ? realpath($file) : false; $uploads = wp_get_upload_dir(); $root = realpath((string) ($uploads['basedir'] ?? ''));
        $size = $real && is_file($real) ? filesize($real) : 0; $hash = (string) get_post_meta($id, '_dreminex_mcp_sha256', true);
        if ($include_hash && $hash === '' && $real && is_file($real)) { $hash = hash_file('sha256', $real); if ($hash) update_post_meta($id, '_dreminex_mcp_sha256', $hash); }
        $refs = self::references($id);
        $meta = wp_get_attachment_metadata($id); $mime = (string) get_post_mime_type($id);
        return ['attachment_id' => $id, 'source_url' => (string) wp_get_attachment_url($id), 'title' => get_the_title($id), 'slug' => (string) $post->post_name, 'alt_text' => (string) get_post_meta($id, '_wp_attachment_image_alt', true), 'caption' => (string) $post->post_excerpt, 'description' => (string) $post->post_content, 'mime_type' => $mime, 'media_type' => wp_attachment_is_image($id) ? 'image' : 'file', 'file_size' => (int) $size, 'sha256' => $hash, 'original_filename' => $real ? wp_basename($real) : '', 'stored_filename' => $real ? wp_basename($real) : '', 'width' => (int) ($meta['width'] ?? 0), 'height' => (int) ($meta['height'] ?? 0), 'modified_gmt' => (string) $post->post_modified_gmt, 'associated_post_ids' => $refs, 'attachment_revision' => self::revision($post)];
    }

    private static function revision($post) { return (string) $post->post_modified_gmt . ':' . substr(hash('sha256', $post->post_title . '|' . $post->post_excerpt . '|' . $post->post_content . '|' . get_post_meta($post->ID, '_wp_attachment_image_alt', true)), 0, 24); }

    public static function execute($name, $input) {
        switch ($name) {
            case 'dreminex-media/library-search': return self::library_search($input);
            case 'dreminex-media/resolve':
            case 'dreminex-media/metadata-read': return self::metadata_read($input);
            case 'dreminex-media/content-read': return self::content_read($input);
            case 'dreminex-media/metadata-update': return self::metadata_update($input);
            case 'dreminex-media/metadata-batch-update': return self::metadata_batch_update($input);
            case 'dreminex-media/upload-inline': return self::upload_inline($input);
            case 'dreminex-media/upload-session-create': return Dreminex_MCP_Upload::create_session($input);
            case 'dreminex-media/upload-session-status': return Dreminex_MCP_Upload::session_status((string) ($input['upload_id'] ?? ''));
            case 'dreminex-media/upload-session-complete': return Dreminex_MCP_Upload::complete_session((string) ($input['upload_id'] ?? ''), (string) ($input['expected_sha256'] ?? ''), $input['metadata'] ?? [], (string) ($input['duplicate_behavior'] ?? 'reject'));
            case 'dreminex-media/upload-session-cancel': return Dreminex_MCP_Upload::cancel_session((string) ($input['upload_id'] ?? ''));
            case 'dreminex-media/upload-from-client-attachment': return new WP_Error('client_attachment_unavailable', 'The chat client must transfer the selected attachment bytes through inline upload or a signed upload session.', ['status' => 424, 'supported_alternatives' => ['dreminex-media/upload-inline', 'dreminex-media/upload-session-create']]);
            case 'dreminex-media/chat-file-capabilities': return self::chat_capabilities($input);
            case 'dreminex-media/url-import-safe': return self::import_url($input);
            case 'dreminex-media/duplicate-find': return self::duplicate_find($input);
            case 'dreminex-media/reference-usage-read': return self::reference_usage($input);
            case 'dreminex-media/attach-to-post': return self::attach_to_post($input);
            case 'dreminex-media/product-gallery-set': return self::product_gallery_set($input);
            case 'dreminex-media/variation-image-set': return self::variation_image_set($input);
            case 'dreminex-media/image-sizes-read': return self::image_sizes($input);
            case 'dreminex-media/regenerate-metadata': return self::regenerate_metadata($input);
            case 'dreminex-media/attachment-trash': return self::trash_attachment($input);
            case 'dreminex-media/attachment-restore': return self::restore_attachment($input);
            case 'dreminex-media/attachment-delete-permanent': return self::delete_attachment($input);
            case 'dreminex-media/filename-rename-plan': return self::rename_plan($input);
            case 'dreminex-media/import-batch': return self::import_batch($input);
        }
        return new WP_Error('ability_not_implemented', 'No media handler exists for this ability.', ['status' => 501]);
    }

    private static function library_search($input) {
        $page = max(1, absint($input['page'] ?? 1)); $per = max(1, min(100, absint($input['per_page'] ?? 40))); $args = ['post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => $per, 'paged' => $page, 's' => sanitize_text_field((string) ($input['query'] ?? '')), 'orderby' => 'date', 'order' => 'DESC'];
        $family = sanitize_key((string) ($input['mime_family'] ?? ''));
        if ($family && in_array($family, ['image','audio','video','application','text'], true)) $args['post_mime_type'] = $family;
        if (!empty($input['associated_post_id'])) $args['post_parent'] = absint($input['associated_post_id']);
        $query = new WP_Query($args); $items = [];
        foreach ($query->posts as $post) {
            if (!current_user_can('upload_files') && !current_user_can('edit_post', $post->ID)) continue;
            $items[] = self::canonical_metadata($post);
        }
        return ['results' => $items, 'page' => $page, 'per_page' => $per, 'total' => (int) $query->found_posts, 'total_pages' => (int) $query->max_num_pages];
    }

    private static function metadata_read($input) {
        $post = self::attachment($input); return is_wp_error($post) ? $post : self::canonical_metadata($post, true);
    }

    private static function confined_file($id) {
        $path = get_attached_file($id); $real = is_string($path) ? realpath($path) : false; $uploads = wp_get_upload_dir(); $root = realpath((string) ($uploads['basedir'] ?? ''));
        if (!$real || !$root || !is_file($real) || !str_starts_with($real, rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR)) return new WP_Error('attachment_not_found', 'The attachment file is missing or outside this site’s uploads directory.');
        return $real;
    }

    private static function content_read($input) {
        $post = self::attachment($input); if (is_wp_error($post)) return $post; $id = (int) $post->ID; $mode = sanitize_key((string) ($input['representation'] ?? 'metadata'));
        if ($mode === '' || $mode === 'metadata') return self::canonical_metadata($post, true);
        if ($mode === 'thumbnail') {
            if (!wp_attachment_is_image($id)) return new WP_Error('unsupported_mime', 'Only image attachments have thumbnail previews.');
            return ['attachment_id' => $id, 'representation' => 'thumbnail', 'preview_url' => (string) wp_get_attachment_image_url($id, 'thumbnail'), 'mime_type' => get_post_mime_type($id)];
        }
        $path = self::confined_file($id); if (is_wp_error($path)) return $path;
        $size = filesize($path); $max = max(1024, min(262144, absint($input['max_bytes'] ?? 131072))); $offset = max(0, absint($input['offset'] ?? 0));
        if ($mode === 'preview_base64' && (!wp_attachment_is_image($id) || $size > 262144)) return new WP_Error('preview_unavailable', 'Inline image preview is limited to image files up to 256 KiB.');
        if (!in_array($mode, ['preview_base64','original_chunk_base64'], true)) return new WP_Error('invalid_representation', 'Choose metadata, thumbnail, preview_base64 or original_chunk_base64.');
        if ($offset >= $size) return new WP_Error('invalid_offset', 'The requested byte offset is beyond the file.');
        $handle = fopen($path, 'rb'); if (!$handle) return new WP_Error('read_failed', 'The attachment could not be read.');
        fseek($handle, $offset); $bytes = fread($handle, min($max, $size - $offset)); fclose($handle);
        if (!is_string($bytes)) return new WP_Error('read_failed', 'The attachment could not be read.');
        return ['attachment_id' => $id, 'representation' => $mode, 'offset' => $offset, 'bytes_read' => strlen($bytes), 'total_bytes' => (int) $size, 'next_offset' => $offset + strlen($bytes), 'complete' => $offset + strlen($bytes) >= $size, 'mime_type' => get_post_mime_type($id), 'sha256' => hash('sha256', $bytes), 'content_base64' => base64_encode($bytes)];
    }

    private static function references($id) {
        global $wpdb; $id = absint($id); $found = [];
        foreach ($wpdb->get_col($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_thumbnail_id' AND meta_value=%s LIMIT 101", (string) $id)) as $post_id) $found[(int) $post_id] = true;
        $rows = $wpdb->get_col("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_product_image_gallery' ORDER BY post_id DESC LIMIT 1000");
        foreach ($rows as $post_id) { $gallery = (string) get_post_meta((int) $post_id, '_product_image_gallery', true); if (in_array((string) $id, array_map('trim', explode(',', $gallery)), true)) $found[(int) $post_id] = true; }
        $attachment = get_post($id); if ($attachment && $attachment->post_parent) $found[(int) $attachment->post_parent] = true;
        return array_slice(array_keys($found), 0, 100);
    }
    private static function reference_usage($input) {
        $post = self::attachment($input); if (is_wp_error($post)) return $post;
        $ids = self::references((int) $post->ID); $items = [];
        foreach ($ids as $id) { $related = get_post($id); if ($related) $items[] = ['post_id' => $id, 'post_type' => $related->post_type, 'status' => $related->post_status, 'title' => get_the_title($related), 'permalink' => $related->post_status === 'publish' ? esc_url_raw(get_permalink($related)) : '']; }
        return ['attachment_id' => (int) $post->ID, 'references' => $items, 'reference_count' => count($items), 'shared' => count($items) > 1];
    }

    private static function metadata_update($input) {
        $post = self::attachment($input); if (is_wp_error($post)) return $post; $id = (int) $post->ID;
        $fields = ['title','alt_text','caption','description','slug']; $patch = [];
        foreach ($fields as $field) if (array_key_exists($field, $input)) $patch[$field] = $input[$field];
        if (!$patch) return new WP_Error('empty_patch', 'Provide at least one attachment metadata field.');
        foreach ($patch as $key => $value) if (!is_string($value) || strlen($value) > ['title'=>300,'alt_text'=>2000,'caption'=>4000,'description'=>10000,'slug'=>190][$key]) return new WP_Error('invalid_metadata', 'Attachment metadata is invalid or exceeds its allowed length.');
        if (array_key_exists('alt_text', $patch) && !wp_attachment_is_image($id)) return new WP_Error('unsupported_mime', 'Alternative text is supported for image attachments only.');
        if (!empty($input['expected_modified_gmt']) && !hash_equals((string) $post->post_modified_gmt, (string) $input['expected_modified_gmt'])) return new WP_Error('revision_conflict', 'The attachment metadata changed. Read it again before applying the patch.', ['status' => 409]);
        if (isset($patch['alt_text']) && count(self::references($id)) > 1 && $patch['alt_text'] !== get_post_meta($id, '_wp_attachment_image_alt', true)) return new WP_Error('media_shared_edit_requires_confirmation', 'This image is used by multiple posts or products. Edit its shared alt text only after reviewing all listed references.');
        if (!empty($input['dry_run'])) return ['dry_run' => true, 'attachment_id' => $id, 'fields' => array_keys($patch), 'before' => self::canonical_metadata($post)];
        $data = ['ID' => $id];
        if (isset($patch['title'])) $data['post_title'] = sanitize_text_field($patch['title']);
        if (isset($patch['caption'])) $data['post_excerpt'] = sanitize_textarea_field($patch['caption']);
        if (isset($patch['description'])) $data['post_content'] = wp_kses_post($patch['description']);
        if (isset($patch['slug'])) $data['post_name'] = sanitize_title($patch['slug']);
        if (count($data) > 1) { $updated = wp_update_post($data, true); if (is_wp_error($updated)) return $updated; }
        if (isset($patch['alt_text'])) update_post_meta($id, '_wp_attachment_image_alt', sanitize_text_field($patch['alt_text']));
        $saved = get_post($id); $result = self::canonical_metadata($saved);
        return ['success' => true, 'attachment' => $result, 'readback_verified' => (!isset($patch['alt_text']) || $result['alt_text'] === sanitize_text_field($patch['alt_text']))];
    }

    private static function metadata_batch_update($input) {
        $operations = array_slice((array) ($input['operations'] ?? []), 0, 20); $results = [];
        foreach ($operations as $index => $operation) {
            if (!is_array($operation) || empty($operation['attachment_id']) || !is_array($operation['fields'] ?? null)) { $results[] = ['index' => $index, 'success' => false, 'error_code' => 'invalid_operation']; continue; }
            $result = self::metadata_update(['attachment_id' => absint($operation['attachment_id']), 'expected_modified_gmt' => (string) ($operation['expected_modified_gmt'] ?? ''), 'dry_run' => !empty($input['dry_run'])] + $operation['fields']);
            $results[] = is_wp_error($result) ? ['index' => $index, 'attachment_id' => absint($operation['attachment_id']), 'success' => false, 'error_code' => $result->get_error_code(), 'message' => $result->get_error_message()] : ['index' => $index, 'attachment_id' => absint($operation['attachment_id']), 'success' => true, 'result' => $result];
        }
        return ['results' => $results, 'submitted' => count((array) ($input['operations'] ?? [])), 'processed' => count($results), 'truncated' => count((array) ($input['operations'] ?? [])) > 20];
    }

    private static function duplicate_by_hash($hash) {
        if (!preg_match('/^[a-f0-9]{64}$/i', $hash)) return 0;
        $ids = get_posts(['post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_dreminex_mcp_sha256', 'meta_value' => strtolower($hash)]);
        return $ids ? absint($ids[0]) : 0;
    }
    public static function ingest_file($path, $filename, $claimed_mime = '', $metadata = [], $duplicate_behavior = 'reject', $expected_hash = '') {
        if (!current_user_can('upload_files') || !is_file($path)) return new WP_Error('permission_denied', 'The connected WordPress user cannot upload this file.');
        $filename = sanitize_file_name(wp_basename((string) $filename)); if ($filename === '' || strlen($filename) > 255) return new WP_Error('invalid_filename', 'A safe file name is required.');
        $size = filesize($path); $max = min((int) wp_max_upload_size(), 104857600); if ($size < 1 || $size > $max) return new WP_Error('upload_too_large', 'The file is empty or exceeds the site upload limit.', ['max_bytes' => $max]);
        $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (in_array($extension, ['php','phtml','phar','cgi','pl','py','sh','exe','dll','com','bat','cmd','htaccess','svg','shtml'], true)) return new WP_Error('unsupported_mime', 'This file type is not accepted by the secure MCP uploader.');
        $filetype = wp_check_filetype($filename); $checked = wp_check_filetype_and_ext($path, $filename); $mime = (string) ($checked['type'] ?? $filetype['type'] ?? '');
        if (!$mime || empty($checked['ext']) || empty($checked['type'])) return new WP_Error('unsupported_mime', 'WordPress does not allow this file type.');
        if ($claimed_mime && strtolower(trim($claimed_mime)) !== strtolower($mime)) return new WP_Error('mime_mismatch', 'The submitted MIME type does not match the detected file type.');
        $hash = hash_file('sha256', $path); if ($expected_hash && !hash_equals(strtolower($expected_hash), $hash)) return new WP_Error('chunk_hash_mismatch', 'The file SHA-256 did not match the declared checksum.');
        $scanner = apply_filters('dreminex_mcp_scan_upload', true, $path, ['filename' => $filename, 'mime_type' => $mime, 'sha256' => $hash]);
        if (is_wp_error($scanner)) return $scanner; if ($scanner !== true) return new WP_Error('malware_detected', 'The configured upload scanner rejected this file.');
        $duplicate = self::duplicate_by_hash($hash);
        if ($duplicate) {
            if ($duplicate_behavior === 'reuse') return ['success' => true, 'deduplicated' => true, 'attachment' => self::canonical_metadata(get_post($duplicate), true)];
            if ($duplicate_behavior === 'reject') return new WP_Error('duplicate_file', 'An attachment with the same verified SHA-256 already exists.', ['attachment_id' => $duplicate]);
        }
        require_once ABSPATH . 'wp-admin/includes/file.php'; require_once ABSPATH . 'wp-admin/includes/media.php'; require_once ABSPATH . 'wp-admin/includes/image.php';
        $id = media_handle_sideload(['name' => $filename, 'tmp_name' => $path, 'size' => $size, 'error' => 0, 'type' => $mime], absint($metadata['attach_to_post_id'] ?? 0), sanitize_text_field((string) ($metadata['description'] ?? '')),
            ['post_title' => sanitize_text_field((string) ($metadata['title'] ?? pathinfo($filename, PATHINFO_FILENAME))), 'post_excerpt' => sanitize_textarea_field((string) ($metadata['caption'] ?? '')), 'post_content' => wp_kses_post((string) ($metadata['description'] ?? ''))]);
        if (is_wp_error($id)) return $id;
        update_post_meta($id, '_dreminex_mcp_sha256', $hash);
        if (!empty($metadata['alt_text']) && wp_attachment_is_image($id)) update_post_meta($id, '_wp_attachment_image_alt', sanitize_text_field((string) $metadata['alt_text']));
        clean_post_cache($id); $post = get_post($id);
        return ['success' => true, 'deduplicated' => false, 'attachment' => self::canonical_metadata($post, true), 'verification_readback' => ['id' => (int) $id, 'sha256_matches' => hash_equals($hash, (string) get_post_meta($id, '_dreminex_mcp_sha256', true)), 'mime_matches' => get_post_mime_type($id) === $mime]];
    }

    private static function upload_inline($input) {
        $encoded = (string) ($input['content_base64'] ?? ''); if ($encoded === '' || strlen($encoded) > 700000) return new WP_Error('upload_too_large', 'Inline file data exceeds the supported 512 KiB file limit.');
        $bytes = base64_decode($encoded, true); unset($encoded); if (!is_string($bytes) || strlen($bytes) > 524288) return new WP_Error('upload_too_large', 'Inline files are limited to 512 KiB.');
        $root = Dreminex_MCP_Upload::private_directory(); if (is_wp_error($root)) return $root;
        $path = tempnam($root, 'inline-'); if (!$path) return new WP_Error('transfer_interrupted', 'A private upload staging file could not be created.'); chmod($path, 0600);
        if (file_put_contents($path, $bytes, LOCK_EX) !== strlen($bytes)) { @unlink($path); return new WP_Error('transfer_interrupted', 'The file could not be written to private staging.'); }
        unset($bytes); $result = self::ingest_file($path, (string) ($input['filename'] ?? ''), (string) ($input['mime_type'] ?? ''), $input, (string) ($input['duplicate_behavior'] ?? 'reject'), (string) ($input['sha256'] ?? ''));
        if (is_file($path)) @unlink($path); return $result;
    }

    private static function chat_capabilities($input) {
        return ['client_provider' => sanitize_text_field((string) ($input['client_provider'] ?? 'unknown')), 'available_methods' => array_values(array_intersect((array) ($input['available_methods'] ?? []), ['inline_base64','signed_upload','external_adapter'])), 'inline_max_file_bytes' => 524288, 'session_max_chunk_bytes' => 4194304, 'chat_attachment_bridge' => false, 'fallback_error_code' => 'CLIENT_ATTACHMENT_UNAVAILABLE'];
    }

    private static function public_host($host) {
        $host = strtolower(trim($host, '[]')); if ($host === '' || $host === 'localhost' || str_ends_with($host, '.localhost') || str_ends_with($host, '.local') || str_ends_with($host, '.internal')) return false;
        $addresses = [];
        if (filter_var($host, FILTER_VALIDATE_IP)) $addresses[] = $host;
        else { $ip = gethostbyname($host); if ($ip !== $host) $addresses[] = $ip; if (function_exists('dns_get_record')) foreach ((array) @dns_get_record($host, DNS_AAAA) as $record) if (!empty($record['ipv6'])) $addresses[] = $record['ipv6']; }
        if (!$addresses) return false;
        foreach ($addresses as $ip) if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return false;
        return true;
    }

    private static function import_url($input) {
        $url = esc_url_raw(trim((string) ($input['url'] ?? ''))); $parts = wp_parse_url($url);
        if (!$parts || strtolower((string) ($parts['scheme'] ?? '')) !== 'https' || empty($parts['host']) || !empty($parts['user']) || !empty($parts['pass']) || !self::public_host((string) $parts['host']) || !wp_http_validate_url($url)) return new WP_Error('remote_url_not_allowed', 'Only a public HTTPS URL can be imported.');
        $max = min((int) wp_max_upload_size(), 104857600);
        $response = wp_safe_remote_get($url, ['timeout' => 15, 'redirection' => 0, 'limit_response_size' => $max + 1, 'headers' => ['Accept' => 'image/*,application/pdf,audio/*,video/*,text/plain,application/zip']]);
        if (is_wp_error($response)) return $response;
        $status = (int) wp_remote_retrieve_response_code($response); if ($status >= 300 && $status < 400) return new WP_Error('remote_url_not_allowed', 'Redirects are disabled for remote media import.');
        if ($status !== 200) return new WP_Error('remote_fetch_failed', 'The public file URL did not return HTTP 200.', ['status' => $status]);
        $bytes = (string) wp_remote_retrieve_body($response); if ($bytes === '' || strlen($bytes) > $max) return new WP_Error('upload_too_large', 'The remote file is empty or exceeds the site upload limit.');
        if (!empty($input['expected_sha256']) && !hash_equals(strtolower((string) $input['expected_sha256']), hash('sha256', $bytes))) return new WP_Error('chunk_hash_mismatch', 'The remote file did not match the requested SHA-256.');
        $filename = sanitize_file_name((string) ($input['filename'] ?? rawurldecode(wp_basename((string) ($parts['path'] ?? 'file')))));
        $root = Dreminex_MCP_Upload::private_directory(); if (is_wp_error($root)) return $root; $path = tempnam($root, 'remote-'); if (!$path) return new WP_Error('transfer_interrupted', 'Private staging is unavailable.'); chmod($path, 0600);
        if (file_put_contents($path, $bytes, LOCK_EX) !== strlen($bytes)) { @unlink($path); return new WP_Error('transfer_interrupted', 'The remote file could not be staged.'); }
        unset($bytes); $mime = (string) wp_remote_retrieve_header($response, 'content-type'); $result = self::ingest_file($path, $filename, $mime, [], (string) ($input['duplicate_behavior'] ?? 'reject'), (string) ($input['expected_sha256'] ?? ''));
        if (is_file($path)) @unlink($path); return $result;
    }

    private static function duplicate_find($input) {
        $matches = [];
        if (!empty($input['image_attachment_id'])) { $post = self::attachment($input); if (is_wp_error($post)) return $post; $file = self::confined_file((int) $post->ID); if (!is_wp_error($file)) { $hash = hash_file('sha256', $file); $matches[] = ['match_type' => 'sha256', 'attachment' => self::canonical_metadata($post)]; $input['sha256'] = $hash; } }
        $hash = strtolower((string) ($input['sha256'] ?? ''));
        if (preg_match('/^[a-f0-9]{64}$/', $hash)) { $id = self::duplicate_by_hash($hash); if ($id) $matches[] = ['match_type' => 'sha256', 'attachment' => self::canonical_metadata(get_post($id), true)]; }
        $filename = sanitize_file_name((string) ($input['filename'] ?? ''));
        if ($filename !== '') { $ids = get_posts(['post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 20, 'fields' => 'ids', 's' => pathinfo($filename, PATHINFO_FILENAME)]); foreach ($ids as $id) { $post = get_post($id); if (!$post) continue; $meta = self::canonical_metadata($post); if (strtolower($meta['stored_filename']) === strtolower($filename)) $matches[] = ['match_type' => 'filename', 'attachment' => $meta]; } }
        return ['matches' => array_slice($matches, 0, 20), 'count' => count($matches), 'visual_similarity' => 'not_scanned'];
    }

    private static function attach_to_post($input) {
        $attachment = self::attachment($input); if (is_wp_error($attachment)) return $attachment; $id = (int) $attachment->ID; $post_id = absint($input['post_id'] ?? 0); $target = get_post($post_id);
        if (!$target || !current_user_can('edit_post', $post_id) || !current_user_can('edit_post', $id)) return new WP_Error('permission_denied', 'Both the attachment and target post must be editable.');
        if (!empty($input['expected_post_revision']) && !hash_equals($target->post_modified_gmt, (string) $input['expected_post_revision'])) return new WP_Error('revision_conflict', 'The target post changed.');
        $changed = wp_update_post(['ID' => $id, 'post_parent' => $post_id], true); if (is_wp_error($changed)) return $changed;
        return ['attachment_id' => $id, 'post_id' => $post_id, 'attached' => true, 'post_parent_readback' => (int) wp_get_post_parent_id($id)];
    }
    private static function revision_matches($id, $expected) { $post = get_post($id); if (!$post) return false; $revision = $post->post_modified_gmt . ':' . substr(hash('sha256', (string) $post->post_content), 0, 32); return $expected === '' || hash_equals($revision, $expected) || hash_equals($post->post_modified_gmt, $expected); }
    private static function valid_image_ids($ids) { foreach ($ids as $id) if (!absint($id) || !get_post(absint($id)) || !wp_attachment_is_image(absint($id)) || !current_user_can('edit_post', absint($id))) return false; return true; }
    private static function product_gallery_set($input) {
        if (!class_exists('WooCommerce')) return new WP_Error('provider_missing', 'WooCommerce is not active.');
        $id = absint($input['product_id'] ?? 0); $product = wc_get_product($id); $featured = absint($input['featured_image_id'] ?? 0); $gallery = array_values(array_unique(array_map('absint', (array) ($input['gallery_image_ids'] ?? []))));
        if (!$product || !$product->is_type(['simple','variable','grouped','external']) || !current_user_can('edit_post', $id)) return new WP_Error('product_not_found', 'An editable WooCommerce product is required.');
        if (!self::revision_matches($id, (string) ($input['expected_product_revision'] ?? ''))) return new WP_Error('revision_conflict', 'Product content changed. Read it again before replacing its gallery.', ['status' => 409]);
        if (!$featured || !self::valid_image_ids(array_merge([$featured], $gallery))) return new WP_Error('invalid_image', 'Featured and gallery entries must be editable image attachments from this site.');
        $product->set_image_id($featured); $product->set_gallery_image_ids(array_values(array_diff($gallery, [$featured]))); $saved_id = $product->save(); $saved = wc_get_product($saved_id);
        return ['product_id' => $saved_id, 'featured_image_id' => (int) $saved->get_image_id(), 'gallery_image_ids' => array_map('intval', $saved->get_gallery_image_ids()), 'readback_verified' => (int) $saved->get_image_id() === $featured];
    }
    private static function variation_image_set($input) {
        if (!class_exists('WooCommerce')) return new WP_Error('provider_missing', 'WooCommerce is not active.');
        $product_id = absint($input['product_id'] ?? 0); $variation_id = absint($input['variation_id'] ?? 0); $image_id = absint($input['image_id'] ?? 0); $parent = wc_get_product($product_id); $variation = wc_get_product($variation_id);
        if (!$parent || !$parent->is_type('variable') || !$variation || !$variation->is_type('variation') || (int) $variation->get_parent_id() !== $product_id || !current_user_can('edit_post', $product_id) || !self::valid_image_ids([$image_id])) return new WP_Error('invalid_variation_image', 'The variation must belong to the exact parent product and use an editable image attachment.');
        $variation->set_image_id($image_id); $variation->save(); $saved = wc_get_product($variation_id);
        return ['product_id' => $product_id, 'variation_id' => $variation_id, 'image_id' => (int) $saved->get_image_id(), 'readback_verified' => (int) $saved->get_image_id() === $image_id];
    }
    private static function image_sizes($input) {
        $post = self::attachment($input); if (is_wp_error($post)) return $post; if (!wp_attachment_is_image($post->ID)) return new WP_Error('unsupported_mime', 'This Media Library item is not an image.');
        $metadata = wp_get_attachment_metadata($post->ID); $sizes = [];
        foreach ((array) ($metadata['sizes'] ?? []) as $name => $size) $sizes[] = ['name' => sanitize_key($name), 'width' => (int) ($size['width'] ?? 0), 'height' => (int) ($size['height'] ?? 0), 'mime_type' => sanitize_mime_type((string) ($size['mime-type'] ?? '')), 'file' => sanitize_file_name((string) ($size['file'] ?? ''))];
        return ['attachment_id' => (int) $post->ID, 'width' => (int) ($metadata['width'] ?? 0), 'height' => (int) ($metadata['height'] ?? 0), 'sizes' => $sizes];
    }
    private static function regenerate_metadata($input) {
        $post = self::attachment($input); if (is_wp_error($post)) return $post; if (!wp_attachment_is_image($post->ID)) return new WP_Error('unsupported_mime', 'Only image metadata can be regenerated.');
        $path = self::confined_file($post->ID); if (is_wp_error($path)) return $path; $hash = hash_file('sha256', $path);
        if (!empty($input['expected_sha256']) && !hash_equals(strtolower((string) $input['expected_sha256']), $hash)) return new WP_Error('revision_conflict', 'The original image changed since it was inspected.');
        $size = filesize($path); if ($size > 20971520) return new WP_Error('workload_limit', 'Image metadata regeneration is limited to originals up to 20 MiB.');
        require_once ABSPATH . 'wp-admin/includes/image.php'; $metadata = wp_generate_attachment_metadata((int) $post->ID, $path); if (is_wp_error($metadata) || !is_array($metadata)) return is_wp_error($metadata) ? $metadata : new WP_Error('metadata_generation_failed', 'WordPress could not regenerate image metadata.');
        wp_update_attachment_metadata((int) $post->ID, $metadata); return self::image_sizes(['attachment_id' => (int) $post->ID]);
    }
    private static function trash_attachment($input) {
        $post = self::attachment($input); if (is_wp_error($post)) return $post; $refs = self::references((int) $post->ID);
        if ($refs) return new WP_Error('media_in_use', 'This attachment is still referenced by posts or products. Remove its use and verify again before trashing.', ['references' => $refs]);
        if (!empty($input['expected_modified_gmt']) && !hash_equals($post->post_modified_gmt, (string) $input['expected_modified_gmt'])) return new WP_Error('revision_conflict', 'The attachment changed before trashing.');
        $result = wp_trash_post((int) $post->ID); return $result ? ['attachment_id' => (int) $post->ID, 'status' => 'trash'] : new WP_Error('trash_failed', 'WordPress could not move the attachment to Trash.');
    }
    private static function restore_attachment($input) {
        $id = absint($input['attachment_id'] ?? 0); $post = get_post($id); if (!$post || $post->post_type !== 'attachment' || $post->post_status !== 'trash' || !current_user_can('edit_post', $id)) return new WP_Error('attachment_not_found', 'A trashed editable attachment is required.');
        $restored = wp_untrash_post($id); return $restored ? ['attachment_id' => $id, 'status' => get_post_status($id)] : new WP_Error('restore_failed', 'WordPress could not restore the attachment.');
    }
    private static function delete_attachment($input) {
        $id = absint($input['attachment_id'] ?? 0); if (!$id || $id !== absint($input['confirm_attachment_id'] ?? 0)) return new WP_Error('confirmation_required', 'Repeat the exact attachment ID to confirm permanent deletion.');
        $post = get_post($id); if (!$post || $post->post_type !== 'attachment' || $post->post_status !== 'trash' || !current_user_can('delete_post', $id)) return new WP_Error('attachment_not_in_trash', 'Permanent deletion is allowed only for an editable attachment already in Trash.');
        $refs = self::references($id); if ($refs) return new WP_Error('media_in_use', 'Referenced attachments cannot be permanently deleted.', ['references' => $refs]);
        if (empty($input['approval_id'])) return new WP_Error('approval_required', 'Permanent deletion requires a fresh one-time Native MCP approval.');
        $deleted = wp_delete_attachment($id, true); return $deleted ? ['attachment_id' => $id, 'deleted_permanently' => true] : new WP_Error('delete_failed', 'WordPress could not delete the attachment.');
    }
    private static function rename_plan($input) {
        $post = self::attachment($input); if (is_wp_error($post)) return $post; $filename = sanitize_file_name((string) ($input['proposed_filename'] ?? ''));
        if ($filename === '' || strlen($filename) > 255 || in_array(strtolower(pathinfo($filename, PATHINFO_EXTENSION)), ['php','phtml','phar','svg','exe','dll'], true)) return new WP_Error('invalid_filename', 'Choose a safe proposed filename.');
        $current = self::canonical_metadata($post);
        return ['attachment_id' => (int) $post->ID, 'current_filename' => $current['stored_filename'], 'proposed_filename' => $filename, 'will_mutate' => false, 'physical_rename_enabled' => false, 'impact' => ['references' => $current['associated_post_ids'], 'current_url' => $current['source_url']], 'required_follow_up' => ['backup', 'URL/reference migration plan', 'same-site redirect or URL repair', 'post-change readback']];
    }
    private static function import_batch($input) {
        $items = (array) ($input['items'] ?? []); if (count($items) > 10) return new WP_Error('batch_too_large', 'A media batch is limited to 10 files.'); $results = [];
        foreach ($items as $index => $item) { if (!is_array($item)) { $results[] = ['index' => $index, 'success' => false, 'error_code' => 'invalid_item']; continue; } $result = self::upload_inline($item); $results[] = is_wp_error($result) ? ['index' => $index, 'success' => false, 'error_code' => $result->get_error_code(), 'message' => $result->get_error_message()] : ['index' => $index, 'success' => true, 'result' => $result]; }
        return ['results' => $results, 'submitted' => count($items), 'processed' => count($results), 'truncated' => false];
    }
}
