<?php
if(!defined('ABSPATH'))exit;
/** Independent presentation/workflow features; never disables mandatory payment validation. */
final class Dreminex_Suite_Features {
 public static function catalog(){return [
  'newsletter_offers'=>['newsletter'=>['Newsletter signup',false],'offers'=>['Promotional offers',false]],
  'receipt_ip_warning'=>['shortcode'=>['Visitor IP shortcode',true],'receipt'=>['Order receipt IP notice',true]],
  'customer_history'=>['list_column'=>['Order-list history column',true],'detail_box'=>['Order-detail history panel',true]],
  'order_tracking'=>['email_details'=>['Tracking details in order emails',true],'change_email'=>['Customer email when tracking number changes',true]],
  'admin_order_alert'=>['notice'=>['New-order admin notice',true],'widget'=>['Recent-orders dashboard widget',true]],
 ];}
 public static function enabled($module,$feature){$catalog=self::catalog();if(!isset($catalog[$module][$feature]))return false;$settings=(array)get_option('dreminex_suite_module_settings',[]);return (bool)($settings[$module]['_features'][$feature]??$catalog[$module][$feature][1]);}
 public static function boot(){add_action('dreminex_suite_module_panel',[__CLASS__,'panel'],3);add_action('admin_post_dreminex_suite_features',[__CLASS__,'save']);}
 public static function panel($module){$items=self::catalog()[$module]??[];if(!$items)return;
  echo '<h3>'.esc_html(Dreminex_Suite_Control::tr('Independent features','আলাদা Feature control')).'</h3><p>Module On is the master switch. Feature Off hides/stops that feature without deleting its records. Saved choices remain when the module is toggled or updated.</p>';
  if($module==='newsletter_offers')echo '<p>Newsletter and Offers start Off. Enable the features you want below. Existing offer eligibility and issued-coupon validity are retained.</p>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_suite_features"><input type="hidden" name="module" value="'.esc_attr($module).'">';wp_nonce_field('dreminex_suite_features_'.$module);
  foreach($items as $id=>$spec)echo '<p><label><input type="checkbox" name="features['.esc_attr($id).']" value="1" '.checked(self::enabled($module,$id),true,false).'> '.esc_html($spec[0]).'</label> <strong>'.(self::enabled($module,$id)?'On':'Off').'</strong></p>';
  submit_button('Save feature switches');echo '</form>';
 }
 public static function save(){if(!current_user_can('manage_options'))wp_die('Access denied.',403);$module=sanitize_key(wp_unslash($_POST['module']??''));check_admin_referer('dreminex_suite_features_'.$module);$items=self::catalog()[$module]??[];if(!$items)wp_die('Unknown module.',400);
  $all=(array)get_option('dreminex_suite_module_settings',[]);foreach($items as $id=>$spec)$all[$module]['_features'][$id]=!empty($_POST['features'][$id]);update_option('dreminex_suite_module_settings',$all,false);Dreminex_Suite_Cache::changed($module,true);wp_safe_redirect(admin_url('admin.php?page=dreminex-suite&module='.$module.'&saved=features'));exit;
 }
}
