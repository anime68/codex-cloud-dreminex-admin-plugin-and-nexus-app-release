<?php
if(!defined('ABSPATH'))exit;
/** Explicit module ownership; never deletes WordPress users, pages or orders. */
final class Dreminex_Suite_Data {
 public static function boot() {
  add_action('admin_menu',[__CLASS__,'menu'],33);
  add_action('dreminex_suite_module_panel',[__CLASS__,'panel'],20);
  add_action('admin_post_dreminex_suite_backup',[__CLASS__,'download']);
  add_action('admin_post_dreminex_suite_data_delete',[__CLASS__,'delete_action']);
 }
 public static function menu(){add_submenu_page('dreminex-suite','Module data','Backup & module data','manage_options','dreminex-suite-data',[__CLASS__,'page']);}
 public static function spec($key) {
  $map=[
   'flash_sale'=>['options'=>['dreminex_flash_sale']],
   'newsletter_offers'=>['options'=>['dreminex_newsletter_settings'],'tables'=>['dreminex_newsletter','dreminex_offers','dreminex_offer_claims']],
   'contact_requests'=>['options'=>['dreminex_contact_mail_defaults'],'tables'=>['dreminex_contact_requests','dreminex_contact_replies']],
   'mobile_payment'=>['options'=>['dreminex_payment_profiles','woocommerce_dreminex_mobile_payment_settings']],
   'checkout_protection'=>['posts'=>'dreminex_partial','order_meta'=>['_dreminex_device_key']],
   'order_management'=>['options'=>['dreminex_courier_api_profiles','dreminex_courier_api_secrets'],'order_meta'=>['_dreminex_courier','_dreminex_courier_tracking','_dreminex_admin_alert_sent'],'user_meta'=>['_dreminex_last_seen_order_id']],
   'store_email_branding'=>['options'=>['dreminex_suite_email_logo_id','woocommerce_email_header_image','woocommerce_email_from_name','woocommerce_email_from_address','woocommerce_email_base_color','woocommerce_email_background_color','woocommerce_email_body_background_color','woocommerce_email_text_color','woocommerce_email_footer_text']],
   'delivery_advance'=>['order_meta'=>['_dreminex_advance_method','_dreminex_advance_receiver','_dreminex_advance_account_type','_dreminex_advance_txid','_dreminex_advance_due','_dreminex_balance_due','_dreminex_advance_verified','_dreminex_advance_recorded_at','_dreminex_advance_verified_at','_dreminex_advance_verified_by']],
   'registration_email'=>['user_meta'=>['_dreminex_email_confirmed']],
   'supplier_monitor'=>['options'=>['dreminex_sm_pricing','dreminex_sm_last_reconcile','dreminex_sm_last_worker_scan'],'tables'=>['dreminex_supplier_events']],
  ];
  if(isset(Dreminex_Suite::catalog()[$key]))return $map[$key]??[];
  if(class_exists('Dreminex_Suite_Imports')&&isset(Dreminex_Suite_Imports::all()[$key]))return ['options'=>['dreminex_import_data_'.$key,'dreminex_import_settings_'.$key]];
  return null;
 }
 public static function sanitize_export($value) {
  if(!is_array($value))return $value;
  foreach($value as $key=>$item) {
   if(is_string($key)&&preg_match('/password|secret|token|signature|app_key|api_key|private_key|credential/i',$key))$value[$key]='[excluded: credential or token]';
   else $value[$key]=self::sanitize_export($item);
  }return $value;
 }
 public static function snapshot($key) {
  $spec=self::spec($key);if($spec===null)return new WP_Error('unknown_module','Unknown module.');global $wpdb;
  $out=['format'=>'dreminex-module-backup','schema'=>1,'version'=>DREMINEX_SUITE_VERSION,'site'=>home_url('/'),'module'=>$key,'created_at'=>gmdate('c'),'settings'=>Dreminex_Suite_Control::setting($key,'__unused__',null),'options'=>[],'tables'=>[],'posts'=>[],'order_metadata'=>[],'user_metadata'=>[],'notes'=>['Credentials, auth/reset tokens and passwords are excluded. Core orders/users/pages are not included. Financial order metadata is a read-only audit snapshot.']];
  $settings=(array)get_option('dreminex_suite_module_settings',[]);$out['settings']=$settings[$key]??[];
  foreach($spec['options']??[] as $name){if(preg_match('/password|secret|token|credential|api_key/i',$name)){$out['options'][$name]='[excluded: credential material]';continue;}$out['options'][$name]=self::sanitize_export(get_option($name));}
  foreach($spec['tables']??[] as $suffix) {
   $table=$wpdb->prefix.$suffix;if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)))!==$table)continue;
   $rows=$wpdb->get_results("SELECT * FROM `{$table}` LIMIT 10001",ARRAY_A);
   if(count($rows)>10000)return new WP_Error('too_large','This module has over 10,000 records. Use a hosting database backup for a complete archive.');
   $out['tables'][$suffix]=self::sanitize_export($rows);
  }
  if(!empty($spec['posts']))foreach(get_posts(['post_type'=>$spec['posts'],'post_status'=>['publish','private','draft','pending','future','trash'],'numberposts'=>10001]) as $p){if(count($out['posts'])>=10000)return new WP_Error('too_large','Use a hosting database backup for this large module.');$out['posts'][]=['post'=>get_post($p->ID,ARRAY_A),'meta'=>self::sanitize_export(get_post_meta($p->ID))];}
  if(!empty($spec['order_meta'])&&function_exists('wc_get_orders')) {
   $orders=wc_get_orders(['type'=>'shop_order','limit'=>10001,'return'=>'ids']);if(count($orders)>10000)return new WP_Error('too_large','Use a hosting backup for stores with over 10,000 orders.');
   foreach($orders as $id){$order=wc_get_order($id);if(!$order instanceof WC_Order)continue;$meta=[];foreach($spec['order_meta'] as $name){$v=$order->get_meta($name);if($v!=='')$meta[$name]=$v;}if($meta)$out['order_metadata'][]=['order_id'=>$id,'meta'=>$meta];}
  }
  if(!empty($spec['user_meta']))foreach($spec['user_meta'] as $name){$rows=$wpdb->get_results($wpdb->prepare("SELECT user_id,meta_value FROM {$wpdb->usermeta} WHERE meta_key=%s LIMIT 10001",$name),ARRAY_A);if(count($rows)>10000)return new WP_Error('too_large','Use a hosting backup for this large user-metadata dataset.');$out['user_metadata'][$name]=$rows;}
  if($key==='newsletter_offers') {
   $out['coupons']=[];foreach(get_posts(['post_type'=>'shop_coupon','post_status'=>['publish','private','draft','pending','future','trash'],'numberposts'=>10001,'meta_key'=>'_dreminex_owner_user_id']) as $coupon)$out['coupons'][]=['post'=>get_post($coupon->ID,ARRAY_A),'meta'=>get_post_meta($coupon->ID)];
  }
  if($key==='supplier_monitor') {
   $out['product_sources']=[];
   $ids=get_posts(['post_type'=>'product','post_status'=>['publish','private','draft','pending','trash'],'posts_per_page'=>10001,'fields'=>'ids','meta_key'=>'_dreminex_sm_sources']);
   if(count($ids)>10000)return new WP_Error('too_large','Use a full site backup for more than 10,000 supplier-linked products.');
   foreach($ids as $id)$out['product_sources'][]=['product_id'=>(int)$id,'sources'=>get_post_meta($id,'_dreminex_sm_sources',true),'snapshots'=>get_post_meta($id,'_dreminex_sm_snapshots',true)];
  }
  if(count($out['coupons']??[])>10000)return new WP_Error('too_large','Use a hosting backup for this large coupon dataset.');
  return $out;
 }
 public static function download() {
  if(!current_user_can('manage_options'))wp_die('Access denied.',403);
  $key=sanitize_key(wp_unslash($_GET['module']??''));check_admin_referer('dreminex_suite_backup_'.$key);
  $temp=self::archive($key);if(is_wp_error($temp))wp_die(esc_html($temp->get_error_message()),400);
  while(ob_get_level())ob_end_clean();nocache_headers();header('Content-Type: application/zip');header('X-Content-Type-Options: nosniff');header('Content-Disposition: attachment; filename="'.$key.'-backup-'.gmdate('Ymd-His').'.zip"');header('Content-Length: '.filesize($temp));readfile($temp);unlink($temp);exit;
 }
 public static function archive($key) {
  $data=self::snapshot($key);if(is_wp_error($data))return $data;
  if(!class_exists('ZipArchive'))return new WP_Error('zip','ZIP support is required for complete module backups.');
  $temp=wp_tempnam('suite-backup');$zip=new ZipArchive();if($zip->open($temp,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)return new WP_Error('zip','Could not create backup.');
  $json=wp_json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
  if($json===false||!$zip->addFromString('module-data.json',$json)){$zip->close();unlink($temp);return new WP_Error('json','Could not encode complete module data.');}
  $missing=[];
  if($key==='contact_requests') {
   $base=realpath(dirname(ABSPATH).'/dreminex-contact-evidence');$names=[];
   foreach($data['tables']['dreminex_contact_requests']??[] as $row)if(!empty($row['stored_name']))$names[]=$row['stored_name'];
   
   foreach(array_unique($names) as $name){$path=$base?realpath($base.'/'.$name):false;if(!$path||basename($name)!==$name||dirname($path)!==$base||is_link($base.'/'.$name)||!is_readable($path)){$missing[]=$name;continue;}if(!$zip->addFile($path,'private-media/'.$name))$missing[]=$name;}
   $mailbase=$base?realpath($base.'/mail-media'):false;
   foreach((array)get_option('dreminex_contact_mail_defaults',[]) as $media){$name=is_array($media)?($media['stored']??''):'';$path=$mailbase&&$name?realpath($mailbase.'/'.$name):false;if(!$name)continue;if($path&&basename($name)===$name&&dirname($path)===$mailbase&&!is_link($mailbase.'/'.$name)&&is_readable($path)){if(!$zip->addFile($path,'private-media/mail-media/'.$name))$missing[]=$name;}else $missing[]=$name;}
  }
  if($missing){$zip->close();unlink($temp);return new WP_Error('missing_files','Some referenced private attachments are missing or unreadable. Review storage before creating a complete backup.');}
  if(!$zip->close()){unlink($temp);return new WP_Error('backup_failed','Backup failed.');}
  return $temp;
 }
 public static function erase($key,$scope) {
  $spec=self::spec($key);if($spec===null)return new WP_Error('unknown','Unknown module.');
  if(!in_array($scope,['settings','records'],true))return new WP_Error('scope','Unknown deletion scope.');
  if(!empty(((array)get_option('dreminex_suite_modules',[]))[$key])||(!empty((Dreminex_Suite_Imports::all()[$key]??[])['enabled'])))return new WP_Error('enabled','Turn this module off before deleting its data.');
  global $wpdb;
  if($scope==='settings') {
   if($key==='mobile_payment')return new WP_Error('payment_audit','Remove each merchant connection through Dreminex Payments while the module is enabled. Pending payments must be reconciled first; this reset never erases payment evidence or API credentials.');
   if($key==='supplier_monitor')return new WP_Error('monitor_audit','Supplier links, alerts and pricing context must be reviewed before any reset. Export a full site backup first.');
   $settings=(array)get_option('dreminex_suite_module_settings',[]);unset($settings[$key]);update_option('dreminex_suite_module_settings',$settings,false);
   foreach($spec['options']??[] as $name){if(str_starts_with($key,'addon-')&&$name==='dreminex_import_data_'.$key)continue;delete_option($name);}return true;
  }
  if($key==='contact_requests') {
   $ids=$wpdb->get_col('SELECT id FROM '.Dreminex_Suite_Contact_Trash::table().' LIMIT 101');if(count($ids)>100)return new WP_Error('batch','Use Contact Requests bulk actions in batches of up to 100.');
   $a=Dreminex_Suite_Contact_Trash::operate($ids,'trash');$b=Dreminex_Suite_Contact_Trash::operate($ids,'delete');if(is_wp_error($a)||is_wp_error($b)||!empty($a['failed_ids'])||!empty($b['failed_ids']))return new WP_Error('delete_failed','Some requests could not be deleted. Review Trash.');return true;
  }
  if($key==='supplier_monitor')return new WP_Error('monitor_audit','Supplier mapping and approval audit are retained. This module has no automatic records deletion.');
  if($key==='newsletter_offers') {
   // Claimed coupon terms and audit references must outlive marketing-list resets.
   foreach($spec['tables'] as $suffix)if($suffix==='dreminex_newsletter') { if($wpdb->query('DELETE FROM `'.$wpdb->prefix.$suffix.'`')===false)return new WP_Error('db','Could not delete subscriber records.'); }
   return true;
  }
  if(!empty($spec['posts'])) { $posts=get_posts(['post_type'=>$spec['posts'],'post_status'=>['publish','private','draft','pending','future','trash'],'numberposts'=>101]);if(count($posts)>100)return new WP_Error('batch','Delete records through Partial Checkouts in smaller batches.');foreach($posts as $p)wp_delete_post($p->ID,true);return true; }
  if(!empty($spec['order_meta'])||$key==='mobile_payment')return new WP_Error('audit','Order-linked history, anti-fraud identity, tracking and financial evidence are preserved. Delete an individual order through WooCommerce only after reviewing it. Settings can still be reset independently.');
  foreach($spec['user_meta']??[] as $name)delete_metadata('user',0,$name,'',true);
  if(str_starts_with($key,'addon-'))delete_option('dreminex_import_data_'.$key);
  $activity=(array)get_option('dreminex_suite_activity',[]);unset($activity[$key]);update_option('dreminex_suite_activity',$activity,false);return true;
 }
 public static function delete_action() {
  if(!current_user_can('manage_options'))wp_die('Access denied.',403);
  $key=sanitize_key(wp_unslash($_POST['module']??''));check_admin_referer('dreminex_suite_data_delete_'.$key);
  if(empty($_POST['backup_confirm'])||($_POST['confirm_module']??'')!==$key)wp_die('Download a backup and type the module ID before deleting.',400);
  $scope=sanitize_key(wp_unslash($_POST['scope']??''));if($scope==='fresh'&&($_POST['fresh_confirm']??'')!=='RESET')wp_die('Type RESET to confirm the fresh reset.',400);
  $r=$scope==='fresh'?self::fresh($key):self::erase($key,$scope);if(is_wp_error($r))wp_die(esc_html($r->get_error_message()),400);
  if(get_option('dreminex_suite_cache_auto',1))Dreminex_Suite_Cache::changed($key,true);
  wp_safe_redirect(admin_url('admin.php?page=dreminex-suite-settings&section=backup&module='.$key.'&deleted=1'));exit;
 }
 public static function reset_plan($key) {
  $spec=self::spec($key);if($spec===null)return new WP_Error('unknown','Unknown module.');
  $desc='Module settings, module activity and Suite display cache. No independent persistent records are owned by this module.';
  if(!empty($spec['order_meta']))$desc='Module settings/activity/display cache reset. Existing order-linked payment, tracking, identity or sent-email audit markers remain; historical orders are not reset.';
  if($key==='order_management')$desc='Module settings/activity/display cache reset. History is recalculated and order-linked status, tracking and email evidence remains.';
  if($key==='contact_requests')$desc='All Contact Requests, replies, private original attachments, default reply media/settings and module activity/cache. Other media-library files remain.';
  if($key==='checkout_protection')$desc='Consented unfinished-checkout posts can be removed; order-linked browser identity and WooCommerce orders remain. Settings and activity/cache can be reset.';
  if($key==='newsletter_offers')$desc='All Suite subscriber, offer and claim records, Suite-owned coupons, newsletter settings and module activity/cache. Existing issued Suite coupons will stop working; WooCommerce orders remain.';
  if($key==='registration_email')$desc='Module settings/activity/cache. Email-confirmation history and pending verification tokens remain to avoid disrupting existing accounts.';
  if($key==='supplier_monitor')$desc='Supplier links, observations, pricing context and approval audit are retained. Automatic reset is disabled; export a full site backup before any manual data review.';
  if($key==='mobile_payment')$desc='Gateway/module settings and display activity/cache after all connections have been removed through Dreminex Payments. Financial order evidence remains.';
  if(str_starts_with($key,'addon-'))$desc='Imported owned-data and settings options, activity/cache. Installed package remains disabled. Custom tables/files outside the owned-data API require a developer adapter.';
  return ['description'=>$desc,'protected'=>!empty($spec['order_meta'])||in_array($key,['order_management','checkout_protection','registration_email','mobile_payment'],true)];
 }
 public static function fresh_check($key) {
  $spec=self::spec($key);if($spec===null)return new WP_Error('unknown','Unknown module.');
  if(!empty(((array)get_option('dreminex_suite_modules',[]))[$key])||!empty(Dreminex_Suite_Imports::all()[$key]['enabled']))return new WP_Error('enabled','Turn this module off first.');global $wpdb;
  if($key==='mobile_payment'&&((array)get_option('dreminex_payment_profiles',[])||(array)get_option('dreminex_payment_secrets',[])))return new WP_Error('connections','Remove connections through Dreminex Payments after reconciling unresolved payments. This reset cannot bypass payment reconciliation.');
  if($key==='contact_requests'&&(int)$wpdb->get_var('SELECT COUNT(*) FROM '.Dreminex_Suite_Contact_Trash::table())>100)return new WP_Error('batch','Use Contact Requests bulk deletion until at most 100 records remain, then retry.');
  if(!empty($spec['posts'])&&count(get_posts(['post_type'=>$spec['posts'],'post_status'=>['publish','private','draft','pending','future','trash'],'numberposts'=>101,'fields'=>'ids']))>100)return new WP_Error('batch','Delete unfinished-checkout records in batches, then retry.');
  if($key==='newsletter_offers'&&count(get_posts(['post_type'=>'shop_coupon','post_status'=>['publish','private','draft','pending','future','trash'],'numberposts'=>101,'fields'=>'ids','meta_key'=>'_dreminex_owner_user_id']))>100)return new WP_Error('batch','Remove Suite coupons in batches until at most 100 remain.');
  return true;
 }
 public static function fresh($key) {
  $check=self::fresh_check($key);if(is_wp_error($check))return $check;$spec=self::spec($key);global $wpdb;
  if($key==='newsletter_offers') {
   foreach(get_posts(['post_type'=>'shop_coupon','post_status'=>['publish','private','draft','pending','future','trash'],'numberposts'=>100,'meta_key'=>'_dreminex_owner_user_id']) as $p)if(!wp_delete_post($p->ID,true))return new WP_Error('coupon','Could not delete an owned coupon.');
   foreach($spec['tables'] as $suffix){$table=$wpdb->prefix.$suffix;if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)))===$table&&$wpdb->query('DELETE FROM `'.$table.'`')===false)return new WP_Error('db','Could not clear module records.');}
  }elseif(!empty($spec['order_meta'])||in_array($key,['registration_email','order_management','checkout_protection','mobile_payment'],true)) {
   // Existing business/security audit is not a module cache.
  }else{$result=self::erase($key,'records');if(is_wp_error($result))return $result;}
  if($key==='contact_requests'){
   $base=realpath(dirname(ABSPATH).'/dreminex-contact-evidence/mail-media');foreach((array)get_option('dreminex_contact_mail_defaults',[]) as $row){$name=is_array($row)?($row['stored']??''):'';$path=$base&&$name?realpath($base.'/'.$name):false;if($path&&basename($name)===$name&&dirname($path)===$base&&!is_link($base.'/'.$name)&&is_file($path)&&!unlink($path))return new WP_Error('media','Could not delete default private media.');}
  }
  if($key==='mobile_payment'){$s=(array)get_option('dreminex_suite_module_settings',[]);unset($s[$key]);update_option('dreminex_suite_module_settings',$s,false);delete_option('woocommerce_dreminex_mobile_payment_settings');}
  else{$result=self::erase($key,'settings');if(is_wp_error($result))return $result;}
  $activity=(array)get_option('dreminex_suite_activity',[]);unset($activity[$key]);update_option('dreminex_suite_activity',$activity,false);
  Dreminex_Suite_Cache::changed($key,true);Dreminex_Suite_Cache::flush();
  $history=(array)get_option('dreminex_suite_data_resets',[]);array_unshift($history,['module'=>$key,'time'=>time(),'user'=>get_current_user_id(),'result'=>'completed']);update_option('dreminex_suite_data_resets',array_slice($history,0,20),false);
  return true;
 }
 public static function scope_panel($key){$plan=self::reset_plan($key);if(is_wp_error($plan))return;$spec=self::spec($key);echo '<h3>Owned data locations</h3><p>'.esc_html(wp_json_encode($spec)).'</p>';echo '<div class="notice notice-warning inline"><h3>Fresh reset scope</h3><p>'.esc_html($plan['description']).'</p><p>Turn the module Off, download a backup, select Fresh reset and confirm. It remains Off until you configure and enable it again.</p></div>';}
 public static function reset_history($key){echo '<h3>Recent Fresh resets</h3><ul>';$found=false;foreach((array)get_option('dreminex_suite_data_resets',[]) as $row)if(($row['module']??'')===$key){$found=true;echo '<li>'.esc_html(wp_date('Y-m-d H:i:s',(int)$row['time']).' — '.$row['result']).'</li>';}if(!$found)echo '<li>No Fresh reset recorded.</li>';echo '</ul>';}
 public static function panel($key){echo '<p><a class="button" href="'.esc_url(admin_url('admin.php?page=dreminex-suite-settings&section=backup&module='.$key)).'">Backup / manage this module’s data</a></p>';}
 public static function page() {
  if(!current_user_can('manage_options'))return;$key=sanitize_key(wp_unslash($_GET['module']??'delivery_advance'));
  echo '<div class="wrap"><h1>Backup & module data</h1><p>Backups contain private customer records. Store them securely. Deletion is manual, scoped and requires the module to be off. Core pages, menus, products, users and orders are never deleted here.</p><form method="get" action="'.esc_url(admin_url('admin.php')).'"><input type="hidden" name="page" value="dreminex-suite-settings"><input type="hidden" name="section" value="backup"><label for="suite-data-module">Select module</label> <select id="suite-data-module" name="module" onchange="if(this.form.requestSubmit){this.form.requestSubmit()}else{this.form.submit()}">';
  $catalog=Dreminex_Suite::catalog();foreach(Dreminex_Suite_Imports::all() as $id=>$item)$catalog[$id]=[$item['manifest']['name']];foreach($catalog as $id=>$module)echo '<option value="'.esc_attr($id).'" '.selected($key,$id,false).'>'.esc_html($module[0]).'</option>';echo '</select>';submit_button('Open selected module','secondary','open_module',false);echo '</form>';
  $spec=self::spec($key);if($spec===null){echo '<p>Unknown module.</p></div>';return;}
  echo '<h2>'.esc_html($catalog[$key][0]).' — '.esc_html($key).'</h2><p>Backup: module settings, listed module-owned records, private Contact attachments, and read-only order metadata where applicable. Passwords/API keys/reset tokens are excluded. Restore requires developer/hosting review; this is not a full-site backup.</p><p>Deletion scope: settings reset; Contact requests/replies/files; consented partial checkouts; newsletter subscriber records. Records-only deletion preserves coupons/claims and order-linked audit. Fresh reset has the module-specific scope shown below.</p><p><a class="button button-primary" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=dreminex_suite_backup&module='.$key),'dreminex_suite_backup_'.$key)).'">Download backup ZIP</a></p>';
  self::scope_panel($key);
  if(isset($_GET['deleted']))echo '<p>Selected module data scope removed.</p>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_suite_data_delete"><input type="hidden" name="module" value="'.esc_attr($key).'">';wp_nonce_field('dreminex_suite_data_delete_'.$key);
  echo '<p><select name="scope"><option value="settings">Reset this module’s settings</option><option value="records">Delete this module’s deletable records</option><option value="fresh">Fresh reset: settings + module-owned records</option></select></p><p><label><input required type="checkbox" name="backup_confirm" value="1"> I downloaded a backup and understand the displayed scope.</label></p><p>For Fresh reset, also type <code>RESET</code>: <input name="fresh_confirm" autocomplete="off"></p><p>Type <code>'.esc_html($key).'</code>: <input required name="confirm_module" autocomplete="off"></p>';submit_button('Delete selected scope','delete');echo '</form>';self::reset_history($key);echo '</div>';
 }
}
