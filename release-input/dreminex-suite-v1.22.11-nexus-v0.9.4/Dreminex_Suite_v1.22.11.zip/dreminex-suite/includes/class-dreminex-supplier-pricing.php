<?php
if (!defined('ABSPATH')) exit;

/** A conservative one-item pricing quote; it never writes a WooCommerce product. */
final class Dreminex_Supplier_Pricing {
 public static function quote($wholesale, $policy, $item) {
  $required=['other_cost'=>$policy['other_cost']??null,'return_reserve'=>$policy['return_reserve']??null,
   'supplier_fee_percent'=>$policy['supplier_fee_percent']??null,
   'coupon_reserve'=>$policy['coupon_reserve']??null,
   'coupon_percent_reserve'=>$policy['coupon_percent_reserve']??null,'minimum_profit'=>$policy['minimum_profit']??null,
   'maximum_profit'=>$policy['maximum_profit']??null,'ad_cost'=>$item['ad_cost']??null,
   'target_profit'=>$item['target_profit']??null,'customer_cap'=>$item['customer_cap']??null,
   'delivery_min'=>$item['delivery_min']??null,'delivery_max'=>$item['delivery_max']??null];
  if(!is_numeric($wholesale)||!is_finite((float)$wholesale)||(float)$wholesale<=0)return ['ok'=>false,'reason'=>'Wholesale cost is missing or invalid.'];
  foreach($required as $name=>$value)if(!is_numeric($value)||!is_finite((float)$value)||(float)$value<0)return ['ok'=>false,'reason'=>'Missing or invalid '.$name.'.'];
  $p=array_map('floatval',$required);
  if($p['supplier_fee_percent']>=100||$p['coupon_percent_reserve']>=100||$p['ad_cost']<25||$p['ad_cost']>90||$p['minimum_profit']<70||$p['maximum_profit']>=200||$p['maximum_profit']<$p['minimum_profit']||$p['target_profit']<$p['minimum_profit']||$p['target_profit']>$p['maximum_profit']||$p['delivery_max']<$p['delivery_min']||$p['customer_cap']<=0)return ['ok'=>false,'reason'=>'Profit range, ad budget, discount, delivery or cap is invalid.'];
  $coupon=$p['coupon_percent_reserve']/100;
  $supplier_fee=(float)$wholesale*$p['supplier_fee_percent']/100;
  $cost=(float)$wholesale+$supplier_fee+$p['other_cost']+$p['return_reserve']+$p['ad_cost'];
  // Delivery is charged in advance and handled by the dropshipping platform;
  // it is included in the customer cap, not treated as store revenue or cost.
  $raw=($p['coupon_reserve']+$p['target_profit']+$cost)/(1-$coupon);
  if(!is_finite($raw)||$raw>10000000)return ['ok'=>false,'reason'=>'Required price is outside the supported range.'];
  $price=max(9,ceil(($raw+1-0.00000001)/10)*10-1);
  // Account for decimal precision at an exact ending-in-9 boundary.
  for($n=0;$n<2;$n++){
   $discounted=max(0,$price*(1-$coupon)-$p['coupon_reserve']);
   $promo_profit=$discounted-$cost;
   if($promo_profit+0.000001>=$p['target_profit'])break;
   $price+=10;
  }
  $regular_profit=$price-$cost;
  $customer_total=$price+$p['delivery_max'];
  if($regular_profit>$p['maximum_profit']+0.000001)return ['ok'=>false,'reason'=>'Discount protection would exceed the maximum regular profit.'];
  if($customer_total>$p['customer_cap']+0.000001)return ['ok'=>false,'reason'=>'Safe price exceeds the customer total cap including delivery.'];
  return ['ok'=>true,'price'=>(string)(int)$price,'regular_profit'=>round($regular_profit,2),
   'promotion_profit'=>round($promo_profit,2),'customer_total'=>round($customer_total,2),
   'wholesale'=>round((float)$wholesale,2),'other_cost'=>$p['other_cost'],'return_reserve'=>$p['return_reserve'],
   'ad_cost'=>$p['ad_cost'],'supplier_fee'=>round($supplier_fee,2),
   'coupon_fixed'=>$p['coupon_reserve'],'coupon_percent'=>$p['coupon_percent_reserve'],
   'delivery_min'=>$p['delivery_min'],'delivery_max'=>$p['delivery_max'],'customer_cap'=>$p['customer_cap']];
 }
}
