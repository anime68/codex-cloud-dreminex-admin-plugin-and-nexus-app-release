<?php
if (!defined('ABSPATH')) exit;

/** Bounded, site/client/user-bound upload sessions for non-inline media. */
final class Dreminex_MCP_Upload {
    const SCHEMA = 1;
    const CHUNK_BYTES = 4194304;
    const SESSION_TTL = 900;

    private static function table($suffix) { global $wpdb; return $wpdb->prefix . 'dreminex_mcp_' . $suffix; }
    private static function site_id() { return hash('sha256', untrailingslashit(home_url('/'))); }
    private static function now() { return current_time('mysql', true); }

    public static function enabled() { $settings = Dreminex_Native_MCP::settings(); return !empty($settings['media_enabled']); }

    public static function install() {
        if ((int) get_option('dreminex_mcp_media_schema', 0) >= self::SCHEMA) return;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php'; global $wpdb; $charset = $wpdb->get_charset_collate(); $sessions = self::table('upload_sessions'); $chunks = self::table('upload_chunks');
        dbDelta("CREATE TABLE {$sessions} (
          id bigint unsigned NOT NULL AUTO_INCREMENT, upload_uuid char(36) NOT NULL, client_id varchar(64) NOT NULL,
          user_id bigint unsigned NOT NULL, site_hash char(64) NOT NULL, filename varchar(255) NOT NULL, mime_claimed varchar(160) NOT NULL DEFAULT '',
          file_size_expected bigint unsigned NOT NULL, sha256_expected char(64) NOT NULL, bytes_received bigint unsigned NOT NULL DEFAULT 0,
          upload_state varchar(20) NOT NULL DEFAULT 'pending', ticket_sha256 char(64) NOT NULL, ticket_expires_at datetime NOT NULL,
          idempotency_key_hash char(64) NOT NULL DEFAULT '', desired_metadata_json text NOT NULL, committed_attachment_id bigint unsigned NOT NULL DEFAULT 0,
          created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY (id), UNIQUE KEY upload_uuid (upload_uuid),
          UNIQUE KEY client_idempotency (client_id,idempotency_key_hash), KEY user_state (user_id,upload_state), KEY expiry (ticket_expires_at)
        ) {$charset};");
        dbDelta("CREATE TABLE {$chunks} (
          id bigint unsigned NOT NULL AUTO_INCREMENT, upload_uuid char(36) NOT NULL, chunk_index int unsigned NOT NULL,
          byte_offset bigint unsigned NOT NULL, byte_count int unsigned NOT NULL, chunk_sha256 char(64) NOT NULL,
          received_at datetime NOT NULL, PRIMARY KEY (id), UNIQUE KEY upload_chunk (upload_uuid,chunk_index), KEY upload_uuid (upload_uuid)
        ) {$charset};");
        update_option('dreminex_mcp_media_schema', self::SCHEMA, false);
    }

    public static function boot() {
        if (!self::enabled()) return;
        self::install();
        add_action('rest_api_init', [__CLASS__, 'routes'], 45);
    }

    public static function routes() {
        register_rest_route('dreminex/v1', '/mcp-media/sessions', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => [__CLASS__, 'rest_create']]);
        register_rest_route('dreminex/v1', '/mcp-media/sessions/(?P<upload_id>[a-f0-9-]{36})', ['methods' => ['GET','DELETE'], 'permission_callback' => '__return_true', 'callback' => [__CLASS__, 'rest_session']]);
        register_rest_route('dreminex/v1', '/mcp-media/sessions/(?P<upload_id>[a-f0-9-]{36})/chunks/(?P<sequence>\d+)', ['methods' => 'PUT', 'permission_callback' => '__return_true', 'callback' => [__CLASS__, 'rest_chunk']]);
        register_rest_route('dreminex/v1', '/mcp-media/sessions/(?P<upload_id>[a-f0-9-]{36})/commit', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => [__CLASS__, 'rest_commit']]);
    }

    private static function oauth($request) {
        if (!self::enabled()) return new WP_Error('media_disabled', 'Native MCP media transfer is disabled by the site administrator.', ['status' => 403]);
        return Dreminex_Native_OAuth::authenticate($request, ['media:write']);
    }

    public static function private_directory() {
        $tmp = realpath(sys_get_temp_dir()); if (!$tmp || !is_dir($tmp) || !is_writable($tmp)) return new WP_Error('transfer_storage_unavailable', 'The server does not provide a private writable temporary directory.');
        $path = $tmp . DIRECTORY_SEPARATOR . 'dreminex-mcp-' . substr(hash('sha256', home_url('/')), 0, 24);
        if (is_link($path)) return new WP_Error('transfer_storage_unavailable', 'Private transfer storage cannot be a symbolic link.');
        if (!is_dir($path) && !wp_mkdir_p($path)) return new WP_Error('transfer_storage_unavailable', 'Private transfer storage could not be created.');
        @chmod($path, 0700); $real = realpath($path);
        if (!$real || !str_starts_with($real, rtrim($tmp, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) || !is_writable($real)) return new WP_Error('transfer_storage_unavailable', 'Private transfer storage is not isolated from the server temp root.');
        return $real;
    }

    private static function file_path($uuid) {
        if (!preg_match('/^[a-f0-9-]{36}$/', $uuid)) return '';
        $root = self::private_directory(); if (is_wp_error($root)) return '';
        return $root . DIRECTORY_SEPARATOR . hash('sha256', $uuid) . '.part';
    }

    public static function create_session($input) {
        if (!self::enabled()) return new WP_Error('media_disabled', 'Enable Native MCP media transfer in WordPress admin first.');
        if (!current_user_can('upload_files')) return new WP_Error('permission_denied', 'Media upload requires upload_files.');
        $filename = sanitize_file_name(wp_basename((string) ($input['filename'] ?? ''))); $size = absint($input['file_size'] ?? 0); $hash = strtolower((string) ($input['sha256'] ?? '')); $mime = sanitize_mime_type((string) ($input['mime_type'] ?? $input['claimed_mime'] ?? ''));
        $max = min((int) wp_max_upload_size(), 104857600);
        if ($filename === '' || strlen($filename) > 255 || !$size || $size > $max) return new WP_Error('upload_too_large', 'The declared file is empty or exceeds the site transfer limit.', ['max_bytes' => $max]);
        if (!preg_match('/^[a-f0-9]{64}$/', $hash)) return new WP_Error('invalid_checksum', 'A lowercase hexadecimal SHA-256 checksum is required.');
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (in_array($ext, ['php','phtml','phar','cgi','pl','py','sh','exe','dll','com','bat','cmd','htaccess','svg','shtml'], true)) return new WP_Error('unsupported_mime', 'This file extension is not allowed.');
        $type = wp_check_filetype($filename); if (empty($type['type']) || ($mime && strtolower($mime) !== strtolower($type['type']))) return new WP_Error('unsupported_mime', 'WordPress does not allow the declared filename/MIME type.');
        global $wpdb; $ctx = Dreminex_Native_OAuth::context(); $client = (string) ($ctx['client_id'] ?? ''); $user = (int) ($ctx['user_id'] ?? get_current_user_id());
        if ($client === '' || !$user) return new WP_Error('oauth_required', 'A Native MCP OAuth client context is required.', ['status' => 401]);
        $open = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . self::table('upload_sessions') . " WHERE client_id=%s AND user_id=%d AND site_hash=%s AND upload_state='pending' AND ticket_expires_at >= %s", $client, $user, self::site_id(), self::now()));
        if ($open >= 5) return new WP_Error('upload_quota_exceeded', 'This client already has five active upload sessions. Complete or cancel one before creating another.', ['status' => 429]);
        $idem = sanitize_text_field((string) ($input['idempotency_key'] ?? '')); $idem_hash = $idem !== '' ? hash('sha256', $client . '|' . $idem) : hash('sha256', wp_generate_uuid4());
        $table = self::table('upload_sessions'); $existing = $wpdb->get_row($wpdb->prepare("SELECT upload_uuid,upload_state,file_size_expected,sha256_expected,bytes_received FROM {$table} WHERE client_id=%s AND idempotency_key_hash=%s", $client, $idem_hash), ARRAY_A);
        if ($existing) {
            if ((int) $existing['file_size_expected'] !== $size || !hash_equals($existing['sha256_expected'], $hash)) return new WP_Error('idempotency_conflict', 'The idempotency key was already used for a different file.');
            return new WP_Error('upload_session_exists', 'This upload is already known. Resume it with its upload ID and OAuth credential; transfer ticket credentials are not reissued.', ['upload_id' => $existing['upload_uuid'], 'state' => $existing['upload_state'], 'bytes_received' => (int) $existing['bytes_received']]);
        }
        $root = self::private_directory(); if (is_wp_error($root)) return $root; $uuid = wp_generate_uuid4(); $path = self::file_path($uuid); if (!$path) return new WP_Error('transfer_storage_unavailable', 'Private transfer staging is unavailable.');
        $handle = @fopen($path, 'x+b'); if (!$handle) return new WP_Error('transfer_storage_unavailable', 'The upload staging file could not be reserved.'); chmod($path, 0600); fclose($handle);
        $ticket = rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '='); $expires = gmdate('Y-m-d H:i:s', time() + self::SESSION_TTL); $now = self::now();
        $inserted = $wpdb->insert($table, ['upload_uuid' => $uuid, 'client_id' => $client, 'user_id' => $user, 'site_hash' => self::site_id(), 'filename' => $filename, 'mime_claimed' => $mime, 'file_size_expected' => $size, 'sha256_expected' => $hash, 'bytes_received' => 0, 'upload_state' => 'pending', 'ticket_sha256' => hash('sha256', $ticket), 'ticket_expires_at' => $expires, 'idempotency_key_hash' => $idem_hash, 'desired_metadata_json' => wp_json_encode((array) ($input['desired_metadata'] ?? [])), 'created_at' => $now, 'updated_at' => $now], ['%s','%s','%d','%s','%s','%s','%d','%s','%d','%s','%s','%s','%s','%s','%s','%s']);
        if (!$inserted) { @unlink($path); return new WP_Error('upload_session_failed', 'The upload session could not be stored.'); }
        return ['upload_id' => $uuid, 'chunk_size' => self::CHUNK_BYTES, 'expires_at' => gmdate('c', strtotime($expires)), 'server_site_url' => home_url('/'), 'transfer_credential' => $ticket, 'credential_header' => 'Authorization: Bearer ' . $ticket, 'state' => 'pending'];
    }

    private static function get_session($uuid) {
        if (!preg_match('/^[a-f0-9-]{36}$/', $uuid)) return null;
        global $wpdb; return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table('upload_sessions') . ' WHERE upload_uuid=%s', $uuid), ARRAY_A);
    }

    private static function assert_owner($row, $request, $ticket_allowed = false) {
        if (!$row || $row['site_hash'] !== self::site_id()) return new WP_Error('site_lock_mismatch', 'Upload session belongs to a different WordPress site.', ['status' => 404]);
        $auth = self::oauth($request);
        if (!is_wp_error($auth)) {
            $ctx = Dreminex_Native_OAuth::context();
            if (($ctx['client_id'] ?? '') !== $row['client_id'] || (int) ($ctx['user_id'] ?? 0) !== (int) $row['user_id']) return new WP_Error('file_source_unauthorized', 'The session belongs to a different OAuth client or WordPress user.', ['status' => 403]);
            return ['mode' => 'oauth'];
        }
        if (!$ticket_allowed) return $auth;
        $header = (string) $request->get_header('authorization');
        if (!preg_match('/^Bearer\s+([A-Za-z0-9_-]{32,128})$/i', $header, $matches)) return $auth;
        if (strtotime((string) $row['ticket_expires_at']) < time() || !hash_equals((string) $row['ticket_sha256'], hash('sha256', $matches[1]))) return new WP_Error('upload_token_expired', 'The upload transfer credential is invalid or expired.', ['status' => 401]);
        if ($row['upload_state'] !== 'pending') return new WP_Error('invalid_upload_state', 'This upload session is no longer accepting chunks.', ['status' => 409]);
        wp_set_current_user((int) $row['user_id']);
        if (!current_user_can('upload_files')) return new WP_Error('permission_denied', 'The session owner no longer has upload_files.');
        return ['mode' => 'ticket'];
    }

    public static function session_status($uuid) {
        $row = self::get_session($uuid); if (!$row) return new WP_Error('upload_session_not_found', 'Upload session was not found.', ['status' => 404]);
        if ($row['site_hash'] !== self::site_id() || (int) $row['user_id'] !== get_current_user_id() || (Dreminex_Native_OAuth::context()['client_id'] ?? '') !== $row['client_id']) return new WP_Error('file_source_unauthorized', 'This upload session belongs to another client or user.', ['status' => 403]);
        $next = (int) $row['bytes_received']; $sequence = (int) $row['bytes_received'] > 0 ? (int) ceil((int) $row['bytes_received'] / self::CHUNK_BYTES) : 0;
        return ['upload_id' => $uuid, 'state' => $row['upload_state'], 'bytes_received' => $next, 'file_size_expected' => (int) $row['file_size_expected'], 'expected_next_chunk' => $sequence, 'expires_at' => gmdate('c', strtotime($row['ticket_expires_at'])), 'committed_attachment_id' => (int) $row['committed_attachment_id']];
    }

    public static function rest_create($request) {
        $auth = self::oauth($request); if (is_wp_error($auth)) return $auth;
        $input = $request->get_json_params(); return rest_ensure_response(self::create_session(is_array($input) ? $input : []));
    }

    public static function rest_session($request) {
        $uuid = (string) $request['upload_id']; $row = self::get_session($uuid); if (!$row) return new WP_Error('upload_session_not_found', 'Upload session was not found.', ['status' => 404]);
        $owner = self::assert_owner($row, $request, false); if (is_wp_error($owner)) return $owner;
        if ($request->get_method() === 'DELETE') return rest_ensure_response(self::cancel_session($uuid));
        return rest_ensure_response(self::session_status($uuid));
    }

    public static function rest_chunk($request) {
        if (!self::enabled()) return new WP_Error('media_disabled', 'Native MCP media transfer is disabled.', ['status' => 403]);
        $uuid = (string) $request['upload_id']; $row = self::get_session($uuid); if (!$row) return new WP_Error('upload_session_not_found', 'Upload session was not found.', ['status' => 404]);
        $owner = self::assert_owner($row, $request, true); if (is_wp_error($owner)) return $owner;
        $sequence = absint($request['sequence']); $body = (string) $request->get_body(); $length = strlen($body);
        if ($length < 1 || $length > self::CHUNK_BYTES) return new WP_Error('upload_too_large', 'Each binary chunk must be between 1 byte and 4 MiB.');
        $range = (string) $request->get_header('content-range');
        if (!preg_match('/^bytes\s+(\d+)-(\d+)\/(\d+)$/i', $range, $match)) return new WP_Error('invalid_content_range', 'Set Content-Range as bytes start-end/total.');
        $start = (int) $match[1]; $end = (int) $match[2]; $total = (int) $match[3];
        if ($end - $start + 1 !== $length || $total !== (int) $row['file_size_expected'] || $end >= $total) return new WP_Error('invalid_content_range', 'Content-Range does not match the uploaded bytes or declared file size.');
        $is_final_chunk = $end + 1 === $total;
        if (!$is_final_chunk && $length !== self::CHUNK_BYTES) return new WP_Error('invalid_chunk_size', 'Every non-final chunk must be exactly 4 MiB so interrupted uploads can resume at a stable sequence.');
        $hash = strtolower((string) $request->get_header('x-chunk-sha256')); $actual_hash = hash('sha256', $body);
        if (!preg_match('/^[a-f0-9]{64}$/', $hash) || !hash_equals($hash, $actual_hash)) return new WP_Error('chunk_hash_mismatch', 'The binary chunk checksum is invalid.');
        $idem_header = (string) $request->get_header('x-upload-idempotency-key'); if ($idem_header !== '' && !hash_equals((string) $row['idempotency_key_hash'], hash('sha256', $row['client_id'] . '|' . sanitize_text_field($idem_header)))) return new WP_Error('idempotency_conflict', 'This chunk retry has a different idempotency key.');
        global $wpdb; $chunks = self::table('upload_chunks'); $prior = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$chunks} WHERE upload_uuid=%s AND chunk_index=%d", $uuid, $sequence), ARRAY_A);
        if ($prior) { if (hash_equals($prior['chunk_sha256'], $actual_hash) && (int) $prior['byte_offset'] === $start && (int) $prior['byte_count'] === $length) return rest_ensure_response(['upload_id' => $uuid, 'accepted' => true, 'idempotent_retry' => true, 'accepted_offset' => (int) $row['bytes_received'], 'next_sequence' => $sequence + 1]); return new WP_Error('chunk_conflict', 'A different chunk already occupies this sequence number.', ['status' => 409]); }
        if ($start !== (int) $row['bytes_received']) return new WP_Error('transfer_interrupted', 'Chunks must arrive at the current resume offset.', ['status' => 409, 'accepted_offset' => (int) $row['bytes_received']]);
        $expected_sequence = (int) floor($start / self::CHUNK_BYTES); if ($sequence !== $expected_sequence) return new WP_Error('invalid_sequence', 'Chunk sequence does not match the next expected upload position.', ['status' => 409, 'expected_sequence' => $expected_sequence]);
        $path = self::file_path($uuid); if (!$path || !is_file($path)) return new WP_Error('transfer_storage_unavailable', 'The private upload file is missing.');
        $handle = fopen($path, 'c+b'); if (!$handle || !flock($handle, LOCK_EX)) return new WP_Error('transfer_storage_unavailable', 'The private upload file is busy.');
        fseek($handle, 0, SEEK_END); $actual_offset = ftell($handle);
        if ($actual_offset !== $start) { flock($handle, LOCK_UN); fclose($handle); return new WP_Error('transfer_interrupted', 'The staged file offset does not match its upload receipt.'); }
        $written = fwrite($handle, $body); fflush($handle);
        if ($written !== $length) { ftruncate($handle, $start); flock($handle, LOCK_UN); fclose($handle); return new WP_Error('transfer_interrupted', 'The chunk could not be written completely.'); }
        $changed = $wpdb->update(self::table('upload_sessions'), ['bytes_received' => $start + $length, 'updated_at' => self::now()], ['upload_uuid' => $uuid, 'bytes_received' => $start, 'upload_state' => 'pending'], ['%d','%s'], ['%s','%d','%s']);
        $inserted = $changed === 1 ? $wpdb->insert($chunks, ['upload_uuid' => $uuid, 'chunk_index' => $sequence, 'byte_offset' => $start, 'byte_count' => $length, 'chunk_sha256' => $actual_hash, 'received_at' => self::now()], ['%s','%d','%d','%d','%s','%s']) : false;
        if ($inserted !== 1) { ftruncate($handle, $start); $wpdb->update(self::table('upload_sessions'), ['bytes_received' => $start, 'updated_at' => self::now()], ['upload_uuid' => $uuid], ['%d','%s'], ['%s']); flock($handle, LOCK_UN); fclose($handle); return new WP_Error('transfer_conflict', 'Chunk receipt could not be committed; retry the last verified offset.', ['status' => 409]); }
        flock($handle, LOCK_UN); fclose($handle);
        return rest_ensure_response(['upload_id' => $uuid, 'accepted' => true, 'accepted_offset' => $start + $length, 'received_sha256' => $actual_hash, 'next_sequence' => $sequence + 1]);
    }

    public static function complete_session($uuid, $expected_hash, $metadata = [], $duplicate = 'reject') {
        $row = self::get_session($uuid); if (!$row) return new WP_Error('upload_session_not_found', 'Upload session was not found.', ['status' => 404]);
        if ($row['site_hash'] !== self::site_id() || (int) $row['user_id'] !== get_current_user_id() || (Dreminex_Native_OAuth::context()['client_id'] ?? '') !== $row['client_id']) return new WP_Error('file_source_unauthorized', 'Upload session belongs to another client or user.', ['status' => 403]);
        if (!current_user_can('upload_files')) return new WP_Error('permission_denied', 'The connected WordPress user no longer has upload_files.');
        if ($row['upload_state'] === 'completed' && (int) $row['committed_attachment_id']) return ['success' => true, 'deduplicated' => false, 'attachment' => Dreminex_MCP_Media_V2::execute('dreminex-media/metadata-read', ['attachment_id' => (int) $row['committed_attachment_id']]), 'idempotent_retry' => true];
        if ($row['upload_state'] !== 'pending' || strtotime($row['ticket_expires_at']) < time()) return new WP_Error('upload_token_expired', 'This upload session expired or has already been cancelled.', ['status' => 410]);
        if ((int) $row['bytes_received'] !== (int) $row['file_size_expected']) return new WP_Error('transfer_interrupted', 'Not all bytes have arrived yet.', ['status' => 409, 'bytes_received' => (int) $row['bytes_received'], 'file_size_expected' => (int) $row['file_size_expected']]);
        if (!hash_equals($row['sha256_expected'], strtolower($expected_hash))) return new WP_Error('chunk_hash_mismatch', 'Commit checksum differs from the session declaration.');
        $path = self::file_path($uuid); if (!$path || !is_file($path) || filesize($path) !== (int) $row['file_size_expected']) return new WP_Error('transfer_interrupted', 'The private staged file is missing or has the wrong size.');
        $actual = hash_file('sha256', $path); if (!hash_equals($row['sha256_expected'], $actual)) { self::cancel_session($uuid); return new WP_Error('chunk_hash_mismatch', 'The completed file checksum did not match; this session was cancelled.'); }
        $saved_metadata = array_replace((array) json_decode($row['desired_metadata_json'], true), (array) $metadata);
        $result = Dreminex_MCP_Media_V2::ingest_file($path, $row['filename'], $row['mime_claimed'], $saved_metadata, $duplicate, $row['sha256_expected']);
        if (is_wp_error($result)) return $result;
        $attachment_id = absint($result['attachment']['attachment_id'] ?? 0); if (!$attachment_id) return new WP_Error('readback_failed', 'The uploaded Media Library item did not return a verified attachment ID.');
        global $wpdb; $wpdb->update(self::table('upload_sessions'), ['upload_state' => 'completed', 'committed_attachment_id' => $attachment_id, 'updated_at' => self::now()], ['upload_uuid' => $uuid, 'upload_state' => 'pending'], ['%s','%d','%s'], ['%s','%s']);
        if (is_file($path)) @unlink($path);
        return $result + ['upload_id' => $uuid, 'upload_state' => 'completed'];
    }

    public static function cancel_session($uuid) {
        $row = self::get_session($uuid); if (!$row) return ['cancelled' => false, 'reason' => 'not_found'];
        if ($row['site_hash'] !== self::site_id() || (int) $row['user_id'] !== get_current_user_id() || (Dreminex_Native_OAuth::context()['client_id'] ?? '') !== $row['client_id']) return new WP_Error('file_source_unauthorized', 'Upload session belongs to another client or user.', ['status' => 403]);
        global $wpdb; $wpdb->update(self::table('upload_sessions'), ['upload_state' => 'cancelled', 'updated_at' => self::now()], ['upload_uuid' => $uuid, 'upload_state' => 'pending'], ['%s','%s'], ['%s','%s']);
        $path = self::file_path($uuid); if ($path && is_file($path)) @unlink($path);
        return ['cancelled' => true, 'upload_id' => $uuid];
    }

    public static function rest_commit($request) {
        $auth = self::oauth($request); if (is_wp_error($auth)) return $auth; $input = $request->get_json_params(); $input = is_array($input) ? $input : [];
        return rest_ensure_response(self::complete_session((string) $request['upload_id'], (string) ($input['expected_sha256'] ?? ''), (array) ($input['metadata'] ?? []), (string) ($input['duplicate_behavior'] ?? 'reject')));
    }

    public static function capabilities() {
        $maximum = min((int) wp_max_upload_size(), 104857600); $mimes = get_allowed_mime_types(get_current_user_id());
        return ['enabled' => self::enabled(), 'max_json_body_bytes' => 1048576, 'max_inline_file_bytes' => 524288, 'chunk_bytes' => self::CHUNK_BYTES, 'maximum_upload_bytes' => $maximum, 'session_ttl_seconds' => self::SESSION_TTL, 'private_staging_available' => !is_wp_error(self::private_directory()), 'allowed_mimes' => array_values(array_unique(array_filter(array_values((array) $mimes)))), 'malware_scanner' => has_filter('dreminex_mcp_scan_upload') ? 'configured' : 'not_configured', 'chat_attachment_adapter' => 'not_available_from_server'];
    }

    public static function cleanup() {
        global $wpdb; $table = self::table('upload_sessions'); $expired = $wpdb->get_col($wpdb->prepare("SELECT upload_uuid FROM {$table} WHERE upload_state='pending' AND ticket_expires_at < %s LIMIT 200", self::now()));
        foreach ($expired as $uuid) { $path = self::file_path($uuid); if ($path && is_file($path)) @unlink($path); }
        if ($expired) $wpdb->query($wpdb->prepare("UPDATE {$table} SET upload_state='expired',updated_at=%s WHERE upload_state='pending' AND ticket_expires_at < %s", self::now(), self::now()));
        $wpdb->query($wpdb->prepare("DELETE FROM " . self::table('upload_chunks') . " WHERE received_at < %s", gmdate('Y-m-d H:i:s', time() - DAY_IN_SECONDS)));
        $root = self::private_directory(); if (!is_wp_error($root)) foreach (glob($root . DIRECTORY_SEPARATOR . '*') ?: [] as $path) if (is_file($path) && filemtime($path) < time() - DAY_IN_SECONDS) @unlink($path);
    }
}
