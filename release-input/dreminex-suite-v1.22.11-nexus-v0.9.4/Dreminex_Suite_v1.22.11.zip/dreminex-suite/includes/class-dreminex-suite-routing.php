<?php
if(!defined('ABSPATH'))exit;
/** One authoritative route for API/manual Delivery Advance & Wallet. */
final class Dreminex_Suite_Routing {
 public static function enabled($id){return !empty(((array)get_option('dreminex_suite_modules',[]))[$id]);}
 public static function delivery(){return self::enabled('delivery_advance');}
 public static function api_ready(){
  if(!self::enabled('delivery_advance')||!class_exists('Dreminex_Payments_Provider_Registry')||!class_exists('Dreminex_Payments_Connection_Profile_Repository')||get_woocommerce_currency()!=='BDT')return false;
  $s=(array)get_option('woocommerce_dreminex_mobile_payment_settings',[]);if(($s['enabled']??'yes')!=='yes')return false;
  $repo=new Dreminex_Payments_Connection_Profile_Repository();foreach(Dreminex_Payments_Provider_Registry::all() as $provider)if($repo->available_for($provider->id()))return true;return false;
 }
 public static function cod_cart_state(){
  if(!function_exists('WC')||!WC()->cart||WC()->cart->is_empty())return 'none';$cod=0;$normal=0;
  foreach(WC()->cart->get_cart() as $item){$product=$item['data']??null;if(!$product instanceof WC_Product)continue;$enabled=$product->get_meta('_dreminex_cod_only')==='yes';if(!$enabled&&$product->is_type('variation'))$enabled=get_post_meta($product->get_parent_id(),'_dreminex_cod_only',true)==='yes';if($enabled)$cod++;else $normal++;}
  return $cod&&$normal?'mixed':($cod?'all':'none');
 }
 public static function decision($delivery,$api,$cod=false){if($cod==='all'||$cod===true)return 'cod';if($cod==='mixed')return 'mixed';if(!$delivery)return $api?'api':'none';return $api?'api':'manual';}
 public static function route(){return self::decision(self::delivery(),self::api_ready(),self::cod_cart_state());}
 public static function boot(){
  add_filter('option_woocommerce_bacs_settings',[__CLASS__,'manual_settings']);
  add_filter('default_option_woocommerce_bacs_settings',[__CLASS__,'manual_settings']);
  add_filter('option_woocommerce_cod_settings',[__CLASS__,'cod_settings']);
  add_filter('default_option_woocommerce_cod_settings',[__CLASS__,'cod_settings']);
  add_filter('woocommerce_available_payment_gateways',[__CLASS__,'gateways'],99999);
  add_filter('woocommerce_checkout_fields',[__CLASS__,'fields'],10002);
  add_action('woocommerce_after_checkout_validation',[__CLASS__,'validate'],1,2);
  add_action('woocommerce_checkout_create_order',[__CLASS__,'guard_order'],1,2);
 }
 public static function manual_settings($s){$s=is_array($s)?$s:[];if(self::delivery()&&get_woocommerce_currency()==='BDT'){$s['enabled']='yes';$s['title']='Delivery Advance & Wallet';}return $s;}
 public static function cod_settings($s){$s=is_array($s)?$s:[];if(self::cod_cart_state()==='all'){$s['enabled']='yes';$s['title']='Cash on delivery';$s['description']='Pay the complete order amount when this COD-only product is delivered.';}return $s;}
 public static function filter_route($gateways,$delivery,$route){
  if(!$delivery){if($route!=='api')unset($gateways['dreminex_mobile_payment']);return $gateways;}
  if($route==='cod'){unset($gateways['bacs'],$gateways['dreminex_mobile_payment']);}
  elseif($route==='api'){unset($gateways['bacs'],$gateways['cod']);}
  elseif($route==='manual'){unset($gateways['dreminex_mobile_payment'],$gateways['cod']);}
  elseif($route==='mixed')unset($gateways['bacs'],$gateways['dreminex_mobile_payment'],$gateways['cod']);
  return $gateways;
 }
 public static function gateways($gateways){return self::filter_route($gateways,self::delivery(),self::route());}
 public static function fields($fields){if(self::delivery()&&self::route()!=='manual')unset($fields['order']['dreminex_payment_plan'],$fields['order']['dreminex_use_wallet'],$fields['order']['dreminex_advance_method'],$fields['order']['dreminex_advance_txid']);return $fields;}
 public static function blocked($method,$delivery,$route){return ($method==='cod'&&$route!=='cod')||($delivery&&(($route==='cod'&&in_array($method,['bacs','dreminex_mobile_payment'],true))||($route==='api'&&in_array($method,['bacs','cod'],true))||($route==='manual'&&in_array($method,['dreminex_mobile_payment','cod'],true))||$route==='mixed'));}
 public static function validate($data,$errors){$route=self::route();if($route==='mixed')$errors->add('dreminex_cod_mixed_cart','COD-only products and standard products must be ordered separately.');elseif(self::blocked($data['payment_method']??'',self::delivery(),$route))$errors->add('dreminex_payment_route','Payment options have changed. Refresh checkout and choose the available payment option.');}
 public static function guard_order($order,$data){if(self::blocked($data['payment_method']??'',self::delivery(),self::route()))throw new Exception('Payment options have changed. Refresh checkout before placing the order.');}
}
