<?php
if (!defined('ABSPATH')) exit;
require_once __DIR__ . '/class-dreminex-mcp-abilities-v3.php';

/** Registers the versioned, first-party Native MCP ability catalogue. */
final class Dreminex_MCP_Abilities_V2 {
    private static $registered = [];

    private static function categories() {
        return [
            'Media and Files' => ['dreminex-media', 'Media and Files'],
            'Chat Attachment Ingestion' => ['dreminex-media', 'Media and Files'],
            'WordPress Core' => ['dreminex-core', 'WordPress Core'],
            'Gutenberg & Editor' => ['dreminex-core', 'WordPress Core'],
            'Skills & Design' => ['dreminex-design', 'Skills and Design'],
            'MCP Gateway & Diagnostics' => ['dreminex-system', 'Dreminex System'],
            'Editor Queue' => ['dreminex-editor', 'Gutenberg and Editor'],
            'Scoped File Access' => ['dreminex-files', 'Scoped Files'],
            'Safe Built-in Tasks' => ['dreminex-developer', 'Safe built-in tasks'],
            'Supplier Evidence' => ['dreminex-suppliers', 'Supplier Evidence'],
        ];
    }

    public static function register_categories() {
        if (!function_exists('wp_register_ability_category')) return;
        $registered = [];
        foreach (self::categories() as $pair) $registered[$pair[0]] = $pair[1];
        foreach ($registered as $slug => $label) {
            if ($slug === 'dreminex-system') continue;
            $result = wp_register_ability_category($slug, ['label' => $label, 'description' => 'First-party Dreminex abilities with explicit OAuth scope, WordPress capability and risk policy.']);
            if (is_wp_error($result) && $result->get_error_code() !== 'ability_category_already_exists') continue;
        }
    }

    public static function register() {
        if (!function_exists('wp_register_ability')) return;
        foreach (Dreminex_MCP_Registry_Policy::specs() as $name => $spec) {
            if (function_exists('wp_get_ability') && wp_get_ability($name)) { self::$registered[$name] = 'already_registered'; continue; }
            $scope = Dreminex_MCP_Registry_Policy::required_scope($name, ($spec['operation'] ?? '') === 'read');
            $risk = (string) ($spec['operation'] ?? 'high_write');
            $readonly = $risk === 'read';
            $destructive = $risk === 'destructive';
            $category_pair = self::categories()[$spec['functional_group'] ?? ''] ?? [];
            $category = $category_pair[0] ?? 'dreminex-system';
            $annotations = ['readonly' => $readonly, 'destructive' => $destructive, 'idempotent' => $readonly];
            $meta = ['provider_plugin' => 'dreminex-suite', 'annotations' => $annotations, 'mcp' => ['public' => true, 'required_scope' => $scope, 'risk' => $risk]];
            $args = [
                'label' => self::label($name), 'description' => self::description($spec), 'category' => $category,
                'input_schema' => (array) ($spec['input_schema'] ?? ['type' => 'object', 'additionalProperties' => false]),
                'output_schema' => ['type' => 'object', 'additionalProperties' => true],
                'permission_callback' => static function () use ($name) { return self::permission($name); },
                'execute_callback' => static function ($input) use ($name) { return self::execute_named($name, (array) $input); },
                'annotations' => $annotations, 'meta' => $meta,
            ];
            $result = wp_register_ability($name, $args);
            self::$registered[$name] = is_wp_error($result) ? 'registration_error' : 'registered';
            if (!is_wp_error($result)) Dreminex_MCP_Registry_Policy::mark_owned($name);
        }
    }

    private static function label($name) {
        $part = (string) substr($name, strpos($name, '/') + 1);
        $part = preg_replace('/([a-z])([A-Z])/', '$1 $2', str_replace(['-', '_'], ' ', $part));
        return ucwords($part);
    }

    private static function description($spec) {
        $group = sanitize_text_field((string) ($spec['functional_group'] ?? 'Dreminex'));
        $risk = sanitize_key((string) ($spec['operation'] ?? 'read'));
        $contract = array_slice((array) ($spec['output_contract'] ?? []), 0, 4);
        $contract = array_values(array_filter(array_map(static function ($item) {
            return trim(wp_strip_all_tags((string) $item));
        }, $contract)));
        $description = self::label((string) ($spec['name'] ?? 'Dreminex ability')) . '. Group: ' . $group . '. Operation: ' . $risk . '.';
        if ($contract) $description .= ' Returns: ' . implode('; ', $contract) . '.';
        return $description . ' Requires Native MCP allowlisting, the exact OAuth scope and the matching WordPress capability.';
    }

    private static function permission($name) {
        $capability = Dreminex_MCP_Registry_Policy::required_capability($name);
        return !$capability || current_user_can($capability);
    }

    public static function execute_named($name, $input) {
        if (str_starts_with($name, 'dreminex-media/')) return Dreminex_MCP_Media_V2::execute($name, $input);
        if (str_starts_with($name, 'dreminex-editor/') || str_starts_with($name, 'dreminex-files/') || str_starts_with($name, 'dreminex-admin/') || str_starts_with($name, 'dreminex-developer/')) return Dreminex_MCP_Abilities_V3::execute($name, $input);
        if (in_array($name, ['dreminex-system/agent-context-read','dreminex-workflow/skills-delete','dreminex-design/design-list','dreminex-design/design-activate','dreminex-design/design-delete'], true)) return Dreminex_MCP_Abilities_V3::execute($name, $input);
        if (str_starts_with($name, 'dreminex-system/ability-coverage-')) return Dreminex_MCP_Registry_Policy::coverage($input);
        if ($name === 'dreminex-system/media-transfer-capabilities') return Dreminex_MCP_Upload::capabilities();
        if ($name === 'dreminex-suppliers/options-preview') return self::supplier_preview($input);
        if (str_starts_with($name, 'dreminex-core/')) return self::core($name, $input);
        if (str_starts_with($name, 'dreminex-workflow/') || str_starts_with($name, 'dreminex-design/')) return self::managed_document($name, $input);
        return new WP_Error('ability_not_implemented', 'No registered handler exists for this ability.', ['status' => 501]);
    }

    private static function supplier_preview($input) {
        if (!class_exists('Dreminex_Supplier_Nexus')) return new WP_Error('provider_missing', 'Supplier Monitor is unavailable on this site.', ['status' => 424]);
        $url = Dreminex_Supplier_Nexus::canonical_supplier_url((string) ($input['supplier_url'] ?? ''));
        $platform = Dreminex_Supplier_Nexus::platform_for_url($url);
        if (!$platform) return ['status' => 'mapping_required', 'reason_code' => 'unsupported_platform', 'canonical_url' => $url, 'designs' => [], 'sizes' => [], 'supplier_skus' => []];
        if (!empty($input['product_id'])) {
            $sources = (array) get_post_meta(absint($input['product_id']), Dreminex_Supplier_Nexus::SOURCE_META, true);
            $matches = false;
            foreach ($sources as $source) if (Dreminex_Supplier_Nexus::canonical_supplier_url((string) ($source['url'] ?? '')) === $url) $matches = true;
            if (!$matches) return ['status' => 'mapping_required', 'reason_code' => 'product_url_not_mapped', 'platform_id' => $platform['platform_id'], 'canonical_url' => $url, 'designs' => [], 'sizes' => [], 'supplier_skus' => []];
        }
        $observation = Dreminex_Supplier_Nexus::latest_observation($url);
        if (!$observation) return ['status' => 'pending_device', 'reason_code' => 'observation_missing', 'platform_id' => $platform['platform_id'], 'canonical_url' => $url, 'designs' => [], 'sizes' => [], 'supplier_skus' => []];
        $fresh = !empty($observation['checked_at']) && strtotime($observation['checked_at']) >= time() - DAY_IN_SECONDS;
        $variants = array_values((array) ($observation['variants'] ?? []));
        $sizes = array_values(array_unique(array_filter(array_map('sanitize_text_field', (array) ($observation['sizes'] ?? [])))));
        return ['status' => $fresh ? 'observed' : 'stale', 'platform_id' => $platform['platform_id'], 'canonical_url' => $url,
            'observed_at' => $observation['checked_at'] ?? null, 'source_title' => sanitize_text_field((string) ($observation['source_title'] ?? '')),
            'designs' => array_values(array_unique(array_filter(array_map(static fn($row) => sanitize_text_field((string) ($row['color'] ?? $row['design'] ?? '')), $variants)))),
            'sizes' => $sizes,
            'supplier_skus' => array_values(array_filter(array_map(static fn($row) => sanitize_text_field((string) ($row['supplier_sku'] ?? '')), $variants))),
            'availability' => sanitize_key((string) ($observation['product_availability'] ?? 'unknown')), 'evidence' => array_slice((array) ($observation['evidence'] ?? []), 0, 50)];
    }

    private static function core($name, $input) {
        switch ($name) {
            case 'dreminex-core/posts-query': return self::posts_query($input);
            case 'dreminex-core/post-read': return self::post_read(absint($input['post_id'] ?? 0), !empty($input['include_blocks']));
            case 'dreminex-core/post-create': return self::post_create($input);
            case 'dreminex-core/post-update': return self::post_update($input);
            case 'dreminex-core/taxonomies-query': return self::taxonomies_query($input);
            case 'dreminex-core/settings-read': return self::settings_read($input);
            case 'dreminex-core/settings-update': return self::settings_update($input);
            case 'dreminex-core/block-types-read': return self::block_types($input);
            case 'dreminex-core/block-content-read': return self::block_content(absint($input['post_id'] ?? 0));
            case 'dreminex-core/block-change-preflight': return self::block_change($input, true);
            case 'dreminex-core/block-change-apply': return self::block_change($input, false);
            case 'dreminex-core/users-read': return self::users_read($input);
            case 'dreminex-core/plugins-status-read': return self::plugins_read($input);
            case 'dreminex-core/themes-status-read': return self::themes_read();
            case 'dreminex-core/comments-query': return self::comments_query($input);
            case 'dreminex-core/menus-read': return self::menus_read($input);
        }
        return new WP_Error('ability_not_implemented', 'This WordPress Core ability has no handler.', ['status' => 501]);
    }

    private static function post_revision($post) { return $post->post_modified_gmt . ':' . substr(hash('sha256', (string) $post->post_content), 0, 32); }
    private static function can_read_post($post) { return $post && ($post->post_status === 'publish' || current_user_can('edit_post', $post->ID) || current_user_can('read_post', $post->ID)); }

    private static function posts_query($input) {
        $type = sanitize_key((string) ($input['post_type'] ?? 'post'));
        if (!post_type_exists($type) || $type === 'attachment') return new WP_Error('invalid_post_type', 'Choose a registered non-attachment post type.');
        $status = sanitize_key((string) ($input['status'] ?? 'publish'));
        $allowed = ['publish'];
        if (current_user_can('edit_posts')) $allowed = ['publish','draft','pending','private'];
        if (!in_array($status, $allowed, true)) return new WP_Error('permission_denied', 'The connected user cannot query this post status.');
        $page = max(1, absint($input['page'] ?? 1));
        $query = new WP_Query(['post_type' => $type, 'post_status' => $status, 's' => sanitize_text_field((string) ($input['search'] ?? '')), 'posts_per_page' => 50, 'paged' => $page, 'no_found_rows' => false]);
        $items = [];
        foreach ($query->posts as $post) if (self::can_read_post($post)) $items[] = ['post_id' => (int) $post->ID, 'title' => get_the_title($post), 'status' => $post->post_status, 'permalink' => esc_url_raw(get_permalink($post)), 'revision' => self::post_revision($post)];
        return ['items' => $items, 'page' => $page, 'total' => (int) $query->found_posts, 'total_pages' => (int) $query->max_num_pages];
    }

    private static function post_read($id, $include_blocks) {
        $post = get_post($id);
        if (!self::can_read_post($post)) return new WP_Error('post_not_found', 'The post is missing or unavailable to this user.', ['status' => 404]);
        $content = substr((string) $post->post_content, 0, 40000);
        $terms = [];
        foreach (get_object_taxonomies($post->post_type, 'names') as $taxonomy) {
            $values = get_the_terms($id, $taxonomy);
            if (is_array($values)) foreach (array_slice($values, 0, 30) as $term) $terms[] = ['taxonomy' => $taxonomy, 'term_id' => (int) $term->term_id, 'name' => $term->name, 'slug' => $term->slug];
        }
        $result = ['post_id' => $id, 'post_type' => $post->post_type, 'status' => $post->post_status, 'title' => get_the_title($post), 'content' => $content, 'excerpt' => (string) $post->post_excerpt, 'permalink' => esc_url_raw(get_permalink($post)), 'revision' => self::post_revision($post), 'content_hash' => hash('sha256', (string) $post->post_content), 'terms' => $terms];
        if ($include_blocks && function_exists('parse_blocks')) $result['blocks'] = array_slice(parse_blocks($content), 0, 100);
        return $result;
    }

    private static function post_create($input) {
        $type = sanitize_key((string) ($input['post_type'] ?? ''));
        if (!post_type_exists($type) || $type === 'attachment') return new WP_Error('invalid_post_type', 'Choose a registered post type.');
        $type_object = get_post_type_object($type);
        $cap = $type_object && !empty($type_object->cap->create_posts) ? $type_object->cap->create_posts : 'edit_posts';
        if (!current_user_can($cap)) return new WP_Error('permission_denied', 'The connected user cannot create this post type.');
        if (isset($input['status']) && $input['status'] !== 'draft') return new WP_Error('invalid_status', 'New posts can only be created as Drafts.');
        $key = sanitize_text_field((string) ($input['idempotency_key'] ?? ''));
        $hash = $key !== '' ? 'dreminex_mcp_post_' . hash('sha256', get_current_user_id() . '|' . $type . '|' . $key) : '';
        if ($hash && ($existing = absint(get_transient($hash)))) return ['post_id' => $existing, 'status' => get_post_status($existing), 'reused' => true, 'revision' => self::post_revision(get_post($existing))];
        $id = wp_insert_post(['post_type' => $type, 'post_status' => 'draft', 'post_title' => sanitize_text_field((string) $input['title']), 'post_content' => wp_kses_post((string) ($input['content'] ?? ''))], true);
        if (is_wp_error($id)) return $id;
        if ($hash) set_transient($hash, (int) $id, 30 * DAY_IN_SECONDS);
        $post = get_post($id);
        return ['post_id' => (int) $id, 'status' => 'draft', 'reused' => false, 'revision' => self::post_revision($post)];
    }

    private static function post_update($input) {
        $id = absint($input['post_id'] ?? 0); $post = get_post($id);
        if (!self::can_read_post($post) || !current_user_can('edit_post', $id)) return new WP_Error('permission_denied', 'The requested post is not editable.');
        if (!hash_equals(self::post_revision($post), (string) ($input['expected_revision'] ?? ''))) return new WP_Error('revision_conflict', 'The post changed after it was read. Fetch it again before applying this patch.', ['status' => 409, 'current_revision' => self::post_revision($post)]);
        $patch = (array) ($input['patch'] ?? []); $allowed = ['title','content','excerpt','slug','status'];
        if (!$patch || array_diff(array_keys($patch), $allowed)) return new WP_Error('invalid_patch', 'Patch only title, content, excerpt, slug or status.');
        $data = ['ID' => $id];
        foreach ($patch as $key => $value) {
            if (!is_scalar($value)) return new WP_Error('invalid_patch', 'Post fields must be scalar values.');
            if ($key === 'title') $data['post_title'] = sanitize_text_field((string) $value);
            elseif ($key === 'content') $data['post_content'] = wp_kses_post((string) $value);
            elseif ($key === 'excerpt') $data['post_excerpt'] = sanitize_textarea_field((string) $value);
            elseif ($key === 'slug') $data['post_name'] = sanitize_title((string) $value);
            elseif ($key === 'status') { if (!in_array($value, ['draft','pending','private','publish'], true)) return new WP_Error('invalid_status', 'Unsupported post status.'); if ($value === 'publish' && !current_user_can('publish_posts')) return new WP_Error('permission_denied', 'Publishing requires publish_posts.'); $data['post_status'] = $value; }
        }
        $updated = wp_update_post($data, true); if (is_wp_error($updated)) return $updated;
        $saved = get_post($id);
        return ['post_id' => $id, 'before_revision' => self::post_revision($post), 'revision' => self::post_revision($saved), 'status' => $saved->post_status, 'readback' => ['title' => get_the_title($saved), 'content_hash' => hash('sha256', (string) $saved->post_content)]];
    }

    private static function taxonomies_query($input) {
        $taxonomy = sanitize_key((string) ($input['taxonomy'] ?? ''));
        $taxonomies = $taxonomy ? [$taxonomy] : get_taxonomies(['public' => true], 'names');
        $result = [];
        foreach ($taxonomies as $tax) {
            if (!taxonomy_exists($tax)) continue;
            $object = get_taxonomy($tax); $cap = $object->cap->edit_terms ?? 'manage_categories';
            if (!current_user_can($cap) && empty($object->public)) continue;
            $terms = get_terms(['taxonomy' => $tax, 'hide_empty' => false, 'search' => sanitize_text_field((string) ($input['search'] ?? '')), 'number' => 100]);
            if (is_wp_error($terms)) continue;
            foreach ($terms as $term) $result[] = ['taxonomy' => $tax, 'term_id' => (int) $term->term_id, 'name' => $term->name, 'slug' => $term->slug, 'parent' => (int) $term->parent, 'count' => (int) $term->count];
        }
        return ['terms' => array_slice($result, 0, 200), 'count' => min(200, count($result))];
    }

    private static function safe_setting_keys() { return ['blogname','blogdescription','timezone_string','date_format','time_format','start_of_week','WPLANG','permalink_structure','users_can_register','default_role']; }
    private static function settings_revision() { $values = []; foreach (self::safe_setting_keys() as $key) $values[$key] = get_option($key); return hash('sha256', wp_json_encode($values)); }
    private static function settings_read($input) {
        $values = [];
        foreach (array_slice(array_unique(array_map('sanitize_key', (array) ($input['keys'] ?? []))), 0, 20) as $key) {
            if (!in_array($key, self::safe_setting_keys(), true)) continue;
            $value = get_option($key); if (is_scalar($value) || $value === null) $values[$key] = $value;
        }
        return ['settings' => $values, 'revision' => self::settings_revision()];
    }
    private static function settings_update($input) {
        $patch = (array) ($input['patch'] ?? []); if (!$patch || array_diff(array_keys($patch), self::safe_setting_keys())) return new WP_Error('invalid_patch', 'Only the documented non-secret site settings can be changed.');
        if (empty($input['expected_revision']) || !hash_equals(self::settings_revision(), (string) $input['expected_revision'])) return new WP_Error('revision_conflict', 'Site settings changed. Read them again before updating.', ['status' => 409]);
        $before = self::settings_read(['keys' => array_keys($patch)]);
        foreach ($patch as $key => $value) {
            if (!is_scalar($value) && $value !== null) return new WP_Error('invalid_setting_value', 'Setting values must be scalar.');
            if ($key === 'blogname') $value = sanitize_text_field((string) $value);
            elseif ($key === 'blogdescription') $value = sanitize_textarea_field((string) $value);
            elseif ($key === 'users_can_register') $value = (int) (bool) $value;
            elseif ($key === 'default_role' && !get_role((string) $value)) return new WP_Error('invalid_setting_value', 'The requested default role does not exist.');
            elseif (in_array($key, ['permalink_structure'], true) && strlen((string) $value) > 200) return new WP_Error('invalid_setting_value', 'The requested setting is too long.');
            update_option($key, $value, false);
        }
        return ['before' => $before['settings'], 'after' => self::settings_read(['keys' => array_keys($patch)])['settings'], 'revision' => self::settings_revision()];
    }

    private static function block_types($input) {
        if (!class_exists('WP_Block_Type_Registry')) return ['blocks' => [], 'available' => false];
        $all = WP_Block_Type_Registry::get_instance()->get_all_registered(); $prefix = sanitize_text_field((string) ($input['namespace'] ?? '')); $rows = [];
        foreach ($all as $name => $block) { if ($prefix !== '' && !str_starts_with($name, $prefix)) continue; $rows[] = ['name' => $name, 'title' => sanitize_text_field((string) ($block->title ?? '')), 'category' => sanitize_key((string) ($block->category ?? '')), 'attributes' => (array) ($block->get_attributes() ?? [])]; }
        return ['blocks' => array_slice($rows, (max(1, absint($input['page'] ?? 1)) - 1) * 100, 100), 'registered_count' => count($rows), 'page' => max(1, absint($input['page'] ?? 1))];
    }
    private static function block_content($id) {
        $post = get_post($id); if (!self::can_read_post($post)) return new WP_Error('post_not_found', 'The post is missing or unavailable to this user.');
        $content = (string) $post->post_content; $blocks = function_exists('parse_blocks') ? parse_blocks(substr($content, 0, 50000)) : [];
        return ['post_id' => $id, 'content_hash' => hash('sha256', $content), 'revision' => self::post_revision($post), 'blocks' => array_slice($blocks, 0, 100), 'serialized_content' => substr($content, 0, 50000)];
    }
    private static function block_change($input, $preflight) {
        $id = absint($input['post_id'] ?? 0); $post = get_post($id); if (!self::can_read_post($post)) return new WP_Error('post_not_found', 'The post is missing or unavailable to this user.');
        $current_hash = hash('sha256', (string) $post->post_content);
        if (!hash_equals($current_hash, (string) ($input['expected_content_hash'] ?? ''))) return new WP_Error('content_conflict', 'The editor content changed. Read it again before applying.', ['status' => 409, 'current_content_hash' => $current_hash]);
        $spec = (array) ($input['block_spec'] ?? []);
        if (($spec['operation'] ?? '') !== 'replace_content' || !isset($spec['content']) || !is_string($spec['content']) || strlen($spec['content']) > 50000) return ['valid' => false, 'requires_browser_serialization' => true, 'errors' => ['Supported operation: replace_content with serialized Gutenberg content, max 50 KB.']];
        if (!function_exists('parse_blocks') || !function_exists('serialize_blocks')) return ['valid' => false, 'requires_browser_serialization' => true, 'errors' => ['This WordPress version has no block serialization API.']];
        $candidate = wp_kses_post($spec['content']);
        $parsed = parse_blocks($candidate); $roundtrip = serialize_blocks($parsed);
        $valid = $candidate === $spec['content'] && $roundtrip === $candidate;
        $result = ['valid' => $valid, 'requires_browser_serialization' => !$valid, 'block_count' => count($parsed), 'candidate_hash' => hash('sha256', $candidate), 'errors' => $valid ? [] : ['Content failed KSES or Gutenberg parse/serialize round-trip.']];
        if ($preflight || !$valid) return $result;
        if (!current_user_can('edit_post', $id)) return new WP_Error('permission_denied', 'The connected user cannot edit this post.');
        $updated = wp_update_post(['ID' => $id, 'post_content' => $candidate], true); if (is_wp_error($updated)) return $updated;
        $saved = get_post($id); if (!$saved || !hash_equals(hash('sha256', $candidate), hash('sha256', (string) $saved->post_content))) return new WP_Error('readback_failed', 'Saved editor content did not match its verified serialization.');
        return $result + ['saved' => true, 'post_id' => $id, 'revision' => self::post_revision($saved), 'readback_hash' => hash('sha256', (string) $saved->post_content)];
    }

    private static function users_read($input) {
        if (!current_user_can('list_users')) return new WP_Error('permission_denied', 'User listing requires list_users.');
        if (!empty($input['user_id'])) { $users = [get_userdata(absint($input['user_id']))]; } else { $users = get_users(['number' => 50, 'offset' => (max(1, absint($input['page'] ?? 1)) - 1) * 50, 'fields' => ['ID','display_name','user_registered']]); }
        $rows = []; foreach ($users as $user) if ($user) $rows[] = ['user_id' => (int) $user->ID, 'display_name' => sanitize_text_field($user->display_name), 'roles' => array_values(array_map('sanitize_key', (array) $user->roles)), 'registered' => $user->user_registered];
        return ['users' => $rows, 'page' => max(1, absint($input['page'] ?? 1))];
    }
    private static function plugins_read($input) {
        if (!current_user_can('manage_options')) return new WP_Error('permission_denied', 'Plugin inventory requires manage_options.');
        if (!function_exists('get_plugins')) require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $active = (array) get_option('active_plugins', []); $search = strtolower(sanitize_text_field((string) ($input['search'] ?? ''))); $rows = [];
        foreach ((array) get_plugins() as $file => $plugin) { $name = sanitize_text_field((string) ($plugin['Name'] ?? $file)); if ($search !== '' && !str_contains(strtolower($name . ' ' . $file), $search)) continue; $rows[] = ['name' => $name, 'slug' => sanitize_text_field($file), 'version' => sanitize_text_field((string) ($plugin['Version'] ?? '')), 'active' => in_array($file, $active, true)]; }
        return ['plugins' => array_slice($rows, 0, 100), 'count' => count($rows)];
    }
    private static function themes_read() {
        if (!current_user_can('manage_options')) return new WP_Error('permission_denied', 'Theme inventory requires manage_options.');
        $active = get_stylesheet(); $themes = [];
        foreach (wp_get_themes() as $slug => $theme) $themes[] = ['slug' => sanitize_key($slug), 'name' => sanitize_text_field($theme->get('Name')), 'version' => sanitize_text_field($theme->get('Version')), 'active' => $slug === $active, 'parent' => sanitize_key((string) $theme->get_template())];
        return ['active_stylesheet' => sanitize_key($active), 'themes' => array_slice($themes, 0, 100)];
    }
    private static function comments_query($input) {
        if (!current_user_can('moderate_comments')) return new WP_Error('permission_denied', 'Comment review requires moderate_comments.');
        $page = max(1, absint($input['page'] ?? 1)); $comments = get_comments(['status' => sanitize_key((string) ($input['status'] ?? 'hold')), 'post_id' => absint($input['post_id'] ?? 0), 'number' => 50, 'offset' => ($page - 1) * 50, 'orderby' => 'comment_date_gmt', 'order' => 'DESC']); $rows = [];
        foreach ($comments as $comment) $rows[] = ['comment_id' => (int) $comment->comment_ID, 'post_id' => (int) $comment->comment_post_ID, 'author' => sanitize_text_field($comment->comment_author), 'date_gmt' => $comment->comment_date_gmt, 'status' => wp_get_comment_status($comment), 'content' => substr(wp_strip_all_tags($comment->comment_content), 0, 500)];
        return ['comments' => $rows, 'page' => $page];
    }
    private static function menus_read($input) {
        if (!current_user_can('edit_theme_options')) return new WP_Error('permission_denied', 'Menu structure requires edit_theme_options.');
        $locations = get_nav_menu_locations(); $result = [];
        foreach ($locations as $location => $menu_id) { if (!empty($input['location']) && $input['location'] !== $location) continue; $items = wp_get_nav_menu_items($menu_id); $result[] = ['location' => sanitize_key($location), 'menu_id' => (int) $menu_id, 'items' => array_map(static fn($item) => ['id' => (int) $item->ID, 'title' => sanitize_text_field($item->title), 'url' => esc_url_raw($item->url), 'parent' => (int) $item->menu_item_parent, 'object' => sanitize_key($item->object), 'object_id' => (int) $item->object_id], array_slice((array) $items, 0, 100))]; }
        return ['locations' => $result];
    }

    private static function managed_document($name, $input) {
        $design = str_starts_with($name, 'dreminex-design/'); $read = ($name === 'dreminex-workflow/skills-read' || $name === 'dreminex-design/design-read');
        if ($name === 'dreminex-design/design-check') return self::design_check($input);
        $slug = sanitize_title((string) ($input['slug'] ?? '')); if ($slug === '' || strlen($slug) > 120) return new WP_Error('invalid_slug', 'Use a valid document slug.');
        $option = ($design ? 'dreminex_mcp_design_' : 'dreminex_mcp_skill_') . $slug; $current = get_option($option, []); if (!is_array($current)) $current = [];
        if ($read) return empty($current['body']) && empty($current['tokens']) ? new WP_Error('document_not_found', 'No saved document exists for this slug.') : ['slug' => $slug, 'revision' => $current['revision'] ?? '', 'body' => $current['body'] ?? '', 'tokens' => $current['tokens'] ?? [], 'history' => array_slice((array) ($current['history'] ?? []), -10)];
        if (!current_user_can('manage_options')) return new WP_Error('permission_denied', 'Saving skills or design tokens requires manage_options.');
        $revision = (string) ($current['revision'] ?? ''); $expected = (string) ($input['expected_revision'] ?? '');
        if ($revision !== '' && !hash_equals($revision, $expected)) return new WP_Error('revision_conflict', 'This document changed. Read it again before updating.', ['status' => 409]);
        if ($design) {
            $tokens = (array) ($input['tokens'] ?? []); $json = wp_json_encode($tokens); if (strlen((string) $json) > 20000 || preg_match('/<\/?(?:script|style|iframe)\b/i', (string) $json)) return new WP_Error('invalid_design_tokens', 'Design tokens must be compact data and cannot contain executable markup.');
            $body = ''; $saved_tokens = self::sanitize_tokens($tokens);
        } else {
            $body = sanitize_textarea_field((string) ($input['body'] ?? '')); if (strlen($body) > 50000) return new WP_Error('document_too_large', 'Skill body exceeds 50 KB.'); $saved_tokens = [];
        }
        $new_revision = hash('sha256', $design ? wp_json_encode($saved_tokens) : $body); $history = (array) ($current['history'] ?? []);
        if ($revision !== '') $history[] = ['revision' => $revision, 'body' => $current['body'] ?? '', 'tokens' => $current['tokens'] ?? [], 'saved_at' => $current['saved_at'] ?? ''];
        $record = ['revision' => $new_revision, 'body' => $body, 'tokens' => $saved_tokens, 'history' => array_slice($history, -10), 'saved_at' => gmdate('c'), 'saved_by' => get_current_user_id()];
        update_option($option, $record, false);
        return ['saved' => true, 'slug' => $slug, 'revision' => $new_revision, 'previous_revision' => $revision];
    }
    private static function sanitize_tokens($tokens, $depth = 0) {
        if ($depth > 5 || count($tokens) > 100) return [];
        $out = [];
        foreach ($tokens as $key => $value) {
            $key = sanitize_key((string) $key); if ($key === '') continue;
            if (is_array($value)) $out[$key] = self::sanitize_tokens($value, $depth + 1);
            elseif (is_string($value)) { $value = trim($value); if (strlen($value) <= 300 && !preg_match('/url\s*\(|expression\s*\(|javascript:/i', $value)) $out[$key] = sanitize_text_field($value); }
            elseif (is_numeric($value) || is_bool($value) || $value === null) $out[$key] = $value;
        }
        return $out;
    }
    private static function design_check($input) {
        $markup = (string) ($input['candidate_markup'] ?? ''); $issues = [];
        if (preg_match('/<\s*(script|iframe|object|embed)\b/i', $markup)) $issues[] = 'Executable or embedded elements are not allowed.';
        if (preg_match('/\son[a-z]+\s*=/i', $markup)) $issues[] = 'Inline event-handler attributes are not allowed.';
        if (preg_match('/javascript\s*:/i', $markup)) $issues[] = 'JavaScript URLs are not allowed.';
        if (preg_match('/url\s*\(\s*["\']?\s*(?:https?:|\/\/)/i', $markup)) $issues[] = 'Remote CSS URLs require manual review.';
        $design = get_option('dreminex_mcp_design_' . sanitize_title((string) ($input['design_slug'] ?? '')), []);
        return ['valid' => !$issues, 'violations' => $issues, 'design_revision' => is_array($design) ? ($design['revision'] ?? '') : '', 'markup_hash' => hash('sha256', $markup), 'executed' => false];
    }
}
