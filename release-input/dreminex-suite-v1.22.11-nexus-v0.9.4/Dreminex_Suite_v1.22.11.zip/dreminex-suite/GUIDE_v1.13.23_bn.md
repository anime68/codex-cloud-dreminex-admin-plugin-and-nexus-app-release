# Dreminex Suite 1.13.23 — Storefront customer pages

এই release-এ 1.13.20-এর Shop, category, product, Cart, Checkout, tracking, Wishlist, Compare ও Contact কাজ রয়েছে। Cart ও Checkout-এর primary button, Checkout-এর coupon/login notice, এবং order notes-এর duplicate optional label সংশোধিত। WooCommerce/ShopBuilder-এর মূল form, totals, action ও product data অপরিবর্তিত।

আগের `dreminex-suite` plugin-এর ওপর ZIP update দিন; plugin uninstall/delete করবেন না। Main site-এর পূর্ণ backup রাখুন। Storefront Design-এর Customer pages controls থেকে আলাদা অংশ চালু বা বন্ধ করা যায়। Site-এর image/page settings আলাদা, তাই update-এর পর Shop, product, Cart, Checkout, Wishlist, Compare, Contact, tracking ও My Account ফোন/desktop-এ smoke test করুন। Payment বা live order submit করবেন না, যদি না আলাদা test method থাকে।

Rollback: আগের plugin ZIP ও database backup সংরক্ষণ করুন। অসংগতি হলে plugin updater দিয়ে আগের ZIP পুনরায় বসান; customer data বা Suite settings delete করবেন না। Main site-এর PHP ও saved content staging থেকে আলাদা হওয়ায় production promotion আলাদা অনুমোদন ও verification ধাপ।
