# Dreminex Native MCP OAuth — A to Z Handoff, Review ও Update Workflow

সংস্করণ: Suite 1.14.1 · OAuth schema 1 compatible  
মূল source: `includes/class-dreminex-native-oauth.php`, `includes/class-dreminex-native-mcp.php`

এই file-এর উদ্দেশ্য হলো পরে OAuth বা ChatGPT connection update করলে যেনো আগের problem আবার ফিরে না আসে। কাজ শেষে এই reference, মূল Native MCP reference, Changelog, staging evidence এবং package SHA-256 update করতে হবে।

## Problem কেন হয়েছিল

ChatGPT DCR registration request-এ অনেক সময় `scope` field দেয় না। আগের code empty scope দেখলে চারটি read fallback scope-কে client-এর স্থায়ী `allowed_scopes` হিসেবে save করত। পরে ChatGPT selected tools-এর জন্য `site:write` চাইলে authorize endpoint client allow-list-এর বাইরে বলে `Unsupported OAuth scope: site:write` দিত।

## এখনকার সঠিক নিয়ম

- DCR client-এর persisted `allowed_scopes` সব supported Dreminex scope। DCR request-এ scope না থাকলে response/authorization-এর initial fallback শুধু চারটি read scope; এর জন্য নতুন database column লাগে না।
- নতুন external client সবসময় `sandbox` mode-এ শুরু হয়। Scope থাকলেই write হয়ে যায় না; ability switch, WordPress capability, permission mode এবং approval policy আবার check হয়।
- পুরোনো active DCR client read করার সময় in-memory compatible allow-list পায়। Client ID, redirect URI বা database row rewrite হয় না; authorization request-এর exact scope-ই code/token-এ থাকে।
- Authorization ও token request-এর `resource` দিলে সেটি exact `/wp-json/mcp/dreminex` হতে হবে। Server একটিমাত্র protected resource issue করে এবং introspection-এ সেই exact audience দেয়।
- Raw code/token database-এ থাকে না; শুধু SHA-256 hash থাকে। PKCE `S256` বাধ্যতামূলক।
- Dreminex OIDC advertise করে না। ChatGPT connection setup: **DCR On, OIDC Off**। Root OIDC endpoint অন্য plugin-এর হলে সেটিকে Dreminex field-এ বসানো যাবে না।
- Authorization callback `iss` দেয় এবং metadata `authorization_response_iss_parameter_supported=true` বলে।
- প্রতিটি MCP tool top-level `securitySchemes` এবং compatibility `_meta.securitySchemes` দেয়। Dynamic validate/execute tool সব supported scopes declare করে; selected ability-এর exact scope server আবার enforce করে।

## Schema 1 compatible storage

| Table | নতুন/গুরুত্বপূর্ণ data |
|---|---|
| OAuth clients | full supported `allowed_scopes`, sandbox mode, redirect, revoke state |
| OAuth codes | client, user, redirect, PKCE challenge, exact approved scopes, expiry |
| Access tokens | client, user, exact approved scopes, expiry, revoke state |
| Refresh tokens | client, user, exact approved scopes, expiry, rotate/revoke state |
| Device codes | Nexus scopes এবং owner approval state |

এই fix-এর জন্য OAuth table migration নেই। 1.14.0 schema-1 tables একই থাকে। Plugin update/uninstall দিয়ে tables reset করা যাবে না। ভবিষ্যতে per-token multiple-resource support লাগলে তখন আলাদা additive schema migration ও rollback test করতে হবে।

## ChatGPT connection values

```text
MCP server URL:
https://YOUR-SITE/wp-json/mcp/dreminex

Authorization:
OAuth · Dynamic Client Registration (DCR)

OIDC:
Off
```

Manual OAuth endpoint লিখে override করার দরকার নেই; ChatGPT protected-resource এবং authorization-server metadata থেকে নেবে। Consent screen-এ selected scopes দেখা যাবে। Connection row dashboard-এ Sandbox দেখাবে।

## Update করার সময় যা একসঙ্গে বদলাতে হবে

1. নতুন scope যোগ করলে `scopes()`, tool `securitySchemes`, scope mapper, consent text এবং এই reference update করুন।
2. নতুন OAuth column হলে schema number বাড়ান; fresh install এবং old-schema migration দুই test দিন।
3. Resource URL বদলালে protected metadata, issuer/token binding, introspection এবং existing token migration/expiry policy একসঙ্গে ঠিক করুন।
4. OIDC দরকার হলে আলাদা পূর্ণ provider হিসেবে issuer, `openid` scopes, ID token signing, JWKS ও userinfo implement না করে OIDC advertise করবেন না।
5. OAuth error বদলালে Android device flow-এর `code/message` compatibility এবং standard `error/error_description` দুই client test করুন।

## বাধ্যতামূলক test gate

- DCR request with no `scope`: response success, saved allowed scopes complete, response scope read fallback।
- Authorization with `site:write`: consent success; unsupported error নেই।
- Unsupported made-up scope: clear rejection।
- PKCE wrong verifier, expired/reused code, wrong redirect এবং wrong client rejection।
- Authorization/token/refresh-এ supplied resource mismatch rejection; introspection exact `aud`।
- Refresh token single rotation; old refresh replay rejection।
- MCP unauthenticated challenge-এ scoped resource metadata এবং `mcp/www_authenticate` থাকে।
- ChatGPT `tools/list`-এ চার tool-এর security schemes ঠিক থাকে।
- Connected client Sandbox write preview দেয়, save করে না; read চলে।
- Staging ChatGPT custom MCP connection DCR On/OIDC Off দিয়ে বাস্তবে connect ও tool discovery।

Test evidence না মিললে production-ready বলা যাবে না।
