# Dreminex Suite 1.13.40 RC + Dreminex PWA 1.3.7 RC

## দুটি স্বাধীন কাজ

- **Supplier Monitor:** যাচাই করা wholesaler cost, supplier payment fee, ad, return reserve এবং offer reserve ধরে প্রতি item-এ প্রস্তাব দেয়। Dropshipping platform delivery ও COD সামলায়। Observation কোনো price, stock বা content নিজে লেখে না। দাম পরিবর্তনের আগে item cap, source snapshot ও admin approval লাগে।
- **Newsletter & Offers:** ভবিষ্যতের নতুন confirmed customer-এর welcome coupon সর্বোচ্চ ৳৩০, একবার, minimum নেই, sale/Flash Sale product বাদ। Issuance default Off। আলাদা promotional offer-এর ৳৫০/৳৩৯৯+ বা অন্য terms নিজস্ব campaign record; welcome coupon setting তা পরিবর্তন করে না।

## দোকানের দেওয়া সংখ্যাগুলো

আপনি নিজে courier merchant account ব্যবহার করেন না; dropshipping platform অর্ডার fulfil করে এবং COD সামলায়। আপনার দেওয়া customer delivery advance: ঢাকা ৳৮০, আশপাশ ৳১০০, বাইরে ৳১৩০। এটি product revenue বা merchant courier cost নয়; শুধু delivery-সহ customer cap যাচাইয়ে যোগ হয়। আপনার cost model: ৳১৫ packaging/other, ৳৩০ return reserve, সাধারণ ad ৳২৫ (নির্বাচিত item ৳৩০–৳৯০), এবং wholesale-এর ওপর ১.৫% supplier payment fee। Minimum net profit ৳৭০, regular profit ৳২০০-এর নিচে। 

Price proposal-এর জন্য এই field-গুলো পূর্ণ ও যাচাই হওয়া চাই। সর্বোচ্চ delivery advance customer total cap-এ যোগ হয়; delivery advance থেকে product profit বা courier recovery ধরা হয় না। Coupon/offer-এর সবচেয়ে ক্ষতিকর eligible case ধরার পরে psychological price ৯-এ শেষ হয়। Delivery-সহ customer cap quality, uniqueness ও market evidence দিয়ে প্রতিটি item/variation-এ আলাদা দিন। Cap বা margin একসঙ্গে পূরণ না হলে কোনো proposal নেই। Existing sale-price item এবং Flash Sale item automatic regular-price proposal পায় না।

### SKU 33060 sample

Main site product #2745-এর চারটি size variation (M–XXL) SKU suffix 33060; regular ৳৬৪৯ এবং sale ৳৫৯৯। Supplier screenshot-এ আনুমানিক wholesale ৳৪৩০ ও suggested maximum sale ৳৮৫০ দেখা যাচ্ছে; login-এর পরে exact cost/variant URL যাচাই ছাড়া এটিকে stored cost ধরবেন না। Main site-এ আলাদা active campaign #12: ৳৫০ off ৳৩৯৯+; existing sale price ও এই offer-এর সম্মিলিত margin source wholesale নিশ্চিত না হওয়া পর্যন্ত নিরাপদ ঘোষণা করা যায় না। Current item-এ Suite কোনো নতুন দাম লেখেনি।

শুধু ধারণা বোঝাতে: unverified wholesale ৳৪৩০, ৳১৫ other, ৳৩০ return reserve, সাধারণ ad ৳২৫, ১.৫% supplier payment fee (৳৬.৪৫), coupon exposure ৳৫০ এবং target profit ৳৭০ ধরলে psychological product price হবে ৳৬২৯। ৳৫০ offer-এর পরে product profit প্রায় ৳৭২.৫৫; বাইরে delivery advance ৳১৩০ যোগে customer total ৳৭৫৯। ৳৮৫০ delivered cap কেবল এই উদাহরণে ব্যবহার করা হয়েছে। Supplier cost ও market comparison নিশ্চিত না হওয়া পর্যন্ত এটিকে live price হিসেবে ব্যবহার করবেন না।

## Offers placement ও notification image

Sbmart footer.php, `get_footer` hook, existing home page এবং footer widgets যাচাই করে automatic Current offers-কে মূল content-এর শেষে, footer logo-এর আগে রাখা হয়েছে। Signup-এর জন্য আগের footer fallback আছে। Login-specific offer code/page cache এড়াতে private no-store AJAX response দিয়ে offer/sign-up আলাদাভাবে বসে। Explicit shortcode আগে থাকলে automatic duplicate হয় না। Frontend-এ active offer না থাকলে ফাঁকা automatic section সরিয়ে দেওয়া হয়।

Dashboard → Dreminex Suite → Welcome & Offer → Offers → **Notification thumbnail**-এ Media Library-এর landscape image বাছুন; Remove-ও আছে। Suite-এর `notification_image_id` offer record-এ থাকে। Dreminex PWA 1.3.7 ভবিষ্যতের newly active offer push-এ সেই ছবি `image` হিসেবে দেয়। ছবি না থাকলে selected product image, তাও না থাকলে site icon। Android/browser-এর ছোট app `icon` branding হিসেবে থাকতে পারে; বড় notification picture device presentation-এর ওপর নির্ভর করে। ইতিমধ্যে পাঠানো active offer #12-এর notification image edit করলে পুরোনো notification বদলায় বা আবার পাঠায় না।

## Staging ও release gate

1. Full staging site/files/database backup এবং restore rehearsal; বর্তমানে installed Suite 1.13.39 ও PWA 1.3.7 rollback copies রাখুন। Suite 1.13.40 update করুন; staging-এ PWA 1.3.7 ইতিমধ্যে আছে, uninstall করবেন না। Supplier Monitor default Off রাখুন।
2. Offer schema 2 field, পুরোনো record readback, dashboard media picker save/remove, image fallback, new draft→active campaign-এর push payload, existing campaign no-resend এবং subscriber opt-in test করুন। Test notification নিজের disposable browser subscription দিয়ে দেখুন; customerদের কাছে পরীক্ষামূলক push পাঠাবেন না।
3. Mobile, tablet, desktop home এবং newsletter page-এ guest, confirmed, unconfirmed account দিয়ে offers-এর অবস্থান, duplicate, claim, anchor ও no-offer empty state দেখুন। WordPress cache purge করে public ও private state মিলিয়ে নিন।
4. ৳৮০/১০০/১৩০ checkout, advance/COD balance, coupon stacking, new customer welcome ৳৩০, existing ৳৫০/৳৩৯৯+ offer, sale/Flash Sale exclusion, tax/fee/market cap এবং ৩ ধরনের product price quote test করুন।
5. Dropshipping platform-এর authenticated product URL, exact wholesale price ও colour/size mapping দিয়ে worker scan/alert/approval rehearsal করুন। Supplier login বা OTP handoff-এ রাখবেন না। Worker host/session না থাকলে live monitoring coverage দাবি করবেন না।
6. Staging installed-package readback ও rollback evidence ছাড়া production release নয়। Main ও staging সাইটের বর্তমান plugin, campaign, products বা prices এই ZIP তৈরিতে পরিবর্তন হয়নি।
