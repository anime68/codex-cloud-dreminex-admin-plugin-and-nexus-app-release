# Dreminex Supplier Monitor — pricing ও staging guide (1.13.37 RC)

## Pricing policy

প্রতি পণ্যের wholesale cost-এর সঙ্গে ৳১৫ packaging/other, ৳৩০ return-risk reserve এবং সাধারণ ৳২৫ ad budget যোগ করুন। নির্বাচিত simple product বা variation-এ বেশি ad budget দিন। Target net profit কমপক্ষে ৳৭০, নিয়মিত বিক্রির profit ৳২০০-এর নিচে। বর্তমান বা সম্ভাব্য coupon-এর জন্য default ৳১০০ reserve রাখা হয়েছে। প্রকৃত offer policy বদলালে reserve আবার যাচাই করুন।

Customer-এর advance delivery charge হল checkout-এর shipping total; merchant courier charge একই হবে এমন অনুমান নেই। Suite WooCommerce-এর চালু flat shipping method থেকে সবচেয়ে কম এবং বেশি customer charge নেয়। Admin-কে merchant-এর সর্বোচ্চ courier cost এবং সবচেয়ে বেশি payment fee দিতে হবে। Pricing worst case-এ সবচেয়ে কম delivery collection থেকে courier shortfall এবং সবচেয়ে বেশি delivery collection-এ payment fee ধরে। Item-এর গ্রহণযোগ্য সর্বোচ্চ **পণ্য + delivery** মোট দাম market/quality evidence দেখে লিখতে হবে। এই cap ছাড়া proposal হবে না।

উপযুক্ত দামগুলোর মধ্যে সর্বনিম্ন পূর্ণ টাকায় শেষ অঙ্ক `9` নেওয়া হয়। ৳১০০ fixed coupon ও পরে percentage coupon উভয় থাকলে worst-case stacking ধরে। Coupon minimum order value উপেক্ষা করা হয়, কারণ multi-item cart-এ coupon লাগতে পারে। Coupon-এর পরে target profit, coupon ছাড়া regular profit <৳২০০ এবং delivery-সহ customer cap—সব শর্ত একসঙ্গে না মিললে কোনো proposal নেই। Price suggestion কেবল manual approval-এর জন্য।

## Admin workflow

1. Backup এবং staging baseline প্রস্তুত করে Suite ZIP staging-এ install করুন। Supplier Monitor default Off; আগে পুরোনো modules/checkout smoke test করুন।
2. আলাদা authenticated worker host, supplier-authorized logged-in sample এবং exact URL/SKU mapping যাচাই করে monitor চালু করুন। Worker credential plugin ZIP-এ দেবেন না।
3. `Supplier Monitor → Profit and delivered-price protection`-এ courier max cost, payment fee, coupon reserve ও অন্যান্য cost পূরণ করুন। শূন্য cost কেবল বাস্তবে শূন্য হলে লিখুন। একেক item-এর target, প্রয়োজন হলে বেশি ad budget, market-based delivery-inclusive cap সেভ করুন।
4. সফল fresh supplier scan থেকে proposal এলে wholesale, regular profit, coupon-পরবর্তী profit, delivery-inclusive customer total ও cap দেখুন। Product page, quality এবং competitor দামের সঙ্গে তুলনা করুন। তারপর নির্দিষ্ট event approve করুন; WooCommerce readback/audit যাচাই করুন।
5. কোনো Woo sale price, tax rate, non-flat shipping, free-shipping/unsupported coupon বা ঐ item-এ configured Flash Sale থাকলে regular-price proposal বন্ধ। Flash Sale discount/bundle ও coupon stacking publish করার **আগে** আলাদা offer-margin calculation করুন। Coupon বা courier policy পরে বদলালে বিদ্যমান catalog price-ও আবার audit করুন।

## বর্তমান site snapshot (read-only, 2026-10-16)

Main ও staging: BDT; flat shipping Inside Dhaka ৳৮০, suburban/Gazipur/Narayanganj ৳১০০, Outside Dhaka ৳১৩০; Woo tax calculation on কিন্তু tax rates শূন্য; Flash Sale module Off ও offer count শূন্য; প্রকাশিত Woo coupon শূন্য। Newsletter/Offers module On হলেও দুটো feature switch বর্তমানে Off। Default newsletter code চালু হলে ৳১০০ off, minimum order ৳৯৯৯; মূল্য প্রস্তাবে conservative ৳১০০ reserve রাখা হয়েছে।

## উদাহরণ, প্রকৃত পণ্যের দাম নয়

Wholesale ৳২০০, courier সর্বোচ্চ ৳৮০, payment fee শূন্য, অন্যান্য ৳১৫, return ৳৩০, ad ৳২৫, fixed coupon reserve ৳১০০, target profit ৳৭০, item cap ৳৬০০ হলে প্রস্তাব ৳৪৪৯। Regular profit ৳১৭৯, coupon-পরবর্তী profit ৳৭৯; বাইরে delivery ৳১৩০ সহ মোট ৳৫৭৯। Courier বেশি, fee বা customer cap কম হলে ফল বদলাবে বা proposal বন্ধ হবে।

## Release gate

এই RC staging-এ install করা হয়নি। Staging full backup/restore rehearsal, PHP activation, admin/WooCommerce CRUD, supplier authenticated end-to-end scan, variation mapping, stale/duplicate approval, stock checks, coupon/Flash Sale checkout এবং rollback পরীক্ষার পরেই production promotion বিবেচনা করুন। Production deployment ও module activation আলাদা অনুমোদনসাপেক্ষ।
