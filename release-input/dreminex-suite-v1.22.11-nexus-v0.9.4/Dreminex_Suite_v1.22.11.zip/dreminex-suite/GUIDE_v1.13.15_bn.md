# Dreminex Suite 1.13.15 — রেজিস্ট্রেশন ও Suite UI

## আপডেট

বর্তমান `dreminex-suite` প্লাগইনটি মুছে না দিয়ে WordPress-এর **Plugins → Add New → Upload Plugin** থেকে ZIP upload করে **Replace current with uploaded** নির্বাচন করুন। আগে পুরো সাইটের backup রাখুন। 1.13.14-এর সব module, settings, homepage controls ও data একই থাকবে। কোনো database migration নেই।

## রেজিস্ট্রেশন সাজানো

**Dreminex Suite → Modules → Accounts → Registration email confirmation → Open controls → Registration experience** এ যান।

- Account flow: রেজিস্ট্রেশন, email link, নিজের password ও confirmation field।
- Customer details: নাম ও মোবাইল দেখানো এবং required করা। Email সব সময় WooCommerce-এ required।
- Experience: Dreminex account design এবং password Show/Hide।
- Page content & appearance: heading, বর্ণনা, ঐচ্ছিক ছবি, ছবির focus, button-এর background ও text colour। রঙের contrast কম হলে save আটকাবে।
- Confirmation email: subject, intro text ও link label। নিচের **Module settings**-এ popup messages বদলানো যাবে।

**Save registration experience** চাপুন। একই সাইটের Media Library থেকে ছবি বেছে নিন; staging-এর attachment ID production-এ ধরে নেবেন না। ছবি না দিলেও colour panel সম্পূর্ণ দেখাবে।

## যাচাই

Staging-এ লগ আউট করা browser বা private window-তে **My Account** খুলে phone, tablet, desktop layout, optional/required fields, password Show/Hide, অসম password-এর error, privacy link এবং lost-password পথ দেখুন। Disposable account দিয়ে confirmation email, 48-hour expiry ও পুনরায় ব্যবহৃত link যাচাই করুন। Email delivery SMTP-এর ওপর নির্ভর করে।

Suite module Off থাকলে এই account controls আর frontend design চলবে না; পুরোনো order/customer data মুছে যাবে না। Production-এ আপডেটের আগে staging result এবং site backup পর্যালোচনা করুন।
