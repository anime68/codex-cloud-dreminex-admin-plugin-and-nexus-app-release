# Dreminex Suite v1.12.0 — Flash Sale ব্যবহার
Dreminex Suite → Flash Sale module configuration থেকে সব sale rule ও layout নিয়ন্ত্রণ করুন।

## Layout ও ছবি
Desktop columns ডিফল্ট 4 (1–6 নির্বাচন), Mobile columns ডিফল্ট 1 (1–2 নির্বাচন)। Tablet-এ 3।
Quick View-তে product gallery ও variation-এর সব উপলব্ধ ছবি থাকে। Color/size নির্বাচন করলে সংশ্লিষ্ট ছবি, দাম ও Flash Sale discount badge বদলায়। Thumbnail অন্য ছবি দেখায়; কেনার variation পরিবর্তন করতে selector ব্যবহার করুন।

## Offer তৈরি
আগে থেকে থাকা product বা variation search করে যোগ করুন। Fixed offer price, percentage বা amount discount-এর সঙ্গে Minimum target quantity দিন। যেমন 3টি কিনলে 20% ছাড়: Percentage 20, minimum 3। শর্ত পূরণ না হলে cart-এ catalog price থাকে এবং checkout বন্ধ থাকে।

Buy X get Y নির্বাচন করুন। Value হলো reward discount percent: 100 হলে free, 50 হলে অর্ধেক দাম।
একই product: Required product ID 0, Buy 1, Reward 1, Value 100। Customer মোট 2টি cart-এ যোগ করবে; 1টি free। 3টি হলে 2টির দাম, 4টি হলে 2টির দাম। Maximum quantity যেন paid + reward quantity ধারণ করে।
ভিন্ন product: reward product-এ bundle rule দিন, Required product/variation ID-তে qualifying product দিন। Customer নিজের পছন্দের variation বেছে উভয় product আলাদা করে cart-এ যোগ করবে। Gift স্বয়ংক্রিয়ভাবে যোগ হয় না।
একটি qualifying unit একাধিক ভিন্ন reward rule-এ পুনরায় ব্যবহার হয় না। Bundle reward অন্য bundle-এর qualifier হয় না। Reward budget-এর অতিরিক্ত unit catalog price-এ থাকে। একই rule-এর variation-এ সস্তা eligible unit আগে reward পায়।

Title-এর নিচে সংক্ষিপ্ত শর্ত ও বাম দিকে Flash Sale-এর numeric discount badge দেখায়। Cart/order-এ applied reward quantity রাখা হয়। সাধারণ shop থেকে যোগ করা product-এর দাম অপরিবর্তিত।

## Mobile button ও সময়
Homepage-এর banner-এর নিচে, service icons-এর উপরে native Elementor shortcode [dreminex_flash_button] বসানো হয়েছে। Desktop header placement আগের।
Scheduled: button center, শুরু হওয়ার countdown নিচে।
Active: button বামে, শেষ হওয়ার countdown ডানে।
Ended/disabled: button center; click-এ unavailable popup।
Brand cyan background, dark text, secondary tint hover, press effect, fade-in; reduced-motion preference মানা হয়।
Timezone Asia/Dhaka campaign setting ব্যবহার করুন; WordPress global timezone বদলানো হয়নি।

## Update
ZIP-টি WordPress plugin update হিসেবে install করুন। Live homepage shortcode placement আলাদা Elementor content change; অন্য সাইটে shortcode widget banner-এর পর/service-এর আগে যোগ করুন। পুরো homepage overwrite করবেন না।
বর্তমান live campaign, catalog prices ও module on/off states পরিবর্তন বা reset করা হয়নি।

