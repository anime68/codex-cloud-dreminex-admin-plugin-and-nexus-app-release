# Dreminex Suite 1.13.26 — Screenshot → Media Library original

## তিন ধাপ

1. মূল product photos নির্দিষ্ট WordPress site-এর Media Library-তে আগে আপলোড করুন। Preparation Project-এ supplier/demo facts এবং SKU-সহ screenshot দিন। Preparation একই site-এর originals read-only খুঁজে **ছবি দেখে** মিলাবে, প্রতিটির ID/URL এবং supplier code-সহ সম্পূর্ণ text handoff বানাবে; কোনো product/media write নয়।
2. ওই handoff-এর **শুধু text** Publisher Project-এ দিন। Publisher আর ছবি খুঁজবে বা content বানাবে না। `listing-apply`-তে প্রতি image-এর প্রস্তুত `image_id` একমাত্র source হিসেবে পাঠাবে (handoff URL কেবল reference), ordered colour/supplier_sku ও confirmed offered rows বসাবে। `update_media_metadata=true` দিলে prepared attachment title, permalink slug ও alt প্রয়োগ করবে; slug বদলালে physical filename/URL বদলায় না।
3. WordPress-এর technical validation ও saved product readback দিয়ে actual status/ID/media/variation SKU জানাবে। Partial হলে একই product ID-তে resume। Publish বা Delete শুধু user-এর নির্দিষ্ট নির্দেশে।

## Read-only Media search

`dreminex-products/media-candidates` recent/paginated same-site attachments দেয়। `dreminex-products/media-visual-match` supplier screenshot-এর শুধুমাত্র product-photo crop (base64 JPEG/PNG/WebP ≤2 MB) অথবা grayscale 9×8 crop-এর 64-bit horizontal dHash নিয়ে প্রতি page-এ সর্বোচ্চ 120টি attachment compare করে, শীর্ষ candidate ফেরায়। কোনো crop/server-এ জমা থাকে না। Hash ranking **ছবির পরিচয়ের প্রমাণ নয়**; Preparation original thumbnail/full photo খুলে pose, background, print/work, colour ও view মেলাবে। অনেক media থাকলে page ধরে দেখবে। ভুল বা ambiguous original হলে সেই entry UNRESOLVED রাখবে।

## Release boundary

Staging-এ upgrade করার আগে বিদ্যমান 1.13.25 ZIP backup রাখুন। এই release existing product, uploaded media, module state বা Novamira OAuth configuration migrate করে না। Main site upgrade staging ফল পর্যালোচনার পরে আলাদাভাবে হবে। User-provided complete test product ছাড়া বাস্তব product/variation save ও order-line SKU পরীক্ষা হয়েছে বলে দাবি করবেন না।
