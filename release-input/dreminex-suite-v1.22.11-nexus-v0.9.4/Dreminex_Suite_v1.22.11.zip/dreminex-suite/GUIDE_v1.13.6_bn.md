# Dreminex Suite 1.13.6 — ইনস্টল ও ব্যবহার

বিদ্যমান `dreminex-suite` plugin-এ ZIP upload করে **Replace current with uploaded** বেছে update করুন; আগে uninstall/delete করবেন না। Site-এর backup রাখুন। আগের module switches, settings, products ও orders update-এ থাকে। Main site-এর আগে staging-এ পরীক্ষা করুন।

## দুই আলাদা workflow

- `PRODUCT_PREPARATION_INSTRUCTIONS_BN.md` শুধু final content sheet, exact Title/SKU duplicate ও price suggestion তৈরি করে। কোনো WordPress write নয়।
- `PRODUCT_PUBLISHING_INSTRUCTIONS_BN.md` সেই final details এবং Library image links থেকে actual originals নিয়ে Draft/Publish/Update করে। পুনরায় duplicate বা cost preparation নয়। প্রতিটি প্রজেক্টে নিজ নিজ এক লাইনের instruction আছে।

একই ChatGPT Project-এ দুইটি আলাদা skill রাখা যায়; তবে কাজের ভূমিকা পরিষ্কার রাখতে **দুইটি আলাদা Project** ব্যবহার করা ভালো। প্রথম Project থেকে final copy fields ও image links দ্বিতীয়টিতে দিন। Plugin-এর bundled skill ও `dreminex-products/workflow-guide`-তেও একই পথ আছে; কোনো skill নির্দিষ্ট Suite release ধরে নেয় না।

## Product Publisher

Suite → All Modules-এ **AI Product Publisher** চালু ও configured থাকতে হবে; পুরোনো standalone Publisher একসঙ্গে চালাবেন না। Novamira OAuth connection-এ বর্তমান abilities/schema দেখুন। `dreminex-products/listing-apply`-এ prepared field-গুলো সরাসরি পাঠান। নতুন product-এর `mode=draft` বা `publish`; বিদ্যমান product-এর `product_id` ও `mode=update`। Image entries-তে actual JPEG/PNG/WebP original bytes (base64), existing media ID, pre-transferred incoming filename বা public HTTPS source লাগবে। Private Library link নিজে WordPress server-এর public URL নয়; assistant-কে Library থেকে original bytes পড়ে পাঠাতে হবে।

Variation rows-এ শুধু বিক্রিযোগ্য colour/size pair, per-row price ও matching `image_index` দিন। নির্দিষ্ট quantity না থাকলে stock unmanaged থাকবে। Product type option থেকে বোঝা হয়; Simple/Variable এই entry point-এ সমর্থিত। Prepared categories, image alt/title, exact colour HEX, SEO এবং suggested upsell/cross-sell IDs/SKUs প্রয়োগ হয়। Partial response এলে returned `product_id`/`image_ids` দিয়ে resume করুন। সংরক্ষিত `product.status` ও link দেখে ফল নিশ্চিত করুন।

## Quantity button

Storefront Design module-এর **Quantity buttons** switch চালু রাখুন। Product, Quick View ও mobile cart-এ minus/value/plus একটি border ও একই rounded corner-এর মধ্যে থাকবে। Mobile browser cache পরিষ্কার/refresh করলে নতুন CSS দেখা যাবে।

এই package main site-এ স্বয়ংক্রিয়ভাবে install হয় না; ZIP update করলেই code ও bundled skills পৌঁছাবে। ChatGPT account plugin বা WordPress-এর user-created skills আলাদা distribution; সেগুলোর update পৃথকভাবে করতে হয়।
