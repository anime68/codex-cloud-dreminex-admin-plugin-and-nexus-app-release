# Dreminex Suite v1.11.0 — Flash Sale ব্যবহার নির্দেশিকা

Flash Sale page: https://dreminexfashion.store/flash-sale/
Control: WordPress → Dreminex Suite → Flash Sale। Dashboard → All Modules → Flash Sale → Manage থেকেও খোলা যাবে, module Off থাকলেও। Page editor লাগবে না।

## অফার চালু করা

1. Enable Flash Sale module নির্বাচন করুন।
2. Campaign timezone `Asia/Dhaka` রাখলে বাংলাদেশের সময়ে শুরু/শেষ নির্ধারণ করুন। Start ফাঁকা হলে সঙ্গে সঙ্গে শুরু হবে। End অবশ্যই দিন; End, Start-এর পরে হতে হবে। সাইটের global timezone অপরিবর্তিত থাকে।
3. Product name, ID অথবা SKU দিয়ে আগে থেকে আপলোড করা পণ্য খুঁজুন। Add offer দিয়ে নির্বাচন করুন। Variable parent নিলে সব eligible size/color-এ একই rule; নির্দিষ্ট variation নির্বাচন করলে তার rule parent-এর rule-এর ওপর প্রাধান্য পাবে।
4. Fixed offer price, Percentage off অথবা Amount off catalog price নির্বাচন করে মান লিখুন। Offer বর্তমান catalog price-এর চেয়ে কম এবং শূন্যের বেশি হতে হবে। 100% discount/free products সমর্থিত নয়।
5. প্রতি size/variant-এর cart quantity limit দিতে পারবেন। 0 মানে অতিরিক্ত Flash Sale limit নেই; stock এবং অন্য store validation কার্যকর থাকে। সর্বোচ্চ 100 unit এক add request-এ।
6. Heading, introduction, unavailable popup, buttons ও expired cart notice নিজের ভাষায় লিখুন। Countdown এবং products per page নিয়ন্ত্রণ করুন। অতিরিক্ত coupon default-এ Flash Sale item-এ চলে না; normal item-এ eligible coupon চলে। চাইলে coupon checkbox চালু করুন।
7. Save Flash Sale করুন। Products, শেষ সময় ও module On থাকলে campaign live হবে। Unpublished/out-of-stock/invalid discount পণ্য লুকানো থাকবে। সর্বোচ্চ 100 product/variation rule নির্বাচন করা যায়।

## দামের নিয়ম

শুধু Flash Sale page-এর Add to cart / Buy now থেকে যোগ করলে server নির্ধারিত offer price cart এবং checkout-এ যাবে। ছবিতে product link ক্লিক করে সাধারণ product page থেকে add করলে catalog price থাকবে। একই পণ্যের normal এবং Flash Sale line আলাদা থাকবে। Catalog product-এর saved price কখনো বদলানো হয় না। Discount current effective catalog price-এর ওপর হিসাব হয়; existing tax/currency convention বহাল থাকে।

Sale বন্ধ, সময় শেষ, product price/offer/schedule/coupon policy পরিবর্তন হলে আগের Flash Sale cart line আর valid থাকে না। সেটি notice দিয়ে সরানো হয়; হঠাৎ normal বেশি দাম নেওয়া হয় না। নতুন offer অথবা সাধারণ product page থেকে আবার যোগ করতে হবে। Order line-এ Flash Sale audit metadata থাকে। Already placed orders অপরিবর্তিত থাকে।

## বন্ধ করা ও reset

Enable Flash Sale module uncheck করে Save দিন অথবা All Modules থেকে Off করুন। Header button চাপলে editable unavailable popup আসে। Direct Flash Sale URL-তেও unavailable state দেখা যায়। Products সরালে শুধু offer row সরবে; মূল product মুছবে না। Backup & module data থেকে Flash Sale settings reset করলে selected offers/messages/schedule default হয়; products/orders এবং generated page মুছবে না।

## WhatsApp

Header, offcanvas, footer এবং Contact page-এ প্রদর্শিত দোকানের নম্বর official `https://wa.me/8801322523428` link ব্যবহার করে। WordPress → Dreminex Suite → Settings → Store setup → WhatsApp number থেকে international digits পরিবর্তন করুন। অন্য নম্বর বা email link বদলায় না। ডিভাইস অনুযায়ী official WhatsApp app/web খুলবে; কোনো message স্বয়ংক্রিয়ভাবে পাঠানো হয় না।

## প্রাথমিক অবস্থা

এই release live আছে, কিন্তু আসল campaign বন্ধ ও selected products খালি রাখা হয়েছে। আপনার অনুমোদিত পণ্য/discount/end time দেওয়ার পর On করুন। কোনো পরীক্ষামূলক discount live প্রকাশ করা হয়নি, কোনো test order/payment তৈরি করা হয়নি।

## যাচাই

২২টি server-side behavioral check পাস: signed offer, forged price/token rejection, quantity limit, normal/offer mixed WooCommerce totals, unchanged catalog prices, separate cart identity, coupon filtering, schedule/expiry/Off/rule changes, notice, invalid admin input, catalog rendering ও order metadata। Live inactive page/popup এবং WhatsApp links দেখা হয়েছে। PHP files syntax-parse এবং JavaScript syntax checks সম্পন্ন। Browser checkout-এ real payment/order দিয়ে পরীক্ষা করা হয়নি।
