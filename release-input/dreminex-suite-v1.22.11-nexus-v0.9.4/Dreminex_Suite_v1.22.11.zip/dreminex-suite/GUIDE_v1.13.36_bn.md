# Dreminex Suite 1.13.36 — Supplier Monitor release candidate

এই সংস্করণটি দেওয়া `1.13.35` foundation-এর উপর তৈরি। এটি **পূর্ণ চালু Supplier Monitor নয়**: ShopBaseBD/ResellKori logged-in DOM, subscription price, private worker host এবং staging end-to-end পরীক্ষা এখনও দরকার। Module default Off এবং observation নিজে WooCommerce stock/price বদলায় না।

## চালানোর আগে

1. Staging-এর `1.13.34` ZIP ও site backup রেখে এই plugin ZIP install করুন। `supplier-worker` plugin ZIP-এ নেই; আলাদা private worker package ব্যবহার করুন। Plugin upgrade-এর পর অন্য Suite module ও storefront smoke test করুন।
2. Suite → Modules-এ Supplier Monitor enable করলে event table/schema এবং dedicated `dreminex_supplier_worker` role তৈরি হবে। Admin dashboard-এ catalog reconciliation ও supplier observation-এর সময় আলাদা দেখা যায়। WP-Cron traffic-dependent; নিয়মিত server cron প্রয়োজন।
3. Exact HTTPS source URL link করুন। URL কেবল `shopbasebd.com`, `www.shopbasebd.com`, `resellkori.com`, `www.resellkori.com` হতে পারবে। নতুন product needs-source queue-তে আসে; title/photo দেখে auto-link হয় না।
4. Variable product-এর প্রতিটি supplier SKU owner-verified variation ID-তে map করুন। একই source SKU একাধিক variation-এ গ্রহণ করা হয় না। Link বা mapping বদলালে pending alert supersede হয়।
5. Worker host-এ আলাদা package-এর README অনুসারে authenticated sample selector, secure session, least-privilege WP user ও 12-hour scheduler বসান। Test fixture ছাড়া selector লিখে stock proposal বিশ্বাস করবেন না।
6. Initial staging scan-এ stock/price/option evidence logged-in page-এর সঙ্গে মিলিয়ে দেখুন। Missing option দুইটি complete successful observation-এর পর review alert; login/parser failure আগের সফল stock তথ্যকে OOS করে না।
7. Price proposal প্রয়োজন হলে actual seller-paid costs, fee, tax/coupon/sale policy নিশ্চিত করে rule enable এবং simple product বা exact variation-এর target net profit দিন। Sale বা scheduled sale থাকলে regular-price proposal হয় না। প্রতিটি write admin approval ও Woo readback-এর পরে `verified` হয়।

## অনুমোদনের নিরাপত্তা

- OOS approval-এর আগে ঐ item-এর **সব linked supplier**-এর 24 ঘণ্টার মধ্যে পাওয়া explicit OOS দরকার। Stale, unknown, missing variant, অন্য supplier instock, quantity-managed stock বা changed WC value হলে write বন্ধ হয়।
- Price approval-এর আগে same source cost, explicit target, rule version, WC regular/sale values ও cap আবার যাচাই হয়। WooCommerce CRUD শুধু exact stock status বা regular price বদলায়; description, SEO, image, category ও order স্পর্শ করে না।
- Worker REST account-এর custom scan capability আছে; admin approval-এর ক্ষমতা নেই। Source URL exact-host checked; cookies/OTP/plugin ZIP-এ রাখা হয় না।

## Release gate

এই build-এ Node syntax/JSON ও চারটি pure safety test পাস করেছে। PHP CLI এই environment-এ নেই। Staging activation, PHP runtime/schema verification, authenticated supplier extraction, price/stock approval test, rollback rehearsal ও production smoke test **চালানো হয়নি**। সব PASS হওয়ার আগে main-site deployment বা module activation করবেন না।

Rollback: private worker বন্ধ করুন, module Off করুন, staging backup/supplied `1.13.34` ZIP restore করুন; custom supplier table ও mapping/audit review ছাড়া মুছবেন না। Application Password revoke/rotate করুন যদি worker host compromise হয়ে থাকে।
