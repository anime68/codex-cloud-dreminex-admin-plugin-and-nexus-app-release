---
name: dreminex-product-media-brand
description: Map original product images to prepared colour names, image alt text and legible label brand for a Dreminex listing.
---

# Product media and brand mapping

Preparation records one image slug/alt/title/visual HEX and image index for each supplied original. Keep the image unmodified. A photographic HEX is an approximate visual match, not a manufacturer's dye code. Use only label text legibly present in an original image as a verified brand; never substitute the shop name.

Group alternate views under the same verified colour/design. Choose exactly one representative original product image as that colour's image swatch and keep every distinct original view in the ordered gallery. Use a verified HEX fallback only when no product image exists.

Publishing uses the prepared mapping and actual image bytes or verified attachment IDs. WordPress cannot read a private Library link directly. Put supplied bytes/URL resolution in the handoff's declared media prerequisite and let `handoff-execute` resolve it before fresh preflight. Pass each offered variation's corresponding `image_index` or image ID. Do not turn this handoff into a second editorial check, duplicate search or approval question.
