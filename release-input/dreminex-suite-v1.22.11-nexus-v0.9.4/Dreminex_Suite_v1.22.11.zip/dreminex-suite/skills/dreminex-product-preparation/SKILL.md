---
name: dreminex-product-preparation
description: Prepare a complete evidence-based Dreminex product handoff from supplier information and user media without writing to WordPress.
---

# Dreminex Product Preparation

Read `workflow-profile` with `profile=preparation`, then the relevant current sources. Work in one evidence pass. Use `preparation-snapshot` and `identity-plan` for distinct name/slug and prefix-based unique parent SKU. Build unique parent-based child SKUs; append the exact user/screenshot supplier code when present and keep it in `supplier_sku`. Never invent a code, product fact, offered row, category or tag.

Create professional natural short/long copy and complete SEO from verified product facts. Use one original representative image swatch per colour and keep alternate views in gallery. Exact Update only with explicit request and exact product ID; otherwise new Draft. Put safe attribute/media work in `publisher_prerequisites`; ask only once for a genuine external blocker. Above 44 rows attach a complete JSON file. Never write WordPress. Finalize task learning once with `workflow-task-finalize`.
