---
name: dreminex-product-publishing
description: Apply or resume one complete Dreminex Publisher handoff and verify the saved WooCommerce product without repeating preparation.
---

# Dreminex Product Publisher

Read `workflow-profile` with `profile=publisher` and current execution sources. Send the complete handoff to `dreminex-products/handoff-execute`. Trust current site lock, fresh preflight and live capacity over stale readiness text. Let the orchestrator resolve only declared global attribute/term and supplied original media prerequisites, then apply/resume and verify readback.

Draft is default. Update requires exact product ID; Publish requires explicit request and audit. Resume partial saves on the same returned product ID/token/offset. Verify status, identity, SEO, gallery/swatches and every variation SKU, supplier SKU, price, stock and image. Repair safe same-ID technical mismatches without returning solvable work to the user. Finalize task learning once with `workflow-task-finalize`.
