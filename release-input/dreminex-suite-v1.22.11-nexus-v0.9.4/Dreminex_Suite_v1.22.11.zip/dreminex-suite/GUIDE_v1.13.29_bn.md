# Dreminex Suite 1.13.29 — colour SKU ও size taxonomy

## ব্যবহার

1. Preparation-এ supplier/demo facts ও screenshots দিন। একই রঙের একাধিক view থাকলে একটিমাত্র **নিশ্চিত purchasable supplier code** বেছে নিন। ছবিতে ভিন্ন code থাকলে product-level প্রমাণ বা মালিকের নিশ্চিতকরণ ছাড়া কোনোটিই child SKU হিসেবে ব্যবহার করবেন না। সব ছবি আলাদাভাবে Media Library originals-এর সঙ্গে যাচাই করুন।
2. Preparation নির্বাচিত site-এর প্রকাশিত catalog read-only দেখে প্রাসঙ্গিক উচ্চতর মূল্যের বিকল্প Upsell এবং পরিপূরক Cross-sell খুঁজবে। না থাকলে দুই জায়গাই খালি থাকবে। Women’s item-এর জন্য site-এ `pa_size`-এর মতো উপযুক্ত global size taxonomy থাকলে সেটি `size_attribute`-এ দেবে; `pa_for-men-size` নয়।
3. সাধারণ প্রস্তুতি চাইলে শুধু preparation context; স্পষ্টভাবে hand-off চাইলে শুধু একটি সম্পূর্ণ JSON block। Hand-off-এ `color_supplier_skus` (যেমন `{"Purple":"CONFIRMED_CODE"}`), `size_attribute`, যাচাইকৃত media IDs এবং থাকলে related IDs থাকবে। অসমর্থিত দাম, variation availability বা operation লিখবেন না।
4. Publisher prepared text নিয়ে নির্দিষ্ট site-এ `listing-apply` চালাবে এবং product-read/draft-audit দিয়ে saved status, size attribute, gallery, related products ও child SKU যাচাই করবে। একই রঙের সব view-এ supplier code দিতে হলে একই নিশ্চিত code পুনরাবৃত্তি হবে। Existing item-এ নতুন related recommendation না পাওয়া গেলে `upsell_ids`/`cross_sell_ids` বাদ রাখুন, খালি array দিয়ে পুরোনো links মুছবেন না।

## Product 3164 ও Staging

- বর্তমানে Staging-এ Product 3164 **Trash**-এ আছে। এই Suite-এর listing update Draft/Published product-এ কাজ করে। মালিকের নির্দেশে একই ID restore করা হলে তবেই সেটি resume করুন; duplicate তৈরি করবেন না।
- Product-এ Men’s size attribute ছিল, child variation নেই। Restore ও এই version স্থাপনের পর নিশ্চিত size-সহ `size_attribute:"pa_size"` দিয়ে parent options migration করা যাবে। Child variations থাকলে এই automatic migration বন্ধ থাকবে।
- ৩টি রঙের দুটি করে screenshot code আছে। প্রতি রঙে একটিমাত্র purchasable code নিশ্চিত করতে হবে। Retail selling price ছাড়া paid variations তৈরি করবেন না। Publish-এর জন্য আলাদা স্পষ্ট নির্দেশ প্রয়োজন।

## স্থাপন ও সীমা

Staging-এর বর্তমান Suite ZIP-এর rollback copy রেখে বিদ্যমান `dreminex-suite` upgrade করুন; uninstall/delete করবেন না। আগে Staging-এ catalog-এ Size attribute এবং saved product readback যাচাই করুন। Main site আলাদাভাবে পরে। এই release পুরোনো product/media/Novamira connection নিজে থেকে বদলায় না। PWA-এর raw worker screen-এর সমস্যাটি আলাদা plugin-এর; Suite ZIP দিয়ে সেটি বদলাবে না।
