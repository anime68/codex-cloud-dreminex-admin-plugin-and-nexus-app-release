# Dreminex Suite 1.13.35 — Supplier Monitor

এই release-এ Suite → Modules থেকে Supplier Monitor চালু করা যায়। Module চালু হলে WooCommerce product ID ধরে নতুন/পরিবর্তিত product শনাক্ত করে; ১২ ঘণ্টা অন্তর catalog reconcile হয়। Supplier page পড়ার জন্য `supplier-worker`-কে আলাদা private server-এ চালাতে হবে। শুধু WordPress module চালু থাকলে supplier stock স্ক্যান হয় না।

## কাজের ধারা

1. Source URL জানা থাকলে Suite → Supplier Monitor-এ WooCommerce product ID ও supplier HTTPS link যুক্ত করুন। উৎস চেনা না গেলে product “Needs link” তালিকায় থাকবে। Title/SEO দেখে স্বয়ংক্রিয় exact match দাবি করা হয় না।
2. Worker deployment, reseller account-এ owner sign-in এবং logged-in page-এর CSS selectors যাচাই করার পর browser worker প্রথম scan করবে। `config.example.json`-এ ফাঁকা selector ইচ্ছাকৃত: সরাসরি চালালে সেটি stock সত্য বলে ধরবে না।
3. Wholesale cost, variation availability, missing option ও login/scan error admin dashboard-এ alert হবে; email-ও যাবে। কোনো product সরাসরি delete বা publish হবে না।
4. নির্দিষ্ট stock change approve করলে ঠিক সেই variation-এর current status ও source পুনরায় মিলিয়ে আপডেট হবে। Quantity-managed stock এবং একাধিক supplier-এর conflicting availability-তে manual review লাগবে।
5. Fixed cost, percentage fee ও minimum net profit সেট করার পর প্রথম নির্ভরযোগ্য supplier cost থেকে simple product-এর target profit ধরা হবে। নতুন cost এলে একই target ধরে প্রস্তাবিত sale/regular price দেওয়া হবে। Approval ছাড়া price বদলাবে না; sale price regular price ছাড়ালে manual review হবে। Variable product price-এর জন্য এখন শুধু cost alert থাকবে।

## Release gate

- Staging-এ প্রকৃত ShopBaseBD/ResellKori logged-in page যাচাই করে selectors সেট না করা পর্যন্ত কোনো site-এ supplier scan operational নয়।
- Account password, OTP, browser session ও WordPress Application Password chat, Media Library বা ZIP-এ দেবেন না। One-time private login এবং encrypted state worker host-এ রাখতে হবে।
- Staging smoke test: module enable, product create/update/trash detection, WooCommerce ID mapping, mock observation, duplicate alert prevention, stale approval rejection, exact variation approval এবং price readback। এরপর অনুমোদিত production deployment ও observation-only rollout।
- Rollback: Suite 1.13.34 ZIP ও full-site backup রেখে 1.13.35 module বন্ধ করুন; worker থামান; প্রয়োজনে আগের ZIP restore করুন। Product mapping/alerts audit স্বয়ংক্রিয়ভাবে মোছা হয় না।
