(() => {
  'use strict';
  const cfg = window.DreminexFlashLink;
  if (!cfg) return;
  let dialog, saleState, clockDelta = 0, refreshing = false;
  const phone = href => String(href || '').replace(/\D/g, '').replace(/^00/, '');
  const updateLinks = root => {
    root.querySelectorAll('a[href^="tel:"]').forEach(a => {
      const digits = phone(a.getAttribute('href'));
      if (cfg.phone && (digits === cfg.phone || (cfg.phone.startsWith('880') && digits === '0' + cfg.phone.slice(3)))) {
        a.href = cfg.whatsapp; a.title = 'Contact Dreminex Fashion on WhatsApp';
        a.setAttribute('rel', 'noopener');
      }
    });
    root.querySelectorAll('.rt-sale-offer-btn').forEach(a => { a.href = cfg.url; });
  };
  const setupHeader = () => {
    const header = document.querySelector('#masthead');
    if (header && !document.querySelector('.df-mobile-sale')) {
      const row = document.createElement('div'); row.className = 'df-mobile-sale';
      const button = document.createElement('a'); button.href = cfg.url; button.dataset.dreminexFlashTrigger = '1';
      const icon = document.createElement('i'); icon.className = 'icon-rt-flash'; icon.setAttribute('aria-hidden','true'); button.append(icon, document.createTextNode('Flash Sale Offer!')); row.append(button); header.append(row);
    }
    document.querySelectorAll('.rt-sale-offer-btn,.df-mobile-sale').forEach(container => {
      if (!container.querySelector('[data-flash-start-clock]')) {
        const time = document.createElement('span'); time.dataset.flashStartClock = '1'; time.hidden = true; container.append(time);
      }
    });
  };
  const refreshStatus = async () => {
    if (refreshing) return; refreshing = true;
    try {
      const url = new URL(cfg.ajax); url.searchParams.set('action', 'dreminex_flash_status'); url.searchParams.set('_', Date.now());
      const r = await fetch(url, { credentials: 'same-origin', cache: 'no-store' }); const result = await r.json();
      if (r.ok && result.success) { saleState = result.data; clockDelta = saleState.server_time - Date.now() / 1000; tickHeader(); }
    } catch { /* Keep purchase availability verified on click. */ }
    finally { refreshing = false; }
  };
  const tickHeader = () => {
    const scheduled = saleState?.reason === 'scheduled'; const active = !!saleState?.active;
    const deadline = scheduled ? saleState.start : (active ? saleState.end : 0);
    const remain = deadline ? Math.max(0, Math.ceil(deadline - Date.now() / 1000 - clockDelta)) : 0;
    document.querySelectorAll('.df-mobile-sale').forEach(row=>row.classList.toggle('has-clock',active && !!remain));
    document.querySelectorAll('[data-flash-start-clock]').forEach(el => {
      el.hidden = !remain;
      if (remain) {
        const values = [Math.floor(remain / 86400), Math.floor(remain % 86400 / 3600), Math.floor(remain % 3600 / 60), remain % 60];
        if (!el.querySelector('.df-clock-phase')) {
          // Static markup only; server text is never inserted as HTML.
          el.innerHTML = '<span class="df-clock-phase"></span><span class="df-clock-values">' + ['Days','Hrs','Mins','Secs'].map(unit => '<span class="df-clock-unit"><b class="df-clock-number"></b><span class="df-clock-label">' + unit + '</span></span>').join('') + '</span>';
        }
        el.querySelector('.df-clock-phase').textContent = scheduled ? 'Starts in' : 'Ends in';
        el.querySelectorAll('.df-clock-number').forEach((number,i) => { number.textContent = String(values[i]).padStart(2,'0'); });
        el.setAttribute('aria-label', (scheduled ? 'Starts in ' : 'Ends in ') + values[0] + ' days ' + values.slice(1).map(n=>String(n).padStart(2,'0')).join(':'));
      }
    });
    if ((scheduled || active) && !remain) refreshStatus();
  };
  const init = () => { updateLinks(document); setupHeader(); refreshStatus(); setInterval(tickHeader, 1000); setInterval(() => { if (!document.hidden) refreshStatus(); },30000); document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshStatus(); }); };
  const show = data => {
    if (!dialog) {
      dialog = document.createElement('dialog');
      dialog.className = 'df-flash-dialog';
      dialog.setAttribute('aria-labelledby', 'df-flash-dialog-title');
      dialog.innerHTML = '<h2 id="df-flash-dialog-title"></h2><p></p><div class="df-flash-dialog-actions"><a></a><button type="button"></button></div>';
      dialog.querySelector('button').addEventListener('click', () => {
        if (dialog.close) dialog.close(); else dialog.removeAttribute('open');
      });
      dialog.addEventListener('click', e => { if (e.target === dialog) { if (dialog.close) dialog.close(); else dialog.removeAttribute('open'); } });
      document.body.append(dialog);
    }
    dialog.querySelector('h2').textContent = data.title;
    dialog.querySelector('p').textContent = data.message;
    const link = dialog.querySelector('a'); link.textContent = data.shop_label; link.href = data.shop_url;
    dialog.querySelector('button').textContent = data.close_label;
    if (!dialog.open) {
      if (typeof dialog.showModal === 'function') dialog.showModal(); else dialog.setAttribute('open', '');
    }
  };
  document.addEventListener('click', async e => {
    const a = e.target.closest('a');
    if (!a || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey || e.button > 0) return;
    const rawHref = (a.getAttribute('href') || '').trim();
    const isSale = a.matches('.rt-sale-offer-btn,[data-dreminex-flash-trigger]') || (rawHref !== '' && !rawHref.startsWith('#') && a.href.split('#')[0] === cfg.url.split('#')[0]);
    if (!isSale) return;
    e.preventDefault(); if (a.getAttribute('aria-busy') === 'true') return;
    a.setAttribute('aria-busy', 'true');
    try {
      const url = new URL(cfg.ajax); url.searchParams.set('action', 'dreminex_flash_status'); url.searchParams.set('_', Date.now());
      const response = await fetch(url, { credentials: 'same-origin', cache: 'no-store' });
      const result = await response.json();
      if (!response.ok || !result.success) throw new Error('status');
      if (result.data.active) window.location.assign(result.data.url); else show(result.data);
    } catch {
      show({ title: 'অফার যাচাই করা যাচ্ছে না', message: 'সংযোগটি পরীক্ষা করে আবার চেষ্টা করুন, অথবা Flash Sale page খুলে বর্তমান অবস্থা দেখুন।', shop_label: 'Flash Sale page খুলুন', shop_url: cfg.url, close_label: 'বন্ধ করুন' });
    } finally { a.removeAttribute('aria-busy'); }
  });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
