(function () {
  'use strict';
  function ready() {
    var dialog = document.getElementById('dreminex-register-dialog');
    if (dialog) {
      var close = dialog.querySelector('.dreminex-confirm-close');
      var previous = document.activeElement;
      if (close) {
        close.focus();
        close.addEventListener('click', function (event) {
          if (!window.history || !window.history.replaceState) return;
          event.preventDefault();
          dialog.remove();
          var clean = new URL(window.location.href);
          clean.searchParams.delete('dreminex_registered');
          clean.searchParams.delete('dreminex_email_result');
          window.history.replaceState(null, '', clean.pathname + clean.search + clean.hash);
          if (previous && typeof previous.focus === 'function') previous.focus();
        });
        dialog.addEventListener('keydown', function (event) {
          if (event.key === 'Escape') { close.click(); return; }
          if (event.key === 'Tab') { event.preventDefault(); close.focus(); }
        });
      }
    }
    if (!document.body.classList.contains('dreminex-account-experience')) return;
    document.querySelectorAll('#customer_login input[type="password"]').forEach(function (input) {
      if (document.body.classList.contains('dreminex-password-toggle-off')) return;
      var wrapper = document.createElement('span');
      wrapper.className = 'dreminex-password-control';
      input.parentNode.insertBefore(wrapper, input);
      wrapper.appendChild(input);
      var button = document.createElement('button');
      button.type = 'button';
      button.className = 'dreminex-password-toggle';
      button.textContent = 'Show';
      button.setAttribute('aria-label', 'Show ' + ((document.querySelector('label[for="' + input.id + '"]') || {}).textContent || 'password').trim());
      button.setAttribute('aria-pressed', 'false');
      button.addEventListener('click', function () {
        var visible = input.type === 'password';
        input.type = visible ? 'text' : 'password';
        button.textContent = visible ? 'Hide' : 'Show';
        button.setAttribute('aria-pressed', visible ? 'true' : 'false');
        button.setAttribute('aria-label', (visible ? 'Hide ' : 'Show ') + ((document.querySelector('label[for="' + input.id + '"]') || {}).textContent || 'password').trim());
        input.focus();
      });
      wrapper.appendChild(button);
    });
    var password = document.getElementById('reg_password');
    var confirmation = document.getElementById('reg_password_confirm');
    if (password && confirmation) {
      var row = confirmation.closest('.woocommerce-form-row');
      var status = document.createElement('p');
      status.className = 'dreminex-password-match';
      status.setAttribute('aria-live', 'polite');
      status.hidden = true;
      if (row) row.insertAdjacentElement('afterend', status);
      function updateMatchStatus() {
        if (!confirmation.value) {
          status.hidden = true;
          status.className = 'dreminex-password-match';
          confirmation.removeAttribute('aria-invalid');
          return;
        }
        var matched = password.value === confirmation.value;
        status.hidden = false;
        status.className = 'dreminex-password-match ' + (matched ? 'is-match' : 'is-mismatch');
        status.textContent = matched ? confirmation.dataset.matchText : confirmation.dataset.mismatchText;
        confirmation.setAttribute('aria-invalid', matched ? 'false' : 'true');
      }
      password.addEventListener('input', updateMatchStatus);
      confirmation.addEventListener('input', updateMatchStatus);
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready);
  else ready();
})();
