(() => {
  'use strict';
  const root = document.querySelector('.df-sale-page'), cfg = window.DreminexFlashPage;
  if (!root || !cfg) return;
  const content = root.querySelector('.df-sale-content'), pager = root.querySelector('.df-sale-pagination');
  const summary = root.querySelector('.df-sale-summary'), countdown = root.querySelector('.df-sale-countdown');
  let catalog, page = 1, loading = false, clock, poll, delta = 0;
  const endpoint = (action, fields = {}) => { const url = new URL(cfg.ajax); url.searchParams.set('action', action); Object.entries(fields).forEach(([k, v]) => url.searchParams.set(k, v)); url.searchParams.set('_', Date.now()); return url; };
  const request = async (action, fields = {}) => {
    const res = await fetch(endpoint(action, fields), { credentials: 'same-origin', cache: 'no-store' }); const result = await res.json();
    if (!res.ok || !result.success) throw new Error(result.data?.message || 'Could not load this offer.'); return result.data;
  };
  const element = (tag, text) => { const el = document.createElement(tag); if (text !== undefined) el.textContent = text; return el; };
  const unavailable = data => {
    clearInterval(clock); clearInterval(poll); countdown.hidden = true; summary.hidden = true; pager.replaceChildren();
    const box = element('div'); box.className = 'df-sale-empty'; box.append(element('h2', data.title), element('p', data.message));
    const shop = element('a', data.shop_label); shop.href = data.shop_url; box.append(shop); content.replaceChildren(box);
  };
  const tick = () => {
    if (!catalog?.active || !catalog.show_countdown) return;
    const remain = Math.max(0, Math.floor(catalog.end - (Date.now() / 1000 + delta)));
    if (!remain) { clearInterval(clock); load(page); return; }
    const days = Math.floor(remain / 86400), hours = Math.floor(remain % 86400 / 3600), minutes = Math.floor(remain % 3600 / 60), seconds = remain % 60;
    root.querySelector('[data-sale-clock]').textContent = (days ? days + 'd ' : '') + [hours, minutes, seconds].map(n => String(n).padStart(2, '0')).join(':');
  };
  const load = async number => {
    closeQuick();
    if (loading) return; loading = true; root.setAttribute('aria-busy', 'true');
    try {
      catalog = await request('dreminex_flash_catalog', { sale_page: number }); page = catalog.page || number; delta = catalog.server_time - Date.now() / 1000;
      if (!catalog.active) { unavailable(catalog); return; }
      root.style.setProperty('--df-desktop-cols', String(catalog.desktop_columns || 4)); root.style.setProperty('--df-mobile-cols', String(catalog.mobile_columns || 1));
      const grid = element('div'); grid.className = 'df-sale-grid'; grid.innerHTML = catalog.html; content.replaceChildren(grid);
      grid.querySelectorAll('.df-sale-card').forEach(initGallery);
      summary.hidden = false; root.querySelector('[data-sale-total]').textContent = catalog.total + ' selected products';
      countdown.hidden = !catalog.show_countdown; clearInterval(clock); if (catalog.show_countdown) { tick(); clock = setInterval(tick, 1000); }
      pager.replaceChildren(); if (catalog.pages > 1) for (let i = 1; i <= catalog.pages; i++) { const b = element('button', String(i)); b.type = 'button'; if (i === page) b.setAttribute('aria-current', 'page'); b.addEventListener('click', () => load(i)); pager.append(b); }
      clearInterval(poll); poll = setInterval(async () => {
        if (document.hidden) return;
        try { const state = await request('dreminex_flash_status'); if (!state.active) unavailable(state); else if (state.revision !== catalog.revision) load(page); } catch { /* The add endpoint remains authoritative if connection fails. */ }
      }, 30000);
    } catch (error) {
      const box = element('div'); box.className = 'df-sale-empty'; box.append(element('h2', 'অফার লোড করা যাচ্ছে না'), element('p', 'সংযোগটি পরীক্ষা করে আবার চেষ্টা করুন।'));
      const b = element('button', 'আবার চেষ্টা করুন'); b.type = 'button'; b.className = 'df-sale-buy'; b.addEventListener('click', () => load(number)); box.append(b); content.replaceChildren(box);
    } finally { loading = false; root.removeAttribute('aria-busy'); }
  };
  const setImage = (card,image) => {
    const img = card.querySelector('.df-sale-photo img'); if (!img) return;
    img.src = image.url; img.alt = image.alt; img.removeAttribute('srcset'); img.removeAttribute('sizes');
    card.querySelectorAll('.df-sale-thumb').forEach(b=>b.setAttribute('aria-pressed',String(+b.dataset.image===image.id)));
  };
  const initGallery = card => {
    card.dataset.conditionHtml=card.querySelector('.df-sale-condition').innerHTML; card.dataset.badge=card.querySelector('.df-sale-badge').textContent;
    const thumbs=card.querySelector('.df-sale-thumbs');
    (catalog.galleries?.[card.dataset.product] || []).forEach((image,index)=>{
      const b=element('button'); b.type='button'; b.className='df-sale-thumb'; b.dataset.image=image.id;
      b.setAttribute('aria-label','View product image '+(index+1)); b.setAttribute('aria-pressed',String(index===0));
      const img=element('img'); img.src=image.thumb; img.alt=''; img.loading='lazy'; b.append(img); b.addEventListener('click',()=>setImage(card,image)); thumbs.append(b);
    });
  };
  const choose = card => {
    const attributes = {}; let complete = true;
    card.querySelectorAll('.df-sale-attribute').forEach(select => { attributes[select.name] = select.value; if (!select.value) complete = false; });
    const variants = catalog?.variations?.[card.dataset.product] || [];
    const selected = complete ? variants.find(v => Object.entries(v.attributes).every(([k, value]) => value === '' || value === attributes[k])) : null;
    card.dataset.variation = selected?.id || '';
    card.querySelector('.df-sale-condition').innerHTML = selected?.condition_html || card.dataset.conditionHtml;
    card.querySelector('.df-sale-badge').textContent = selected?.badge || card.dataset.badge;
    card.querySelector('.df-sale-offer-label').textContent = selected?.bundle ? 'Reward price shown. Paid / excess units keep catalog price.' : 'Offer applies only when the condition above is met.';
    if (selected?.image_id) { const image = (catalog.galleries?.[card.dataset.product] || []).find(i=>i.id===selected.image_id); if (image) setImage(card,image); }
    card.querySelector('.df-sale-price').innerHTML = selected ? selected.price_html : (complete ? 'এই options-এ Flash Sale offer নেই।' : 'Select your options for the offer price');
    card.querySelectorAll('.df-sale-buy').forEach(b => { b.disabled = !selected; });
    const qty = card.querySelector('.df-sale-qty input'); qty.max = selected?.max_qty ? Math.min(100, selected.max_qty) : 100;
    if (+qty.value > +qty.max) qty.value = qty.max;
    return attributes;
  };
  let quickDialog, quickCard, quickAnchor, quickTrigger;
  const closeQuick = () => {
    if (!quickCard) return;
    quickAnchor.replaceWith(quickCard); quickCard = null;
    if (quickDialog.open) quickDialog.close();
    quickTrigger?.focus();
  };
  root.addEventListener('click', e => {
    const trigger = e.target.closest('.df-sale-quick'); if (!trigger) return;
    closeQuick();
    if (!quickDialog) {
      quickDialog = element('dialog'); quickDialog.className = 'df-sale-quick-dialog';
      quickDialog.setAttribute('aria-label', 'Flash Sale product quick view');
      const close = element('button', 'Close ×'); close.type = 'button'; close.className = 'df-sale-quick-close';
      close.addEventListener('click', closeQuick); quickDialog.append(close); root.append(quickDialog);
      quickDialog.addEventListener('cancel', e => { e.preventDefault(); closeQuick(); });
      quickDialog.addEventListener('click', e => { if (e.target === quickDialog) closeQuick(); });
    }
    quickTrigger = trigger; quickCard = trigger.closest('.df-sale-card'); quickAnchor = document.createElement('span');
    quickCard.before(quickAnchor); quickDialog.append(quickCard); quickDialog.showModal();
  });
  root.addEventListener('change', e => { if (e.target.matches('.df-sale-attribute')) choose(e.target.closest('.df-sale-card')); });
  root.addEventListener('click', async e => {
    const button = e.target.closest('.df-sale-buy[data-buy]'); if (!button || button.disabled) return;
    const card = button.closest('.df-sale-card'), feedback = card.querySelector('.df-sale-feedback');
    const qty = card.querySelector('.df-sale-qty input'); if (!qty.reportValidity()) return;
    const attributes = card.dataset.variable === '1' ? choose(card) : {};
    if (card.dataset.variable === '1' && !card.dataset.variation) return;
    const buttons = [...card.querySelectorAll('.df-sale-buy')]; buttons.forEach(b => { b.disabled = true; }); feedback.classList.remove('is-error'); feedback.textContent = 'Adding at Flash Sale price…';
    try {
      if (+String(catalog.token).split('.')[0] < Date.now() / 1000 + 60) { const fresh = await request('dreminex_flash_catalog', { token_only: 1 }); catalog.token = fresh.token; }
      const fields = new URLSearchParams({ action: 'dreminex_flash_add', token: catalog.token, product_id: card.dataset.product, variation_id: card.dataset.variation || '0', quantity: qty.value, attributes: JSON.stringify(attributes) });
      const res = await fetch(cfg.ajax, { method: 'POST', credentials: 'same-origin', cache: 'no-store', body: fields }); const result = await res.json();
      if (!res.ok || !result.success) throw new Error(result.data?.message || 'Could not add this offer.');
      feedback.textContent = result.data.message + ' '; const link = element('a', 'View cart'); link.href = result.data.cart_url; feedback.append(link);
      if (window.jQuery) window.jQuery(document.body).trigger('wc_fragment_refresh');
      if (button.dataset.buy === 'checkout') window.location.assign(result.data.conditions_met === false ? result.data.cart_url : result.data.checkout_url);
    } catch (error) { feedback.textContent = error.message; feedback.classList.add('is-error'); }
    finally { buttons.forEach(b => { b.disabled = false; }); }
  });
  load(1);
})();
