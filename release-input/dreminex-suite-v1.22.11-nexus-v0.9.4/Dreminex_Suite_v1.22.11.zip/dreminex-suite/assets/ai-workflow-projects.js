document.addEventListener('DOMContentLoaded', () => {
  const area = document.getElementById('ds-workflow-projects');
  if (!area) return;

  let existing = [];
  try { existing = JSON.parse(area.dataset.dsExistingFiles || '[]'); } catch (error) { existing = []; }

  area.addEventListener('click', async (event) => {
    const copyButton = event.target.closest('[data-ds-copy]');
    if (copyButton) {
      const target = document.querySelector(copyButton.dataset.dsCopy);
      if (!target) return;
      try {
        await navigator.clipboard.writeText(target.value);
        const oldLabel = copyButton.textContent;
        copyButton.textContent = 'Copied';
        window.setTimeout(() => { copyButton.textContent = oldLabel; }, 1400);
      } catch (error) {
        target.focus();
        target.select();
        document.execCommand('copy');
      }
      return;
    }
    const button = event.target.closest('[data-ds-confirm]');
    if (button && !window.confirm(button.dataset.dsConfirm)) event.preventDefault();
  });

  area.addEventListener('change', (event) => {
    const input = event.target;
    if (!input.matches('input[type="file"]') || !input.files.length) return;
    if (input.files[0].size > 2097152) {
      window.alert('Each source document must be 2 MB or smaller.');
      input.value = '';
    }
  });

  area.addEventListener('submit', (event) => {
    const form = event.target.closest('[data-ds-upload-form]');
    if (!form) return;
    const input = form.querySelector('input[type="file"]');
    if (!input || !input.files.length) return;
    const uploadedName = input.files[0].name;
    const targetName = form.dataset.dsTargetName || uploadedName;
    if (form.dataset.dsTargetName && uploadedName !== targetName) {
      event.preventDefault();
      window.alert(`Choose the exact filename “${targetName}” to replace it. Use Add a source file for a different filename.`);
      return;
    }
    if (!existing.includes(targetName)) return;
    if (!window.confirm(`“${targetName}” already exists. Replace it with this uploaded file? The current version will remain available as Previous version.`)) {
      event.preventDefault();
      return;
    }
    let confirmed = form.querySelector('input[name="replace_confirmed"]');
    if (!confirmed) {
      confirmed = document.createElement('input');
      confirmed.type = 'hidden';
      confirmed.name = 'replace_confirmed';
      form.appendChild(confirmed);
    }
    confirmed.value = '1';
  });
});
