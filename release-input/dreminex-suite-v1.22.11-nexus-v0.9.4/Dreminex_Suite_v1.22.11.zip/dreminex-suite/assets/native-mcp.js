(function () {
  'use strict';

  function groupFor(key) {
    var groups = document.querySelectorAll('[data-dmcp-provider-group]');
    for (var i = 0; i < groups.length; i += 1) {
      if (groups[i].getAttribute('data-dmcp-provider-group') === key) return groups[i];
    }
    return null;
  }

  function providerCheckbox(key) {
    var input = document.querySelector('[data-dmcp-provider-state="' + key + '"]');
    return input && input.type === 'checkbox' ? input : null;
  }

  function setProviderState(key, enabled) {
    var input = providerCheckbox(key);
    if (input) input.checked = enabled;
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-dmcp-provider-toggle]').forEach(function (button) {
      button.addEventListener('click', function () {
        var key = button.getAttribute('data-dmcp-provider-toggle');
        var provider = providerCheckbox(key);
        var enable = !(provider && provider.checked);
        setProviderState(key, enable);
        button.textContent = enable ? 'Disable all abilities' : 'Enable all abilities';
      });
    });

    document.querySelectorAll('[data-dmcp-provider-state]').forEach(function (input) {
      input.addEventListener('change', function () {
        var key = input.getAttribute('data-dmcp-provider-state');
        var button = document.querySelector('[data-dmcp-provider-toggle="' + key + '"]');
        if (button) button.textContent = input.checked ? 'Disable all abilities' : 'Enable all abilities';
      });
    });
  });
}());
