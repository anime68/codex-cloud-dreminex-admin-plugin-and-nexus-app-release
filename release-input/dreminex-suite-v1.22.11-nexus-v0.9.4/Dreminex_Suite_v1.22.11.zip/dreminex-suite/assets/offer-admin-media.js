(function () {
 'use strict';
 function ready() {
  var root = document.querySelector('.dreminex-offer-media');
  if (!root || !window.wp || !wp.media) return;
  var id = root.querySelector('input[name="notification_image_id"]');
  var preview = root.querySelector('.dreminex-offer-media-preview');
  var remove = root.querySelector('.dreminex-offer-media-remove');
  var picker;
  root.querySelector('.dreminex-offer-media-choose').addEventListener('click', function () {
   if (!picker) {
    picker = wp.media({title:'Choose offer notification image',button:{text:'Use this image'},library:{type:'image'},multiple:false});
    picker.on('select',function () {
     var item=picker.state().get('selection').first();
     if(!item)return;
     var image=item.toJSON();
     id.value=String(image.id);
     preview.src=(image.sizes && (image.sizes.large || image.sizes.medium) || image).url;
     preview.style.display='block';
     remove.disabled=false;
    });
   }
   picker.open();
  });
  remove.addEventListener('click',function(){
   id.value='';preview.removeAttribute('src');preview.style.display='none';remove.disabled=true;
  });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready,{once:true});else ready();
})();
