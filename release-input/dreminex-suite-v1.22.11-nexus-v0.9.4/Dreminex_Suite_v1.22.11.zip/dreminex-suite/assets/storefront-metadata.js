'use strict';
(() => {
  const configuredLimit = Number(window.DreminexStorefrontDesign?.tagLimit);
  const tagLimit = Number.isInteger(configuredLimit) && configuredLimit >= 1 && configuredLimit <= 12 ? configuredLimit : 4;
  const enhanceRow = (row, limit, externalLabel = null) => {
    if (row.classList.contains('dreminex-meta-row')) return;
    const nodes = Array.from(row.childNodes);
    const firstLink = nodes.findIndex(node => node.nodeType === 1 && node.tagName === 'A');
    if (firstLink < 0) return;
    const inlineLabel = nodes.slice(0, firstLink).find(node => node.nodeType === 1 && node.matches('.rtsb-meta-label'));
    // Accept WooCommerce's plain label and ShopBuilder's label span; leave other markup intact.
    if (nodes.some((node, index) => node.nodeType === 1 && node.tagName !== 'A' && node !== inlineLabel ||
      node.nodeType === 3 && index >= firstLink && !/^[\s,،，]*$/.test(node.textContent))) return;

    const title = externalLabel ? externalLabel.textContent.trim() : nodes.slice(0, firstLink).map(node => node.textContent).join('').trim();
    const anchors = nodes.filter(node => node.nodeType === 1 && node.tagName === 'A');
    if (!title || !anchors.length) return;

    const label = externalLabel || inlineLabel || document.createElement('span');
    label.className = 'dreminex-meta-label';
    label.textContent = title;
    const visible = document.createElement('span');
    visible.className = 'dreminex-meta-links';
    anchors.slice(0, limit).forEach(anchor => visible.append(anchor));
    row.replaceChildren(label, visible);
    row.classList.add('dreminex-meta-row');

    const remainder = anchors.slice(limit);
    if (!remainder.length) return;
    const extra = document.createElement('span');
    extra.className = 'dreminex-meta-links dreminex-meta-extra';
    extra.hidden = true;
    remainder.forEach(anchor => extra.append(anchor));
    const toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.className = 'dreminex-meta-toggle';
    toggle.setAttribute('aria-expanded', 'false');
    toggle.textContent = `Show ${remainder.length} more tags`;
    toggle.addEventListener('click', () => {
      extra.hidden = !extra.hidden;
      toggle.setAttribute('aria-expanded', String(!extra.hidden));
      toggle.textContent = extra.hidden ? `Show ${remainder.length} more tags` : 'Show fewer tags';
    });
    row.append(extra, toggle);
  };

  const enhanceMeta = meta => {
    if (meta.matches('.rtsb-product-categories')) {
      const row = meta.querySelector(':scope > .posted_in');
      if (row) enhanceRow(row, Infinity, meta.querySelector(':scope > .categories-title'));
    } else if (meta.matches('.rtsb-product-tags')) {
      const row = meta.querySelector(':scope > .tagged_as');
      if (row) enhanceRow(row, tagLimit, meta.querySelector(':scope > .tags-title'));
    } else {
      meta.querySelectorAll(':scope > .posted_in').forEach(row => enhanceRow(row, Infinity));
      meta.querySelectorAll(':scope > .tagged_as').forEach(row => enhanceRow(row, tagLimit));
    }
    meta.classList.add('dreminex-meta-ready');
  };

  const selector = '.product_meta, .rtsb-product-categories, .rtsb-product-tags';
  document.querySelectorAll(selector).forEach(enhanceMeta);
  // ShopBuilder injects Quick View markup asynchronously; process only newly added metadata.
  const observer = new MutationObserver(changes => {
    for (const change of changes) {
      for (const node of change.addedNodes) {
        if (node.nodeType !== 1) continue;
        const parentMeta = node.closest(selector);
        if (parentMeta) enhanceMeta(parentMeta);
        if (node.matches(selector)) enhanceMeta(node);
        node.querySelectorAll(selector).forEach(enhanceMeta);
      }
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();
