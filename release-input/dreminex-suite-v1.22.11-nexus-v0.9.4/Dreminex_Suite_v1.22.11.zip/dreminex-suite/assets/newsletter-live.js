(function () {
 'use strict';
 function start() {
  var parts = ['heading', 'signup', 'offers'].map(function(key){
   return {key:key, node:document.getElementById('dreminex-news-live-' + key)};
  }).filter(function(part){return part.node;});
  if (!parts.length || parts.some(function(part){return part.node.dataset.loaded === '1';})) return;
  parts.forEach(function(part){part.node.dataset.loaded = '1';part.node.setAttribute('aria-busy','true');});
  var anchor = parts.find(function(part){return part.key !== 'heading';}) || parts[0];
  function load() {
   var controller = new AbortController();
   var timer = setTimeout(function(){controller.abort();},15000);
   fetch(anchor.node.dataset.endpoint,{method:'POST',credentials:'same-origin',cache:'no-store',signal:controller.signal,headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=dreminex_news_live_panel'})
   .then(function(r){if(!r.ok)throw new Error('response');return r.json();})
   .then(function(r){
    if(!r.success||!r.data)throw new Error('data');
    parts.forEach(function(part){
     var node=part.node;
     node.innerHTML=r.data[part.key]||'';
     if(!node.textContent.trim()&&!node.children.length){
      var container=node.closest('.dreminex-auto-offers, .dreminex-auto-newsletter');
      node.remove();
      if(container&&!container.textContent.trim()&&!container.children.length)container.remove();
     }
    });
   })
   .catch(function(){
    parts.forEach(function(part){
     if(!part.node.isConnected||part.key==='heading')return;
     part.node.textContent='This section is temporarily unavailable. ';
     var button=document.createElement('button');
     button.type='button';button.textContent='Try again';
     button.addEventListener('click',load,{once:true});
     part.node.appendChild(button);
    });
   })
   .finally(function(){clearTimeout(timer);parts.forEach(function(part){part.node.removeAttribute('aria-busy');});});
  }
  load();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
