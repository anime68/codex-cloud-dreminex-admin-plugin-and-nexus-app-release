(() => {
  'use strict';
  const cfg = window.DreminexFlashAdmin;
  const search = document.getElementById('df-product-search');
  const results = document.getElementById('df-product-results');
  const rows = document.getElementById('df-offer-rows');
  if (!cfg || !search || !rows) return;
  let timer, controller;
  const el = (tag, text) => { const node = document.createElement(tag); if (text !== undefined) node.textContent = text; return node; };
  const makePicker = () => {
    const box=el('div');box.className='df-qualifier-picker';const label=el('label','Find required product / variation');
    const input=el('input');input.type='search';input.className='df-qualifier-search';input.placeholder='Product name / ID / SKU';input.autocomplete='off';input.style.maxWidth='240px';input.style.width='100%';label.append(input);
    const list=el('div');list.className='df-qualifier-results';list.setAttribute('role','status');
    const selected=el('p','Same selected product (0)');selected.className='df-qualifier-selected';
    const clear=el('button','Use same product');clear.type='button';clear.className='button df-qualifier-clear';box.append(label,list,selected,clear);return box;
  };
  const pickerRequests = new WeakMap();
  rows.addEventListener('input', e => {
    const input=e.target.closest('.df-qualifier-search');if(!input)return;
    const old=pickerRequests.get(input);if(old){clearTimeout(old.timer);old.controller?.abort();}
    const box=input.closest('.df-qualifier-picker'),list=box.querySelector('.df-qualifier-results'),term=input.value.trim();
    if(term.length<2){list.replaceChildren();return;}
    const request={controller:new AbortController()};pickerRequests.set(input,request);
    request.timer=setTimeout(async()=>{
      list.textContent='Searching products…';
      try{
        const url=new URL(cfg.ajax);url.searchParams.set('action','dreminex_flash_search');url.searchParams.set('nonce',cfg.nonce);url.searchParams.set('term',term);
        const res=await fetch(url,{credentials:'same-origin',cache:'no-store',signal:request.controller.signal});const body=await res.json();
        if(!res.ok||!body.success)throw new Error('search');
        if(pickerRequests.get(input)!==request||input.value.trim()!==term)return;
        list.replaceChildren();if(!body.data.length){list.textContent='No matching published products.';return;}
        body.data.forEach(product=>{
          const entry=el('p','#'+product.id+' — '+product.name+' ('+product.type+') '),button=el('button','Select required product');button.type='button';button.className='button';
          button.addEventListener('click',()=>{const id=box.closest('tr').querySelector('input[name$="[qualifier_id]"]');id.value=String(product.id);box.querySelector('.df-qualifier-selected').textContent=product.name+' (#'+product.id+')';input.value='';list.replaceChildren();});entry.append(button);list.append(entry);
        });
      }catch(error){if(error.name!=='AbortError'&&pickerRequests.get(input)===request)list.textContent='Could not search. Please try again.';}
    },300);
  });
  rows.addEventListener('click',e=>{const clear=e.target.closest('.df-qualifier-clear');if(!clear)return;const box=clear.closest('.df-qualifier-picker'),input=box.querySelector('.df-qualifier-search'),request=pickerRequests.get(input);if(request){clearTimeout(request.timer);request.controller.abort();pickerRequests.delete(input);}box.closest('tr').querySelector('input[name$="[qualifier_id]"]').value='0';input.value='';box.querySelector('.df-qualifier-results').replaceChildren();box.querySelector('.df-qualifier-selected').textContent='Same selected product (0)';});
  const addRow = product => {
    if (rows.querySelector('[data-offer-id="' + product.id + '"]')) return;
    const tr = el('tr'); tr.dataset.offerId = product.id;
    const name = el('td', product.name); name.append(el('br'), el('small', '#' + product.id + ' · ' + product.type)); tr.append(name);
    const typeCell = el('td'), select = el('select'); select.name = 'offers[' + product.id + '][type]';
    Object.entries({ price: 'Fixed offer price', percent: 'Percentage off', amount: 'Amount off catalog price', bundle: 'Buy X get Y (% off / free)' }).forEach(([value, label]) => { const option = el('option', label); option.value = value; select.append(option); });
    typeCell.append(select); tr.append(typeCell);
    const valueCell = el('td'), value = el('input'); value.type = 'number'; value.min = '0.01'; value.step = '0.01'; value.required = true; value.name = 'offers[' + product.id + '][value]'; valueCell.append(value); tr.append(valueCell);
    const maxCell = el('td'), max = el('input'); max.type = 'number'; max.min = '0'; max.max = '100'; max.value = '0'; max.name = 'offers[' + product.id + '][max_qty]'; maxCell.append(max, el('small', '0 = no additional limit')); tr.append(maxCell);
    const conditionCell = el('td');
    Object.entries({min_qty:'Minimum target quantity',buy_qty:'Buy quantity (bundle)',get_qty:'Reward quantity (bundle)',qualifier_id:'Required product ID (0 = same)'}).forEach(([key,text])=>{
      const label=el('label',text), input=el('input'); label.style.display='block'; input.style.display='block'; input.style.width='100px';
      input.type='number'; input.min=key==='qualifier_id'?'0':'1'; input.value=input.min; input.name='offers['+product.id+']['+key+']'; label.append(input); conditionCell.append(label);
    }); conditionCell.append(makePicker());tr.append(conditionCell);
    const action = el('td'), remove = el('button', 'Remove'); remove.type = 'button'; remove.className = 'button df-remove-offer'; action.append(remove); tr.append(action);
    rows.append(tr); value.focus(); search.value = ''; results.replaceChildren();
  };
  rows.addEventListener('click', e => { const b = e.target.closest('.df-remove-offer'); if (b) b.closest('tr').remove(); });
  search.addEventListener('input', () => {
    clearTimeout(timer); if (controller) controller.abort();
    const term = search.value.trim(); if (term.length < 2) { results.replaceChildren(); return; }
    timer = setTimeout(async () => {
      controller = new AbortController(); results.textContent = 'Searching products…';
      try {
        const url = new URL(cfg.ajax); url.searchParams.set('action', 'dreminex_flash_search'); url.searchParams.set('nonce', cfg.nonce); url.searchParams.set('term', term);
        const res = await fetch(url, { credentials: 'same-origin', cache: 'no-store', signal: controller.signal }); const body = await res.json();
        if (!res.ok || !body.success) throw new Error('search');
        results.replaceChildren();
        if (!body.data.length) { results.textContent = 'No matching published products.'; return; }
        body.data.forEach(p => {
          const row = el('p', '#' + p.id + ' — ' + p.name + ' (' + p.type + ') ');
          const button = el('button', 'Add to sale'); button.type = 'button'; button.className = 'button'; button.disabled = !!rows.querySelector('[data-offer-id="' + p.id + '"]'); button.addEventListener('click', () => addRow(p)); row.append(button); results.append(row);
        });
      } catch (error) { if (error.name !== 'AbortError') results.textContent = 'Could not search. Refresh the page and try again.'; }
    }, 300);
  });
})();
