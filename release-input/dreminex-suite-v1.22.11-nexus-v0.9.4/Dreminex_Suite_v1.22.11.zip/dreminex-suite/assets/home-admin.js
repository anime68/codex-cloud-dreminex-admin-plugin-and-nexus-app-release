(function ($) {
  'use strict';
  $(document).on('click', '.ds-pick-media', function () {
    const input = $(this).siblings('.ds-media-id');
    const frame = wp.media({title:'Select homepage image', library:{type:'image'}, multiple:false});
    frame.on('select', function () {
      const item = frame.state().get('selection').first().toJSON();
      input.val(item.id);
      const card = input.closest('.ds-home-card');
      const image = card.find('summary .ds-home-thumb');
      const url = item.sizes && item.sizes.thumbnail ? item.sizes.thumbnail.url : item.url;
      if (image.length) image.attr('src', url);
      else card.find('.ds-home-card-label').prepend($('<img>', {class:'ds-home-thumb', src:url, alt:'', width:96, height:64}));
    });
    frame.open();
  });
  $(document).on('click', '.ds-clear-media', function () {
    $(this).siblings('.ds-media-id').val('');
  });
  $(document).on('input', '.ds-home-color', function () {
    $(this).prev('input[type=text]').val(this.value);
  });
  $(document).on('input', '.ds-home-field input[type=text]', function () {
    const picker = $(this).next('.ds-home-color');
    if (picker.length && /^#[0-9a-f]{6}$/i.test(this.value)) picker.val(this.value);
  });
}(jQuery));
