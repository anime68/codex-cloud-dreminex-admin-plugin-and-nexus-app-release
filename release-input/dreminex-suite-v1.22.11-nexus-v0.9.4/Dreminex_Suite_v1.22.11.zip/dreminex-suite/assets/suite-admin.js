(function () {
  'use strict';
  // Some admin extensions append notices after the first H1. Keep them visible
  // in the normal notice area instead of allowing them to stretch our header.
  const header = document.querySelector('.ds-page-header');
  if (header) {
    const relocateNotices = function () {
      header.querySelectorAll('.notice').forEach(function (notice) {
        header.parentNode.insertBefore(notice, header);
      });
    };
    relocateNotices();
    new MutationObserver(relocateNotices).observe(header, {childList:true, subtree:true});
  }
  document.querySelectorAll('[data-ds-media-field]').forEach(function (field) {
    const input = field.querySelector('input[name="settings[hero_image_id]"]');
    const preview = field.querySelector('[data-ds-media-preview]');
    const choose = field.querySelector('[data-ds-media-choose]');
    const clear = field.querySelector('[data-ds-media-clear]');
    if (!input || !preview || !choose || !clear) return;
    choose.addEventListener('click', function () {
      if (!window.wp || !wp.media) return;
      const frame = wp.media({title:'Choose account image',button:{text:'Use this image'},library:{type:'image'},multiple:false});
      frame.on('select', function () {
        const image = frame.state().get('selection').first().toJSON();
        input.value = image.id;
        const img = document.createElement('img');
        img.src = image.sizes && image.sizes.thumbnail ? image.sizes.thumbnail.url : image.url;
        img.alt = image.alt || '';
        preview.replaceChildren(img);
      });
      frame.open();
    });
    clear.addEventListener('click', function () {
      input.value = '0';
      const label = document.createElement('span');
      label.textContent = 'No image selected';
      preview.replaceChildren(label);
    });
  });
  document.querySelectorAll('[data-ds-accent-code]').forEach(function (code) {
    const picker = code.parentElement.querySelector('[data-ds-accent-picker]');
    if (!picker) return;
    code.addEventListener('input', function () {
      const match = code.value.trim().match(/^#?([a-f0-9]{3}|[a-f0-9]{6})$/i);
      if (!match) return;
      const hex = match[1].length === 3
        ? match[1].split('').map(function (digit) { return digit + digit; }).join('')
        : match[1];
      picker.value = '#' + hex.toLowerCase();
    });
    code.addEventListener('blur', function () {
      if (/^#?([a-f0-9]{3}|[a-f0-9]{6})$/i.test(code.value.trim())) {
        code.value = '#' + code.value.trim().replace(/^#/, '').toUpperCase();
      }
    });
    picker.addEventListener('input', function () { code.value = picker.value.toUpperCase(); });
  });
  const search = document.getElementById('ds-module-search');
  const filter = document.getElementById('ds-module-filter');
  if (!search || !filter) return;
  const cards = Array.from(document.querySelectorAll('.ds-module-card'));
  const groups = Array.from(document.querySelectorAll('.ds-module-group-title'));
  const count = document.getElementById('ds-module-count');
  const empty = document.querySelector('.ds-module-empty');
  function update() {
    const term = search.value.trim().toLocaleLowerCase();
    let visible = 0;
    cards.forEach(function (card) {
      const show = (filter.value === 'all' || filter.value === card.dataset.dsStatus) &&
        (!term || (card.textContent + ' ' + card.dataset.dsSearch).toLocaleLowerCase().includes(term));
      card.hidden = !show;
      if (show) visible++;
    });
    groups.forEach(function (group) {
      group.hidden = !cards.some(function (card) {
        return !card.hidden && card.dataset.dsGroup === group.dataset.dsGroup;
      });
    });
    if (count) count.textContent = visible + ' of ' + cards.length + ' modules';
    if (empty) empty.hidden = visible !== 0;
  }
  search.addEventListener('input', update);
  filter.addEventListener('change', update);
  update();
}());
