(() => {
    'use strict';
    const update = () => {
        document.querySelectorAll('.rtsb-product-default-filters.rtsb-ratings').forEach((filter) => {
            const counts = [...filter.querySelectorAll('.rtsb-count')].map((item) => Number(item.textContent.replace(/[^0-9]/g, '')));
            filter.classList.toggle('dreminex-filter-empty', counts.length > 0 && counts.every((n) => n === 0));
        });
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', update, { once: true });
    else update();
    document.addEventListener('pageshow', update);
    const host = document.querySelector('.rtsb-archive-default-filters-wrapper, .rtsb-default-archive-filters-wrapper');
    if (host && 'MutationObserver' in window) new MutationObserver(update).observe(host, { childList: true, subtree: true, characterData: true });
})();
