# Dreminex Nexus ↔ Dreminex Suite Integration Contract

Contract version: 1.1.0 (`Suite 1.14.1`, `Nexus 0.2.0`)

সব route HTTPS এবং `/wp-json/dreminex/v1/nexus` namespace-এ। Register ছাড়া প্রতিটি route-এ OAuth Bearer token, `X-Dreminex-Device-Id` এবং `X-Dreminex-Device-Key` লাগে। Token-এর user এবং registered device owner একই হতে হবে।

Nexus 0.2.0 একটি app instance-এ সর্বোচ্চ পাঁচটি Suite site রাখতে পারে। প্রতিটি site-এর token/device registration আলাদা এবং request সবসময় সেই connection-এর নিজের base URL-এ যায়। Server API payload-এ অন্য site ID পাঠিয়ে routing করা হয় না; এতে এক site-এর credentials দিয়ে অন্য site access করার সুযোগ থাকে না।

## Routes

| Method/path | Scope | উদ্দেশ্য |
|---|---|---|
| `POST /device/register` | `devices:write` | একবার device ID/key তৈরি |
| `POST /device/heartbeat` | `devices:write` | app/network/last-seen update |
| `GET /platforms` | `suppliers:read` | current built-in/custom profiles |
| `GET /jobs?limit=10` | `suppliers:read` | due pending jobs |
| `GET /history?limit=30` | `suppliers:read` | এই device-এর claimed history |
| `POST /jobs/enqueue-due` | `suppliers:write` | due mappings queue করা |
| `POST /jobs/{uuid}/claim` | `suppliers:write` | atomic lease claim |
| `POST /jobs/{uuid}/renew` | `suppliers:write` | running lease বাড়ানো |
| `POST /jobs/{uuid}/observation` | `suppliers:write` | normalized result submit |
| `POST /jobs/{uuid}/fail` | `suppliers:write` | bounded failure/retry state |

## Job response-এর প্রয়োজনীয় অংশ

```json
{
  "job_id": "uuid",
  "idempotency_key": "sha256",
  "platform_id": "shopbasebd",
  "product_id": 123,
  "supplier_url": "https://exact-product-url",
  "scan_type": "scheduled|manual|preview",
  "mapping": {
    "source_key": "shopbasebd.com",
    "expected_url": "https://exact-product-url",
    "variations": [
      {"variation_id": 456, "supplier_sku": "supplier-code", "attributes": {}}
    ]
  },
  "platform": {
    "platform_id": "shopbasebd",
    "revision": 1,
    "domains": ["shopbasebd.com"],
    "login_mode": "form_credentials",
    "login_url": "https://shopbasebd.com/store/login",
    "config": {},
    "config_hash": "sha256"
  }
}
```

## Observation request

```json
{
  "status": "ok",
  "observed_at": "2026-10-21T00:00:00Z",
  "network_type": "wifi|cellular|ethernet|unknown",
  "connector_version": "0.2.0",
  "config_hash": "exact profile hash",
  "source_title": "supplier product title",
  "wholesale_price": "530.00",
  "suggested_price_max": null,
  "product_availability": "instock|outofstock|unknown",
  "stock_quantity": null,
  "sizes": ["M", "L"],
  "images": [{"url": "https://allowlisted/image.jpg", "sha256": "64 hex", "dhash": "64 bits", "index": 0}],
  "variants": [{"variation_id": 456, "supplier_sku": "supplier-code", "availability": "unknown", "wholesale_price": null, "reason": "supplier_page_did_not_expose_variant_stock"}],
  "evidence": [{"type": "page", "label": "Extraction", "value": "Phone fetched and parsed the authenticated supplier page."}]
}
```

`variants` claimed mapping-এর exact complete set হবে। Extra, duplicate, missing ID বা SKU mismatch পুরো request reject করবে। Observation সর্বোচ্চ 150 KB। `images` সর্বোচ্চ ২০, `sizes` ১০০, `variants` ২৫০। Image URL current platform HTTPS domain-এর হতে হবে।

Allowed result status: `ok`, `unavailable`, `unknown`, `login_required`, `account_restricted`, `product_removed`, `parse_unknown`, `rate_limited`।

## Failure request

```json
{"error_code":"scan_failed|login_required|captcha_required|account_restricted","message":"bounded safe detail"}
```

Transient failure ১৫ মিনিট, ১ ঘণ্টা, ৩ ঘণ্টা, ৬ ঘণ্টা backoff পায়; চার attempt-এর পরে failed। Login/CAPTCHA job paused; restricted job manual resume ছাড়া চলে না।

## Compatibility rule

- Server নতুন optional response field যোগ করতে পারে; app unknown field ignore করবে।
- Required field remove/rename করলে contract major version বাড়বে।
- Platform config বদলালে revision/hash বদলবে; stale app result 409 পাবে এবং profiles refresh করবে।
- Same job observation replay একই device থেকে এলে `duplicate=true` success response পাবে।
- Server কখনও job payload-এ supplier credential/cookie দেবে না; app কখনও observation-এ সেগুলো পাঠাবে না।
- App-এর Room retry row, platform cache, settings এবং supplier session local `siteId` দিয়ে partition হবে। একই job/platform ID অন্য connected site-এ থাকলেও data share হবে না।
