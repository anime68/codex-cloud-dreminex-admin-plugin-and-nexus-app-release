# Dreminex Suite 1.13.17 — Account pages

## কী বদলেছে

- My Account-এর Dashboard-এর সঙ্গে Orders, Downloads, Addresses, Billing/Shipping edit, Account details ও Order details-এ একই responsive style। Empty Orders ও Downloads message-এর text/button আলাদা করে পরিষ্কারভাবে দেখা যায়।
- Addresses-এর card ও action, Account details-এর input/password area এবং Orders-এর native table/mobile layout সাজানো হয়েছে। WooCommerce-এর saved data, field names, nonces, validation ও form submission বদলায়নি।
- `Dreminex Suite → All Modules → Accounts → Account experience & registration`-এ **Style the signed-in account pages** switch, প্রতিটি page-এর description এবং optional empty-orders illustration control আছে। আগের registration ও dashboard settings অক্ষত।

## Update ও staging পরীক্ষা

বিদ্যমান `dreminex-suite` plugin-এর উপর ZIP update দিন; plugin uninstall করবেন না। Backup রাখুন। আগের settings ও modules বজায় থাকবে; নতুন setting-এর default values তখনও দেখা যাবে যদি আগে save না করা হয়।

Staging-এ customer login করে Dashboard, Orders (empty/real), Downloads, Addresses, Billing/Shipping edit, Account details এবং একটি নিজের order detail দেখুন। ফোন, tablet ও desktop-এ horizontal overflow, PWA bottom bar এবং field visibility পরীক্ষা করুন। Save changes বা Save address পরীক্ষা করতে disposable customer data ব্যবহার করুন; অন্যের account data বদলাবেন না। Main site update করার আগে storefront visual QA শেষ করুন।
