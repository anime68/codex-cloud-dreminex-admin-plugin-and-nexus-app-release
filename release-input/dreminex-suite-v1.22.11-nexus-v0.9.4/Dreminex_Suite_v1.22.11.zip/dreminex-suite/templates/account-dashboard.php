<?php
/** WooCommerce My Account dashboard. Other account endpoints use Woo templates. */
defined('ABSPATH') || exit;

$cards=[
    ['orders','Orders','Track a new purchase or revisit a past one.','View orders','<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 15h4"/>'],
    ['edit-address','Addresses','Keep your delivery and billing details ready.','Manage addresses','<path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>'],
    ['edit-account','Account details','Update your profile, email and password.','Edit profile','<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'],
];
?>
<section class="dreminex-account-dashboard" aria-labelledby="dreminex-account-tools-title">
  <div class="dreminex-account-section-head"><div><span class="dreminex-account-section-kicker">ACCOUNT TOOLS</span><h3 id="dreminex-account-tools-title">What would you like to do?</h3></div><p>Choose a shortcut to get there.</p></div>
  <div class="dreminex-account-shortcuts">
  <?php foreach($cards as $card): ?>
    <a class="dreminex-account-shortcut" href="<?php echo esc_url(wc_get_account_endpoint_url($card[0])); ?>">
      <span class="dreminex-account-shortcut-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" focusable="false"><?php echo $card[4]; // Fixed local SVG paths. ?></svg></span>
      <strong><?php echo esc_html($card[1]); ?></strong><span class="dreminex-account-shortcut-desc"><?php echo esc_html($card[2]); ?></span><span class="dreminex-account-shortcut-action"><?php echo esc_html($card[3]); ?> <span aria-hidden="true">→</span></span>
    </a>
  <?php endforeach; ?>
  </div>
</section>
<?php
// Preserve extensions attached to WooCommerce's native dashboard lifecycle.
do_action('woocommerce_account_dashboard');
do_action('woocommerce_before_my_account');
do_action('woocommerce_after_my_account');
