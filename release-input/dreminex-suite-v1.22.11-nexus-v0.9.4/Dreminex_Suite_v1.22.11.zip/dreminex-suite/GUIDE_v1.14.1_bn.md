# Dreminex Suite 1.14.1 + Dreminex Nexus 0.2.0 — Install ও ব্যবহার

## Update করার আগে

1. Staging site-এর বর্তমান plugin/database backup রাখুন।
2. Plugin uninstall করবেন না; existing Dreminex Suite-কে ZIP দিয়ে replace/update করুন। OAuth ও Native MCP schema `1`-ই থাকে; এই update নতুন database column চায় না।
3. একই release signing key দিয়ে Android app update করলে app data clear করবেন না। 0.1.0 single-site data 0.2.0-এ প্রথম connected site হিসেবে migrate হবে। এই bundle-এর debug APK পুরোনো debug APK-এর signing key-এর সঙ্গে না মিললে Android আগে পুরোনো debug build uninstall করতে বলবে; তখন পুরোনো local app data থাকবে না।

## ChatGPT MCP connection

1. **Dreminex Suite → All Modules** থেকে Native MCP On রাখুন।
2. ChatGPT custom MCP server URL দিন: `https://YOUR-SITE/wp-json/mcp/dreminex`।
3. Authorization-এ **OAuth + DCR** ব্যবহার করুন। **OIDC Off** রাখুন।
4. WordPress consent page-এ scopes দেখে Approve করুন। নতুন client dashboard-এ Sandbox mode-এ থাকবে।
5. ChatGPT-এ tools দেখা এবং read ability চালানো যাচাই করুন। Sandbox write request preview হবে; product/site save হবে না।

`Unsupported OAuth scope: site:write` আর আসার কথা নয়। এলে Suite version 1.14.1, authorization metadata, DCR response এবং authorization request-এর exact scope যাচাই করুন।

## Nexus-এ ১–৫ website connect

1. Nexus 0.2.0 install/open করুন। প্রথম WordPress HTTPS URL দিয়ে secure pairing করুন।
2. WordPress approval page-এ code approve করুন।
3. Top bar switcher বা **Sites** screen থেকে **Connect website 2 of 5** ব্যবহার করুন।
4. একই site আবার দিলে duplicate হবে না; existing site select হবে। পাঁচটি হলে Add Site বন্ধ হবে।
5. Platforms login, Activity, network mode, automatic scan এবং pending কাজ selected site অনুযায়ী আলাদা থাকবে।

## Logo

Launcher-এ supplied DN mark দেখা যাবে। Android splash, pairing screen এবং Settings/About অংশে full Dreminex Nexus logo থাকবে।

## Staging verification

- ChatGPT DCR connect, consent, tools list এবং Sandbox read/write-preview।
- Nexus পুরোনো single-site migration।
- অন্তত দুই staging WordPress site connect করে site switch ও আলাদা platform session।
- আলাদা manual worker/notification এবং pending retry।
- Selected site disconnect করলে অন্য connection ও session অক্ষত।

পূর্ণ architecture ও future update rules:

- `DREMINEX_NATIVE_MCP_MODULE_A_TO_Z_HANDOFF_BN.md`
- `DREMINEX_NATIVE_MCP_OAUTH_A_TO_Z_HANDOFF_BN.md`
- `DREMINEX_NEXUS_ANDROID_A_TO_Z_HANDOFF_BN.md`
- `DREMINEX_NEXUS_MULTI_SITE_A_TO_Z_HANDOFF_BN.md`
- `DREMINEX_NEXUS_SUITE_INTEGRATION_CONTRACT_BN.md`
