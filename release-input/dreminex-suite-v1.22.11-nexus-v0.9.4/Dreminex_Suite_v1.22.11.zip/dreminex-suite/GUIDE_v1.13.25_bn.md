# Dreminex Suite 1.13.25 — supplier SKU

Staging-এ বর্তমান Suite-এর backup রেখে বিদ্যমান `dreminex-suite`-এর ওপর এই ZIP update করুন; Novamira connector, অন্য module বা existing product বদলাবেন না। PHP 8.3 ও বর্তমান WooCommerce-এর সঙ্গে staging-এ পরীক্ষা করে তারপর production release বিবেচনা করুন।

Preparation sheet-এ ছবিভিত্তিক supplier code স্পষ্ট থাকলে `Supplier SKU` এবং Publisher handoff-এর `images[].supplier_sku` দিন। একই entry-তে `images[].color` থাকা জরুরি। উদাহরণ: parent `DRX-SBB-OXBC-001`, Deep Purple `31651` হলে M, L, XL variation SKU যথাক্রমে `DRX-SBB-OXBC-001-31651-M`, `...-L`, `...-XL`। কেবল রঙ variation হলে `DRX-SBB-OXBC-001-31651`। কোড না থাকলে supplier-linked variation SKU তৈরি হয় না; parent SKU থাকে।

`dreminex-products/product-read` দিয়ে parent SKU, রঙ ও সাইজ, raw variation SKU, `supplier_sku`, variation image, price ও status যাচাই করুন। Conflict/partial হলে নতুন পণ্য নয়, একই product ID-তে সংশোধন করে `mode=update` দিন। কোনো live product স্বয়ংক্রিয়ভাবে migrate হবে না।

Rollback: আগের 1.13.24 ZIP সংরক্ষণ করুন। সমস্যা হলে staging-এ পূর্বের ZIP ফিরিয়ে দিন; পরিবর্তিত variation SKU থাকলে পৃথক verified readback করে ঠিক করুন। Production update-এর আগে staging ফল পর্যালোচনা প্রয়োজন।
