<?php
if (!defined('ABSPATH')) { exit; }
/* Dreminex | Customer order tracking and manual courier reference.
 * Separate PHP Code Snippets entry. Use WooCommerce's native tracking form
 * on the Track Your Order page (order number + billing email).
 */
if ( ! function_exists( 'dreminex_tracking_page_url' ) ) {
	function dreminex_tracking_page_url() {
		$assigned=(int)get_option('dreminex_suite_tracking_page',0);if($assigned&&get_post_status($assigned)==='publish')return get_permalink($assigned);
        $page = get_page_by_path( 'track-your-order' );
		return $page && 'publish' === $page->post_status ? get_permalink( $page ) : '';
	}
}
if ( ! function_exists( 'dreminex_tracking_meta_box' ) ) {
	function dreminex_tracking_meta_box( $object ) {
		$order = $object instanceof WC_Order ? $object : wc_get_order( $object->ID ?? 0 );
		if ( ! $order instanceof WC_Order ) return;
		wp_nonce_field( 'dreminex_save_tracking', 'dreminex_tracking_nonce' );
		$carrier = $order->get_meta( '_dreminex_courier' );
		$number = $order->get_meta( '_dreminex_courier_tracking' );
		echo '<p><label for="dreminex_courier">Courier</label><select id="dreminex_courier" name="dreminex_courier" style="width:100%">';
		foreach ( array( '' => 'Not assigned', 'pathao' => 'Pathao', 'steadfast' => 'Steadfast', 'other' => 'Other courier' ) as $value => $label ) echo '<option value="' . esc_attr( $value ) . '" ' . selected( $carrier, $value, false ) . '>' . esc_html( $label ) . '</option>';
		echo '</select></p><p><label for="dreminex_tracking_number">Courier consignment / tracking number</label><input id="dreminex_tracking_number" name="dreminex_tracking_number" value="' . esc_attr( $number ) . '" style="width:100%" maxlength="80"></p>';
		echo Dreminex_Suite_Control::tr("<p>After booking with the courier, enter the real reference and update the order. A customer-note email is sent when its feature switch is On.</p>", '<p>কুরিয়ারে বুকিংয়ের পর আসল নম্বরটি লিখে অর্ডার Update করুন। তখন গ্রাহককে একটি customer note email যাবে।</p>');
	}
}
add_action( 'add_meta_boxes', function () {
	$screen = \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ? 'woocommerce_page_wc-orders' : 'shop_order';
	add_meta_box( 'dreminex-tracking', 'Dreminex · Courier tracking', 'dreminex_tracking_meta_box', $screen, 'side', 'default' );
} );
add_action( 'woocommerce_process_shop_order_meta', function ( $order_id ) {
	if ( ! current_user_can( 'manage_woocommerce' ) || ! isset( $_POST['dreminex_tracking_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['dreminex_tracking_nonce'] ) ), 'dreminex_save_tracking' ) ) return;
	$order = wc_get_order( $order_id );
	if ( ! $order instanceof WC_Order || 'shop_order' !== $order->get_type() ) return;
	$allowed = array( '', 'pathao', 'steadfast', 'other' );
	$carrier = isset( $_POST['dreminex_courier'] ) ? sanitize_key( wp_unslash( $_POST['dreminex_courier'] ) ) : '';
	if ( ! in_array( $carrier, $allowed, true ) ) $carrier = '';
	$number = isset( $_POST['dreminex_tracking_number'] ) ? sanitize_text_field( wp_unslash( $_POST['dreminex_tracking_number'] ) ) : '';
	$number = substr( $number, 0, 80 );
	$old = (string) $order->get_meta( '_dreminex_courier_tracking' );
	$order->update_meta_data( '_dreminex_courier', $carrier );
	$order->update_meta_data( '_dreminex_courier_tracking', $number );
	$order->save();
	if ( Dreminex_Suite_Features::enabled('order_tracking','change_email') && $number && $number !== $old && is_email( $order->get_billing_email() ) ) {
		$labels = array( 'pathao' => 'Pathao', 'steadfast' => 'Steadfast', 'other' => 'Courier' );
		$note = Dreminex_Suite_Control::tr("Your order #", 'আপনার অর্ডার #') . $order->get_order_number() . Dreminex_Suite_Control::tr(" Courier tracking number: ", ' কুরিয়ার ট্র্যাকিং নম্বর: ') . $number . Dreminex_Suite_Control::tr(". Courier: ", '. কুরিয়ার: ') . ( $labels[ $carrier ] ?? 'Courier' ) . '. ';
		$url = dreminex_tracking_page_url();
		if ( $url ) $note .= Dreminex_Suite_Control::tr("Check order status: ", 'অর্ডারের অবস্থা দেখতে: ') . $url;
		$order->add_order_note( $note, 1 );
	}
}, 45 );
add_action( 'woocommerce_email_after_order_table', function ( $order, $sent_to_admin, $plain_text ) {
    if(!Dreminex_Suite_Features::enabled('order_tracking','email_details'))return;
	if ( $sent_to_admin || ! $order instanceof WC_Order ) return;
	$url = dreminex_tracking_page_url();
	if ( ! $url ) return;
	$number = $order->get_meta( '_dreminex_courier_tracking' );
	$text = Dreminex_Suite_Control::tr("To track order #", 'অর্ডার ট্র্যাক করতে অর্ডার নম্বর #') . $order->get_order_number() . Dreminex_Suite_Control::tr(" use the billing email entered at checkout.", ' এবং checkout-এ দেওয়া billing email ব্যবহার করুন।');
	if ( $number ) $text .= Dreminex_Suite_Control::tr(" Courier tracking number: ", ' কুরিয়ার ট্র্যাকিং নম্বর: ') . $number . '.';
	if ( $plain_text ) echo "\n" . $text . "\n" . $url . "\n";
	else echo '<p>' . esc_html( $text ) . ' <a href="' . esc_url( $url ) . Dreminex_Suite_Control::tr("\">Track your order</a></p>", '">অর্ডার ট্র্যাক করুন</a></p>');
}, 20, 3 );

/** Encrypted provider credential vault for optional courier adapters. */
final class Dreminex_Suite_Courier_Connections {
 private static function secret_key(){return hash('sha256',wp_salt('auth').'|dreminex-suite-courier-v1',true);}
 private static function encrypt($data){if(!function_exists('openssl_encrypt'))return new WP_Error('crypto','OpenSSL is required to save courier credentials.');$iv=random_bytes(12);$tag='';$plain=wp_json_encode($data);$cipher=openssl_encrypt($plain,'aes-256-gcm',self::secret_key(),OPENSSL_RAW_DATA,$iv,$tag,'dreminex-courier');if($cipher===false)return new WP_Error('crypto','Could not encrypt courier credentials.');return base64_encode($iv.$tag.$cipher);}
 private static function decrypt($blob){$raw=base64_decode((string)$blob,true);if(!$raw||strlen($raw)<29||!function_exists('openssl_decrypt'))return [];$json=openssl_decrypt(substr($raw,28),'aes-256-gcm',self::secret_key(),OPENSSL_RAW_DATA,substr($raw,0,12),substr($raw,12,16),'dreminex-courier');$data=$json?json_decode($json,true):[];return is_array($data)?$data:[];}
 private static function providers(){return ['pathao'=>['label'=>'Pathao','fields'=>['client_id'=>'Client ID','client_secret'=>'Client secret','username'=>'Merchant email/username','password'=>'Merchant password']],'steadfast'=>['label'=>'Steadfast','fields'=>['api_key'=>'API key','secret_key'=>'Secret key']]];}
 public static function panel($module){if($module!=='order_management'||!current_user_can('manage_options'))return;$profiles=(array)get_option('dreminex_courier_api_profiles',[]);$vault=(array)get_option('dreminex_courier_api_secrets',[]);
  echo '<section class="ds-courier-connections"><h3>Courier API credentials</h3><p>Encrypted credentials are stored on this site and never displayed again. Connection state means “saved”; no automatic consignment will be created until a provider-specific, official API adapter is installed and authenticated. Manual tracking references continue to work.</p>';
  foreach(self::providers() as $id=>$provider){$profile=(array)($profiles[$id]??[]);$saved=(bool)($vault[$id]??'');echo '<div class="card"><h4>'.esc_html($provider['label']).'</h4><p><strong>Status:</strong> '.esc_html(!empty($profile['enabled'])?'Enabled; awaiting adapter authentication':($saved?'Saved; disabled':'Not configured')).'</p>';
   echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_courier_connection"><input type="hidden" name="provider" value="'.esc_attr($id).'"><input type="hidden" name="operation" value="save">';wp_nonce_field('dreminex_courier_'.$id);
   foreach($provider['fields'] as $name=>$label){$is_secret=preg_match('/secret|password|key/i',$name);echo '<p><label>'.esc_html($label).' <input class="regular-text" type="'.($is_secret?'password':'text').'" name="credentials['.esc_attr($name).']" value="" autocomplete="new-password" placeholder="'.esc_attr($saved?'Saved; leave blank to keep':'Not saved').'" '.($saved?'':'required').'></label></p>';}
   echo '<p><label><input type="checkbox" name="enabled" value="1" '.checked(!empty($profile['enabled']),true,false).'> Enable this saved profile</label></p>';submit_button('Save credentials','primary','submit',false);echo '</form>';
   if($saved){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_courier_connection"><input type="hidden" name="provider" value="'.esc_attr($id).'"><input type="hidden" name="operation" value="delete">';wp_nonce_field('dreminex_courier_'.$id);submit_button('Delete credentials','delete','submit',false);echo '</form>';}
   echo '</div>';
  }
  echo '<p><a href="https://merchant.pathao.com/" target="_blank" rel="noopener">Open Pathao Merchant API settings</a> · <a href="https://steadfast.com.bd/login" target="_blank" rel="noopener">Open Steadfast merchant account</a></p><p class="description">Pathao’s official help confirms that website integration is configured through its merchant Developer API. Steadfast advertises an API, but its public official pages do not provide the endpoint/authentication contract. This screen therefore never probes guessed URLs or sends customer/order details.</p></section>';
 }
 public static function handle(){if(!current_user_can('manage_options'))wp_die('Access denied.',403);$id=sanitize_key(wp_unslash($_POST['provider']??''));$providers=self::providers();if(!isset($providers[$id]))wp_die('Unknown courier provider.',400);check_admin_referer('dreminex_courier_'.$id);$profiles=(array)get_option('dreminex_courier_api_profiles',[]);$vault=(array)get_option('dreminex_courier_api_secrets',[]);$op=sanitize_key(wp_unslash($_POST['operation']??''));
  if($op==='delete'){unset($profiles[$id],$vault[$id]);update_option('dreminex_courier_api_profiles',$profiles,false);update_option('dreminex_courier_api_secrets',$vault,false);}
  elseif($op==='save'){$old=self::decrypt($vault[$id]??'');$input=is_array($_POST['credentials']??null)?wp_unslash($_POST['credentials']):[];$data=[];foreach($providers[$id]['fields'] as $name=>$label){$value=$input[$name]??'';if(!is_string($value)||strlen($value)>8192)wp_die('Invalid credential value.',400);$value=trim($value);$data[$name]=$value!==''?$value:(string)($old[$name]??'');if($data[$name]==='')wp_die('Complete each required credential before saving.',400);}
   $sealed=self::encrypt($data);if(is_wp_error($sealed))wp_die(esc_html($sealed->get_error_message()),400);$vault[$id]=$sealed;$profiles[$id]=['enabled'=>!empty($_POST['enabled']),'saved_at'=>time(),'connection_state'=>'unverified'];update_option('dreminex_courier_api_secrets',$vault,false);update_option('dreminex_courier_api_profiles',$profiles,false);
  }else wp_die('Unknown operation.',400);
  Dreminex_Suite_Cache::changed('order_management',true);wp_safe_redirect(admin_url('admin.php?page=dreminex-suite&module=order_management&courier_saved=1'));exit;
 }
}
add_action('dreminex_suite_module_panel',[Dreminex_Suite_Courier_Connections::class,'panel'],12);
add_action('admin_post_dreminex_courier_connection',[Dreminex_Suite_Courier_Connections::class,'handle']);
