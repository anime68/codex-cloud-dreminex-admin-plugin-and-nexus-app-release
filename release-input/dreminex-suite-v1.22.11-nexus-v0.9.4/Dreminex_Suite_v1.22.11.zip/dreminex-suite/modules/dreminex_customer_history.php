<?php
if (!defined('ABSPATH')) { exit; }
/* Dreminex | Customer order history in the order screen and order list.
 * Uses billing phone and WooCommerce CRUD, compatible with HPOS and legacy.
 * Completed ratio = completed orders divided by all placed orders.
 */
if ( ! function_exists( 'dreminex_history_phone' ) ) {
	function dreminex_history_phone( $value ) {
		$digits = preg_replace( '/\D+/', '', (string) $value );
		if (function_exists('WC') && WC()->countries && WC()->countries->get_base_country() !== 'BD') return preg_match('/^[0-9]{8,15}$/D',$digits) ? $digits : '';
		if ( 13 === strlen( $digits ) && 0 === strpos( $digits, '880' ) ) $digits = '0' . substr( $digits, 3 );
		if ( 10 === strlen( $digits ) && '1' === $digits[0] ) $digits = '0' . $digits;
		return preg_match( '/^01[3-9][0-9]{8}$/D', $digits ) ? $digits : '';
	}
}
if ( ! function_exists( 'dreminex_history_orders' ) ) {
	function dreminex_history_orders( $phone ) {
		static $cache = array();
		$original_phone=(string)$phone;
		$phone = dreminex_history_phone( $phone );
		if ( ! $phone ) return array();
		if ( isset( $cache[ $phone ] ) ) return $cache[ $phone ];
		$ids = array();
		foreach ( array_unique( WC()->countries->get_base_country()==='BD' ? array($original_phone,$phone,'+880'.substr($phone,1),'880'.substr($phone,1)) : array($original_phone,$phone,'+'.$phone) ) as $variant ) {
			foreach ( wc_get_orders( array( 'type' => 'shop_order', 'billing_phone' => $variant, 'limit' => -1, 'return' => 'ids' ) ) as $id ) $ids[ (int) $id ] = true;
		}
		$orders = array();
		foreach ( array_keys( $ids ) as $id ) {
			$order = wc_get_order( $id );
			if ( $order instanceof WC_Order && 'shop_order' === $order->get_type() ) $orders[] = $order;
		}
		usort( $orders, function ( $a, $b ) {
			return ( $b->get_date_created() ? $b->get_date_created()->getTimestamp() : 0 ) <=> ( $a->get_date_created() ? $a->get_date_created()->getTimestamp() : 0 );
		} );
		$cache[ $phone ] = $orders;
		return $orders;
	}
}
if ( ! function_exists( 'dreminex_history_summary' ) ) {
	function dreminex_history_summary( $orders ) {
		$result = array( 'total' => count( $orders ), 'confirmed' => 0, 'completed' => 0, 'cancelled' => 0, 'by_status' => array() );
		$confirmed = array( 'processing', 'completed', 'advance-verified', 'packing', 'ready-to-ship', 'pickup-requested', 'picked-up', 'shipped', 'in-transit', 'at-hub', 'out-for-delivery', 'attempted', 'courier-hold', 'courier-review', 'partial-delivered', 'delivery-failed', 'delivered', 'return-requested', 'return-in-transit', 'returned-sender', 'returned' );
		foreach ( $orders as $order ) {
			$status = $order->get_status();
			$result['by_status'][ $status ] = ( $result['by_status'][ $status ] ?? 0 ) + 1;
			if ( in_array( $status, $confirmed, true ) ) ++$result['confirmed'];
			if ( 'completed' === $status ) ++$result['completed'];
			if ( 'cancelled' === $status ) ++$result['cancelled'];
		}
		$result['ratio'] = $result['total'] ? round( 100 * $result['completed'] / $result['total'] ) : 0;
		return $result;
	}
}
if ( ! function_exists( 'dreminex_history_box' ) ) {
	function dreminex_history_box( $object ) {
		$order = $object instanceof WC_Order ? $object : wc_get_order( $object->ID ?? 0 );
		if ( ! $order instanceof WC_Order || ! current_user_can( 'manage_woocommerce' ) ) return;
		$orders = dreminex_history_orders( $order->get_billing_phone() );
		$summary = dreminex_history_summary( $orders );
		echo '<p><strong>' . esc_html( $summary['total'] <= 1 ? 'New customer' : 'Returning customer' ) . '</strong></p>';
		echo '<p><strong>' . esc_html( $summary['total'] ) . ' orders · ' . esc_html( $summary['confirmed'] ) . ' confirmed · ' . esc_html( $summary['completed'] ) . ' completed · ' . esc_html( $summary['cancelled'] ) . ' cancelled</strong></p>';
		echo '<p>This store completed ratio: <strong>' . esc_html( $summary['ratio'] ) . '%</strong> (completed / total)</p>';
		if ( ! $orders ) { echo Dreminex_Suite_Control::tr("<p>No earlier orders found for this phone number.</p>", '<p>এই নম্বরে আগের অর্ডার পাওয়া যায়নি।</p>'); return; }
		echo '<p><strong>Status breakdown</strong></p><ul>';
		foreach ( $summary['by_status'] as $status => $count ) echo '<li>' . esc_html( wc_get_order_status_name( $status ) ) . ': ' . esc_html( $count ) . '</li>';
		echo '</ul><p><strong>Recent orders</strong></p><div style="max-height:280px;overflow:auto"><table class="widefat striped"><thead><tr><th>Order</th><th>Status</th><th>Date</th></tr></thead><tbody>';
		foreach ( array_slice( $orders, 0, 15 ) as $item ) {
			echo '<tr><td><a href="' . esc_url( $item->get_edit_order_url() ) . '">#' . esc_html( $item->get_order_number() ) . '</a></td><td>' . esc_html( wc_get_order_status_name( $item->get_status() ) ) . '</td><td>' . esc_html( $item->get_date_created() ? wc_format_datetime( $item->get_date_created(), 'd M Y' ) : '—' ) . '</td></tr>';
		}
		echo Dreminex_Suite_Control::tr("</tbody></table></div><p><small>This shows orders from this store only. History from other stores requires a separate courier API connection.</small></p>", '</tbody></table></div><p><small>এখানে শুধু এই সাইটের অর্ডার দেখানো হয়; কুরিয়ারের অন্য দোকানের ইতিহাস দেখাতে আলাদা API সংযোগ দরকার।</small></p>');
	}
}
add_action( 'add_meta_boxes', function () {
    if(!Dreminex_Suite_Features::enabled('customer_history','detail_box'))return;
	$screen = \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ? 'woocommerce_page_wc-orders' : 'shop_order';
	add_meta_box( 'dreminex-customer-history', 'Dreminex · Customer order history', 'dreminex_history_box', $screen, 'side', 'default' );
} );
if ( ! function_exists( 'dreminex_history_list_columns' ) ) {
	function dreminex_history_list_columns( $columns ) {
    if(!Dreminex_Suite_Features::enabled('customer_history','list_column'))return $columns;
		$columns['dreminex_customer_type'] = 'Customer';
		$columns['dreminex_customer_history'] = 'This store history';
		return $columns;
	}
}
// HPOS uses this WooCommerce filter, not manage_woocommerce_page_wc-orders_columns.
add_filter( 'woocommerce_shop_order_list_table_columns', 'dreminex_history_list_columns', 20 );
add_filter( 'manage_edit-shop_order_columns', 'dreminex_history_list_columns', 20 );

if ( ! function_exists( 'dreminex_history_list_cell' ) ) {
	function dreminex_history_list_cell( $column, $order ) {
		if ( ! in_array( $column, array( 'dreminex_customer_type', 'dreminex_customer_history' ), true ) || ! $order instanceof WC_Order || 'shop_order' !== $order->get_type() ) return;
		$summary = dreminex_history_summary( dreminex_history_orders( $order->get_billing_phone() ) );
		if ( ! $summary['total'] ) { echo '<span aria-label="No matching order history">—</span>'; return; }
		if ( 'dreminex_customer_type' === $column ) {
			$label = $summary['total'] <= 1 ? 'New customer' : 'Returning customer';
			echo '<div class="dreminex-history-cell"><a href="' . esc_url( $order->get_edit_order_url() . '#dreminex-customer-history' ) . '"><strong>' . esc_html( $label ) . '</strong></a>';
			echo '<div>' . esc_html( $summary['total'] . ' orders · ' . $summary['confirmed'] . ' confirmed' ) . '</div></div>';
			return;
		}
		$completed_width = 100 * $summary['completed'] / $summary['total'];
		$cancelled_width = 100 * $summary['cancelled'] / $summary['total'];
		echo '<div class="dreminex-history-cell">';
		echo '<div>' . esc_html( 'All: ' . $summary['total'] . ' · Confirmed: ' . $summary['confirmed'] ) . '</div>';
		echo '<div>' . esc_html( 'Completed: ' . $summary['completed'] . ' · Cancelled: ' . $summary['cancelled'] ) . '</div>';
		echo '<div class="dreminex-history-bar" role="img" aria-label="' . esc_attr( 'Completed ratio: ' . $summary['ratio'] . '%; cancelled: ' . $summary['cancelled'] ) . '"><span class="dreminex-history-success" style="width:' . esc_attr( round( $completed_width, 2 ) ) . '%"></span><span class="dreminex-history-cancelled" style="width:' . esc_attr( round( $cancelled_width, 2 ) ) . '%"></span></div>';
		echo '<strong>' . esc_html( $summary['ratio'] ) . '% completed here</strong></div>';
	}
}
add_action( 'woocommerce_shop_order_list_table_custom_column', 'dreminex_history_list_cell', 10, 2 );
add_action( 'manage_shop_order_posts_custom_column', function ( $column, $post_id ) {
	if ( in_array( $column, array( 'dreminex_customer_type', 'dreminex_customer_history' ), true ) ) dreminex_history_list_cell( $column, wc_get_order( $post_id ) );
}, 10, 2 );

add_action( 'admin_head', function () {
	$screen = get_current_screen();
	if ( ! $screen || ! in_array( $screen->id, array( 'woocommerce_page_wc-orders', 'edit-shop_order' ), true ) ) return;
	echo Dreminex_Suite_Setup::text('<style>.column-dreminex_customer_history{width:175px}.column-dreminex_customer_type{width:150px}.dreminex-history-cell{min-width:125px;line-height:1.5}.dreminex-history-cell a{color:#212529}.dreminex-history-bar{display:flex;width:100%;height:10px;background:#e6e8ea;border-radius:4px;overflow:hidden;margin:6px 0}.dreminex-history-success{background:#00b4d8}.dreminex-history-cancelled{background:#d63638}</style>');
} );
