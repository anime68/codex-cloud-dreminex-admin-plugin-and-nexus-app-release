<?php
defined('ABSPATH') || exit;

/**
 * Storefront presentation belongs to Suite; the PWA remains an install shell.
 * Settings are stored with Suite module data so backups and resets include them.
 */
final class Dreminex_Storefront_Design {
    private const KEY = 'storefront_design';

    private static function defaults() {
        return [
            'metadata' => 1, 'variations' => 1, 'descriptions' => 1,
            'titles' => 1, 'cart' => 1, 'quantity' => 1, 'tag_limit' => 4,
            'accent' => '#007D96', 'swatch_size' => 38,
            'size_preset' => 'balanced', 'description_desktop' => 400,
            'description_tablet' => 340, 'description_mobile' => 300,
            'mobile_title' => 24,
            'journey_titles' => 1, 'archive_filters' => 1,
            'cart_checkout' => 1, 'saved_lists' => 1,
            'contact_cleanup' => 1, 'product_cards' => 1, 'quick_view' => 1,
            'discount_badges' => 1, 'badge_shine' => 1, 'badge_period' => 6,
            'badge_radius' => 8, 'badge_bg' => '#CAF0F8', 'badge_text' => '#007D96',
            'badge_x' => 5, 'badge_y' => 5, 'badge_pad_x' => 10, 'badge_pad_y' => 5,
            'badge_font_size' => 15, 'bangla_font' => 'noto',
            'product_card_bg' => '#DEE2E6', 'product_card_radius' => 16,
            'product_card_padding' => 12, 'product_card_image_bg' => '#DEE2E6', 'quick_view_width' => 1200,
            'quick_view_gap' => 24, 'quick_view_image_bg' => '#F8F9FA',
            'shop_heading' => 'Shop',
        ];
    }

    public static function settings() {
        $all = get_option('dreminex_suite_module_settings', []);
        $stored = is_array($all) && isset($all[self::KEY]) && is_array($all[self::KEY]) ? $all[self::KEY] : [];
        $settings = array_replace(self::defaults(), $stored);
        $settings['accent'] = self::normalize_accent($settings['accent']) ?: self::defaults()['accent'];
        foreach (['product_card_bg', 'product_card_image_bg', 'quick_view_image_bg', 'badge_bg', 'badge_text'] as $key) {
            $settings[$key] = self::normalize_accent($settings[$key]) ?: self::defaults()[$key];
        }
        return $settings;
    }

    /** Only opaque CSS HEX colours may enter the frontend custom properties. */
    public static function normalize_accent($value) {
        if (!is_string($value)) return '';
        $value = trim($value);
        if (!preg_match('/^#?([a-f0-9]{3}|[a-f0-9]{6})$/iD', $value, $match)) return '';
        return '#' . strtoupper($match[1]);
    }

    private static function accent_tokens($accent) {
        $hex = substr($accent, 1);
        if (strlen($hex) === 3) $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        $rgb = array_map('hexdec', str_split($hex, 2));
        $luminance = static function ($channels) {
            $linear = array_map(static function ($channel) {
                $value = $channel / 255;
                return $value <= 0.04045 ? $value / 12.92 : pow(($value + 0.055) / 1.055, 2.4);
            }, $channels);
            return 0.2126 * $linear[0] + 0.7152 * $linear[1] + 0.0722 * $linear[2];
        };
        $ink = $luminance($rgb) > 0.179 ? '#000000' : '#FFFFFF';
        $link = $rgb;
        for ($i = 0; $i < 30 && $luminance($link) > 0.18; $i++) {
            $link = array_map(static fn($channel) => (int) floor($channel * 0.9), $link);
        }
        $soft = array_map(static fn($channel) => (int) round(255 * 0.85 + $channel * 0.15), $rgb);
        return [
            'ink' => $ink,
            'link' => sprintf('#%02X%02X%02X', ...$link),
            'soft' => sprintf('#%02X%02X%02X', ...$soft),
        ];
    }

    public static function enabled() {
        $modules = get_option('dreminex_suite_modules', []);
        return is_array($modules) && !empty($modules[self::KEY]);
    }

    public static function boot() {
        require_once DREMINEX_SUITE_PATH . 'includes/class-dreminex-homepage-design.php';
        Dreminex_Homepage_Design::boot();
        add_action('dreminex_suite_module_panel', [__CLASS__, 'panel'], 30);
        add_action('admin_post_dreminex_design_save', [__CLASS__, 'save']);
        if (!self::enabled()) return;
        add_action('wp_enqueue_scripts', [__CLASS__, 'assets'], 30);
        add_filter('body_class', [__CLASS__, 'body_classes']);
        add_filter('elementor/frontend/builder_content_data', [__CLASS__, 'use_full_description'], 10, 2);
        add_filter('elementor/frontend/the_content', [__CLASS__, 'clean_contact_copy'], 30);
        add_action('wp', [__CLASS__, 'shop_heading'], 30);
    }

    public static function assets() {
        $s = self::settings();
        $base = plugin_dir_url(DREMINEX_SUITE_PATH . 'dreminex-suite.php') . 'assets/';
        $colors = self::accent_tokens($s['accent']);
        wp_register_style('dreminex-storefront-accent', false, [], DREMINEX_SUITE_VERSION);
        wp_enqueue_style('dreminex-storefront-accent');
        wp_add_inline_style('dreminex-storefront-accent', sprintf(
            ':root{--dreminex-design-accent:%s;--dreminex-design-accent-ink:%s;--dreminex-design-accent-link:%s;--dreminex-design-accent-soft:%s}',
            $s['accent'], $colors['ink'], $colors['link'], $colors['soft']
        ));
        $parts = [
            'metadata' => 'storefront-metadata.css',
            'variations' => 'storefront-variations.css',
            'descriptions' => 'storefront-descriptions.css',
            'titles' => 'storefront-titles.css',
            'cart' => 'storefront-cart.css',
            'quantity' => 'storefront-quantity.css',
        ];
        foreach ($parts as $key => $file) {
            if (!$s[$key]) continue;
            $handle = 'dreminex-storefront-' . $key;
            wp_enqueue_style($handle, $base . $file, [], DREMINEX_SUITE_VERSION);
            if ($key === 'variations') {
                $sizes = ['compact' => [42, 36], 'balanced' => [46, 40], 'large' => [50, 44]];
                [$width, $height] = $sizes[$s['size_preset']] ?? $sizes['balanced'];
                wp_add_inline_style($handle, sprintf(
                    ':root{--dreminex-swatch-size:%dpx;--dreminex-size-width:%dpx;--dreminex-size-height:%dpx}',
                    (int) $s['swatch_size'], $width, $height
                ));
            }
            if ($key === 'descriptions' || $key === 'titles') {
                $variables = sprintf(
                    ':root{--dreminex-desc-desktop:%dpx;--dreminex-desc-tablet:%dpx;--dreminex-desc-mobile:%dpx;--dreminex-mobile-title:%dpx}',
                    (int) $s['description_desktop'], (int) $s['description_tablet'],
                    (int) $s['description_mobile'], (int) $s['mobile_title']
                );
                wp_add_inline_style($handle, $variables);
            }
        }
        if ($s['metadata']) {
            $handle = 'dreminex-storefront-metadata';
            wp_enqueue_script($handle, $base . 'storefront-metadata.js', [], DREMINEX_SUITE_VERSION, true);
            wp_add_inline_script($handle, 'window.DreminexStorefrontDesign=' . wp_json_encode(['tagLimit' => (int) $s['tag_limit']]) . ';', 'before');
        }
        $journey = self::is_journey_page();
        if ($s['journey_titles'] && $journey) self::style($base, 'storefront-journey-titles.css');
        if ($s['archive_filters'] && function_exists('is_shop') && (is_shop() || is_product_taxonomy())) {
            self::style($base, 'storefront-archive-filters.css');
            wp_enqueue_script('dreminex-storefront-archive-filters', $base . 'storefront-archive-filters.js', [], DREMINEX_SUITE_VERSION, true);
        }
        if ($s['bangla_font'] === 'noto') self::style($base, 'storefront-bangla-font.css');
        if (($s['product_cards'] || $s['quick_view'] || $s['discount_badges']) && (is_front_page() || (function_exists('is_woocommerce') && is_woocommerce()))) {
            $handle = 'dreminex-storefront-product-surfaces';
            wp_enqueue_style($handle, $base . 'storefront-product-surfaces.css', [], DREMINEX_SUITE_VERSION);
            wp_add_inline_style($handle, sprintf(
                ':root{--dreminex-product-card-bg:%s;--dreminex-product-card-image-bg:%s;--dreminex-product-card-radius:%dpx;--dreminex-product-card-padding:%dpx;--dreminex-badge-bg:%s;--dreminex-badge-text:%s;--dreminex-badge-radius:%dpx;--dreminex-badge-period:%ds;--dreminex-badge-x:%dpx;--dreminex-badge-y:%dpx;--dreminex-badge-pad-x:%dpx;--dreminex-badge-pad-y:%dpx;--dreminex-badge-font-size:%dpx;--dreminex-quick-view-width:%dpx;--dreminex-quick-view-gap:%dpx;--dreminex-quick-view-image-bg:%s}',
                $s['product_card_bg'], $s['product_card_image_bg'], (int) $s['product_card_radius'], (int) $s['product_card_padding'], $s['badge_bg'], $s['badge_text'], (int) $s['badge_radius'], (int) $s['badge_period'],
                (int) $s['badge_x'], (int) $s['badge_y'], (int) $s['badge_pad_x'], (int) $s['badge_pad_y'], (int) $s['badge_font_size'],
                (int) $s['quick_view_width'], (int) $s['quick_view_gap'], $s['quick_view_image_bg']
            ));
        }
        if ($s['cart_checkout'] && function_exists('is_cart') && (is_cart() || is_checkout() || is_page('track-your-order'))) {
            self::style($base, 'storefront-cart-checkout.css');
        }
        if ($s['saved_lists'] && is_page(['wishlist-2', 'compare-2'])) self::style($base, 'storefront-saved-lists.css');
    }

    private static function style($base, $file) {
        wp_enqueue_style('dreminex-' . str_replace('.css', '', $file), $base . $file, [], DREMINEX_SUITE_VERSION);
    }

    private static function is_journey_page() {
        return (function_exists('is_woocommerce') && is_woocommerce()) ||
            (function_exists('is_cart') && (is_cart() || is_checkout() || is_account_page())) ||
            is_page(['wishlist-2', 'compare-2', 'track-your-order', 'contact', 'about-us', 'faqs',
                'shipping-policy', 'return-refund-policy', 'privacy-policy', 'blog']);
    }

    public static function body_classes($classes) {
        $s = self::settings();
        if ($s['journey_titles'] && self::is_journey_page()) $classes[] = 'dreminex-journey-titles';
        if ($s['product_cards'] && (is_front_page() || (function_exists('is_woocommerce') && is_woocommerce()))) $classes[] = 'dreminex-product-cards';
        if (function_exists('is_woocommerce') && is_woocommerce()) {
            if ($s['quick_view']) $classes[] = 'dreminex-quick-view';
        }
        if ($s['discount_badges']) $classes[] = 'dreminex-discount-badges';
        if ($s['badge_shine']) $classes[] = 'dreminex-badge-shine';
        if ($s['bangla_font'] === 'noto') $classes[] = 'dreminex-bangla-type';
        if ($s['saved_lists'] && is_page(['wishlist-2', 'compare-2'])) $classes[] = 'dreminex-saved-list-page';
        if ($s['cart_checkout'] && function_exists('is_cart') && is_cart() && function_exists('WC') && WC()->cart && WC()->cart->is_empty()) {
            $classes[] = 'dreminex-cart-empty';
        }
        return $classes;
    }

    public static function clean_contact_copy($html) {
        if (!is_string($html) || !self::settings()['contact_cleanup'] || is_admin() || wp_doing_ajax() || !is_page('contact')) return $html;
        return str_replace('List title put here ', '', $html);
    }

    public static function shop_heading() {
        $s = self::settings();
        $theme = 'RT\\Sbmart\\Options\\Opt';
        if (empty($s['journey_titles']) || !function_exists('is_shop') || !is_shop() ||
            !class_exists($theme) || !property_exists($theme, 'options') ||
            ($theme::$options['rt_shop_banner_single_title'] ?? '') !== 'Shop Page') return;
        // The theme reads this static value directly in its banner template.
        // Change only the current response; preserve the site's theme option.
        $theme::$options['rt_shop_banner_single_title'] = $s['shop_heading'];
    }

    public static function use_full_description($elements, $template_id) {
        if (!self::settings()['descriptions'] || is_admin() || wp_doing_ajax()
            || !function_exists('is_product') || !is_product()
            || get_post_type($template_id) !== 'rtsb_builder'
            || get_post_meta($template_id, 'rtsb_tb_template_type', true) !== 'product') return $elements;
        $product = function_exists('wc_get_product') ? wc_get_product(get_queried_object_id()) : false;
        if (!$product || trim($product->get_description()) === '') return $elements;
        return self::replace_short_description($elements);
    }

    private static function replace_short_description($elements) {
        if (!is_array($elements)) return $elements;
        foreach ($elements as &$element) {
            if (!is_array($element)) continue;
            if (($element['elType'] ?? '') === 'widget' && ($element['widgetType'] ?? '') === 'rtsb-short-description') {
                $element['widgetType'] = 'rtsb-product-description';
            }
            if (!empty($element['elements'])) $element['elements'] = self::replace_short_description($element['elements']);
        }
        unset($element);
        return $elements;
    }

    public static function save() {
        if (!current_user_can('manage_options')) wp_die('Access denied.', 403);
        check_admin_referer('dreminex_design_save');
        $input = isset($_POST['design']) && is_array($_POST['design']) ? wp_unslash($_POST['design']) : [];
        $s = self::defaults();
        foreach (['metadata', 'variations', 'descriptions', 'titles', 'cart', 'quantity',
            'journey_titles', 'archive_filters', 'cart_checkout', 'saved_lists', 'contact_cleanup',
            'product_cards', 'quick_view', 'discount_badges', 'badge_shine'] as $key) $s[$key] = empty($input[$key]) ? 0 : 1;
        foreach (['tag_limit' => [1, 12], 'swatch_size' => [28, 48],
            'description_desktop' => [180, 800], 'description_tablet' => [180, 700],
            'description_mobile' => [180, 600], 'mobile_title' => [18, 34]] as $key => $range) {
            $s[$key] = min($range[1], max($range[0], absint($input[$key] ?? $s[$key])));
        }
        foreach (['product_card_radius' => [0, 28], 'product_card_padding' => [8, 24], 'badge_radius' => [0, 24], 'badge_period' => [4, 12],
            'badge_x' => [0, 30], 'badge_y' => [0, 30], 'badge_pad_x' => [4, 20], 'badge_pad_y' => [2, 12], 'badge_font_size' => [11, 20],
            'quick_view_width' => [760, 1480], 'quick_view_gap' => [8, 48]] as $key => $range) {
            $s[$key] = min($range[1], max($range[0], absint($input[$key] ?? $s[$key])));
        }
        $s['accent'] = self::normalize_accent($input['accent'] ?? '');
        if ($s['accent'] === '') wp_die('Enter a valid HEX colour, such as #00B4D7 or #0BD.', 'Invalid accent colour', ['response' => 400, 'back_link' => true]);
        foreach (['product_card_bg', 'product_card_image_bg', 'quick_view_image_bg', 'badge_bg', 'badge_text'] as $key) {
            $s[$key] = self::normalize_accent($input[$key] ?? '');
            if ($s[$key] === '') wp_die('Enter a valid HEX colour for product surfaces.', 'Invalid surface colour', ['response' => 400, 'back_link' => true]);
        }
        $s['shop_heading'] = sanitize_text_field($input['shop_heading'] ?? 'Shop');
        $s['shop_heading'] = function_exists('mb_substr') ? mb_substr($s['shop_heading'], 0, 80) : $s['shop_heading'];
        $s['shop_heading'] = $s['shop_heading'] ?: 'Shop';
        $preset = sanitize_key($input['size_preset'] ?? '');
        $s['size_preset'] = in_array($preset, ['compact', 'balanced', 'large'], true) ? $preset : 'balanced';
        $s['bangla_font'] = ($input['bangla_font'] ?? '') === 'system' ? 'system' : 'noto';
        $all = get_option('dreminex_suite_module_settings', []);
        if (!is_array($all)) $all = [];
        $all[self::KEY] = array_merge((array) ($all[self::KEY] ?? []), $s);
        update_option('dreminex_suite_module_settings', $all, false);
        Dreminex_Suite_Cache::changed(self::KEY, true);
        wp_safe_redirect(admin_url('admin.php?page=dreminex-suite&module=storefront_design&saved=settings'), 303);
        exit;
    }

    public static function panel($key) {
        if ($key !== self::KEY || !current_user_can('manage_options')) return;
        $s = self::settings();
        echo '<div class="ds-design"><div class="ds-design-intro"><h3>Storefront controls</h3><p>One style system for single products, Quick View and small screens. Changes affect the storefront when this module is on.</p></div>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="dreminex_design_save">';
        echo str_replace(' id="_wpnonce"', '', wp_nonce_field('dreminex_design_save', '_wpnonce', true, false));
        echo '<div class="ds-design-grid">';
        $sections = [
            'metadata' => ['Categories, tags and brand', 'Tidy chips and expandable tags on product views.'],
            'variations' => ['Colour and size choices', 'Compact swatches and clear size buttons.'],
            'descriptions' => ['Product descriptions', 'Readable full description panel on single products.'],
            'titles' => ['Product titles', 'Balanced titles that wrap on mobile.'],
            'cart' => ['Mobile cart', 'Product cards and totals that fit a narrow screen.'],
            'quantity' => ['Quantity buttons', 'Rounded minus and plus buttons on products, Quick View and cart.'],
            'product_cards' => ['Shop and related product cards', 'Match the homepage card surface across phone, tablet and desktop grids.'],
            'quick_view' => ['Desktop Quick View layout', 'Fit the image, description and controls inside a scrollable two-column modal; leave the phone layout unchanged.'],
            'discount_badges' => ['Branded discount badges', 'Use the real sale percentage in the cyan brand pill on product grids.'],
            'badge_shine' => ['Gentle badge shine', 'A periodic white sweep; reduced-motion visitors see a still badge.'],
        ];
        foreach ($sections as $name => [$label, $help]) {
            echo '<label class="ds-design-tile"><span class="ds-design-tile-head"><strong>' . esc_html($label) . '</strong><input type="checkbox" name="design[' . esc_attr($name) . ']" value="1" ' . checked($s[$name], 1, false) . '></span><span>' . esc_html($help) . '</span></label>';
        }
        echo '</div><h3>Customer pages</h3><p class="description">Scoped to the matching WooCommerce or support pages. ShopBuilder and WooCommerce keep the forms, totals and saved product data.</p><div class="ds-design-grid">';
        foreach ([
            'journey_titles' => ['Compact page headings', 'Shorter branded banner and clear breadcrumbs on store and support pages.'],
            'archive_filters' => ['Shop and category filters', 'Hide unavailable size and zero-result rating filters; tidy the sidebar.'],
            'cart_checkout' => ['Cart, checkout and tracking', 'Style notices, empty cart, totals and fields without changing checkout logic.'],
            'saved_lists' => ['Wishlist and compare', 'Style ShopBuilder lists and their empty states.'],
            'contact_cleanup' => ['Contact placeholder cleanup', 'Remove the old theme demo phrase from Contact details.'],
        ] as $name => [$label, $help]) {
            echo '<label class="ds-design-tile"><span class="ds-design-tile-head"><strong>' . esc_html($label) . '</strong><input type="checkbox" name="design[' . esc_attr($name) . ']" value="1" ' . checked($s[$name], 1, false) . '></span><span>' . esc_html($help) . '</span></label>';
        }
        echo '</div><div class="ds-design-tuning"><h3>Appearance</h3><div class="ds-design-fields">';
        echo '<label class="ds-design-field"><span>Shop heading</span><input type="text" name="design[shop_heading]" maxlength="80" value="' . esc_attr($s['shop_heading']) . '"><small>Replaces the theme demo “Shop Page” banner text when compact headings are on.</small></label>';
        self::number_field('tag_limit', 'Tags shown first', $s, 1, 12, 'The rest appear behind “Show more tags”.');
        self::number_field('swatch_size', 'Colour circle (px)', $s, 28, 48, 'Used on product pages and Quick View.');
        echo '<label class="ds-design-field"><span>Size button</span><select name="design[size_preset]">';
        foreach (['compact' => 'Compact', 'balanced' => 'Balanced', 'large' => 'Large'] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '" ' . selected($s['size_preset'], $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select><small>Choose a comfortable touch target.</small></label>';
        self::color_field('accent', 'Storefront accent colour', $s, 'Enter any HEX code (#RGB or #RRGGBB), or use the picker. Product choices, links and Storefront page accents follow this colour.');
        self::number_field('mobile_title', 'Mobile title (px)', $s, 18, 34, 'Single product and Quick View.');
        echo '<label class="ds-design-field"><span>Bangla typeface</span><select name="design[bangla_font]"><option value="noto" '.selected($s['bangla_font'],'noto',false).'>Noto Sans Bengali (same on every device)</option><option value="system" '.selected($s['bangla_font'],'system',false).'>Device font</option></select><small>Applies to Bengali text in headings, product copy and store pages; Latin letters retain Roboto.</small></label>';
        echo '</div><h3>Description panel height</h3><div class="ds-design-fields">';
        self::number_field('description_desktop', 'Desktop (px)', $s, 180, 800, '');
        self::number_field('description_tablet', 'Tablet (px)', $s, 180, 700, '');
        self::number_field('description_mobile', 'Phone (px)', $s, 180, 600, '');
        echo '</div><h3>Product cards and badges</h3><div class="ds-design-fields">';
        self::color_field('product_card_bg', 'Product card background', $s, 'Default matches the homepage card surface.');
        self::color_field('product_card_image_bg', 'Product image background', $s, 'Quiet neutral behind product photos.');
        self::number_field('product_card_radius', 'Product card corners (px)', $s, 0, 28, '');
        self::number_field('product_card_padding', 'Product card inner space (px)', $s, 8, 24, '');
        self::color_field('badge_bg', 'Sale badge colour', $s, 'Real discount badge only.');
        self::color_field('badge_text', 'Sale badge text colour', $s, 'Keep clear contrast with the badge colour.');
        self::number_field('badge_radius', 'Sale badge corners (px)', $s, 0, 24, '');
        self::number_field('badge_x', 'Badge distance from image left (px)', $s, 0, 30, 'Default 5px, close to the image corner.');
        self::number_field('badge_y', 'Badge distance from image top (px)', $s, 0, 30, 'Default 5px, close to the image corner.');
        self::number_field('badge_pad_x', 'Badge horizontal space (px)', $s, 4, 20, '');
        self::number_field('badge_pad_y', 'Badge vertical space (px)', $s, 2, 12, '');
        self::number_field('badge_font_size', 'Badge text size (px)', $s, 11, 20, '');
        self::number_field('badge_period', 'Shine interval (seconds)', $s, 4, 12, 'When gentle badge shine is on.');
        self::number_field('quick_view_width', 'Quick View maximum width (px)', $s, 760, 1480, 'The modal height stays within the screen and scrolls when needed.');
        self::number_field('quick_view_gap', 'Quick View column gap (px)', $s, 8, 48, '');
        self::color_field('quick_view_image_bg', 'Quick View image ground', $s, 'A quiet neutral behind product photography.');
        echo '</div></div>';
        submit_button('Save storefront settings', 'primary', 'ds_save_storefront');
        echo '</form></div>';
        Dreminex_Homepage_Design::panel();
    }

    private static function number_field($key, $label, $s, $min, $max, $help) {
        echo '<label class="ds-design-field"><span>' . esc_html($label) . '</span><input type="number" name="design[' . esc_attr($key) . ']" value="' . esc_attr($s[$key]) . '" min="' . (int) $min . '" max="' . (int) $max . '" required><small>' . esc_html($help) . '</small></label>';
    }

    private static function color_field($key, $label, $s, $help) {
        echo '<label class="ds-design-field ds-design-colour"><span>' . esc_html($label) . '</span><span class="ds-design-colour-inputs"><input type="text" name="design[' . esc_attr($key) . ']" value="' . esc_attr($s[$key]) . '" maxlength="7" pattern="#?([a-fA-F0-9]{3}|[a-fA-F0-9]{6})" placeholder="#00B4D7" spellcheck="false" required data-ds-accent-code><input type="color" value="' . esc_attr(self::picker_color($s[$key])) . '" data-ds-accent-picker aria-label="Choose ' . esc_attr($label) . '"></span><small>' . esc_html($help) . '</small></label>';
    }

    private static function picker_color($accent) {
        if (strlen($accent) === 7) return $accent;
        $hex = substr($accent, 1);
        return '#' . $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }
}

Dreminex_Storefront_Design::boot();
