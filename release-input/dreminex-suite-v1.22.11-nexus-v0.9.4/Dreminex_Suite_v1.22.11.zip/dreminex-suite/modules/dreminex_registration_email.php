<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// Confirm ownership of the address without changing WooCommerce's login/password flow.
add_action( 'woocommerce_created_customer', function ( $customer_id ) {
    if ( ! Dreminex_Suite_Control::setting( 'registration_email', 'email_confirmation', 1 ) ) return;
    $user = get_userdata( $customer_id );
    if ( ! $user || ! is_email( $user->user_email ) ) return;
    $token = bin2hex( random_bytes( 24 ) );
    update_user_meta( $customer_id, '_dreminex_email_token', hash( 'sha256', $token ) );
    update_user_meta( $customer_id, '_dreminex_email_token_expires', time() + 2 * DAY_IN_SECONDS );
    $link = add_query_arg( array( 'dreminex_confirm_email' => $customer_id, 'key' => $token ), wc_get_page_permalink( 'myaccount' ) );
    $subject = Dreminex_Suite_Control::setting( 'registration_email', 'email_subject', 'Confirm your Dreminex Fashion email' );
    $intro = Dreminex_Suite_Control::setting( 'registration_email', 'email_intro', 'Welcome to Dreminex Fashion. Please confirm your email address.' );
    $button = Dreminex_Suite_Control::setting( 'registration_email', 'email_button', 'Confirm my email' );
    $message = '<p>' . esc_html( $intro ) . '</p><p><a href="' . esc_url( $link ) . '">' . esc_html( $button ) . '</a></p><p>This link expires in 48 hours. If you did not register, ignore this email.</p>';
    $subject = sanitize_text_field( $subject );
    $sent = wp_mail( $user->user_email, $subject, $message, array( 'Content-Type: text/html; charset=UTF-8' ) );
    if ( function_exists( 'WC' ) && WC()->session ) WC()->session->set( 'dreminex_registration_email_sent', $sent ? 'yes' : 'no' );
    if ( ! $sent ) delete_user_meta( $customer_id, '_dreminex_email_token' );
}, 20 );

add_filter( 'woocommerce_registration_redirect', function ( $url ) {
    if ( ! Dreminex_Suite_Control::setting( 'registration_email', 'email_confirmation', 1 ) ) return $url;
    return add_query_arg( 'dreminex_registered', '1', $url );
}, 90 );

add_action( 'template_redirect', function () {
    if ( empty( $_GET['dreminex_confirm_email'] ) || empty( $_GET['key'] ) ) return;
    $id = absint( $_GET['dreminex_confirm_email'] );
    $token = sanitize_text_field( wp_unslash( $_GET['key'] ) );
    $stored = get_user_meta( $id, '_dreminex_email_token', true );
    $expires = (int) get_user_meta( $id, '_dreminex_email_token_expires', true );
    $ok = strlen( $token ) === 48 && $stored && $expires >= time() && hash_equals( $stored, hash( 'sha256', $token ) );
    if ( $ok ) {
        update_user_meta( $id, '_dreminex_email_confirmed', time() );
        delete_user_meta( $id, '_dreminex_email_token' );
        delete_user_meta( $id, '_dreminex_email_token_expires' );
    }
    wp_safe_redirect( add_query_arg( 'dreminex_email_result', $ok ? 'confirmed' : 'expired', wc_get_page_permalink( 'myaccount' ) ), 303 );
    exit;
} );

add_action( 'wp_footer', function () {
    if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) return;
    if ( ! Dreminex_Suite_Control::setting( 'registration_email', 'email_confirmation', 1 ) ) return;
    $registered = isset( $_GET['dreminex_registered'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['dreminex_registered'] ) );
    $result = isset( $_GET['dreminex_email_result'] ) ? sanitize_key( wp_unslash( $_GET['dreminex_email_result'] ) ) : '';
    if ( ! $registered && ! in_array( $result, array( 'confirmed', 'expired' ), true ) ) return;
    $mail_sent = function_exists( 'WC' ) && WC()->session ? WC()->session->get( 'dreminex_registration_email_sent' ) : '';
    if ( $registered && function_exists( 'WC' ) && WC()->session ) WC()->session->__unset( 'dreminex_registration_email_sent' );
    $message = $result === 'confirmed' ? Dreminex_Suite_Control::message('registration_email','msg_confirmed',Dreminex_Suite_Control::tr("Your email has been confirmed. Thank you!", 'আপনার ইমেইল নিশ্চিত হয়েছে। ধন্যবাদ!')) : ( $result === 'expired' ? Dreminex_Suite_Control::message('registration_email','msg_expired',Dreminex_Suite_Control::tr("This link has expired or has already been used. Contact us for help.", 'লিংকটির মেয়াদ শেষ বা এটি ইতিমধ্যে ব্যবহৃত হয়েছে। সহায়তার জন্য আমাদের সাথে যোগাযোগ করুন।')) : ( $mail_sent === 'no' ? Dreminex_Suite_Control::message('registration_email','msg_registered_failed',Dreminex_Suite_Control::tr("Registration succeeded, but the confirmation email could not be sent. Contact us for help.", 'রেজিস্ট্রেশন হয়েছে, কিন্তু কনফার্মেশন ইমেইল পাঠানো যায়নি। সহায়তার জন্য আমাদের সাথে যোগাযোগ করুন।')) : Dreminex_Suite_Control::message('registration_email','msg_registered_sent',Dreminex_Suite_Control::tr("Registration is complete. Check your email and click the confirmation link. Check Spam if it is not in your Inbox.", 'রেজিস্ট্রেশন সম্পন্ন হয়েছে। আপনার ইমেইল চেক করুন এবং কনফার্মেশন লিংকে ক্লিক করুন। Inbox-এ না থাকলে Spam ফোল্ডার দেখুন।')) ) );
    $close_url = remove_query_arg( array( 'dreminex_registered', 'dreminex_email_result' ) );
    ?>
    <div id="dreminex-register-dialog" class="dreminex-confirm-overlay" role="dialog" aria-modal="true" aria-labelledby="dreminex-register-title" aria-describedby="dreminex-register-message">
      <div class="dreminex-confirm-card">
        <span class="dreminex-confirm-mark" aria-hidden="true"><?php echo $result === 'expired' || $mail_sent === 'no' ? '!' : '✓'; ?></span>
        <h2 id="dreminex-register-title"><?php echo esc_html( Dreminex_Suite_Setup::brand() ); ?></h2>
        <p id="dreminex-register-message"><?php echo esc_html( $message ); ?></p>
        <a class="dreminex-confirm-close" href="<?php echo esc_url( $close_url ); ?>"><?php echo esc_html( Dreminex_Suite_Control::message( 'registration_email', 'msg_popup_button', Dreminex_Suite_Control::tr( 'Continue', 'চালিয়ে যান' ) ) ); ?></a>
      </div>
    </div>
    <?php
} );


// Branded registration fields. WooCommerce continues to handle password hashing and resets.
function dreminex_registration_post_value($key) {
    return isset($_POST[$key]) && is_scalar($_POST[$key]) ? sanitize_text_field(wp_unslash($_POST[$key])) : '';
}
function dreminex_registration_phone_value() {
    $digits=preg_replace('/\D/','',dreminex_registration_post_value('billing_phone'));
    return preg_match('/^8801[3-9][0-9]{8}$/D',$digits)?substr($digits,2):$digits;
}
add_action('wp_enqueue_scripts',function(){
    if(!function_exists('is_account_page')||!is_account_page())return;
    $registration_asset_version=DREMINEX_SUITE_VERSION.'.2';
    wp_enqueue_style('dreminex-registration',plugins_url('../assets/registration.css',__FILE__),[],$registration_asset_version);
    if(!is_user_logged_in())wp_enqueue_script('dreminex-registration',plugins_url('../assets/registration.js',__FILE__),[],$registration_asset_version,true);
    if(is_user_logged_in()&&Dreminex_Suite_Control::setting('registration_email','dashboard_enabled',1)){
        wp_enqueue_style('dreminex-account-dashboard',plugins_url('../assets/account-dashboard.css',__FILE__),['dreminex-registration'],DREMINEX_SUITE_VERSION);
        wp_enqueue_style('dreminex-account-pages',plugins_url('../assets/account-pages.css',__FILE__),['dreminex-account-dashboard'],DREMINEX_SUITE_VERSION);
    }
    $button = sanitize_hex_color(Dreminex_Suite_Control::setting('registration_email','button_color','#007D96')) ?: '#007D96';
    $button_text = sanitize_hex_color(Dreminex_Suite_Control::setting('registration_email','button_text_color','#FFFFFF')) ?: '#FFFFFF';
    wp_add_inline_style('dreminex-registration',':root{--dreminex-account-button:'.esc_attr($button).';--dreminex-account-button-text:'.esc_attr($button_text).';}');
});
add_filter('body_class',function($classes){
    if(function_exists('is_account_page')&&is_account_page()&&is_user_logged_in()&&
        Dreminex_Suite_Control::setting('registration_email','dashboard_enabled',1)){
        $classes[]='dreminex-account-signed-in';
        $endpoint=dreminex_account_endpoint_kind();
        if($endpoint){
            $classes[]='dreminex-account-endpoint';
            $classes[]='dreminex-account-endpoint-'.sanitize_html_class($endpoint);
        }
        if(Dreminex_Suite_Control::setting('registration_email','empty_state_art',1))$classes[]='dreminex-account-empty-art';
    }
    if(function_exists('is_account_page')&&is_account_page()&&!is_user_logged_in()&&
        !is_wc_endpoint_url('lost-password')&&!is_wc_endpoint_url('reset-password')&&
        Dreminex_Suite_Control::setting('registration_email','enable_registration',1)&&
        Dreminex_Suite_Control::setting('registration_email','design_enabled',1)){
        $classes[]='dreminex-account-experience';
        if(!Dreminex_Suite_Control::setting('registration_email','show_password_toggle',1))$classes[]='dreminex-password-toggle-off';
    }
    return $classes;
});
function dreminex_account_endpoint_kind(){
    if(!function_exists('is_wc_endpoint_url'))return '';
    foreach(['view-order','orders','downloads','edit-address','edit-account'] as $endpoint){
        if(is_wc_endpoint_url($endpoint))return $endpoint;
    }
    return '';
}
function dreminex_account_endpoint_details($endpoint){
    $address=sanitize_key((string)get_query_var('edit-address',''));
    if($endpoint==='edit-address'&&in_array($address,['billing','shipping'],true)){
        return [$address==='billing'?'Billing address':'Shipping address','Review your details before your next checkout.'];
    }
    $details=[
        'orders'=>['Orders',Dreminex_Suite_Control::setting('registration_email','orders_intro','See current status and revisit past purchases.')],
        'downloads'=>['Downloads',Dreminex_Suite_Control::setting('registration_email','downloads_intro','Your available digital files will appear here.')],
        'edit-address'=>['Addresses',Dreminex_Suite_Control::setting('registration_email','addresses_intro','Keep your billing and delivery details up to date.')],
        'edit-account'=>['Account details',Dreminex_Suite_Control::setting('registration_email','profile_intro','Update your name, email address and password.')],
        'view-order'=>['Order details','Review the items and current status of your order.'],
    ];
    return $details[$endpoint]??['',''];
}
add_action('woocommerce_account_content',function(){
    if(!is_user_logged_in()||!Dreminex_Suite_Control::setting('registration_email','dashboard_enabled',1))return;
    $endpoint=dreminex_account_endpoint_kind();
    if(!$endpoint)return;
    [$title,$description]=dreminex_account_endpoint_details($endpoint);
    echo '<header class="dreminex-account-content-head"><span class="dreminex-account-section-kicker">YOUR ACCOUNT</span><h3>'.esc_html($title).'</h3><p>'.esc_html($description).'</p></header>';
},5);
// Keep WooCommerce navigation and endpoints intact; replace only the default
// dashboard introduction with the Suite layout. The template retains Woo hooks.
add_filter('woocommerce_locate_template',function($template,$template_name){
    if($template_name==='myaccount/dashboard.php'&&function_exists('is_account_page')&&is_account_page()&&is_user_logged_in()&&
        Dreminex_Suite_Control::setting('registration_email','dashboard_enabled',1)){
        return dirname(__DIR__).'/templates/account-dashboard.php';
    }
    return $template;
},20,2);
add_action('woocommerce_before_account_navigation',function(){
    if(!is_user_logged_in()||!Dreminex_Suite_Control::setting('registration_email','dashboard_enabled',1))return;
    $endpoint=dreminex_account_endpoint_kind();
    if($endpoint){
        [$title]=dreminex_account_endpoint_details($endpoint);
        echo '<div class="dreminex-account-pagebar"><span>'.esc_html(Dreminex_Suite_Setup::brand()).' <span aria-hidden="true">/</span> '.esc_html($title).'</span><a href="'.esc_url(wc_get_page_permalink('myaccount')).'">Account home <span aria-hidden="true">↗</span></a></div>';
        return;
    }
    $user=wp_get_current_user();
    $first=trim((string)get_user_meta($user->ID,'first_name',true));
    $name=$first!==''?$first:($user->display_name?:$user->user_login);
    $name=wp_strip_all_tags($name);
    $heading=Dreminex_Suite_Control::setting('registration_email','dashboard_heading','Your Dreminex space');
    $text=Dreminex_Suite_Control::setting('registration_email','dashboard_text','Your orders, delivery details and profile, all in one easy place.');
    $shop=wc_get_page_permalink('shop');
    echo '<section class="dreminex-account-hero" aria-labelledby="dreminex-account-hero-title"><div class="dreminex-account-hero-copy"><span class="dreminex-account-hero-kicker">'.esc_html(Dreminex_Suite_Setup::brand()).' · MY ACCOUNT</span><p class="dreminex-account-greeting">'.esc_html(sprintf('Welcome back, %s',$name)).'</p><h2 id="dreminex-account-hero-title">'.esc_html($heading).'</h2><p class="dreminex-account-hero-text">'.esc_html($text).'</p><div class="dreminex-account-hero-actions"><a class="dreminex-account-hero-primary" href="'.esc_url(wc_get_account_endpoint_url('orders')).'">View orders <span aria-hidden="true">↗</span></a>';
    if($shop)echo '<a class="dreminex-account-hero-secondary" href="'.esc_url($shop).'">Explore the shop</a>';
    echo '</div></div><div class="dreminex-account-hero-art" aria-hidden="true"><span class="dreminex-account-art-ring"></span><span class="dreminex-account-art-mark">D</span><span class="dreminex-account-art-caption">YOUR STYLE · YOUR SPACE</span></div></section>';
},5);
add_action('woocommerce_before_customer_login_form',function(){
    if(!Dreminex_Suite_Control::setting('registration_email','enable_registration',1)||
       !Dreminex_Suite_Control::setting('registration_email','design_enabled',1))return;
    $title=Dreminex_Suite_Control::setting('registration_email','hero_title','Your style, your account');
    $text=Dreminex_Suite_Control::setting('registration_email','hero_text','Keep your orders, addresses and account details together.');
    $image_id=absint(Dreminex_Suite_Control::setting('registration_email','hero_image_id',0));
    $image=$image_id?wp_get_attachment_image($image_id,'large',false,['class'=>'dreminex-account-photo','loading'=>'eager']):'';
    $position=sanitize_key(Dreminex_Suite_Control::setting('registration_email','hero_position','center'));
    if(!in_array($position,['center','left','right','top'],true))$position='center';
    $benefits=[
        Dreminex_Suite_Control::tr('Track orders and delivery updates','অর্ডার ও ডেলিভারি আপডেট দেখুন'),
        Dreminex_Suite_Control::tr('Save details for a faster checkout','দ্রুত চেকআউটের জন্য তথ্য সংরক্ষণ করুন'),
        Dreminex_Suite_Control::tr('Secure email confirmation','নিরাপদ ইমেইল কনফার্মেশন'),
    ];
    echo '<section class="dreminex-account-intro'.($image?' has-image':'').' pos-'.esc_attr($position).'" aria-labelledby="dreminex-account-intro-title"><div class="dreminex-account-intro-copy"><span class="dreminex-account-kicker">'.esc_html(Dreminex_Suite_Setup::brand()).' · '.esc_html(Dreminex_Suite_Control::tr('MEMBER ACCOUNT','মেম্বার অ্যাকাউন্ট')).'</span><h2 id="dreminex-account-intro-title">'.esc_html($title).'</h2><p class="dreminex-account-lead">'.esc_html($text).'</p><div class="dreminex-account-intro-actions"><a class="dreminex-account-intro-primary" href="#dreminex-register-form">'.esc_html(Dreminex_Suite_Control::tr('Create an account','অ্যাকাউন্ট তৈরি করুন')).' <span aria-hidden="true">→</span></a><a class="dreminex-account-intro-secondary" href="#dreminex-login-form">'.esc_html(Dreminex_Suite_Control::tr('Sign in','সাইন ইন করুন')).'</a></div></div>';
    if($image)echo '<div class="dreminex-account-photo-wrap">'.$image.'</div>';
    else echo '<div class="dreminex-account-intro-art" aria-hidden="true"><span class="dreminex-intro-orbit orbit-one"></span><span class="dreminex-intro-orbit orbit-two"></span><span class="dreminex-intro-monogram">D</span></div>';
    echo '</section><ul class="dreminex-account-benefits" aria-label="'.esc_attr(Dreminex_Suite_Control::tr('Account benefits','অ্যাকাউন্টের সুবিধা')).'">';
    foreach($benefits as $benefit)echo '<li><span aria-hidden="true">✓</span>'.esc_html($benefit).'</li>';
    echo '</ul>';
});
add_action('woocommerce_login_form_start',function(){
    if(!Dreminex_Suite_Control::setting('registration_email','design_enabled',1))return;
    echo '<span id="dreminex-login-form" class="dreminex-register-anchor" tabindex="-1"></span><div class="dreminex-account-panel-intro"><span class="dreminex-account-panel-icon" aria-hidden="true">↗</span><p>'.esc_html(Dreminex_Suite_Control::tr('Sign in to continue to your orders and account.','আপনার অর্ডার ও অ্যাকাউন্টে যেতে সাইন ইন করুন।')).'</p></div>';
},1);
add_action('woocommerce_register_form_start',function(){
    if(!Dreminex_Suite_Control::setting('registration_email','design_enabled',1))return;
    echo '<div class="dreminex-account-panel-intro is-register"><span class="dreminex-account-panel-icon" aria-hidden="true">+</span><p>'.esc_html(Dreminex_Suite_Control::tr('Create your account in a few simple steps.','কয়েকটি সহজ ধাপে আপনার অ্যাকাউন্ট তৈরি করুন।')).'</p></div>';
},1);
add_action('woocommerce_register_form_start',function(){
    $fields=[
        'first_name'=>['First name','text','given-name','show_first_name','require_first_name'],
        'last_name'=>['Last name','text','family-name','show_last_name','require_last_name'],
        'billing_phone'=>['Mobile number','tel','tel','show_phone','require_phone'],
    ];
    $visible=array_filter($fields,static function($field){return Dreminex_Suite_Control::setting('registration_email',$field[3],1);});
    echo '<span id="dreminex-register-form" class="dreminex-register-anchor" tabindex="-1"></span>';
    if(!$visible)return;
    echo '<div class="dreminex-register-profile">';
    foreach($fields as $key=>$field){
        if(!Dreminex_Suite_Control::setting('registration_email',$field[3],1))continue;
        $required=(bool)Dreminex_Suite_Control::setting('registration_email',$field[4],$key==='billing_phone'?0:1);
        $value=dreminex_registration_post_value($key);
        echo '<p class="woocommerce-form-row form-row-wide'.($key==='billing_phone'?' dreminex-register-phone':'').'"><label for="reg_'.esc_attr($key).'">'.esc_html($field[0]).($required?' <span class="required" aria-hidden="true">*</span>':' <span class="optional">(optional)</span>').'</label><input class="woocommerce-Input input-text" type="'.esc_attr($field[1]).'" name="'.esc_attr($key).'" id="reg_'.esc_attr($key).'" autocomplete="'.esc_attr($field[2]).'" value="'.esc_attr($value).'" maxlength="'.($key==='billing_phone'?'15':'80').'"'.($key==='billing_phone'?' inputmode="tel"':'').($required?' required aria-required="true"':'').'></p>';
    }
    echo '</div>';
});
add_filter('woocommerce_registration_errors',function($errors,$username,$email){
    foreach(['first_name'=>['First name','show_first_name','require_first_name'],'last_name'=>['Last name','show_last_name','require_last_name']] as $key=>$field){
        if(!Dreminex_Suite_Control::setting('registration_email',$field[1],1)||!Dreminex_Suite_Control::setting('registration_email',$field[2],1))continue;
        if(trim(dreminex_registration_post_value($key))==='')$errors->add('dreminex_'.$key,'Enter your '.$field[0].'.');
    }
    if(Dreminex_Suite_Control::setting('registration_email','show_phone',1)){
        $phone=dreminex_registration_phone_value();
        $required=(bool)Dreminex_Suite_Control::setting('registration_email','require_phone',0);
        if($phone===''&&$required)$errors->add('dreminex_registration_phone_required','Enter your mobile number.');
        elseif($phone!==''&&!preg_match('/^01[3-9][0-9]{8}$/D',$phone))$errors->add('dreminex_registration_phone','Enter a valid 11-digit Bangladesh mobile number.');
    }
    return $errors;
},15,3);
add_action('woocommerce_created_customer',function($customer_id){
    foreach(['first_name'=>'show_first_name','last_name'=>'show_last_name'] as $key=>$setting){
        if(!Dreminex_Suite_Control::setting('registration_email',$setting,1))continue;
        $value=dreminex_registration_post_value($key);
        if($value!=='')update_user_meta($customer_id,$key,$value);
    }
    if(Dreminex_Suite_Control::setting('registration_email','show_phone',1)){
        $phone=dreminex_registration_phone_value();
        if(preg_match('/^01[3-9][0-9]{8}$/D',$phone)){update_user_meta($customer_id,'billing_phone',$phone);update_user_meta($customer_id,'shipping_phone',$phone);}
    }
},10);

// The Suite module owns the registration settings only while this module is enabled.
add_filter('pre_option_woocommerce_enable_myaccount_registration',function($pre){
    if(!Dreminex_Suite_Routing::enabled('registration_email'))return $pre;
    return Dreminex_Suite_Control::setting('registration_email','enable_registration',1)?'yes':'no';
});
// Let the customer choose a password; WordPress hashes it during registration.
add_filter('pre_option_woocommerce_registration_generate_password',function($pre){
    if(!Dreminex_Suite_Routing::enabled('registration_email'))return $pre;
    return Dreminex_Suite_Control::setting('registration_email','choose_password',1)?'no':'yes';
});
add_action('woocommerce_register_form',function(){
    if(!Dreminex_Suite_Control::setting('registration_email','choose_password',1))return;
    if(!Dreminex_Suite_Control::setting('registration_email','password_confirm',1))return;
    echo '<p class="woocommerce-form-row form-row-wide"><label for="reg_password_confirm">'.esc_html(Dreminex_Suite_Control::tr('Confirm password','পাসওয়ার্ড নিশ্চিত করুন')).' <span class="required" aria-hidden="true">*</span></label><input required aria-required="true" autocomplete="new-password" type="password" class="woocommerce-Input input-text" name="password_confirm" id="reg_password_confirm" data-match-text="'.esc_attr(Dreminex_Suite_Control::tr('Passwords match.','পাসওয়ার্ড দুটি মিলেছে।')).'" data-mismatch-text="'.esc_attr(Dreminex_Suite_Control::tr('Passwords do not match yet.','পাসওয়ার্ড দুটি এখনো মিলেনি।')).'"></p>';
    if(Dreminex_Suite_Control::setting('registration_email','design_enabled',1))echo '<p class="dreminex-password-hint">'.(Dreminex_Suite_Control::setting('registration_email','show_password_toggle',1)?'Use at least 8 characters. You can show the password before submitting.':'Use at least 8 characters.').'</p>';
});
add_filter('woocommerce_registration_errors',function($errors,$username,$email){
    if(!Dreminex_Suite_Control::setting('registration_email','choose_password',1))return $errors;
    $password=is_string($_POST['password']??null)?wp_unslash($_POST['password']):'';
    $confirmation=is_string($_POST['password_confirm']??null)?wp_unslash($_POST['password_confirm']):'';
    if(strlen($password)<8)$errors->add('dreminex_password_short','Use a password of at least 8 characters.');
    if(Dreminex_Suite_Control::setting('registration_email','password_confirm',1)&&!hash_equals($password,$confirmation))$errors->add('dreminex_password_mismatch','The passwords do not match.');
    return $errors;
},20,3);
