<?php
if (!defined('ABSPATH')) { exit; }
/* Dreminex | One order per customer IP during the configured cooldown.
 * Paste into a PHP Code Snippets entry without an opening <?php tag.
 * Change 2 to 1 below for a one-hour cooldown.
 */
if ( ! function_exists( 'dreminex_ip_order_cooldown_seconds' ) ) {
	function dreminex_ip_order_cooldown_seconds() {
			return (int) Dreminex_Suite_Control::setting( 'checkout_protection', 'cooldown_hours', 2 ) * HOUR_IN_SECONDS;
	}
}

if ( ! function_exists( 'dreminex_ip_has_recent_order' ) ) {
	function dreminex_ip_has_recent_order( $ip ) {
		if ( ! function_exists( 'wc_get_orders' ) || ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return false;
		}

		$seconds = absint( dreminex_ip_order_cooldown_seconds() );
		if ( ! $seconds ) {
			return false;
		}

		$args = array(
			'type'         => 'shop_order',
			'date_created' => '>=' . ( time() - $seconds ),
			'status'       => array( 'pending', 'on-hold' ),
			'limit'        => 1,
			'return'       => 'ids',
		);
		if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
			$args['field_query'] = array( array( 'field' => 'customer_ip_address', 'value' => $ip ) );
		} else {
			$args['meta_query'] = array( array( 'key' => '_customer_ip_address', 'value' => $ip ) );
		}

		return ! empty( wc_get_orders( $args ) );
	}
}

add_action( 'woocommerce_after_checkout_validation', function ( $data, $errors ) {
	$ip = WC_Geolocation::get_ip_address();
	if ( dreminex_ip_has_recent_order( $ip ) ) {
		$hours = dreminex_ip_order_cooldown_seconds() / HOUR_IN_SECONDS;
		$errors->add(
			'dreminex_ip_order_cooldown',
				str_replace( '%s', esc_html( $hours ), Dreminex_Suite_Control::message( 'checkout_protection', 'msg_ip_cooldown', Dreminex_Suite_Control::tr("An order was placed from this internet connection within the last %s hours. Try again after the waiting period, or contact us for help.", 'এই ইন্টারনেট সংযোগ থেকে গত %s ঘণ্টার মধ্যে একটি অর্ডার করা হয়েছে। অনুগ্রহ করে সময় শেষ হলে আবার চেষ্টা করুন অথবা আমাদের সঙ্গে যোগাযোগ করুন।') ) )
		);
	}
}, 40, 2 );
