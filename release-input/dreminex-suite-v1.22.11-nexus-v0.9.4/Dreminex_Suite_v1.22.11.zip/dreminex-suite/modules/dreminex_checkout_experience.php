<?php
if (!defined('ABSPATH')) exit;
/** Unified customer-facing checkout messages. */
$dreminex_modules=(array)get_option('dreminex_suite_modules',[]);
if(!empty($dreminex_modules['checkout_experience'])){
 if((int)Dreminex_Suite_Control::setting('checkout_experience','receipt_enabled',1)===1)require_once __DIR__.'/dreminex_receipt_message.php';
 if((int)Dreminex_Suite_Control::setting('checkout_experience','popup_enabled',1)===1)require_once __DIR__.'/dreminex_checkout_error_popup.php';
}
unset($dreminex_modules);

