<?php
if (!defined('ABSPATH')) exit;

/** Page-owned promotional pricing. Catalog products and their saved prices are never changed. */
final class Dreminex_Flash_Sale {
    const OPTION = 'dreminex_flash_sale';
    const ITEM = '_dreminex_flash';

    public static function boot() {
        add_shortcode('dreminex_flash_button', [__CLASS__, 'mobile_button']);
        add_shortcode('dreminex_flash_sale', [__CLASS__, 'render']);
        add_action('admin_menu', [__CLASS__, 'menu'], 36);
        add_action('admin_enqueue_scripts', [__CLASS__, 'admin_assets']);
        add_action('admin_post_dreminex_flash_save', [__CLASS__, 'save']);
        add_action('wp_ajax_dreminex_flash_search', [__CLASS__, 'search']);
        foreach (['status', 'catalog', 'add'] as $action) {
            add_action('wp_ajax_dreminex_flash_' . $action, [__CLASS__, 'ajax_' . $action]);
            add_action('wp_ajax_nopriv_dreminex_flash_' . $action, [__CLASS__, 'ajax_' . $action]);
        }
        add_action('wp_enqueue_scripts', [__CLASS__, 'assets']);
        add_filter('elementor/widget/render_content', [__CLASS__, 'whatsapp_content'], 20);
        add_filter('theme_mod_rt_header_sale_link', [__CLASS__, 'sale_link']);
        add_action('updated_option', [__CLASS__, 'module_changed'], 10, 3);
        add_action('woocommerce_before_calculate_totals', [__CLASS__, 'price_cart'], 999);
        add_action('woocommerce_check_cart_items', [__CLASS__, 'checkout_check']);
        add_action('woocommerce_after_checkout_validation', [__CLASS__, 'checkout_validation'], 999, 2);
        add_action('woocommerce_checkout_create_order', [__CLASS__, 'order_guard'], 999, 2);
        add_filter('woocommerce_update_cart_validation', [__CLASS__, 'update_quantity'], 10, 4);
        add_filter('woocommerce_get_item_data', [__CLASS__, 'item_label'], 10, 2);
        add_filter('woocommerce_coupon_get_items_to_apply', [__CLASS__, 'coupon_items'], 10, 2);
        add_filter('woocommerce_coupon_is_valid_for_product', [__CLASS__, 'coupon_product'], 10, 4);
        add_action('woocommerce_checkout_create_order_line_item', [__CLASS__, 'order_meta'], 10, 4);
        add_action('dreminex_suite_module_panel', [__CLASS__, 'module_panel'], 6);
    }

    public static function defaults() {
        return [
            'title' => 'Flash Sale',
            'intro' => 'Selected styles, special prices. Choose your favourites before the sale ends.',
            'timezone' => wp_timezone_string(), 'start' => 0, 'end' => 0, 'offers' => [], 'generation' => 'initial',
            'show_countdown' => 1, 'desktop_columns' => 4, 'mobile_columns' => 1, 'per_page' => 12, 'allow_coupons' => 0,
            'unavailable_title' => 'নতুন Flash Sale-এর জন্য অপেক্ষা করুন',
            'unavailable_message' => 'এই মুহূর্তে Flash Sale Offer চালু নেই। নতুন অফার এলে এখানেই পাবেন। ততক্ষণে আমাদের Shop থেকে আপনার পছন্দের পণ্যগুলো দেখে নিতে পারেন।',
            'shop_label' => 'Shop দেখুন', 'close_label' => 'ঠিক আছে',
            'expired_message' => 'এই Flash Sale offer-এর সময় বা শর্ত বদলেছে। পুরোনো offer item cart থেকে সরানো হয়েছে। বর্তমান offer অথবা সাধারণ product page থেকে আবার যোগ করুন।',
        ];
    }

    public static function settings() {
        $stored = get_option(self::OPTION, []);
        return array_replace(self::defaults(), is_array($stored) ? $stored : []);
    }

    public static function enabled() {
        return !empty(((array) get_option('dreminex_suite_modules', []))['flash_sale']);
    }

    public static function url() {
        $id = (int) get_option('dreminex_flash_sale_page_id', 0);
        return $id && get_post_status($id) === 'publish' ? get_permalink($id) : home_url('/flash-sale/');
    }

    public static function sale_link($original) { return self::url(); }

    public static function ensure_page() {
        $id = (int) get_option('dreminex_flash_sale_page_id', 0);
        if ($id && get_post_status($id) === 'publish') return $id;
        $pages = get_posts(['post_type' => 'page', 'post_status' => 'publish', 'numberposts' => 1, 'meta_key' => '_dreminex_flash_page', 'meta_value' => '1']);
        if ($pages) $id = $pages[0]->ID;
        else {
            // Never replace an unrelated page with the same slug.
            $id = wp_insert_post(['post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Flash Sale', 'post_name' => 'flash-sale', 'post_content' => '[dreminex_flash_sale]', 'meta_input' => ['_dreminex_flash_page' => '1', 'rt_layout_meta_data' => ['banner' => 'off', 'padding_top' => '32', 'padding_bottom' => '48']]], true);
        }
        if (!is_wp_error($id)) update_option('dreminex_flash_sale_page_id', $id, false);
        return $id;
    }

    public static function module_changed($name, $old, $new) {
        if ($name !== 'dreminex_suite_modules' || (bool) ($old['flash_sale'] ?? false) === (bool) ($new['flash_sale'] ?? false)) return;
        $s = self::settings(); $s['generation'] = wp_generate_uuid4();
        update_option(self::OPTION, $s, false);
    }

    public static function revision($s = null) {
        $s = $s ?? self::settings();
        return hash('sha256', wp_json_encode([$s['generation'], $s['start'], $s['end'], $s['offers'], $s['allow_coupons'], get_woocommerce_currency()]));
    }

    public static function state($now = null) {
        $s = self::settings(); $now = $now ?? time(); $reason = '';
        if (!self::enabled()) $reason = 'disabled';
        elseif (empty($s['offers']) || !(int) $s['end']) $reason = 'not_configured';
        elseif ((int) $s['start'] > $now) $reason = 'scheduled';
        elseif ((int) $s['end'] <= $now) $reason = 'ended';
        if ($reason === '' && !self::has_eligible_products($s)) $reason = 'no_eligible_products';
        return ['revision' => self::revision($s), 'active' => $reason === '', 'reason' => $reason, 'server_time' => $now, 'end' => (int) $s['end'], 'start' => (int) $s['start'], 'url' => self::url(), 'title' => $s['unavailable_title'], 'message' => $s['unavailable_message'], 'shop_url' => wc_get_page_permalink('shop'), 'shop_label' => $s['shop_label'], 'close_label' => $s['close_label']];
    }

    private static function has_eligible_products($s) {
        static $checked = [];
        $key = self::revision($s);
        if (isset($checked[$key])) return $checked[$key];
        foreach ((array) $s['offers'] as $id => $rule) {
            $p = wc_get_product($id);
            if (!$p) continue;
            if ($p->is_type('variable')) {
                foreach ($p->get_children() as $vid) { $v = wc_get_product($vid); if (self::offer_for($v) && $v->variation_is_visible() && $v->variation_is_active()) return $checked[$key] = true; }
            } elseif (self::offer_for($p)) return $checked[$key] = true;
        }
        return $checked[$key] = false;
    }

    /** Prices use the store's existing tax convention, currency and decimal precision. */
    public static function calculate_offer($base, $type, $value) {
        if (!is_numeric($base) || !is_numeric($value) || (float) $base <= 0 || (float) $value <= 0) return null;
        $base = (float) $base; $value = (float) $value;
        if ($type === 'percent' && $value < 100) $price = $base * (1 - $value / 100);
        elseif ($type === 'amount') $price = $base - $value;
        elseif ($type === 'price') $price = $value;
        else return null;
        $price = (float) wc_format_decimal($price, wc_get_price_decimals());
        return $price > 0 && $price < $base ? $price : null;
    }

    public static function offer_for($product) {
        if (!$product instanceof WC_Product || !in_array($product->get_type(), ['simple', 'variation'], true) || !$product->is_purchasable() || !$product->is_in_stock()) return null;
        $parent = $product->is_type('variation') ? $product->get_parent_id() : $product->get_id();
        if (get_post_status($parent) !== 'publish' || get_post_status($product->get_id()) !== 'publish') return null;
        $s = self::settings(); $offers = (array) $s['offers'];
        $rule = $offers[$product->get_id()] ?? ($offers[$parent] ?? null);
        if (!is_array($rule)) return null;
        $base = $product->get_price('edit');
        if (!is_numeric($base) || (float)$base <= 0) return null;
        $price = ($rule['type'] ?? '') === 'bundle' && is_numeric($rule['value'] ?? null) && (float)$rule['value'] > 0 && (float)$rule['value'] <= 100 ? (float)$base * (1 - (float)$rule['value'] / 100) : self::calculate_offer($base, $rule['type'] ?? '', $rule['value'] ?? 0);
        if ($price === null) return null;
        return ['price' => $price, 'base' => (float) $base, 'max_qty' => max(0, (int) ($rule['max_qty'] ?? 0)),
            'min_qty' => max(1, (int) ($rule['min_qty'] ?? 1)), 'rule_id' => isset($offers[$product->get_id()]) ? $product->get_id() : $parent,
            'type' => $rule['type'], 'buy_qty' => max(1, (int) ($rule['buy_qty'] ?? 1)), 'get_qty' => max(1, (int) ($rule['get_qty'] ?? 1)),
            'qualifier_id' => absint($rule['qualifier_id'] ?? 0)];
    }

    private static function canonical($record) {
        return wp_json_encode([(int) ($record['product_id'] ?? 0), (int) ($record['variation_id'] ?? 0), (string) ($record['price'] ?? ''), (string) ($record['base'] ?? ''), (string) ($record['revision'] ?? ''), (string) ($record['currency'] ?? '')]);
    }

    public static function make_record($product_id, $variation_id, $offer) {
        $r = ['product_id' => (int) $product_id, 'variation_id' => (int) $variation_id, 'price' => wc_format_decimal($offer['price'], wc_get_price_decimals()), 'base' => wc_format_decimal($offer['base'], wc_get_price_decimals()), 'revision' => self::revision(), 'currency' => get_woocommerce_currency()];
        $r['signature'] = hash_hmac('sha256', self::canonical($r), wp_salt('auth'));
        return $r;
    }

    public static function valid_item($item) {
        $r = $item[self::ITEM] ?? null;
        if ((float)($item['quantity'] ?? 0) < 1 || floor((float)($item['quantity'] ?? 0)) !== (float)($item['quantity'] ?? 0)) return false;
        if (!is_array($r) || empty($r['signature']) || !self::state()['active']) return false;
        if ((int) ($r['product_id'] ?? 0) !== (int) ($item['product_id'] ?? 0) || (int) ($r['variation_id'] ?? 0) !== (int) ($item['variation_id'] ?? 0)) return false;
        if (!hash_equals(hash_hmac('sha256', self::canonical($r), wp_salt('auth')), (string) $r['signature']) || !hash_equals(self::revision(), (string) ($r['revision'] ?? ''))) return false;
        $p = wc_get_product((int) ($r['variation_id'] ?: $r['product_id'])); $o = self::offer_for($p);
        if (!$o || (float) $r['price'] !== $o['price'] || (float) $r['base'] !== $o['base']) return false;
        if ($o['max_qty'] && (float) ($item['quantity'] ?? 0) > $o['max_qty']) return false;
        return true;
    }

    /** Allocation is recomputed from the current cart; client data never grants reward eligibility. */
    public static function allocation($cart) {
        $groups = []; $out = []; $consumed = [];
        foreach ($cart->cart_contents as $key => $item) {
            if (!isset($item[self::ITEM]) || !self::valid_item($item)) continue;
            $o = self::offer_for(wc_get_product($item['variation_id'] ?: $item['product_id']));
            $id = $o['rule_id'];
            if (!isset($groups[$id])) $groups[$id] = ['offer'=>$o, 'quantity'=>0, 'items'=>[]];
            $groups[$id]['quantity'] += (int)$item['quantity']; $groups[$id]['items'][$key] = $item;
        }
        foreach ($groups as $group) {
            $o = $group['offer']; $qty = $group['quantity'];
            $eligible = $qty >= $o['min_qty']; $reward = $qty;
            if ($o['type'] === 'bundle') {
                $source = $o['qualifier_id']; $qualifying = 0; $available = [];
                if (!$source || $source === $o['rule_id']) $reward = intdiv($qty, $o['buy_qty'] + $o['get_qty']) * $o['get_qty'];
                else {
                    foreach ($cart->cart_contents as $source_key=>$item) {
                        if ((int)$item['product_id'] !== $source && (int)$item['variation_id'] !== $source) continue;
                        if (isset($item[self::ITEM])) {
                            if (!self::valid_item($item)) continue;
                            $source_offer = self::offer_for(wc_get_product($item['variation_id'] ?: $item['product_id']));
                            // Bundle reward lines cannot qualify another bundle, avoiding circular free-item grants.
                            if (!$source_offer || $source_offer['type'] === 'bundle') continue;
                        }
                        if ((float)$item['data']->get_price() <= 0) continue;
                        $available[$source_key] = max(0, (int)$item['quantity'] - ($consumed[$source_key] ?? 0));
                        $qualifying += $available[$source_key];
                    }
                    $reward = intdiv($qualifying, $o['buy_qty']) * $o['get_qty'];
                    if ($eligible && $reward > 0) {
                        $use = (int)ceil(min($qty,$reward) / $o['get_qty']) * $o['buy_qty'];
                        foreach ($available as $source_key=>$units) { $take=min($units,$use); $consumed[$source_key]=($consumed[$source_key]??0)+$take; $use-=$take; if (!$use) break; }
                    }
                }
                $eligible = $eligible && $reward > 0;
            }
            $remaining = $eligible ? min($qty, $reward) : 0;
            uasort($group['items'],static fn($a,$b)=> (float)$a[self::ITEM]['base'] <=> (float)$b[self::ITEM]['base']);
            foreach ($group['items'] as $key=>$item) {
                $line_o = self::offer_for(wc_get_product($item['variation_id'] ?: $item['product_id']));
                $units = min((int)$item['quantity'], $remaining); $remaining -= $units;
                $line_total = ($item['quantity'] - $units) * $line_o['base'] + $units * $line_o['price'];
                $out[$key] = ['eligible'=>$eligible, 'discounted_units'=>$units, 'unit_price'=>$line_total / $item['quantity'], 'condition'=>self::condition_label($line_o)];
            }
        }
        return $out;
    }
    private static function conditions_met($cart) {
        foreach (self::allocation($cart) as $a) if (!$a['eligible']) return false;
        return true;
    }
    private static function condition_error() { return 'Flash Sale-এর quantity / required product শর্ত পূরণ করুন, অথবা ওই offer item cart থেকে সরিয়ে সাধারণ product page থেকে কিনুন।'; }

    public static function price_cart($cart) {
        if (!$cart instanceof WC_Cart || (is_admin() && !wp_doing_ajax())) return;
        $removed = false; $allocation = self::allocation($cart);
        foreach ($cart->cart_contents as $key => $item) {
            if (!isset($item[self::ITEM])) continue;
            if (!self::valid_item($item)) { $cart->remove_cart_item($key); $removed = true; continue; }
            // Never mutate a shared WC_Product instance or a normal cart line.
            $copy = clone $item['data']; $copy->set_price($allocation[$key]['unit_price']);
            $cart->cart_contents[$key]['data'] = $copy;
        }
        if ($removed && function_exists('wc_add_notice')) {
            $message = self::settings()['expired_message'];
            if (!wc_has_notice($message, 'notice')) wc_add_notice($message, 'notice');
        }
    }

    public static function checkout_check() {
        if (!WC()->cart) return;
        if (!self::conditions_met(WC()->cart)) wc_add_notice(self::condition_error(), 'error');
        foreach (WC()->cart->get_cart() as $item) if (isset($item[self::ITEM]) && !self::valid_item($item)) {
            wc_add_notice(self::settings()['expired_message'], 'error'); break;
        }
    }
    public static function checkout_validation($data, $errors) {
        if (!WC()->cart) return;
        if (!self::conditions_met(WC()->cart)) $errors->add('dreminex_flash_conditions', self::condition_error());
        foreach (WC()->cart->get_cart() as $item) if (isset($item[self::ITEM]) && !self::valid_item($item)) { $errors->add('dreminex_flash_expired', self::settings()['expired_message']); break; }
    }
    public static function order_guard($order, $data) {
        if (!WC()->cart) return;
        if (!self::conditions_met(WC()->cart)) throw new Exception(self::condition_error());
        foreach (WC()->cart->get_cart() as $item) if (isset($item[self::ITEM]) && !self::valid_item($item)) throw new Exception(self::settings()['expired_message']);
    }
    public static function update_quantity($valid, $key, $item, $quantity) {
        if (!isset($item[self::ITEM])) return $valid;
        $item['quantity'] = $quantity;
        if (!self::valid_item($item)) { wc_add_notice('Flash Sale quantity limit exceeded or this offer is no longer active.', 'error'); return false; }
        return $valid;
    }
    public static function item_label($data, $item) {
        if (isset($item[self::ITEM])) {
            $o = self::offer_for(wc_get_product($item['variation_id'] ?: $item['product_id']));
            $data[] = ['key' => 'Offer', 'value' => 'Flash Sale'];
            if ($o) $data[] = ['key'=>'Conditions', 'value'=>self::condition_label($o)];
            if (WC()->cart) foreach (self::allocation(WC()->cart) as $key=>$a) if (WC()->cart->cart_contents[$key][self::ITEM]['signature'] === $item[self::ITEM]['signature']) {
                $data[] = ['key'=>'Applied offer', 'value'=>$a['eligible'] ? $a['discounted_units'] . ' item(s) discounted; other units at catalog price' : 'Conditions not met; complete required quantity / product before checkout']; break;
            }
        }
        return $data;
    }
    public static function coupon_items($items, $coupon) {
        if (!empty(self::settings()['allow_coupons'])) return $items;
        return array_filter($items, static function($item) { return !is_array($item->object ?? null) || !isset($item->object[self::ITEM]); });
    }
    public static function coupon_product($valid, $product, $coupon, $values) {
        return isset($values[self::ITEM]) && empty(self::settings()['allow_coupons']) ? false : $valid;
    }
    public static function order_meta($line, $key, $values, $order) {
        if (!isset($values[self::ITEM])) return;
        $line->add_meta_data('Offer', 'Flash Sale', true);
        $line->add_meta_data('_dreminex_flash_revision', $values[self::ITEM]['revision'], true);
        $line->add_meta_data('_dreminex_flash_catalog_price', $values[self::ITEM]['base'], true);
        $o = self::offer_for(wc_get_product($values['variation_id'] ?: $values['product_id']));
        if ($o) $line->add_meta_data('Offer conditions', self::condition_label($o), true);
        $a = WC()->cart ? (self::allocation(WC()->cart)[$key] ?? null) : null;
        if ($a) $line->add_meta_data('_dreminex_flash_discounted_units', $a['discounted_units'], true);
    }

    private static function load_cart() {
        if (!WC()->cart || !WC()->session) wc_load_cart();
        if (WC()->session) WC()->session->set_customer_session_cookie(true);
    }
    public static function add_token($expiry = null) {
        $expiry = $expiry ?? time() + 1200;
        $id = WC()->session ? WC()->session->get_customer_id() : '';
        return $expiry . '.' . hash_hmac('sha256', 'dreminex-flash-add|' . $id . '|' . $expiry, wp_salt('nonce'));
    }
    public static function token_valid($token) {
        if (!is_string($token) || !preg_match('/^(\d+)\.[a-f0-9]{64}$/D', $token, $m)) return false;
        $expiry = (int) $m[1];
        return $expiry >= time() && $expiry <= time() + 1800 && hash_equals(self::add_token($expiry), $token);
    }
    public static function ajax_status() {
        nocache_headers(); wp_send_json_success(self::state());
    }
    public static function ajax_catalog() {
        nocache_headers(); self::load_cart();
        $s = self::settings(); $state = self::state(); $page = max(1, absint($_GET['sale_page'] ?? 1));
        if (!empty($_GET['token_only'])) wp_send_json_success(array_merge($state, ['token' => self::add_token()]));
        $cards = $state['active'] ? self::cards($page) : ['html' => '', 'variations' => [], 'pages' => 0, 'total' => 0];
        if (!$cards['total']) { $state['active'] = false; $state['reason'] = $state['reason'] ?: 'no_eligible_products'; }
        wp_send_json_success(array_merge($state, $cards, ['token' => self::add_token(), 'show_countdown' => !empty($s['show_countdown']), 'cart_url' => wc_get_cart_url()]));
    }
    public static function ajax_add() {
        nocache_headers(); self::load_cart();
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !self::token_valid(wp_unslash($_POST['token'] ?? ''))) wp_send_json_error(['message' => 'আপনার offer session-এর সময় শেষ হয়েছে। পেজটি refresh করে আবার চেষ্টা করুন।'], 403);
        if (!self::state()['active']) wp_send_json_error(['message' => self::settings()['unavailable_message']], 409);
        $pid = absint($_POST['product_id'] ?? 0); $vid = absint($_POST['variation_id'] ?? 0);
        $quantity = $_POST['quantity'] ?? '1';
        $qty = is_scalar($quantity) && preg_match('/^[1-9][0-9]*$/D', (string) $quantity) ? (int) $quantity : 0;
        if ($qty < 1 || $qty > 100) wp_send_json_error(['message' => 'Choose a quantity between 1 and 100.'], 400);
        $p = wc_get_product($pid); $attrs = [];
        if (!$p || !in_array($p->get_type(), ['simple', 'variable'], true)) wp_send_json_error(['message' => 'This product is unavailable.'], 400);
        if ($p->is_type('variable')) {
            $raw = json_decode(wp_unslash($_POST['attributes'] ?? '{}'), true);
            if (!is_array($raw)) wp_send_json_error(['message' => 'Select all product options.'], 400);
            foreach ($p->get_variation_attributes() as $attribute => $options) {
                $key = wc_variation_attribute_name($attribute);
                $value = isset($raw[$key]) && is_scalar($raw[$key]) ? wc_clean((string) $raw[$key]) : '';
                if ($value === '' || !in_array($value, $options, true)) wp_send_json_error(['message' => 'Select valid product options.'], 400);
                $attrs[$key] = $value;
            }
            $selected = wc_get_product($vid);
            if (!$selected || !$selected->is_type('variation') || !$selected->variation_is_visible() || !$selected->variation_is_active() || $selected->get_parent_id() !== $pid) wp_send_json_error(['message' => 'Invalid product options.'], 400);
            foreach ($selected->get_variation_attributes() as $key => $value) if ($value !== '' && ($attrs[$key] ?? '') !== $value) wp_send_json_error(['message' => 'Invalid product options.'], 400);
        } else {
            if ($vid) wp_send_json_error(['message' => 'Invalid product options.'], 400);
            $selected = $p;
        }
        $offer = self::offer_for($selected);
        if (!$offer) wp_send_json_error(['message' => 'This product no longer has an active Flash Sale price.'], 409);
        WC()->cart->calculate_totals();
        $existing = 0;
        foreach (WC()->cart->get_cart() as $item) if (isset($item[self::ITEM]) && (int) $item['product_id'] === $pid && (int) $item['variation_id'] === $vid) $existing += (int) $item['quantity'];
        if ($offer['max_qty'] && $existing + $qty > $offer['max_qty']) wp_send_json_error(['message' => 'Flash Sale limit: ' . $offer['max_qty'] . ' of this size/variant per cart.'], 400);
        // Keep other store/stock/purchase-limit validators in the standard WooCommerce flow.
        if (!apply_filters('woocommerce_add_to_cart_validation', true, $pid, $qty, $vid, $attrs)) wp_send_json_error(['message' => self::cart_error()], 400);
        $key = WC()->cart->add_to_cart($pid, $qty, $vid, $attrs, [self::ITEM => self::make_record($pid, $vid, $offer)]);
        if (!$key) wp_send_json_error(['message' => self::cart_error()], 400);
        WC()->cart->calculate_totals(); WC()->cart->set_session();
        wp_send_json_success(['message' => self::conditions_met(WC()->cart) ? 'Flash Sale offer-সহ cart-এ যোগ হয়েছে।' : 'Cart-এ যোগ হয়েছে। Offer পেতে required quantity / product যোগ করুন; শর্ত পূরণ না হলে checkout হবে না।', 'cart_url' => wc_get_cart_url(), 'checkout_url' => wc_get_checkout_url(), 'conditions_met' => self::conditions_met(WC()->cart), 'cart_count' => WC()->cart->get_cart_contents_count()]);
    }
    private static function cart_error() {
        $notices = wc_get_notices('error');
        return !empty($notices) ? wp_strip_all_tags(end($notices)['notice']) : 'Could not add this product. Check availability and try again.';
    }

    private static function available_variations($parent) {
        $out = [];
        foreach ($parent->get_children() as $id) {
            $v = wc_get_product($id); $o = self::offer_for($v);
            if (!$o || !$v->variation_is_visible() || !$v->variation_is_active()) continue;
            $out[] = ['id' => $id, 'attributes' => $v->get_variation_attributes(), 'price_html' => self::price_html($v, $o), 'max_qty' => $o['max_qty'], 'offer_label' => self::offer_label($o), 'condition_html' => self::condition_html($o), 'badge' => self::badge_label($o), 'image_id' => $v->get_image_id(), 'min_qty' => $o['min_qty'], 'bundle' => $o['type'] === 'bundle', 'pricing' => $o];
        }
        return $out;
    }
    public static function condition_label($offer) {
        if ($offer['type'] === 'bundle') {
            $p = $offer['qualifier_id'] ? wc_get_product($offer['qualifier_id']) : null;
            $source = $p ? $p->get_name() : 'this product';
            $percent = round((1 - $offer['price'] / $offer['base']) * 100, 1);
            return 'Buy ' . $offer['buy_qty'] . ' × ' . $source . ', get ' . $offer['get_qty'] . ' ' . ($percent >= 100 ? 'free' : 'at ' . $percent . '% off') . '. ' . (!$p ? 'Add paid + reward quantities to cart.' : 'Add both products to cart.') . ($offer['min_qty'] > 1 ? ' Minimum ' . $offer['min_qty'] . ' target items.' : '');
        }
        return 'Buy at least ' . $offer['min_qty'] . ' of this product for the offer.' . ($offer['max_qty'] ? ' Max ' . $offer['max_qty'] . ' per size / variant.' : '');
    }
    public static function condition_html($offer) {
        $html = esc_html(self::condition_label($offer));
        if ($offer['type'] !== 'bundle' || !$offer['qualifier_id'] || $offer['qualifier_id'] === $offer['rule_id']) return $html;
        $p = wc_get_product($offer['qualifier_id']);
        if (!$p) return $html;
        $name = esc_html($p->get_name()); $pos = strpos($html, $name);
        if ($pos === false) return $html;
        return substr_replace($html, '<a class="df-required-product" href="' . esc_url($p->get_permalink()) . '">' . $name . '</a>', $pos, strlen($name));
    }
    private static function offer_label($offer) { return self::condition_label($offer); }
    private static function badge_label($offer) { return '-' . round((1 - $offer['price'] / $offer['base']) * 100, 1) . '%'; }
    private static function gallery($product) {
        $ids = array_merge([$product->get_image_id()], $product->get_gallery_image_ids());
        if ($product->is_type('variable')) foreach ($product->get_children() as $id) {
            $v = wc_get_product($id); if (!$v) continue;
            $ids = array_merge($ids, [$v->get_image_id()], $v->get_gallery_image_ids(), (array)get_post_meta($id, 'rtwpvg_images', true));
        }
        $out = [];
        foreach (array_unique(array_filter(array_map('absint', $ids))) as $id) {
            $url = wp_get_attachment_image_url($id, 'woocommerce_single'); $thumb = wp_get_attachment_image_url($id, 'woocommerce_gallery_thumbnail');
            if ($url) $out[] = ['id'=>$id,'url'=>$url,'thumb'=>$thumb ?: $url, 'alt'=>get_post_meta($id,'_wp_attachment_image_alt',true) ?: $product->get_name()];
        }
        return $out;
    }
    private static function price_html($p, $o) {
        return '<del>' . wc_price(wc_get_price_to_display($p, ['price' => $o['base']])) . '</del> <ins>' . wc_price(wc_get_price_to_display($p, ['price' => $o['price']])) . '</ins>';
    }
    public static function cards($page = 1) {
        $s = self::settings(); $groups = [];
        foreach ((array) $s['offers'] as $id => $rule) {
            $p = wc_get_product($id); if (!$p) continue;
            $parent = $p->is_type('variation') ? $p->get_parent_id() : $id;
            $groups[$parent] = $parent;
        }
        $eligible = []; $variations = [];
        foreach ($groups as $id) {
            $p = wc_get_product($id); if (!$p || get_post_status($id) !== 'publish') continue;
            if ($p->is_type('variable')) { $vs = self::available_variations($p); if ($vs) { $eligible[$id] = $p; $variations[$id] = $vs; } }
            elseif (self::offer_for($p)) $eligible[$id] = $p;
        }
        $per = (int) $s['per_page']; $total = count($eligible); $pages = (int) ceil($total / max(1, $per));
        $page = min(max(1, $page), max(1, $pages));
        $items = array_slice($eligible, ($page - 1) * $per, $per, true); $data = []; $galleries = []; ob_start();
        foreach ($items as $id => $p) {
            $variable = $p->is_type('variable'); $o = $variable ? null : self::offer_for($p);
            $galleries[$id] = self::gallery($p);
            $preview = $o ?: self::offer_for(wc_get_product($variations[$id][0]['id']));
            $badges = $variable ? array_unique(array_column($variations[$id], 'badge')) : [self::badge_label($o)];
            $badge = count($badges) > 1 ? 'Up to ' . max(array_map(static fn($b)=>(float)trim($b,'-%'),$badges)) . '%' : reset($badges);
            $image = $p->get_image('woocommerce_thumbnail', ['loading' => 'lazy', 'decoding' => 'async']);
            echo '<article class="df-sale-card" data-product="' . esc_attr($id) . '" data-variable="' . ($variable ? '1' : '0') . '"><div class="df-sale-media"><span class="df-sale-badge">' . esc_html($badge) . '</span><a class="df-sale-photo" href="' . esc_url($p->get_permalink()) . '">' . wp_kses_post($image) . '</a><div class="df-sale-thumbs" aria-label="Product gallery"></div></div><div class="df-sale-card-body"><h2>' . esc_html($p->get_name()) . '</h2><p class="df-sale-condition">' . self::condition_html($preview) . '</p>';
            echo '<div class="df-sale-price" aria-live="polite">' . ($variable ? 'Select your options for the offer price' : wp_kses_post(self::price_html($p, $o))) . '</div>';
            echo '<p class="df-sale-offer-label" aria-live="polite">' . esc_html('Flash Sale page / cart only') . '</p>';
            echo '<button class="df-sale-quick" type="button">Quick View</button><div class="df-sale-details">' . wp_kses_post(wpautop($p->get_short_description() ?: $p->get_description())) . '</div>';
            if ($variable) {
                $data[$id] = $variations[$id];
                echo '<div class="df-sale-options">';
                foreach ($p->get_variation_attributes() as $attribute => $options) {
                    $key = wc_variation_attribute_name($attribute); $control = 'df-sale-' . $id . '-' . sanitize_title($attribute);
                    echo '<label for="' . esc_attr($control) . '">' . esc_html(wc_attribute_label($attribute, $p)) . '</label>';
                    // Native, module-owned selectors: third-party swatch filters require a Woo variation form.
                    echo '<select class="df-sale-attribute" name="' . esc_attr($key) . '" id="' . esc_attr($control) . '"><option value="">Choose an option</option>';
                    foreach ($options as $value) {
                        $term = taxonomy_exists($attribute) ? get_term_by('slug', $value, $attribute) : false;
                        echo '<option value="' . esc_attr($value) . '">' . esc_html($term ? $term->name : $value) . '</option>';
                    }
                    echo '</select>';
                }
                echo '</div>';
            }
            echo '<label class="df-sale-qty">Qty <input type="number" min="1" max="' . esc_attr($o && $o['max_qty'] ? min(100, $o['max_qty']) : 100) . '" value="1" step="1" inputmode="numeric"></label><div class="df-sale-actions"><button type="button" class="df-sale-buy" data-buy="cart"' . ($variable ? ' disabled' : '') . '>Add to cart</button><button type="button" class="df-sale-buy df-sale-buy-now" data-buy="checkout"' . ($variable ? ' disabled' : '') . '>Buy now</button></div><p class="df-sale-feedback" role="status"></p></div></article>';
        }
        return ['html' => ob_get_clean(), 'variations' => $data, 'galleries' => $galleries, 'desktop_columns' => $s['desktop_columns'], 'mobile_columns' => $s['mobile_columns'], 'pages' => $pages, 'page' => $page, 'total' => $total];
    }

    public static function phone() { return preg_replace('/\D/', '', (string) get_option('dreminex_suite_whatsapp_number', '')); }
    public static function whatsapp_content($html) {
        $phone = self::phone();
        if (!$phone || !class_exists('WP_HTML_Tag_Processor')) return $html;
        $tags = new WP_HTML_Tag_Processor($html);
        while ($tags->next_tag(['tag_name' => 'A'])) {
            $href = (string) $tags->get_attribute('href');
            if (stripos($href, 'tel:') !== 0) continue;
            $digits = preg_replace('/\D/', '', $href);
            if ($digits === $phone || (str_starts_with($phone, '880') && $digits === '0' . substr($phone, 3))) {
                $tags->set_attribute('href', 'https://wa.me/' . $phone);
                $tags->set_attribute('rel', 'noopener');
                $tags->set_attribute('title', 'Contact us on WhatsApp');
            }
        }
        return $tags->get_updated_html();
    }

    public static function assets() {
        if (is_admin()) return;
        wp_enqueue_script('dreminex-flash-link', plugins_url('../assets/flash-link.js', __FILE__), [], DREMINEX_SUITE_VERSION . '-flash5', true);
        wp_localize_script('dreminex-flash-link', 'DreminexFlashLink', ['ajax' => admin_url('admin-ajax.php'), 'url' => self::url(), 'phone' => self::phone(), 'whatsapp' => self::phone() ? 'https://wa.me/' . self::phone() : '']);
        wp_enqueue_style('dreminex-flash-link', plugins_url('../assets/flash-link.css', __FILE__), [], DREMINEX_SUITE_VERSION . '-flash5');
        $id = (int) get_option('dreminex_flash_sale_page_id', 0);
        if (($id && is_page($id)) || (is_singular() && has_shortcode((string) get_post_field('post_content', get_queried_object_id()), 'dreminex_flash_sale'))) {
            self::page_assets();
        }
    }
    private static function page_assets() {
        wp_enqueue_style('dreminex-flash-sale', plugins_url('../assets/flash-sale.css', __FILE__), [], DREMINEX_SUITE_VERSION);
        wp_enqueue_script('dreminex-flash-sale', plugins_url('../assets/flash-sale.js', __FILE__), [], DREMINEX_SUITE_VERSION, true);
        wp_localize_script('dreminex-flash-sale', 'DreminexFlashPage', ['ajax' => admin_url('admin-ajax.php')]);
    }
    public static function mobile_button() {
        return '<div class="df-mobile-sale" data-dreminex-flash-mobile><a href="' . esc_url(self::url()) . '" data-dreminex-flash-trigger="1"><i class="icon-rt-flash" aria-hidden="true"></i>Flash Sale Offer!</a><span data-flash-start-clock hidden></span></div>';
    }
    public static function render() {
        self::page_assets(); $s = self::settings();
        return '<section class="df-sale-page" aria-labelledby="df-sale-heading"><header class="df-sale-header"><div><h1 id="df-sale-heading">' . esc_html($s['title']) . '</h1><p>' . esc_html($s['intro']) . '</p></div><div class="df-sale-countdown" hidden><span>Sale ends in</span><strong data-sale-clock></strong></div></header><div class="df-sale-summary" hidden><span data-sale-total></span><a href="' . esc_url(wc_get_cart_url()) . '">View cart</a></div><div class="df-sale-content" aria-live="polite"><p>Checking the current Flash Sale…</p><div class="df-sale-skeleton" aria-hidden="true"><div></div><div></div><div></div><div></div></div></div><nav class="df-sale-pagination" aria-label="Flash Sale product pages"></nav><noscript>Enable JavaScript to see current Flash Sale availability and safely select offer prices.</noscript></section>';
    }

    public static function menu() {
        add_submenu_page('dreminex-suite', 'Flash Sale', 'Flash Sale', 'manage_options', 'dreminex-flash-sale', [__CLASS__, 'admin_page']);
    }
    public static function module_panel($key) {
        if ($key === 'flash_sale') echo '<p><a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=dreminex-flash-sale')) . '">Manage Flash Sale products, prices & schedule</a></p>';
    }
    public static function admin_assets() {
        if (sanitize_key(wp_unslash($_GET['page'] ?? '')) !== 'dreminex-flash-sale') return;
        wp_enqueue_script('dreminex-flash-admin', plugins_url('../assets/flash-admin.js', __FILE__), [], DREMINEX_SUITE_VERSION, true);
        wp_localize_script('dreminex-flash-admin', 'DreminexFlashAdmin', ['ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('dreminex_flash_search')]);
    }
    public static function search() {
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Access denied.'], 403);
        check_ajax_referer('dreminex_flash_search', 'nonce');
        $term = sanitize_text_field(wp_unslash($_GET['term'] ?? ''));
        if (strlen($term) < 2 || strlen($term) > 100) wp_send_json_success([]);
        wp_send_json_success(self::search_results($term));
    }
    public static function search_results($term) {
        $term = sanitize_text_field($term);
        if (strlen($term) < 2 || strlen($term) > 100) return [];
        $ids = WC_Data_Store::load('product')->search_products($term, '', true, false, 20);
        $out = [];
        foreach ($ids as $id) {
            $p = wc_get_product($id);
            if (!$p || !in_array($p->get_type(), ['simple', 'variable', 'variation'], true)) continue;
            $parent = $p->is_type('variation') ? $p->get_parent_id() : $id;
            if (get_post_status($parent) !== 'publish' || get_post_status($id) !== 'publish') continue;
            $out[] = ['id' => $id, 'name' => $p->get_name() . ($p->is_type('variation') ? ' — ' . wc_get_formatted_variation($p, true, true, true) : ''), 'type' => $p->get_type(), 'price' => $p->get_price('edit')];
        }
        return $out;
    }
    public static function sanitize_settings($raw) {
        $s = self::settings(); $errors = [];
        foreach (['title', 'intro', 'unavailable_title', 'unavailable_message', 'shop_label', 'close_label', 'expired_message'] as $key) $s[$key] = mb_substr(sanitize_textarea_field(is_scalar($raw[$key] ?? null) ? $raw[$key] : $s[$key]), 0, $key === 'intro' || str_contains($key, 'message') ? 1000 : 120);
        foreach (['show_countdown', 'allow_coupons'] as $key) $s[$key] = empty($raw[$key]) ? 0 : 1;
        $s['desktop_columns'] = min(6, max(1, (int)($raw['desktop_columns'] ?? 4)));
        $s['mobile_columns'] = min(2, max(1, (int)($raw['mobile_columns'] ?? 1)));
        $s['per_page'] = in_array((int) ($raw['per_page'] ?? 12), [8, 12, 16, 24], true) ? (int) ($raw['per_page'] ?? 12) : 12;
        $tz = is_scalar($raw['timezone'] ?? null) ? sanitize_text_field($raw['timezone']) : $s['timezone'];
        try { $zone = new DateTimeZone($tz); $s['timezone'] = $tz; } catch (Throwable $e) { $errors[] = 'Select a valid campaign timezone.'; $zone = wp_timezone(); }
        foreach (['start', 'end'] as $key) {
            $date = sanitize_text_field(is_scalar($raw[$key] ?? null) ? $raw[$key] : '');
            if ($date === '') { $s[$key] = 0; continue; }
            $parsed = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $date, $zone);
            if (!$parsed || $parsed->format('Y-m-d\TH:i') !== $date) $errors[] = 'Enter a valid ' . $key . ' date.';
            else $s[$key] = $parsed->getTimestamp();
        }
        if ($s['end'] && $s['start'] && $s['end'] <= $s['start']) $errors[] = 'End time must be after start time.';
        $offers = []; $rows = $raw['offers'] ?? [];
        if (!is_array($rows) || count($rows) > 100) $errors[] = 'Select at most 100 product/variation rules.';
        else foreach ($rows as $id => $row) {
            if (!is_array($row)) { $errors[] = 'Invalid offer row.'; continue; }
            $id = absint($id); $p = wc_get_product($id); $type = sanitize_key(is_scalar($row['type'] ?? null) ? $row['type'] : '');
            $value = wc_format_decimal(is_scalar($row['value'] ?? null) ? $row['value'] : '');
            if (!$p || !in_array($p->get_type(), ['simple', 'variable', 'variation'], true) || !in_array($type, ['price', 'percent', 'amount', 'bundle'], true) || !is_numeric($value) || (float) $value <= 0 || ($type === 'percent' && (float) $value >= 100) || ($type === 'bundle' && (float)$value > 100)) { $errors[] = 'Invalid offer for product #' . $id . '.'; continue; }
            $offers[$id] = ['type' => $type, 'value' => $value, 'max_qty' => min(100, max(0, (int) ($row['max_qty'] ?? 0))),
                'min_qty'=>min(100,max(1,(int)($row['min_qty'] ?? 1))), 'buy_qty'=>min(99,max(1,(int)($row['buy_qty'] ?? 1))),
                'get_qty'=>min(99,max(1,(int)($row['get_qty'] ?? 1))), 'qualifier_id'=>absint($row['qualifier_id'] ?? 0)];
            $r = $offers[$id];
            if ($r['qualifier_id'] && !wc_get_product($r['qualifier_id'])) $errors[] = 'Required product does not exist for #' . $id . '.';
            if ($r['max_qty'] && $r['min_qty'] > $r['max_qty']) $errors[] = 'Minimum quantity exceeds maximum for #' . $id . '.';
            if ($type === 'bundle' && (!$r['qualifier_id'] || $r['qualifier_id'] === $id) && $r['max_qty'] && $r['buy_qty']+$r['get_qty'] > $r['max_qty']) $errors[] = 'Maximum quantity must include paid and reward units for #' . $id . '.';
        }
        foreach ($offers as $id=>$r) if ($r['type']==='bundle' && $r['qualifier_id'] && $r['qualifier_id'] !== $id) {
            $qp = wc_get_product($r['qualifier_id']); $qid = $qp && $qp->is_type('variation') ? $qp->get_parent_id() : $r['qualifier_id'];
            if (($offers[$r['qualifier_id']]['type'] ?? $offers[$qid]['type'] ?? '') === 'bundle') $errors[] = 'A bundle reward product cannot be the qualifying product of another bundle.';
            if ($qp && $qp->is_type('variable') && $qp->get_id() === ($p = wc_get_product($id))->get_parent_id()) $errors[] = 'For same-product bundles choose required product 0 (same rule).';
        }
        $s['offers'] = $offers;
        foreach (['title', 'unavailable_title', 'unavailable_message', 'shop_label', 'close_label', 'expired_message'] as $key) if ($s[$key] === '') $s[$key] = self::defaults()[$key];
        return ['settings' => $s, 'errors' => $errors];
    }
    public static function save() {
        if (!current_user_can('manage_options')) wp_die('Access denied.', 403);
        check_admin_referer('dreminex_flash_save');
        $parsed = self::sanitize_settings(wp_unslash($_POST));
        if ($parsed['errors']) wp_die(esc_html(implode(' ', $parsed['errors'])), 'Flash Sale settings', ['response' => 400, 'back_link' => true]);
        update_option(self::OPTION, $parsed['settings'], false);
        $modules = (array) get_option('dreminex_suite_modules', []); $modules['flash_sale'] = empty($_POST['enabled']) ? 0 : 1;
        update_option('dreminex_suite_modules', $modules, false);
        self::ensure_page();
        if (has_action('litespeed_purge_all')) do_action('litespeed_purge_all');
        wp_safe_redirect(admin_url('admin.php?page=dreminex-flash-sale&saved=1')); exit;
    }
    private static function rule_controls($id,$row) {
        $labels=['min_qty'=>'Minimum target quantity','buy_qty'=>'Buy quantity (bundle)','get_qty'=>'Reward quantity (bundle)','qualifier_id'=>'Required product / variation ID (0 = same)']; $html='';
        foreach ($labels as $key=>$label) $html .= '<label style="display:block;margin:5px 0">' . esc_html($label) . '<input style="width:100px;display:block" type="number" name="offers[' . esc_attr($id) . '][' . $key . ']" min="' . ($key==='qualifier_id'?0:1) . '" value="' . esc_attr($row[$key] ?? ($key==='qualifier_id'?0:1)) . '"></label>';
        $required = wc_get_product(absint($row['qualifier_id'] ?? 0));
        $html .= '<div class="df-qualifier-picker"><label>Find required product / variation<input type="search" class="df-qualifier-search" autocomplete="off" placeholder="Product name / ID / SKU" style="max-width:240px;width:100%"></label><div class="df-qualifier-results" role="status"></div><p class="df-qualifier-selected">' . esc_html($required ? $required->get_name() . ' (#' . $required->get_id() . ')' : 'Same selected product (0)') . '</p><button type="button" class="button df-qualifier-clear">Use same product</button></div>';
        return $html;
    }
    public static function admin_page() {
        if (!current_user_can('manage_options')) wp_die('Access denied.', 403);
        $s = self::settings(); $state = self::state();
        echo '<div class="wrap dreminex-suite"><h1>Flash Sale</h1><p>Manage this page from here. Catalog prices remain unchanged; only items added through Flash Sale carry the offer price into cart and checkout.</p>';
        if (isset($_GET['saved'])) echo '<div class="notice notice-success"><p>Flash Sale settings saved.</p></div>';
        echo '<div class="card"><h2>Campaign status: ' . esc_html($state['active'] ? 'Live' : ucwords(str_replace('_', ' ', $state['reason']))) . '</h2><p><a class="button" href="' . esc_url(self::url()) . '" target="_blank" rel="noopener">Open Flash Sale page</a></p><p>Current campaign has ' . count((array) $s['offers']) . ' offer rules. Products with an invalid price, unpublished status or no stock are hidden. A configured end time and selected products are required to go live.</p></div>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="dreminex_flash_save">';
        wp_nonce_field('dreminex_flash_save');
        echo '<div class="card"><h2>Schedule & controls</h2><p><label><input type="checkbox" name="enabled" value="1" ' . checked(self::enabled(), true, false) . '> Enable Flash Sale module</label></p><table class="form-table"><tbody>';
        echo '<tr><th><label for="df-timezone">Campaign timezone</label></th><td><select id="df-timezone" name="timezone">';
        foreach (array_unique([$s['timezone'], wp_timezone_string(), 'Asia/Dhaka', 'UTC']) as $tz) echo '<option value="' . esc_attr($tz) . '" ' . selected($s['timezone'], $tz, false) . '>' . esc_html($tz) . '</option>';
        echo '</select><p class="description">Asia/Dhaka = Bangladesh time. Changing this affects the campaign schedule only.</p></td></tr>';
        foreach (['start' => 'Starts (blank = immediately)', 'end' => 'Ends / countdown deadline'] as $key => $label) echo '<tr><th><label for="df-' . $key . '">' . esc_html($label) . '</label></th><td><input id="df-' . $key . '" type="datetime-local" name="' . $key . '" value="' . esc_attr($s[$key] ? wp_date('Y-m-d\TH:i', (int) $s[$key], new DateTimeZone($s['timezone'])) : '') . '"><p class="description">Campaign timezone: ' . esc_html($s['timezone']) . '. Server time controls availability.</p></td></tr>';
        echo '<tr><th>Display</th><td><label><input type="checkbox" name="show_countdown" value="1" ' . checked($s['show_countdown'], 1, false) . '> Show countdown</label></td></tr><tr><th>Coupons</th><td><label><input type="checkbox" name="allow_coupons" value="1" ' . checked($s['allow_coupons'], 1, false) . '> Allow additional coupons on Flash Sale items</label><p class="description">Off: coupons still work for eligible normal cart items.</p></td></tr><tr><th>Products per page</th><td><select name="per_page">';
        foreach ([8,12,16,24] as $n) echo '<option value="' . $n . '" ' . selected($s['per_page'], $n, false) . '>' . $n . '</option>';
        echo '</select></td></tr>';
        foreach (['desktop_columns'=>'Desktop columns','mobile_columns'=>'Mobile columns'] as $key=>$label) {
            echo '<tr><th>' . esc_html($label) . '</th><td><select name="' . esc_attr($key) . '">';
            foreach (range(1,$key==='desktop_columns'?6:2) as $n) echo '<option value="' . $n . '" ' . selected($s[$key],$n,false) . '>' . $n . '</option>';
            echo '</select></td></tr>';
        }
        echo '</tbody></table></div><div class="card"><h2>Selected products & offer prices</h2><p>Search existing products by name, ID or SKU. A parent variation rule applies to all eligible variants; selecting a specific variant overrides the parent rule. Removing a row removes only its offer, never the product.</p><label for="df-product-search">Find products</label> <input id="df-product-search" class="regular-text" type="search" autocomplete="off" placeholder="Product name / ID / SKU"><div id="df-product-results" role="status"></div><table class="widefat"><thead><tr><th>Product</th><th>Offer type</th><th>Value</th><th>Max qty per size/variant in cart</th><th>Quantity / bundle conditions</th><th>Remove</th></tr></thead><tbody id="df-offer-rows">';
        foreach ((array) $s['offers'] as $id => $row) {
            $p = wc_get_product($id); $name = $p ? $p->get_name() : 'Missing product';
            echo '<tr data-offer-id="' . esc_attr($id) . '"><td>' . esc_html($name) . '<br><small>#' . esc_html($id) . '</small></td><td><select name="offers[' . esc_attr($id) . '][type]">';
            foreach (['price' => 'Fixed offer price', 'percent' => 'Percentage off', 'amount' => 'Amount off catalog price', 'bundle'=>'Buy X get Y (% off / free)'] as $value => $label) echo '<option value="' . $value . '" ' . selected($row['type'], $value, false) . '>' . esc_html($label) . '</option>';
            echo '</select></td><td><input type="number" name="offers[' . esc_attr($id) . '][value]" value="' . esc_attr($row['value']) . '" min="0.01" step="0.01" required></td><td><input type="number" name="offers[' . esc_attr($id) . '][max_qty]" value="' . esc_attr($row['max_qty']) . '" min="0" max="100"><small>0 = no additional limit</small></td><td>' . self::rule_controls($id,$row) . '</td><td><button type="button" class="button df-remove-offer">Remove</button></td></tr>';
        }
        echo '</tbody></table><p class="description">Normal offers must be below catalog price and above zero. Bundle value is reward discount %, 100 = free. Required product 0 means the same selected product; add paid and reward quantities together. Other product IDs require both products in cart. Missing conditions block checkout; excess reward units use catalog price. Updating prices/schedule or switching the module off invalidates old Flash Sale cart items; customers receive a notice rather than a silent price increase.</p></div><div class="card"><h2>Page & message text</h2><table class="form-table"><tbody>';
        $labels = ['title'=>'Page heading','intro'=>'Page introduction','unavailable_title'=>'Unavailable popup heading','unavailable_message'=>'Unavailable popup message','shop_label'=>'Shop button label','close_label'=>'Close button label','expired_message'=>'Expired cart notice'];
        foreach ($labels as $key=>$label) echo '<tr><th><label for="df-text-' . esc_attr($key) . '">' . esc_html($label) . '</label></th><td><textarea id="df-text-' . esc_attr($key) . '" name="' . esc_attr($key) . '" rows="' . (str_contains($key,'message')?3:2) . '" class="large-text" maxlength="1000">' . esc_textarea($s[$key]) . '</textarea></td></tr>';
        echo '</tbody></table></div>'; submit_button('Save Flash Sale'); echo '</form></div>';
    }
}
