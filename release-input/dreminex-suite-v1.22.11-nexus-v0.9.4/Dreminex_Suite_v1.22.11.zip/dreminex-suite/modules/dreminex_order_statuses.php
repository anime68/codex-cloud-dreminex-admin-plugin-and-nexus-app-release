<?php
if (!defined('ABSPATH')) { exit; }
/* Dreminex Fashion | Manual WooCommerce order workflow.
 * Separate PHP Code Snippets entry; run everywhere. Do not add <?php.
 * These labels are for manual order management; status changes do not verify
 * payments or send custom customer emails automatically.
 */
if ( ! function_exists( 'dreminex_order_workflow_statuses' ) ) {
	function dreminex_order_workflow_statuses() {
		return array(
			'wc-advance-verified' => 'Advance verified',
			'wc-packing' => 'Packing',
			'wc-ready-to-ship' => 'Ready to ship',
			'wc-pickup-requested' => 'Courier pickup requested',
			'wc-picked-up' => 'Picked up by courier',
			'wc-shipped' => 'Shipped',
			'wc-in-transit' => 'In transit',
			'wc-at-hub' => 'At courier hub',
			'wc-out-for-delivery' => 'Out for delivery',
			'wc-attempted' => 'Delivery attempted',
			'wc-courier-hold' => 'Courier hold',
			'wc-courier-review' => 'Courier review',
			'wc-partial-delivered' => 'Partially delivered',
			'wc-delivery-failed' => 'Delivery failed',
			'wc-delivered' => 'Delivered / balance due',
			'wc-return-requested' => 'Return requested',
			'wc-return-in-transit' => 'Return in transit',
			'wc-returned-sender' => 'Returned to sender',
			'wc-returned' => 'Returned',
		);
	}
}

add_action( 'init', function () {
	foreach ( dreminex_order_workflow_statuses() as $slug => $label ) {
		register_post_status( $slug, array(
			'label'                     => $label,
			'public'                    => true,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'   => true,
			'show_in_admin_status_list'=> true,
			'label_count'               => _n_noop( $label . ' <span class="count">(%s)</span>', $label . ' <span class="count">(%s)</span>' ),
		) );
	}
}, 9 );

add_filter( 'wc_order_statuses', function ( $statuses ) {
	$custom = dreminex_order_workflow_statuses();
	$ordered = array();
	foreach ( $statuses as $slug => $label ) {
		$ordered[ $slug ] = $label;
		if ( 'wc-on-hold' === $slug ) {
			foreach ( $custom as $key => $custom_label ) {
				$ordered[ $key ] = $custom_label;
			}
		}
	}
	return $ordered;
} );

// WooCommerce handles registered mark_<status> actions for every selected order.
// Support both the HPOS order table and the legacy WordPress order list.
$dreminex_add_order_bulk_statuses = function ( $actions ) {
	foreach ( dreminex_order_workflow_statuses() as $slug => $label ) {
		$actions[ 'mark_' . substr( $slug, 3 ) ] = 'Change status to ' . $label;
	}
	return $actions;
};
add_filter( 'bulk_actions-woocommerce_page_wc-orders', $dreminex_add_order_bulk_statuses, 100 );
add_filter( 'bulk_actions-edit-shop_order', $dreminex_add_order_bulk_statuses, 100 );
