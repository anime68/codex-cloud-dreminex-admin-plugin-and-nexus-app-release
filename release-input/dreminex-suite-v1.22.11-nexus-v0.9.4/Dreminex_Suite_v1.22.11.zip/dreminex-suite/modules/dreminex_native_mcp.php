<?php
if (!defined('ABSPATH')) exit;
/** Loader marker for the independently implemented Native MCP module. */

