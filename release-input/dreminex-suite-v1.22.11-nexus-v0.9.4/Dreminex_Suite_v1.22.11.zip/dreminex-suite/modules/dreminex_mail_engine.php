<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Dreminex Mail Engine. Monitor-first mail ownership with encrypted queue data.
 * A second SMTP plugin is reported and blocks takeover; it is never modified.
 */
final class Dreminex_Mail_Engine {
	const DB_VERSION = 1;
	const OPTION = 'dreminex_mail_engine_settings';
	const DB_OPTION = 'dreminex_mail_engine_db_version';
	private static $dispatching = false;

	private static function table($name) { global $wpdb; return $wpdb->prefix . 'dme_' . $name; }
	private static function now() { return current_time('mysql', true); }
	public static function defaults() {
		return [
			'module_enabled'=>false, 'operating_mode'=>'monitor', 'capture_wp_mail'=>true,
			'default_transport_id'=>'', 'from_name'=>'', 'from_email'=>'', 'reply_to'=>'',
			'queue'=>['batch_size'=>20,'max_attempts'=>8,'claim_ttl_seconds'=>180],
			'bot'=>['enabled'=>true,'minimum_fill_seconds'=>2,'ip_10_min'=>5,'ip_24_hours'=>20,'email_1_hour'=>3,'duplicate_10_min'=>2],
			'privacy'=>['event_retention_days'=>30,'bot_retention_days'=>14],
			'transports'=>[],
		];
	}
	public static function settings() { return array_replace_recursive(self::defaults(), (array) get_option(self::OPTION, [])); }
	public static function enabled() { $s=self::settings(); return !empty($s['module_enabled']); }
	public static function master_key() {
		if (!defined('DREMINEX_MAIL_ENGINE_KEY')) return '';
		$key=(string)DREMINEX_MAIL_ENGINE_KEY;
		return strlen($key)>=32 ? hash('sha256',$key,true) : '';
	}
	public static function key_ready() { return self::master_key()!=='' && function_exists('openssl_encrypt'); }
	private static function encrypt($plain) {
		$key=self::master_key(); if($key===''||!function_exists('openssl_encrypt')) return new WP_Error('mail_key_unavailable','A Mail Engine encryption key is required.');
		$iv=random_bytes(12);$tag='';$cipher=openssl_encrypt((string)$plain,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);
		if($cipher===false)return new WP_Error('mail_encrypt_failed','Mail Engine could not encrypt the value.');
		return base64_encode(wp_json_encode(['v'=>1,'i'=>base64_encode($iv),'t'=>base64_encode($tag),'c'=>base64_encode($cipher)]));
	}
	private static function decrypt($value) {
		$key=self::master_key();$raw=json_decode((string)base64_decode((string)$value,true),true);
		if($key===''||!is_array($raw)||empty($raw['i'])||empty($raw['t'])||!isset($raw['c']))return new WP_Error('mail_decrypt_failed','Mail Engine secret is unavailable.');
		$plain=openssl_decrypt(base64_decode($raw['c']),'aes-256-gcm',$key,OPENSSL_RAW_DATA,base64_decode($raw['i']),base64_decode($raw['t']));
		return $plain===false?new WP_Error('mail_decrypt_failed','Mail Engine secret is unavailable.'):$plain;
	}

	public static function install() {
		if((int)get_option(self::DB_OPTION,0)>=self::DB_VERSION)return;
		require_once ABSPATH.'wp-admin/includes/upgrade.php';global $wpdb;$c=$wpdb->get_charset_collate();$p=$wpdb->prefix.'dme_';
		dbDelta("CREATE TABLE {$p}messages (
			uuid char(36) NOT NULL,idempotency_key char(64) NOT NULL,message_class varchar(32) NOT NULL DEFAULT 'generic',priority tinyint unsigned NOT NULL DEFAULT 5,
			transport_id varchar(64) NOT NULL DEFAULT '',status varchar(24) NOT NULL DEFAULT 'queued',payload longtext NOT NULL,payload_hash char(64) NOT NULL,
			attempts smallint unsigned NOT NULL DEFAULT 0,available_at datetime NOT NULL,lease_until datetime NULL,accepted_at datetime NULL,terminal_at datetime NULL,
			last_error varchar(191) NOT NULL DEFAULT '',created_at datetime NOT NULL,updated_at datetime NOT NULL,
			PRIMARY KEY (uuid),UNIQUE KEY idempotency_key (idempotency_key),KEY queue (status,available_at),KEY lease (lease_until),KEY created (created_at)
		) {$c};");
		dbDelta("CREATE TABLE {$p}recipients (
			id bigint unsigned NOT NULL AUTO_INCREMENT,message_uuid char(36) NOT NULL,recipient_hash char(64) NOT NULL,recipient_mask varchar(191) NOT NULL,
			kind varchar(12) NOT NULL DEFAULT 'to',status varchar(24) NOT NULL DEFAULT 'queued',provider_id varchar(191) NOT NULL DEFAULT '',updated_at datetime NOT NULL,
			PRIMARY KEY (id),UNIQUE KEY message_recipient (message_uuid,recipient_hash,kind),KEY recipient_hash (recipient_hash),KEY status (status)
		) {$c};");
		dbDelta("CREATE TABLE {$p}events (
			id bigint unsigned NOT NULL AUTO_INCREMENT,message_uuid char(36) NOT NULL DEFAULT '',event_type varchar(40) NOT NULL,severity varchar(16) NOT NULL DEFAULT 'info',details_json longtext NOT NULL,
			created_at datetime NOT NULL,PRIMARY KEY (id),KEY message_event (message_uuid,event_type),KEY created (created_at)
		) {$c};");
		dbDelta("CREATE TABLE {$p}suppressions (
			id bigint unsigned NOT NULL AUTO_INCREMENT,recipient_hash char(64) NOT NULL,reason varchar(40) NOT NULL,provider_id varchar(191) NOT NULL DEFAULT '',expires_at datetime NULL,created_at datetime NOT NULL,
			PRIMARY KEY (id),UNIQUE KEY recipient_hash (recipient_hash),KEY expires (expires_at)
		) {$c};");
		dbDelta("CREATE TABLE {$p}rate_limits (
			bucket varchar(191) NOT NULL,window_start datetime NOT NULL,hits int unsigned NOT NULL DEFAULT 0,updated_at datetime NOT NULL,
			PRIMARY KEY (bucket),KEY window_start (window_start)
		) {$c};");
		dbDelta("CREATE TABLE {$p}bot_events (
			id bigint unsigned NOT NULL AUTO_INCREMENT,form_id varchar(64) NOT NULL,ip_hash char(64) NOT NULL,email_hash char(64) NOT NULL DEFAULT '',outcome varchar(24) NOT NULL,
			reason varchar(64) NOT NULL,created_at datetime NOT NULL,PRIMARY KEY (id),KEY form_created (form_id,created_at),KEY ip_created (ip_hash,created_at)
		) {$c};");
		dbDelta("CREATE TABLE {$p}daily_stats (day date NOT NULL,metric varchar(64) NOT NULL,value bigint unsigned NOT NULL DEFAULT 0,PRIMARY KEY (day,metric)) {$c};");
		update_option(self::DB_OPTION,self::DB_VERSION,false);
	}
	public static function boot() {
		self::install();add_filter('cron_schedules',[__CLASS__,'cron_schedules']);add_action('admin_menu',[__CLASS__,'menu'],35);add_action('admin_post_dreminex_mail_engine_save',[__CLASS__,'save']);add_action('admin_post_dreminex_mail_engine_test',[__CLASS__,'test']);
		add_action('dreminex_mail_engine_tick',[__CLASS__,'work']);add_action('dreminex_mail_engine_cleanup',[__CLASS__,'cleanup']);
		if(!wp_next_scheduled('dreminex_mail_engine_tick'))wp_schedule_event(time()+MINUTE_IN_SECONDS,'dreminex_minute','dreminex_mail_engine_tick');
		if(!wp_next_scheduled('dreminex_mail_engine_cleanup'))wp_schedule_event(time()+HOUR_IN_SECONDS,'daily','dreminex_mail_engine_cleanup');
		add_filter('dreminex_mail_engine_guard_contact',[__CLASS__,'guard_contact'],10,2);
		if(self::delivery_active())add_filter('pre_wp_mail',[__CLASS__,'capture_wp_mail'],1,2);
	}
	public static function cron_schedules($schedules){if(empty($schedules['dreminex_minute']))$schedules['dreminex_minute']=['interval'=>MINUTE_IN_SECONDS,'display'=>'Every minute (Dreminex Mail Engine)'];return $schedules;}
	public static function menu(){add_submenu_page('dreminex-suite','Mail Engine','Mail Engine','manage_options','dreminex-mail-engine',[__CLASS__,'page']);}
	public static function conflicts(){
		$active=(array)get_option('active_plugins',[]);$matched=[];foreach($active as $plugin)if(preg_match('~(?:easy-wp-smtp|wp-mail-smtp|post-smtp|fluent-smtp|gmail-smtp)~i',$plugin))$matched[]=basename(dirname($plugin));return array_values(array_unique($matched));
	}
	private static function delivery_active(){
		$s=self::settings();return !self::$dispatching&&!empty($s['module_enabled'])&&in_array($s['operating_mode'],['queue','immediate'],true)&&!empty($s['capture_wp_mail'])&&self::key_ready()&&!empty($s['default_transport_id'])&&!self::conflicts();
	}
	private static function mask($email){$at=strpos($email,'@');return $at===false?'hidden':substr($email,0,1).'***'.substr($email,$at);}
	private static function hash_identity($value){return hash_hmac('sha256',strtolower(trim((string)$value)),self::master_key()?:wp_salt('auth'));}
	private static function recipients($value){$values=is_array($value)?$value:preg_split('/[,;]/',(string)$value);$out=[];foreach((array)$values as $email){$email=sanitize_email(trim((string)$email));if($email&&is_email($email))$out[]=$email;}return array_values(array_unique($out));}
	private static function event($uuid,$type,$severity,$details=[]){global $wpdb;$wpdb->insert(self::table('events'),['message_uuid'=>sanitize_text_field($uuid),'event_type'=>sanitize_key($type),'severity'=>sanitize_key($severity),'details_json'=>wp_json_encode($details),'created_at'=>self::now()],['%s','%s','%s','%s','%s']);}
	private static function message_class($atts){$subject=strtolower((string)($atts['subject']??''));if(str_contains($subject,'reset')||str_contains($subject,'password'))return 'password_reset';if(str_contains($subject,'order')||str_contains($subject,'woocommerce'))return 'woocommerce';if(str_contains($subject,'contact'))return 'contact_admin';return 'generic';}
	public static function capture_wp_mail($pre,$atts){
		if(self::$dispatching||!self::delivery_active()||!is_array($atts)||!empty($atts['attachments']))return $pre;
		$to=self::recipients($atts['to']??[]);$subject=(string)($atts['subject']??'');if(!$to||$subject===''||preg_match('/[\r\n]/',$subject))return $pre;
		$result=self::queue(['to'=>$to,'subject'=>$subject,'message'=>(string)($atts['message']??''),'headers'=>(array)($atts['headers']??[]),'class'=>self::message_class($atts)]);
		return is_wp_error($result)?$pre:true;
	}
	public static function queue($payload){
		if(!self::key_ready())return new WP_Error('mail_key_unavailable','Mail Engine queue encryption is unavailable.');
		$to=self::recipients($payload['to']??[]);$subject=trim((string)($payload['subject']??''));$body=(string)($payload['message']??'');if(!$to||$subject===''||strlen($subject)>255||preg_match('/[\r\n]/',$subject))return new WP_Error('mail_message_invalid','Mail message fields are invalid.');$to=array_values(array_filter($to,static fn($email)=>!self::suppressed($email)));if(!$to)return new WP_Error('mail_suppressed','Every recipient is suppressed.');
		$s=self::settings();$transport=sanitize_key((string)($payload['transport_id']??$s['default_transport_id']));if(empty($s['transports'][$transport]['enabled']))return new WP_Error('mail_transport_unavailable','The selected Mail Engine transport is not enabled.');
		$uuid=wp_generate_uuid4();$class=in_array(($payload['class']??''),['password_reset','security','woocommerce','contact_admin','contact_acknowledgement','generic'],true)?$payload['class']:'generic';$plain=['to'=>$to,'subject'=>$subject,'message'=>$body,'headers'=>array_values((array)($payload['headers']??[])),'class'=>$class,'transport_id'=>$transport];$encrypted=self::encrypt(wp_json_encode($plain));if(is_wp_error($encrypted))return $encrypted;
		$idempotency=hash('sha256',$uuid.'|'.wp_json_encode($plain));global $wpdb;$ok=$wpdb->insert(self::table('messages'),['uuid'=>$uuid,'idempotency_key'=>$idempotency,'message_class'=>$class,'priority'=>self::priority($class),'transport_id'=>$transport,'status'=>'queued','payload'=>$encrypted,'payload_hash'=>hash('sha256',wp_json_encode($plain)),'available_at'=>self::now(),'created_at'=>self::now(),'updated_at'=>self::now()],['%s','%s','%s','%d','%s','%s','%s','%s','%s','%s','%s']);if(!$ok)return new WP_Error('mail_queue_failed','Mail Engine could not persist the message.');
		foreach($to as $email)$wpdb->insert(self::table('recipients'),['message_uuid'=>$uuid,'recipient_hash'=>self::hash_identity($email),'recipient_mask'=>self::mask($email),'kind'=>'to','status'=>'queued','updated_at'=>self::now()],['%s','%s','%s','%s','%s','%s']);self::event($uuid,'queued','info',['class'=>$class,'recipient_count'=>count($to)]);return $uuid;
	}
	private static function priority($class){return ['password_reset'=>9,'security'=>8,'woocommerce'=>7,'contact_admin'=>5,'contact_acknowledgement'=>4,'generic'=>3][$class]??3;}
	private static function suppressed($email){global $wpdb;$hash=self::hash_identity($email);return (bool)$wpdb->get_var($wpdb->prepare('SELECT id FROM '.self::table('suppressions').' WHERE recipient_hash=%s AND (expires_at IS NULL OR expires_at>%s) LIMIT 1',$hash,self::now()));}
	private static function claim(){
		$s=self::settings();$limit=max(1,min(100,(int)$s['queue']['batch_size']));global $wpdb;$table=self::table('messages');$wpdb->query($wpdb->prepare("UPDATE {$table} SET status='queued',lease_until=NULL,updated_at=%s WHERE status='sending' AND lease_until<%s",self::now(),self::now()));$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE status IN ('queued','retry_wait') AND available_at<=%s ORDER BY priority DESC,created_at ASC LIMIT %d",self::now(),$limit),ARRAY_A);$out=[];foreach($rows as $row){$lease=gmdate('Y-m-d H:i:s',time()+max(60,(int)$s['queue']['claim_ttl_seconds']));$changed=$wpdb->query($wpdb->prepare("UPDATE {$table} SET status='sending',attempts=attempts+1,lease_until=%s,updated_at=%s WHERE uuid=%s AND status IN ('queued','retry_wait')",$lease,self::now(),$row['uuid']));if($changed)$out[]=$row;}return $out;
	}
	public static function work(){if(!self::delivery_active())return;foreach(self::claim() as $row)self::deliver($row);}
	private static function deliver($row){
		$data=self::decrypt($row['payload']);if(is_wp_error($data)||!($payload=json_decode((string)$data,true))){self::terminal($row,'failed','payload_unavailable');return;}$result=self::send($payload);if($result===true){global $wpdb;$wpdb->update(self::table('messages'),['status'=>'accepted','accepted_at'=>self::now(),'terminal_at'=>self::now(),'lease_until'=>null,'updated_at'=>self::now()],['uuid'=>$row['uuid']],['%s','%s','%s','%s','%s'],['%s']);$wpdb->update(self::table('recipients'),['status'=>'accepted','updated_at'=>self::now()],['message_uuid'=>$row['uuid']],['%s','%s'],['%s']);self::event($row['uuid'],'accepted','info',['transport'=>$row['transport_id']]);return;}$error=is_wp_error($result)?$result->get_error_code():'delivery_failed';$attempt=(int)$row['attempts'];if($attempt>=(int)self::settings()['queue']['max_attempts']){self::terminal($row,'failed',$error);return;}$delay=min(DAY_IN_SECONDS,1800*(2**max(0,$attempt-1)));global $wpdb;$wpdb->update(self::table('messages'),['status'=>'retry_wait','available_at'=>gmdate('Y-m-d H:i:s',time()+$delay),'lease_until'=>null,'last_error'=>substr($error,0,191),'updated_at'=>self::now()],['uuid'=>$row['uuid']],['%s','%s','%s','%s','%s'],['%s']);self::event($row['uuid'],'retry_wait','warning',['error'=>$error,'attempt'=>$attempt]);
	}
	private static function terminal($row,$status,$error){global $wpdb;$wpdb->update(self::table('messages'),['status'=>$status,'terminal_at'=>self::now(),'lease_until'=>null,'last_error'=>substr((string)$error,0,191),'updated_at'=>self::now()],['uuid'=>$row['uuid']],['%s','%s','%s','%s','%s'],['%s']);$wpdb->update(self::table('recipients'),['status'=>$status,'updated_at'=>self::now()],['message_uuid'=>$row['uuid']],['%s','%s'],['%s']);self::event($row['uuid'],$status,'error',['error'=>$error]);}
	private static function send($payload){
		$s=self::settings();$id=sanitize_key((string)$payload['transport_id']);$transport=(array)($s['transports'][$id]??[]);if(empty($transport['enabled']))return new WP_Error('transport_disabled','Mail transport is disabled.');$type=sanitize_key((string)($transport['type']??'wp_mail'));if(in_array($type,['resend','brevo','smtp2go'],true))return self::send_api($type,$transport,$payload,$s);if($type==='smtp')return self::send_smtp($transport,$payload,$s);self::$dispatching=true;try{return wp_mail($payload['to'],$payload['subject'],$payload['message'],(array)$payload['headers']);}finally{self::$dispatching=false;}
	}
	private static function send_smtp($transport,$payload,$settings){
		$host=strtolower(trim((string)($transport['host']??'')));$port=absint($transport['port']??587);$security=in_array(($transport['security']??''),['tls','ssl','none'],true)?$transport['security']:'tls';$username=self::decrypt((string)($transport['username']??''));$password=self::decrypt((string)($transport['secret']??''));$from=sanitize_email($settings['from_email']??'');if(!preg_match('/^[a-z0-9.-]+$/i',$host)||!$port||$port>65535||is_wp_error($username)||is_wp_error($password)||$username===''||$password===''||!is_email($from))return new WP_Error('smtp_configuration_invalid','SMTP transport configuration is incomplete.');
		$configure=static function($mailer)use($host,$port,$security,$username,$password,$from,$settings){$mailer->isSMTP();$mailer->Host=$host;$mailer->Port=$port;$mailer->SMTPAuth=true;$mailer->Username=$username;$mailer->Password=$password;$mailer->SMTPSecure=$security==='none'?'':$security;$mailer->SMTPAutoTLS=$security==='tls';$mailer->setFrom($from,(string)($settings['from_name']??''),false);if(!empty($settings['reply_to'])&&is_email($settings['reply_to']))$mailer->addReplyTo($settings['reply_to']);};
		self::$dispatching=true;add_action('phpmailer_init',$configure,999);try{return wp_mail($payload['to'],$payload['subject'],$payload['message'],(array)$payload['headers']);}finally{remove_action('phpmailer_init',$configure,999);self::$dispatching=false;}
	}
	private static function send_api($type,$transport,$payload,$settings){
		$secret=self::decrypt((string)($transport['secret']??''));if(is_wp_error($secret)||$secret==='')return new WP_Error('transport_secret_unavailable','Transport secret is unavailable.');$from=trim((string)($settings['from_email']??''));if(!is_email($from))return new WP_Error('sender_unconfigured','A valid From email is required.');$name=trim((string)($settings['from_name']??get_bloginfo('name')));
		if($type==='resend'){$url='https://api.resend.com/emails';$headers=['Authorization'=>'Bearer '.$secret,'Content-Type'=>'application/json'];$body=['from'=>($name?$name.' <'.$from.'>':$from),'to'=>$payload['to'],'subject'=>$payload['subject'],'text'=>$payload['message']];}
		elseif($type==='brevo'){$url='https://api.brevo.com/v3/smtp/email';$headers=['api-key'=>$secret,'Content-Type'=>'application/json'];$body=['sender'=>['email'=>$from,'name'=>$name],'to'=>array_map(static fn($v)=>['email'=>$v],$payload['to']),'subject'=>$payload['subject'],'textContent'=>$payload['message']];}
		else{$url='https://api.smtp2go.com/v3/email/send';$headers=['Content-Type'=>'application/json'];$body=['api_key'=>$secret,'sender'=>($name?$name.' <'.$from.'>':$from),'to'=>$payload['to'],'subject'=>$payload['subject'],'text_body'=>$payload['message']];}
		$response=wp_remote_post($url,['timeout'=>15,'headers'=>$headers,'body'=>wp_json_encode($body)]);if(is_wp_error($response))return $response;$code=(int)wp_remote_retrieve_response_code($response);return $code>=200&&$code<300?true:new WP_Error('transport_http_'.$code,'Mail provider rejected the request.');
	}
	private static function hit($bucket,$seconds,$limit){global $wpdb;$table=self::table('rate_limits');$now=time();$start=gmdate('Y-m-d H:i:s',$now-($now%$seconds));$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE bucket=%s",$bucket),ARRAY_A);if(!$row||$row['window_start']!==$start){$wpdb->replace($table,['bucket'=>$bucket,'window_start'=>$start,'hits'=>1,'updated_at'=>self::now()],['%s','%s','%d','%s']);return false;}$changed=$wpdb->query($wpdb->prepare("UPDATE {$table} SET hits=hits+1,updated_at=%s WHERE bucket=%s AND hits<%d",self::now(),$bucket,max(1,$limit)));return !$changed;}
	public static function guard_contact($result,$input=[]){
		if(is_wp_error($result)||!self::enabled())return $result;$s=self::settings();if(empty($s['bot']['enabled']))return $result;$ip=(string)($_SERVER['REMOTE_ADDR']??'');$email=sanitize_email((string)($input['email']??''));$body=(string)($input['message']??'');$ipHash=self::hash_identity($ip);$emailHash=$email?self::hash_identity($email):'';$reason='';
		if(!empty($input['honeypot']))$reason='honeypot';elseif(!empty($input['started_at'])&&time()-(int)$input['started_at']<(int)$s['bot']['minimum_fill_seconds'])$reason='too_fast';elseif(self::hit('ip10:'.$ipHash,600,(int)$s['bot']['ip_10_min']))$reason='ip_rate';elseif(self::hit('ip24:'.$ipHash,DAY_IN_SECONDS,(int)$s['bot']['ip_24_hours']))$reason='ip_daily';elseif($emailHash&&self::hit('email1:'.$emailHash,HOUR_IN_SECONDS,(int)$s['bot']['email_1_hour']))$reason='email_rate';elseif($body!==''&&self::hit('body:'.self::hash_identity($body),600,(int)$s['bot']['duplicate_10_min']))$reason='duplicate';global $wpdb;$wpdb->insert(self::table('bot_events'),['form_id'=>'dreminex_contact','ip_hash'=>$ipHash,'email_hash'=>$emailHash,'outcome'=>$reason?'blocked':'accepted','reason'=>$reason?:'ok','created_at'=>self::now()],['%s','%s','%s','%s','%s','%s']);return $reason?new WP_Error('contact_blocked','Please wait before sending another message.'):true;
	}
	public static function cleanup(){global $wpdb;$s=self::settings();$wpdb->query($wpdb->prepare('DELETE FROM '.self::table('events').' WHERE created_at<%s',gmdate('Y-m-d H:i:s',time()-max(1,(int)$s['privacy']['event_retention_days'])*DAY_IN_SECONDS)));$wpdb->query($wpdb->prepare('DELETE FROM '.self::table('bot_events').' WHERE created_at<%s',gmdate('Y-m-d H:i:s',time()-max(1,(int)$s['privacy']['bot_retention_days'])*DAY_IN_SECONDS)));}
	private static function public_transport($id,$row){return ['id'=>$id,'type'=>$row['type']??'wp_mail','enabled'=>!empty($row['enabled']),'secret_configured'=>!empty($row['secret']),'verified_at'=>$row['verified_at']??null];}
	public static function diagnostics(){$s=self::settings();return ['enabled'=>self::enabled(),'operating_mode'=>$s['operating_mode'],'key_ready'=>self::key_ready(),'competing_mailers'=>self::conflicts(),'capture_active'=>self::delivery_active(),'transport_count'=>count((array)$s['transports']),'queue'=>self::queue_counts()];}
	private static function queue_counts(){global $wpdb;$out=[];foreach($wpdb->get_results('SELECT status,COUNT(*) total FROM '.self::table('messages').' GROUP BY status',ARRAY_A) as $row)$out[$row['status']]=(int)$row['total'];return $out;}
	public static function save(){
		if(!current_user_can('manage_options'))wp_die('Access denied.',403);check_admin_referer('dreminex_mail_engine_save');$s=self::settings();$s['module_enabled']=!empty($_POST['module_enabled']);$s['operating_mode']=in_array($_POST['operating_mode']??'', ['disabled','monitor','queue','immediate'],true)?$_POST['operating_mode']:'monitor';$s['capture_wp_mail']=!empty($_POST['capture_wp_mail']);$s['from_name']=mb_substr(sanitize_text_field(wp_unslash($_POST['from_name']??'')),0,128);$s['from_email']=sanitize_email(wp_unslash($_POST['from_email']??''));$s['reply_to']=sanitize_email(wp_unslash($_POST['reply_to']??''));$s['default_transport_id']=sanitize_key(wp_unslash($_POST['default_transport_id']??''));$s['queue']['batch_size']=max(1,min(100,absint($_POST['batch_size']??20)));$s['bot']['enabled']=!empty($_POST['bot_enabled']);
		$id=sanitize_key(wp_unslash($_POST['transport_id']??''));$type=sanitize_key(wp_unslash($_POST['transport_type']??''));if($id!==''&&preg_match('/^[a-z0-9_-]{3,64}$/',$id)&&in_array($type,['wp_mail','smtp','resend','brevo','smtp2go'],true)){$row=(array)($s['transports'][$id]??[]);$row['type']=$type;$row['enabled']=!empty($_POST['transport_enabled']);$secret=trim((string)wp_unslash($_POST['transport_secret']??''));if($secret!==''){ $encrypted=self::encrypt($secret);if(!is_wp_error($encrypted))$row['secret']=$encrypted;}$smtp_user=trim((string)wp_unslash($_POST['smtp_username']??''));if($smtp_user!==''){ $encrypted=self::encrypt($smtp_user);if(!is_wp_error($encrypted))$row['username']=$encrypted;}$host=strtolower(trim((string)wp_unslash($_POST['smtp_host']??'')));if($host!==''&&preg_match('/^[a-z0-9.-]+$/',$host))$row['host']=$host;$row['port']=max(1,min(65535,absint($_POST['smtp_port']??587)));$row['security']=in_array($_POST['smtp_security']??'', ['tls','ssl','none'],true)?$_POST['smtp_security']:'tls';$s['transports'][$id]=$row;if($s['default_transport_id']==='')$s['default_transport_id']=$id;}
		update_option(self::OPTION,$s,false);wp_safe_redirect(admin_url('admin.php?page=dreminex-mail-engine&saved=1'));exit;
	}
	public static function test(){
		if(!current_user_can('manage_options'))wp_die('Access denied.',403);check_admin_referer('dreminex_mail_engine_test');$to=sanitize_email(wp_unslash($_POST['test_recipient']??get_option('admin_email')));$s=self::settings();$id=sanitize_key(wp_unslash($_POST['test_transport_id']??$s['default_transport_id']));$row=(array)($s['transports'][$id]??[]);$result=(!$to||empty($row['enabled']))?new WP_Error('test_unavailable','Choose an enabled transport and valid recipient.'):self::send(['to'=>[$to],'subject'=>'Dreminex Mail Engine test','message'=>'This is an explicit Mail Engine transport test.','headers'=>[],'transport_id'=>$id]);if($result===true){$row['verified_at']=gmdate('c');$s['transports'][$id]=$row;update_option(self::OPTION,$s,false);$status='accepted';}else $status='failed';wp_safe_redirect(admin_url('admin.php?page=dreminex-mail-engine&test='.$status));exit;
	}
	public static function page(){
		if(!current_user_can('manage_options'))wp_die('Access denied.',403);$s=self::settings();$d=self::diagnostics();echo '<div class="wrap dreminex-suite"><header class="ds-page-header"><div><span class="ds-eyebrow">MAIL · DELIVERY GOVERNANCE</span><h1>Mail Engine</h1><p>Monitor first. Queue only after an explicit, verified configuration.</p></div><span class="ds-version">v1.0</span></header>';if(isset($_GET['saved']))echo '<div class="notice notice-success"><p>Mail Engine settings saved.</p></div>';if(isset($_GET['test']))echo '<div class="notice notice-'.($_GET['test']==='accepted'?'success':'error').'"><p>Transport test '.esc_html($_GET['test']==='accepted'?'was accepted by the transport. Inbox delivery still depends on the provider and receiving mailbox.':'failed safely. Review the transport configuration.').'</p></div>';echo '<section class="ds-summary"><div class="ds-stat"><span>Mode</span><strong class="ds-stat-word">'.esc_html($d['operating_mode']).'</strong><small>Capture '.($d['capture_active']?'active':'inactive').'</small></div><div class="ds-stat"><span>Encryption</span><strong class="ds-stat-word">'.($d['key_ready']?'Ready':'Required').'</strong><small>Set DREMINEX_MAIL_ENGINE_KEY outside WordPress.</small></div><div class="ds-stat"><span>Competing mailers</span><strong>'.esc_html(count($d['competing_mailers'])).'</strong><small>'.esc_html(implode(', ',$d['competing_mailers'])?:'None detected').'</small></div></section><section class="ds-panel"><h2>Safe configuration</h2><p>Monitor mode records no mail payload and never intercepts WordPress mail. Queue or immediate mode remains blocked while another recognized SMTP mailer is active.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_mail_engine_save">';wp_nonce_field('dreminex_mail_engine_save');echo '<p><label><input type="checkbox" name="module_enabled" value="1" '.checked(!empty($s['module_enabled']),true,false).'> Enable Mail Engine configuration</label></p><p><label>Operating mode <select name="operating_mode">';foreach(['disabled'=>'Disabled','monitor'=>'Monitor only','queue'=>'Encrypted queue','immediate'=>'Immediate transport'] as $v=>$label)echo '<option value="'.esc_attr($v).'" '.selected($s['operating_mode'],$v,false).'>'.esc_html($label).'</option>';echo '</select></label> <label><input type="checkbox" name="capture_wp_mail" value="1" '.checked(!empty($s['capture_wp_mail']),true,false).'> Capture WordPress mail when delivery is active</label></p><p><label>From name <input name="from_name" value="'.esc_attr($s['from_name']).'"></label> <label>From email <input type="email" name="from_email" value="'.esc_attr($s['from_email']).'"></label> <label>Reply-to <input type="email" name="reply_to" value="'.esc_attr($s['reply_to']).'"></label></p><p><label>Default transport <select name="default_transport_id"><option value="">Choose a configured transport</option>';foreach((array)$s['transports'] as $id=>$row)echo '<option value="'.esc_attr($id).'" '.selected($s['default_transport_id'],$id,false).'>'.esc_html($id.' · '.($row['type']??'wp_mail')).'</option>';echo '</select></label> <label>Queue batch <input type="number" name="batch_size" min="1" max="100" value="'.esc_attr($s['queue']['batch_size']).'"></label> <label><input type="checkbox" name="bot_enabled" value="1" '.checked(!empty($s['bot']['enabled']),true,false).'> Protect registered contact forms</label></p><hr><h3>Add or replace a transport</h3><p>Secrets and SMTP username are write-only and encrypted with the server key. Leave them blank to retain existing values.</p><p><label>ID <input name="transport_id" pattern="[a-z0-9_-]{3,64}" placeholder="transactional_primary"></label> <label>Type <select name="transport_type"><option value="wp_mail">WordPress mail</option><option value="smtp">SMTP</option><option value="resend">Resend API</option><option value="brevo">Brevo API</option><option value="smtp2go">SMTP2GO API</option></select></label> <label>Secret/API key or SMTP password <input type="password" name="transport_secret" autocomplete="new-password"></label> <label><input type="checkbox" name="transport_enabled" value="1"> Enabled</label></p><p><label>SMTP host <input name="smtp_host" placeholder="smtp.example.com"></label> <label>SMTP port <input type="number" name="smtp_port" value="587" min="1" max="65535"></label> <label>SMTP security <select name="smtp_security"><option value="tls">TLS</option><option value="ssl">SSL</option><option value="none">None</option></select></label> <label>SMTP username <input name="smtp_username" autocomplete="new-password"></label></p>';submit_button('Save Mail Engine');echo '</form></section><section class="ds-panel"><h2>Configured transports</h2><table class="widefat striped"><thead><tr><th>ID</th><th>Type</th><th>Enabled</th><th>Secret</th><th>Verified</th></tr></thead><tbody>';if(!$s['transports'])echo '<tr><td colspan="5">No transport configured.</td></tr>';foreach($s['transports'] as $id=>$row){$r=self::public_transport($id,$row);echo '<tr><td>'.esc_html($r['id']).'</td><td>'.esc_html($r['type']).'</td><td>'.($r['enabled']?'Yes':'No').'</td><td>'.($r['secret_configured']?'Configured':'Not set').'</td><td>'.esc_html($r['verified_at']?:'Not tested').'</td></tr>';}echo '</tbody></table><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:16px"><input type="hidden" name="action" value="dreminex_mail_engine_test">';wp_nonce_field('dreminex_mail_engine_test');echo '<label>Test recipient <input type="email" name="test_recipient" value="'.esc_attr(get_option('admin_email')).'"></label> <label>Transport <select name="test_transport_id">';foreach($s['transports'] as $id=>$row)echo '<option value="'.esc_attr($id).'">'.esc_html($id).'</option>';echo '</select></label>';submit_button('Send explicit test','secondary','submit',false);echo '</form></section></div>';
	}
}

Dreminex_Mail_Engine::boot();
