<?php
if (!defined('ABSPATH')) { exit; }
/* Dreminex Fashion — off-site new order email notification.
 * Separate Code Snippets entry. Sends only website checkout orders to the
 * WordPress administrator email. Requires a working WordPress mail transport.
 * Disables the native WooCommerce New Order email separately to avoid duplicates.
 */
if ( ! function_exists( 'dreminex_order_alert_send' ) ) {
	function dreminex_order_alert_send( $order_id, $attempt = 1 ) {
		$order = wc_get_order( absint( $order_id ) );
		if ( ! $order || $order->get_meta( '_dreminex_admin_alert_sent' ) ) return;
		$to = Dreminex_Suite_Control::setting( 'order_management', 'recipient', get_option( 'admin_email' ) );
		if ( ! is_email( $to ) ) return;
		$lines = array();
		foreach ( $order->get_items( 'line_item' ) as $item ) {
			$lines[] = '<li>' . esc_html( $item->get_name() ) . ' × ' . esc_html( $item->get_quantity() )
				. ' — ' . wp_kses_post( wc_price( $item->get_total(), array( 'currency' => $order->get_currency() ) ) ) . '</li>';
		}
		$address = implode( ', ', array_filter( array(
			$order->get_shipping_address_1() ?: $order->get_billing_address_1(),
			$order->get_shipping_address_2() ?: $order->get_billing_address_2(),
			$order->get_shipping_city() ?: $order->get_billing_city(),
			$order->get_shipping_state() ?: $order->get_billing_state(),
			$order->get_shipping_postcode() ?: $order->get_billing_postcode(),
		) ) );
		$advance = $order->get_meta( '_dreminex_advance_due' );
		$balance = $order->get_meta( '_dreminex_balance_due' );
		$methods = array( 'bkash' => 'bKash', 'nagad' => 'Nagad', 'rocket' => 'Rocket' );
		$method = $order->get_meta( '_dreminex_advance_method' );
		$money = function ( $value ) use ( $order ) {
			return wp_kses_post( wc_price( $value, array( 'currency' => $order->get_currency() ) ) );
		};
		$body = '<div style="font-family:Arial,sans-serif;color:#212529;background:#F8F9FA;padding:20px;max-width:640px">'
			. Dreminex_Suite_Control::tr(Dreminex_Suite_Setup::text("<h2 style=\"color:#212529;border-bottom:3px solid #00B4D8;padding-bottom:10px\">Dreminex Fashion — New order #"), Dreminex_Suite_Setup::text('<h2 style="color:#212529;border-bottom:3px solid #00B4D8;padding-bottom:10px">Dreminex Fashion — নতুন অর্ডার #')) . esc_html( $order->get_order_number() ) . '</h2>'
			. '<p><strong>Customer:</strong> ' . esc_html( $order->get_formatted_billing_full_name() ) . '<br>'
			. '<strong>Phone:</strong> ' . esc_html( $order->get_billing_phone() ) . '<br>'
			. '<strong>Email:</strong> ' . esc_html( $order->get_billing_email() ) . '<br>'
			. '<strong>Delivery address:</strong> ' . esc_html( $address ) . '</p>'
			. '<h3 style="color:#212529">Products</h3><ul>' . implode( '', $lines ) . '</ul>'
			. '<p><strong>Order total:</strong> ' . $money( $order->get_total() ) . '</p>';
		if ( '' !== (string) $advance ) {
			$body .= '<p><strong>Advance to verify:</strong> ' . $money( $advance ) . '<br>'
				. '<strong>Collect at delivery:</strong> ' . $money( $balance ) . '<br>'
				. '<strong>Service:</strong> ' . esc_html( $methods[ $method ] ?? $method ) . '<br>'
				. '<strong>Transaction ID:</strong> ' . esc_html( $order->get_meta( '_dreminex_advance_txid' ) ) . '</p>';
		}
        $body .= '<p><a style="background:#212529;color:#F8F9FA;padding:10px 14px;text-decoration:none" href="'.esc_url($order->get_edit_order_url()).'">'.esc_html(Dreminex_Suite_Control::tr('View order','অর্ডার দেখুন')).'</a></p>';
        if($order->get_payment_method()==='dreminex_mobile_payment' && class_exists('Dreminex_Payments_Order_View')) {
            ob_start();Dreminex_Payments_Order_View::summary($order);$body.=ob_get_clean();
        } else $body.=Dreminex_Suite_Control::tr('<p>Verify the advance payment manually. This email does not confirm payment.</p>','<p>অগ্রিম টাকা ম্যানুয়ালি যাচাই করুন। এই email পেমেন্ট নিশ্চিত করে না।</p>');
        $body.='</div>';
		$sent = wp_mail(
			$to,
			Dreminex_Suite_Setup::text('Dreminex Fashion — New order #') . $order->get_order_number(),
			$body,
			array( 'Content-Type: text/html; charset=UTF-8' )
		);
		if ( $sent ) {
			$order->update_meta_data( '_dreminex_admin_alert_sent', gmdate( 'c' ) );
			$order->save();
			return;
		}
		$attempt = absint( $attempt );
		$delays = array( 10, 30, 60, 180, 360, 1440 ); // Minutes, up to a day.
		if ( $attempt > count( $delays ) ) return;
		$next = time() + $delays[ $attempt - 1 ] * MINUTE_IN_SECONDS;
		$args = array( 'order_id' => $order->get_id(), 'attempt' => $attempt + 1 );
		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action( $next, 'dreminex_order_alert_retry', $args, 'dreminex-orders', true );
		} else {
			wp_schedule_single_event( $next, 'dreminex_order_alert_retry', $args );
		}
	}
}
add_action( 'woocommerce_checkout_order_processed', function ( $order_id ) {
	dreminex_order_alert_send( $order_id, 1 );
}, 30 );
add_action( 'dreminex_order_alert_retry', 'dreminex_order_alert_send', 10, 2 );
