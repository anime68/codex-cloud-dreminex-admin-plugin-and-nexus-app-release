<?php
if (!defined('ABSPATH')) exit;
/** Unified checkout protection loader. Legacy component files remain isolated and can be rolled back. */
$dreminex_protection_components = [
 'phone_enabled'=>'dreminex_phone_validation.php',
 'ip_cooldown_enabled'=>'dreminex_duplicate_checkout.php',
 'receipt_ip_enabled'=>'dreminex_receipt_ip_warning.php',
 'browser_limit_enabled'=>'dreminex_customer_order_limit.php',
 'partial_checkout_enabled'=>'dreminex_partial_checkout.php',
];
$dreminex_modules=(array)get_option('dreminex_suite_modules',[]);
if(!empty($dreminex_modules['checkout_protection'])) foreach($dreminex_protection_components as $setting=>$file){
 if((int)Dreminex_Suite_Control::setting('checkout_protection',$setting,1)!==1)continue;
 $path=__DIR__.'/'.$file;if(is_readable($path))require_once $path;
}
unset($dreminex_protection_components,$dreminex_modules,$setting,$file,$path);

