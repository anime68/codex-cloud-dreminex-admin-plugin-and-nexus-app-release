<?php
if (!defined('ABSPATH')) exit;
/** Unified order operations loader. Each feature can still be switched independently. */
$dreminex_order_components=[
 'history_enabled'=>'dreminex_customer_history.php',
 'admin_alert_enabled'=>'dreminex_admin_order_alert.php',
 'owner_email_enabled'=>'dreminex_order_email_notification.php',
 'statuses_enabled'=>'dreminex_order_statuses.php',
 'tracking_enabled'=>'dreminex_order_tracking.php',
];
$dreminex_modules=(array)get_option('dreminex_suite_modules',[]);
if(!empty($dreminex_modules['order_management']))foreach($dreminex_order_components as $setting=>$file){
 if((int)Dreminex_Suite_Control::setting('order_management',$setting,1)!==1)continue;
 $path=__DIR__.'/'.$file;if(is_readable($path))require_once $path;
}
unset($dreminex_order_components,$dreminex_modules,$setting,$file,$path);

