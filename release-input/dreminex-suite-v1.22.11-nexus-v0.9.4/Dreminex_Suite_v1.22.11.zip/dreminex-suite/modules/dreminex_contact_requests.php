<?php
/**
 * Dreminex Contact evidence form. Loaded by the Novamira sandbox loader.
 */
if (!defined('ABSPATH')) { exit; }

add_shortcode('dreminex_contact_evidence_form', function () {
    $status = isset($_GET['dreminex_contact']) ? sanitize_key(wp_unslash($_GET['dreminex_contact'])) : '';
    $messages = [
        'sent' => 'Thank you. Your request has been saved. We will review it soon.',
        'invalid' => 'Please enter your name, a valid email address, and a message.',
        'file' => 'The attachment could not be accepted. Use JPG, PNG, WebP, MP4, MOV or WebM, up to 10 MB.',
        'failed' => Dreminex_Suite_Setup::text('Sorry, your message could not be sent. Please try again or email hello@dreminexfashion.store.'),
        'wait' => 'Please wait a while before sending another message.',
    ];
    ob_start();
    ?>
    <div class="dreminex-contact-form">
      <?php if (isset($messages[$status])) : ?>
        <div class="dreminex-contact-notice" role="status"><?php echo esc_html($messages[$status]); ?></div>
      <?php endif; ?>
      <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post" enctype="multipart/form-data">
        <input type="hidden" name="action" value="dreminex_contact_evidence">
        <?php wp_nonce_field('dreminex_contact_evidence', 'dreminex_contact_nonce'); ?>
        <input type="hidden" name="dreminex_contact_started_at" value="<?php echo esc_attr(time()); ?>">
        <div class="dreminex-contact-honeypot" aria-hidden="true"><label>Leave this field blank <input type="text" name="dreminex_website" tabindex="-1" autocomplete="off"></label></div>
        <div class="dreminex-contact-row">
          <label for="dreminex-contact-name">Your name <span aria-hidden="true">*</span></label>
          <input id="dreminex-contact-name" type="text" name="contact_name" placeholder="Enter your name" autocomplete="name" maxlength="120" required>
        </div>
        <div class="dreminex-contact-row">
          <label for="dreminex-contact-email">Your email <span aria-hidden="true">*</span></label>
          <input id="dreminex-contact-email" type="email" name="contact_email" placeholder="Enter your email address" autocomplete="email" maxlength="254" required>
        </div>
        <div class="dreminex-contact-row">
          <label for="dreminex-contact-order">Order number (optional)</label>
          <input id="dreminex-contact-order" type="text" name="order_reference" placeholder="Enter your order number, if applicable" maxlength="100">
        </div>
        <div class="dreminex-contact-row">
          <label for="dreminex-contact-message">Your message <span aria-hidden="true">*</span></label>
          <textarea id="dreminex-contact-message" name="contact_message" placeholder="Write your message here" rows="6" maxlength="5000" required></textarea>
        </div>
        <div class="dreminex-contact-row">
          <label for="dreminex-contact-evidence">Photo or video (optional)</label>
          <input id="dreminex-contact-evidence" type="file" name="contact_evidence" accept=".jpg,.jpeg,.png,.webp,.mp4,.mov,.webm,image/jpeg,image/png,image/webp,video/mp4,video/quicktime,video/webm" aria-describedby="dreminex-contact-file-help">
          <small id="dreminex-contact-file-help">For delivery or product issues, you can attach one clear photo or short video. JPG, PNG, WebP, MP4, MOV or WebM; maximum 10 MB.</small>
        </div>
        <button type="submit">Send Message</button>
      </form>
    </div>
    <style>
      .dreminex-contact-form { width:100%; }
      .dreminex-contact-form .dreminex-contact-row { margin-bottom:18px; }
      .dreminex-contact-form label { display:block; margin-bottom:7px; font-weight:600; color:#212529; }
      .dreminex-contact-form input:not([type=hidden]), .dreminex-contact-form textarea { box-sizing:border-box; width:100%; padding:12px 14px; border:1px solid #dee2e6; border-radius:6px; background:#fff; color:#212529; font:inherit; }
      .dreminex-contact-form input[type=file] { padding:10px; }
      .dreminex-contact-form input:focus, .dreminex-contact-form textarea:focus { outline:2px solid #00b4d7; outline-offset:1px; }
      .dreminex-contact-form small { display:block; margin-top:7px; line-height:1.5; color:#555; }
      .dreminex-contact-form button { cursor:pointer; padding:12px 26px; border:1px solid #dee2e6; border-radius:6px; background:#fff; color:#212529; font:inherit; font-weight:600; }
      .dreminex-contact-form button:hover, .dreminex-contact-form button:focus { background:#00b4d7; border-color:#00b4d7; color:#212529; }
      .dreminex-contact-notice { padding:12px 16px; margin-bottom:20px; border-radius:6px; background:#eef8fa; color:#173c46; }
      .dreminex-contact-honeypot { position:absolute!important; left:-9999px!important; width:1px!important; height:1px!important; overflow:hidden!important; }
      @media (max-width:767px) { .dreminex-contact-form button { width:100%; } }
    </style>
    <?php
    return ob_get_clean();
});

function dreminex_contact_evidence_redirect($status) {
    wp_safe_redirect(add_query_arg('dreminex_contact', $status, Dreminex_Suite_Setup::page_url('contact')) . '#dreminex-contact-name', 303);
    exit;
}
add_action('admin_post_nopriv_dreminex_contact_evidence', 'dreminex_contact_evidence_submit');
add_action('admin_post_dreminex_contact_evidence', 'dreminex_contact_evidence_submit');
function dreminex_contact_table() {
    global $wpdb;
    return $wpdb->prefix . 'dreminex_contact_requests';
}
function dreminex_contact_replies_table() {
    global $wpdb;
    return $wpdb->prefix . 'dreminex_contact_replies';
}
function dreminex_contact_private_dir() {
    return dirname(ABSPATH) . '/dreminex-contact-evidence';
}
add_action('init', function () {
    if (get_option('dreminex_contact_storage_version') === '5') return;
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $table = dreminex_contact_table();
    $collate = $wpdb->get_charset_collate();
    dbDelta("CREATE TABLE {$table} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        created_at datetime NOT NULL,
        customer_name varchar(120) NOT NULL,
        customer_email varchar(254) NOT NULL,
        order_reference varchar(100) NOT NULL DEFAULT '',
        customer_message text NOT NULL,
        file_name varchar(255) NOT NULL DEFAULT '',
        stored_name varchar(100) NOT NULL DEFAULT '',
        file_mime varchar(100) NOT NULL DEFAULT '',
        file_size bigint(20) unsigned NOT NULL DEFAULT 0,
        email_status varchar(20) NOT NULL DEFAULT 'pending',
        request_status varchar(20) NOT NULL DEFAULT 'new',
        status_before_trash varchar(20) NOT NULL DEFAULT '',
        trashed_at datetime NULL,
        admin_note text NOT NULL,
        PRIMARY KEY  (id)
    ) {$collate};");
    $replies = dreminex_contact_replies_table();
    dbDelta("CREATE TABLE {$replies} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        request_id bigint(20) unsigned NOT NULL,
        created_at datetime NOT NULL,
        subject varchar(255) NOT NULL,
        message text NOT NULL,
        delivery_status varchar(20) NOT NULL DEFAULT 'pending',
        message_type varchar(20) NOT NULL DEFAULT 'manual',
        PRIMARY KEY  (id),
        KEY request_id (request_id)
    ) {$collate};");
    if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table
        && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $replies)) === $replies) {
        update_option('dreminex_contact_storage_version', '5', false);
    }
});
function dreminex_contact_admin_page() {
    if (!current_user_can('manage_options')) wp_die('Access denied.');
    global $wpdb;
    $table = dreminex_contact_table();
    $id = isset($_GET['request_id']) ? absint($_GET['request_id']) : 0;
    echo '<div class="wrap"><h1>Contact Requests</h1>';
    if ($id) {
        $item = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id));
        if (!$item) { echo '<p>Request not found.</p></div>'; return; }
        echo '<p><a href="' . esc_url(admin_url('admin.php?page=dreminex-contact-requests')) . '">&larr; All requests</a></p>';
        echo '<h2>Request #' . esc_html($item->id) . '</h2><table class="widefat striped"><tbody>';
        echo '<tr><th>Date</th><td>' . esc_html($item->created_at) . ' (site time)</td></tr>';
        echo '<tr><th>Name</th><td>' . esc_html($item->customer_name) . '</td></tr>';
        echo '<tr><th>Email</th><td><a href="' . esc_url('mailto:' . $item->customer_email) . '">' . esc_html($item->customer_email) . '</a></td></tr>';
        echo '<tr><th>Order number</th><td>' . esc_html($item->order_reference ?: 'Not provided') . '</td></tr>';
        echo '<tr><th>Message</th><td>' . nl2br(esc_html($item->customer_message)) . '</td></tr>';
        echo '<tr><th>Notification to store</th><td>' . esc_html($item->email_status) . '</td></tr>';
        echo '<tr><th>Status</th><td>' . esc_html(ucwords(str_replace('_', ' ', $item->request_status))) . '</td></tr>';
        if ($item->stored_name) {
            $url = wp_nonce_url(admin_url('admin-post.php?action=dreminex_contact_download&request_id=' . $item->id), 'dreminex_contact_download_' . $item->id);
            echo '<tr><th>Attachment</th><td><a href="' . esc_url($url) . '">Download ' . esc_html($item->file_name) . '</a> (' . esc_html(size_format($item->file_size)) . ')</td></tr>';
            $preview = wp_nonce_url(admin_url('admin-post.php?action=dreminex_contact_preview&request_id=' . $item->id), 'dreminex_contact_preview_' . $item->id);
            if (str_starts_with($item->file_mime, 'image/')) {
                echo '<tr><th>Photo preview</th><td><img src="' . esc_url($preview) . '" alt="Customer attachment" style="max-width:100%;max-height:520px;object-fit:contain;border:1px solid #ddd"></td></tr>';
            } elseif (str_starts_with($item->file_mime, 'video/')) {
                echo '<tr><th>Video preview</th><td><video controls preload="metadata" src="' . esc_url($preview) . '" style="max-width:100%;max-height:520px"></video><p>If your browser cannot play this format, use Download.</p></td></tr>';
            }
        }
        echo '</tbody></table>';
        if (isset($_GET['saved']) && $_GET['saved'] === '1') echo '<div class="notice notice-success"><p>Status and private note saved.</p></div>';
        if (isset($_GET['status_email'])) {
            if ($_GET['status_email'] === 'accepted') echo '<div class="notice notice-success"><p>Status saved. The mail server accepted the customer email; inbox delivery is not guaranteed.</p></div>';
            if ($_GET['status_email'] === 'failed') echo '<div class="notice notice-error"><p>Status saved, but the customer email failed. Check mail settings, then use “Resend” on this status.</p></div>';
        }
        if (isset($_GET['reply'])) {
            if ($_GET['reply'] === 'accepted') echo '<div class="notice notice-success"><p>The mail server accepted your reply. Check the reply history below.</p></div>';
            if ($_GET['reply'] === 'failed') echo '<div class="notice notice-error"><p>The reply could not be sent. Check the mail settings and try again.</p></div>';
        }
        echo '<h2>Manage request</h2><form method="post" enctype="multipart/form-data" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="dreminex_contact_manage"><input type="hidden" name="request_id" value="' . esc_attr($item->id) . '">';
        wp_nonce_field('dreminex_contact_manage_' . $item->id);
        echo '<p><label for="dreminex-status">Status</label><br><select id="dreminex-status" name="request_status">';
        foreach (['new'=>'New','in_progress'=>'In progress','resolved'=>'Resolved'] as $value=>$label) {
            echo '<option value="' . esc_attr($value) . '" ' . selected($item->request_status,$value,false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></p><p><label for="dreminex-note">Private note (only administrators can see this)</label><br><textarea id="dreminex-note" name="admin_note" rows="4" style="width:100%;max-width:700px">' . esc_textarea($item->admin_note) . '</textarea></p>';
        echo '<p>Changing the status automatically sends its matching branded email to the customer. The private note above is never included.</p>';
        echo '<p><label for="dreminex-extra">Extra comment for the customer (optional; included in the status email)</label><br><textarea id="dreminex-extra" name="customer_comment" rows="4" maxlength="5000" style="width:100%;max-width:700px"></textarea></p>';
        echo '<p><label><input type="checkbox" name="resend_status_email" value="1"> Resend the selected status email even if the status stays the same</label></p>';
        echo '<p><label>Photo or video for this status email (optional)<br><input type="file" name="status_media" accept=".jpg,.jpeg,.png,.webp,.mp4,.mov,.webm,image/jpeg,image/png,image/webp,video/mp4,video/quicktime,video/webm"></label><br><small>Maximum 10 MB. If left empty, the saved default for the selected status is used.</small></p>';
        echo '<details><summary>Preview default status messages</summary>';
        foreach (['new','in_progress','resolved'] as $value) {
            $template = dreminex_contact_status_template($value, $item);
            echo '<h4>' . esc_html($template['heading']) . '</h4><p>' . esc_html($template['text']) . '</p>';
        }
        echo '</details>';
        submit_button('Save status and note');
        echo '</form>';
        $replies = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . dreminex_contact_replies_table() . ' WHERE request_id = %d ORDER BY id DESC', $id));
        echo '<p><a href="' . esc_url(admin_url('admin.php?page=dreminex-contact-mail-media')) . '">Set default photos or videos for status emails and replies</a></p>';
        echo '<h2>Reply to customer</h2><p>To: ' . esc_html($item->customer_email) . ' &nbsp; From: your configured store email</p>';
        echo '<form method="post" enctype="multipart/form-data" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="dreminex_contact_reply"><input type="hidden" name="request_id" value="' . esc_attr($item->id) . '">';
        wp_nonce_field('dreminex_contact_reply_' . $item->id);
        echo '<p><label for="dreminex-reply-subject">Subject</label><br><input required id="dreminex-reply-subject" name="subject" type="text" maxlength="255" style="width:100%;max-width:700px" value="' . esc_attr(Dreminex_Suite_Setup::text('Re: Your Dreminex Fashion request #') . $item->id) . '"></p>';
        echo '<p><label for="dreminex-reply-message">Your reply</label><br><textarea required id="dreminex-reply-message" name="reply_message" rows="8" maxlength="10000" style="width:100%;max-width:700px"></textarea></p>';
        echo '<p><label>Photo or video for this reply (optional)<br><input type="file" name="reply_media" accept=".jpg,.jpeg,.png,.webp,.mp4,.mov,.webm,image/jpeg,image/png,image/webp,video/mp4,video/quicktime,video/webm"></label><br><small>Maximum 10 MB. If left empty, the saved default for this request status is used.</small></p>';
        submit_button('Send reply by email');
        echo '</form>';
        echo '<h3>Reply history</h3>';
        if (!$replies) echo '<p>No replies sent from this dashboard yet.</p>';
        foreach ($replies as $reply) {
            echo '<div style="background:#fff;border:1px solid #ddd;padding:12px;margin:10px 0;max-width:700px"><strong>' . esc_html($reply->subject) . '</strong> &mdash; ' . esc_html($reply->created_at) . ' (site time), ' . esc_html($reply->message_type) . ', mail server: ' . esc_html($reply->delivery_status) . '<p>' . nl2br(esc_html($reply->message)) . '</p></div>';
        }
        $delete_url = wp_nonce_url(admin_url('admin-post.php?action=dreminex_contact_delete&request_id=' . $item->id), 'dreminex_contact_delete_' . $item->id);
        echo '<p><a class="button button-link-delete" href="' . esc_url($delete_url) . '" onclick="return confirm(\'Move this request to Trash?\');">Move this request to Trash</a></p></div>';
        return;
    }
    $page = max(1, isset($_GET['paged']) ? absint($_GET['paged']) : 1);
    $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
    $items = $wpdb->get_results($wpdb->prepare("SELECT id,created_at,customer_name,customer_email,order_reference,stored_name,request_status FROM {$table} ORDER BY id DESC LIMIT 20 OFFSET %d", ($page-1)*20));
    if (isset($_GET['deleted']) && $_GET['deleted'] === '1') echo '<div class="notice notice-success"><p>Request and attachment deleted.</p></div>';
    echo '<p>' . esc_html($total) . ' saved request(s). Messages and files remain here even if the email notification fails. Open each request to see its details, download its attachment, or delete it.</p>';
    echo '<table class="widefat striped"><thead><tr><th>ID</th><th>Date (site time)</th><th>Name</th><th>Email</th><th>Order</th><th>File</th><th>Status</th></tr></thead><tbody>';
    foreach ($items as $item) {
        $url = admin_url('admin.php?page=dreminex-contact-requests&request_id=' . $item->id);
        echo '<tr><td><a href="' . esc_url($url) . '">#' . esc_html($item->id) . '</a></td><td>' . esc_html($item->created_at) . '</td><td>' . esc_html($item->customer_name) . '</td><td>' . esc_html($item->customer_email) . '</td><td>' . esc_html($item->order_reference ?: '—') . '</td><td>' . ($item->stored_name ? 'Yes' : 'No') . '</td><td>' . esc_html(ucwords(str_replace('_',' ',$item->request_status))) . '</td></tr>';
    }
    if (!$items) echo '<tr><td colspan="7">No requests yet.</td></tr>';
    echo '</tbody></table>';
    $pages = (int) ceil($total/20);
    if ($pages > 1) echo '<p>' . wp_kses_post(paginate_links(['base'=>add_query_arg('paged','%#%'),'current'=>$page,'total'=>$pages])) . '</p>';
    echo '</div>';
}
add_action('admin_post_dreminex_contact_download', function () {
    if (!current_user_can('manage_options')) wp_die('Access denied.', 403);
    $id = isset($_GET['request_id']) ? absint($_GET['request_id']) : 0;
    check_admin_referer('dreminex_contact_download_' . $id);
    global $wpdb;
    $item = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . dreminex_contact_table() . ' WHERE id = %d', $id));
    if (!$item || !$item->stored_name || basename($item->stored_name) !== $item->stored_name) wp_die('Attachment not found.', 404);
    $path = dreminex_contact_private_dir() . '/' . $item->stored_name;
    if (!is_file($path)) wp_die('Attachment not found.', 404);
    while (ob_get_level()) ob_end_clean();
    nocache_headers();
    header('Content-Type: application/octet-stream');
    header('X-Content-Type-Options: nosniff');
    header('Content-Disposition: attachment; filename="' . str_replace(['"', "\r", "\n"], '', sanitize_file_name($item->file_name)) . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    exit;
});
add_action('admin_post_dreminex_contact_delete', function () {
    if (!current_user_can('manage_options')) wp_die('Access denied.', 403);
    $id = isset($_GET['request_id']) ? absint($_GET['request_id']) : 0;
    check_admin_referer('dreminex_contact_delete_' . $id);
    global $wpdb;
    $table = dreminex_contact_table();
    $item = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id));
    if (!$item) wp_die('Request not found.', 404);
    $result=Dreminex_Suite_Contact_Trash::operate([$id],'trash');
    if(is_wp_error($result)||!empty($result['failed_ids']))wp_die('Request could not be moved to Trash.',500);
    wp_safe_redirect(admin_url('admin.php?page=dreminex-contact-requests&view=trash&changed=1'), 303);
    exit;
});
add_action('admin_post_dreminex_contact_preview', function () {
    if (!current_user_can('manage_options')) wp_die('Access denied.', 403);
    $id = isset($_GET['request_id']) ? absint($_GET['request_id']) : 0;
    check_admin_referer('dreminex_contact_preview_' . $id);
    global $wpdb;
    $item = $wpdb->get_row($wpdb->prepare('SELECT stored_name,file_mime FROM ' . dreminex_contact_table() . ' WHERE id = %d', $id));
    $allowed = ['image/jpeg','image/png','image/webp','video/mp4','video/quicktime','video/webm'];
    if (!$item || !$item->stored_name || basename($item->stored_name) !== $item->stored_name || !in_array($item->file_mime,$allowed,true)) wp_die('Preview not found.',404);
    $path = dreminex_contact_private_dir() . '/' . $item->stored_name;
    if (!is_file($path)) wp_die('Preview not found.',404);
    $size = filesize($path);
    $start = 0; $end = $size - 1;
    if (isset($_SERVER['HTTP_RANGE']) && preg_match('/^bytes=(\d*)-(\d*)$/', $_SERVER['HTTP_RANGE'], $m)) {
        $start = $m[1] === '' ? max(0, $size - (int)$m[2]) : (int)$m[1];
        $end = $m[1] === '' || $m[2] === '' ? $size - 1 : min($size - 1, (int)$m[2]);
        if ($start > $end || $start >= $size) {
            header('Content-Range: bytes */' . $size, true, 416); exit;
        }
        status_header(206);
        header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
    }
    while (ob_get_level()) ob_end_clean();
    nocache_headers();
    header('Content-Type: ' . $item->file_mime);
    header('X-Content-Type-Options: nosniff');
    header('Content-Security-Policy: sandbox');
    header('Content-Disposition: inline');
    header('Accept-Ranges: bytes');
    header('Content-Length: ' . ($end-$start+1));
    $handle = fopen($path,'rb');
    if ($handle) {
        fseek($handle,$start);
        $left=$end-$start+1;
        while ($left>0 && !feof($handle)) {
            $chunk=fread($handle,min(65536,$left));
            if ($chunk===false || $chunk==='') break;
            echo $chunk;
            $left-=strlen($chunk);
        }
        fclose($handle);
    }
    exit;
});
function dreminex_contact_status_template($status, $item) {
    $templates = [
        'new' => [
            'heading' => 'We received your request',
            'subject' => Dreminex_Suite_Setup::text('We received your Dreminex Fashion request #') . $item->id,
            'text' => Dreminex_Suite_Setup::text('Thank you for contacting Dreminex Fashion. Your request has been saved. Our team will review the details and any file you attached, then get back to you.'),
        ],
        'in_progress' => [
            'heading' => 'We are reviewing your request',
            'subject' => Dreminex_Suite_Setup::text('Update on your Dreminex Fashion request #') . $item->id,
            'text' => 'We are reviewing your request and the information you provided. We will contact you if we need more details or have an update.',
        ],
        'resolved' => [
            'heading' => 'Your request has been marked resolved',
            'subject' => Dreminex_Suite_Setup::text('Your Dreminex Fashion request #') . $item->id . ' has been marked resolved',
            'text' => 'We have marked your request as resolved. If you still need help, please reply to this email and tell us what remains unresolved.',
        ],
    ];
    return $templates[$status] ?? null;
}
function dreminex_contact_send_status_email($item, $status, $comment = '', $media = null) {
    global $wpdb;
    if($media===null)$media=dreminex_contact_mail_resolve('', $status);
    if(!empty($media['error']))return false;
    $template = dreminex_contact_status_template($status, $item);
    if (!$template || !is_email($item->customer_email)) return false;
    $name = $item->customer_name;
    $plain = 'Hi ' . $name . ",\n\n" . $template['text'] . "\n\n";
    if ($comment !== '') $plain .= "A note from our team:\n" . $comment . "\n\n";
    $plain .= 'Request #' . $item->id . ($item->order_reference ? ' | Order reference: ' . $item->order_reference : '') . "\n\n";
    $plain .= Dreminex_Suite_Setup::text("If you have questions, reply to this email.\nDreminex Fashion");
    $html = '<p>Hi ' . esc_html($name) . ',</p><p>' . esc_html($template['text']) . '</p>';
    if ($comment !== '') $html .= '<p><strong>A note from our team:</strong><br>' . nl2br(esc_html($comment)) . '</p>';
    $html .= '<p><strong>Request #</strong>' . esc_html($item->id);
    if ($item->order_reference) $html .= '<br><strong>Order reference:</strong> ' . esc_html($item->order_reference);
    $html .= '</p><p>If you have questions, reply to this email.</p>';
    if (function_exists('WC') && WC()) {
        $mailer = WC()->mailer();
        $html = $mailer->wrap_message($template['heading'], $html);
        $emails = $mailer->get_emails();
        $first = reset($emails);
        if ($first && method_exists($first, 'style_inline')) $html = $first->style_inline($html);
    } else {
        $html = '<html><body><h1>' . esc_html($template['heading']) . '</h1>' . $html . Dreminex_Suite_Setup::text('<p>Dreminex Fashion</p></body></html>');
    }
    $log_message=$plain.(!empty($media['name'])?"\n\nPhoto/video attached: ".$media['name']:'');
    $ok = $wpdb->insert(dreminex_contact_replies_table(), [
        'request_id'=>$item->id,'created_at'=>current_time('mysql'),'subject'=>$template['subject'],
        'message'=>$log_message,'delivery_status'=>'pending','message_type'=>'status'
    ], ['%d','%s','%s','%s','%s','%s']);
    if (!$ok) {dreminex_contact_mail_cleanup($media);return false;}
    $log_id=(int)$wpdb->insert_id;
    $sent=wp_mail($item->customer_email, $template['subject'], $html, [
        'Content-Type: text/html; charset=UTF-8',
        Dreminex_Suite_Setup::text('From: Dreminex Fashion <hello@dreminexfashion.store>'),
        Dreminex_Suite_Setup::text('Reply-To: Dreminex Fashion <hello@dreminexfashion.store>')
    ], !empty($media['path'])?[$media['path']]:[]);
    dreminex_contact_mail_cleanup($media);
    $wpdb->update(dreminex_contact_replies_table(), ['delivery_status'=>$sent?'accepted':'failed'], ['id'=>$log_id], ['%s'], ['%d']);
    return $sent;
}
add_action('admin_post_dreminex_contact_manage', function () {
    if (!current_user_can('manage_options')) wp_die('Access denied.',403);
    $id=isset($_POST['request_id'])?absint($_POST['request_id']):0;
    check_admin_referer('dreminex_contact_manage_'.$id);
    $status=isset($_POST['request_status'])?sanitize_key(wp_unslash($_POST['request_status'])):'';
    $note=isset($_POST['admin_note'])?sanitize_textarea_field(wp_unslash($_POST['admin_note'])):'';
    $comment=isset($_POST['customer_comment'])?sanitize_textarea_field(wp_unslash($_POST['customer_comment'])):'';
    if (!in_array($status,['new','in_progress','resolved'],true) || strlen($note)>10000 || strlen($comment)>5000) wp_die('Invalid status or note.',400);
    global $wpdb;
    $table=dreminex_contact_table();
    $item=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d",$id));
    if (!$item) wp_die('Request not found.',404);
    $changed=$item->request_status!==$status;
    $resend=!empty($_POST['resend_status_email']);
    if (!$changed && !$resend && ($comment!=='' || (isset($_FILES['status_media']) && ($_FILES['status_media']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE))) wp_die('To send a comment or attachment, change the status or select Resend.',400);
    $media=($changed || $resend)?dreminex_contact_mail_resolve('status_media',$status):null;
    if($media && $media['error'])wp_die(esc_html($media['error']),400);
    $ok=$wpdb->update($table,['request_status'=>$status,'admin_note'=>$note],['id'=>$id],['%s','%s'],['%d']);
    if ($ok===false){if($media)dreminex_contact_mail_cleanup($media);wp_die('Could not save request.',500);}
    $query=['page'=>'dreminex-contact-requests','request_id'=>$id,'saved'=>1];
    if ($changed || $resend) $query['status_email']=dreminex_contact_send_status_email($item,$status,$comment,$media)?'accepted':'failed';
    wp_safe_redirect(add_query_arg($query,admin_url('admin.php')),303);
    exit;
});
add_action('admin_post_dreminex_contact_reply', function () {
    if (!current_user_can('manage_options')) wp_die('Access denied.',403);
    $id=isset($_POST['request_id'])?absint($_POST['request_id']):0;
    check_admin_referer('dreminex_contact_reply_'.$id);
    global $wpdb;
    $item=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.dreminex_contact_table().' WHERE id=%d',$id));
    if (!$item || !is_email($item->customer_email)) wp_die('Customer email not found.',404);
    $subject=isset($_POST['subject'])?sanitize_text_field(wp_unslash($_POST['subject'])):'';
    $message=isset($_POST['reply_message'])?sanitize_textarea_field(wp_unslash($_POST['reply_message'])):'';
    if (!$subject || !$message || strlen($subject)>255 || strlen($message)>10000) wp_die('Subject and message are required.',400);
    $media=dreminex_contact_mail_resolve('reply_media',$item->request_status);
    if($media['error'])wp_die(esc_html($media['error']),400);
    $log_message=$message.(!empty($media['name'])?"\n\nPhoto/video attached: ".$media['name']:'');
    $ok=$wpdb->insert(dreminex_contact_replies_table(),[
        'request_id'=>$id,'created_at'=>current_time('mysql'),'subject'=>$subject,
        'message'=>$log_message,'delivery_status'=>'pending','message_type'=>'manual'
    ],['%d','%s','%s','%s','%s','%s']);
    if (!$ok){dreminex_contact_mail_cleanup($media);wp_die('Could not save reply. Email was not sent.',500);}
    $reply_id=(int)$wpdb->insert_id;
    $sent=wp_mail($item->customer_email,$subject,$message,['Content-Type: text/plain; charset=UTF-8',Dreminex_Suite_Setup::text('From: Dreminex Fashion <hello@dreminexfashion.store>'),Dreminex_Suite_Setup::text('Reply-To: Dreminex Fashion <hello@dreminexfashion.store>')],!empty($media['path'])?[$media['path']]:[]);
    dreminex_contact_mail_cleanup($media);
    $wpdb->update(dreminex_contact_replies_table(),['delivery_status'=>$sent?'accepted':'failed'],['id'=>$reply_id],['%s'],['%d']);
    if ($sent) $wpdb->update(dreminex_contact_table(),['request_status'=>'in_progress'],['id'=>$id],['%s'],['%d']);
    wp_safe_redirect(admin_url('admin.php?page=dreminex-contact-requests&request_id='.$id.'&reply='.($sent?'accepted':'failed')),303);
    exit;
});
function dreminex_contact_evidence_submit() {
    if (!isset($_POST['dreminex_contact_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dreminex_contact_nonce'])), 'dreminex_contact_evidence')) {
        dreminex_contact_evidence_redirect('invalid');
    }
    $name = isset($_POST['contact_name']) ? sanitize_text_field(wp_unslash($_POST['contact_name'])) : '';
    $email = isset($_POST['contact_email']) ? sanitize_email(wp_unslash($_POST['contact_email'])) : '';
    $order = isset($_POST['order_reference']) ? sanitize_text_field(wp_unslash($_POST['order_reference'])) : '';
    $message = isset($_POST['contact_message']) ? sanitize_textarea_field(wp_unslash($_POST['contact_message'])) : '';
    if (!$name || strlen($name) > 120 || !is_email($email) || !$message || strlen($message) > 5000 || strlen($order) > 100) {
        dreminex_contact_evidence_redirect('invalid');
    }
    $guard = apply_filters('dreminex_mail_engine_guard_contact', true, [
        'email'=>$email, 'message'=>$message,
        'honeypot'=>sanitize_text_field(wp_unslash($_POST['dreminex_website'] ?? '')),
        'started_at'=>absint($_POST['dreminex_contact_started_at'] ?? 0),
    ]);
    if (is_wp_error($guard)) dreminex_contact_evidence_redirect('wait');
    // The Mail Engine owns rate limiting when enabled. The legacy fallback
    // remains only for stores that keep the new module disabled.
    $remote_ip=(string)($_SERVER['REMOTE_ADDR']??'');
    $rate_key = 'dreminex_contact_' . hash_hmac('sha256',$remote_ip,wp_salt('auth'));
    $mail_engine_active = class_exists('Dreminex_Mail_Engine') && Dreminex_Mail_Engine::enabled();
    $security_managed = class_exists('Dreminex_Security_Center');
    if (!$mail_engine_active && !$security_managed && $remote_ip!=='' && get_transient($rate_key) >= 5) dreminex_contact_evidence_redirect('wait');

    $original = $stored = $mime = '';
    $size = 0;
    if (isset($_FILES['contact_evidence']) && is_array($_FILES['contact_evidence'])) {
        $file = $_FILES['contact_evidence'];
        if (is_array($file['name'] ?? null) || is_array($file['tmp_name'] ?? null)) dreminex_contact_evidence_redirect('file');
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            if (($file['error'] ?? null) !== UPLOAD_ERR_OK || (int) ($file['size'] ?? 0) < 1 || (int) $file['size'] > 10 * 1024 * 1024 || !is_uploaded_file($file['tmp_name'] ?? '')) dreminex_contact_evidence_redirect('file');
            $allowed = ['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','mp4'=>'video/mp4','mov'=>'video/quicktime','webm'=>'video/webm'];
            $original = sanitize_file_name($file['name']);
            $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
            if (!isset($allowed[$ext])) dreminex_contact_evidence_redirect('file');
            $checked = wp_check_filetype_and_ext($file['tmp_name'], $original, $allowed);
            $actual = function_exists('finfo_open') ? (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']) : '';
            $compatible = $actual === $allowed[$ext] || ($ext === 'mov' && in_array($actual,['video/quicktime','video/mp4'],true)) || ($ext === 'mp4' && in_array($actual,['video/mp4','application/mp4'],true));
            if ($checked['ext'] !== $ext || !$compatible) dreminex_contact_evidence_redirect('file');
            $dir = dreminex_contact_private_dir();
            if ((!is_dir($dir) && !wp_mkdir_p($dir)) || !is_writable($dir)) dreminex_contact_evidence_redirect('failed');
            @chmod($dir, 0700);
            $stored = wp_generate_uuid4() . '.' . $ext;
            $path = $dir . '/' . $stored;
            if (!move_uploaded_file($file['tmp_name'], $path)) dreminex_contact_evidence_redirect('failed');
            @chmod($path, 0600);
            $mime = $allowed[$ext];
            $size = (int) $file['size'];
        }
    }
    global $wpdb;
    $ok = $wpdb->insert(dreminex_contact_table(), [
        'created_at'=>current_time('mysql'), 'customer_name'=>$name, 'customer_email'=>$email,
        'order_reference'=>$order, 'customer_message'=>$message, 'file_name'=>$original, 'stored_name'=>$stored,
        'file_mime'=>$mime, 'file_size'=>$size, 'email_status'=>'pending', 'request_status'=>'new', 'admin_note'=>''
    ], ['%s','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s','%s']);
    if (!$ok) {
        if ($stored) @unlink(dreminex_contact_private_dir() . '/' . $stored);
        dreminex_contact_evidence_redirect('failed');
    }
    $id = (int) $wpdb->insert_id;
    if (!$mail_engine_active && !$security_managed && $remote_ip!=='') set_transient($rate_key, (int) get_transient($rate_key) + 1, HOUR_IN_SECONDS);
    $link = admin_url('admin.php?page=dreminex-contact-requests&request_id=' . $id);
    $body = "A contact request has been saved in WordPress.\nRequest #{$id}\nName: {$name}\nEmail: {$email}\n\nMessage:\n{$message}\n\n";
    $body .= $stored ? "Attachment: {$original} (download from the private admin request page)\n" : "Attachment: none\n";
    $body .= "Open request: {$link}\n";
    $recipients = array_unique(array_filter([Dreminex_Suite_Setup::text('hello@dreminexfashion.store'), get_option('admin_email')], 'is_email'));
    $sent = wp_mail($recipients, 'Dreminex Contact Request #' . $id, $body, ['Content-Type: text/plain; charset=UTF-8', Dreminex_Suite_Setup::text('From: Dreminex Fashion <hello@dreminexfashion.store>'), 'Reply-To: ' . $email]);
    $wpdb->update(dreminex_contact_table(), ['email_status'=>$sent?'accepted':'failed'], ['id'=>$id], ['%s'], ['%d']);
    $new_item=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.dreminex_contact_table().' WHERE id=%d',$id));
    if ($new_item) dreminex_contact_send_status_email($new_item,'new');
    if(class_exists('Dreminex_Nexus_App'))Dreminex_Nexus_App::notify('contacts','contact_created','New contact request','A customer contact request needs review.',['resource_type'=>'contact','resource_id'=>$id,'request_id'=>$id,'screen'=>'operations/contacts'],'contact-created-'.$id);
    dreminex_contact_evidence_redirect('sent');
}


/* ---- Module boundary ---- */

/** Private photo/video attachments for Contact Requests emails. */
if(!defined('ABSPATH'))exit;
function dreminex_contact_mail_media_dir(){
    return dreminex_contact_private_dir().'/mail-media';
}
function dreminex_contact_mail_defaults(){
    $saved=get_option('dreminex_contact_mail_defaults',[]);
    return is_array($saved)?$saved:[];
}
function dreminex_contact_mail_path($status){
    $all=dreminex_contact_mail_defaults();
    $name=$all[$status]['stored']??'';
    if(!$name || basename($name)!==$name)return '';
    $path=dreminex_contact_mail_media_dir().'/'.$name;
    return is_file($path)?$path:'';
}
function dreminex_contact_mail_upload($field){
    $file=$_FILES[$field]??null;
    if(!$file)return ['path'=>'','name'=>'','temporary'=>false,'error'=>''];
    if(!is_array($file) || is_array($file['name']??null) || is_array($file['tmp_name']??null))
        return ['path'=>'','name'=>'','temporary'=>false,'error'=>'Only one photo or video may be attached.'];
    $error=(int)($file['error']??UPLOAD_ERR_NO_FILE);
    if($error===UPLOAD_ERR_NO_FILE)return ['path'=>'','name'=>'','temporary'=>false,'error'=>''];
    if($error!==UPLOAD_ERR_OK || (int)($file['size']??0)<1 || (int)$file['size']>10*1024*1024 || !is_uploaded_file($file['tmp_name']??''))
        return ['path'=>'','name'=>'','temporary'=>false,'error'=>'Upload failed or exceeds 10 MB.'];
    $allowed=['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','mp4'=>'video/mp4','mov'=>'video/quicktime','webm'=>'video/webm'];
    $name=sanitize_file_name($file['name']??'');
    $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
    if(!isset($allowed[$ext]))return ['path'=>'','name'=>'','temporary'=>false,'error'=>'Unsupported file type.'];
    $checked=wp_check_filetype_and_ext($file['tmp_name'],$name,$allowed);
    $actual=class_exists('finfo')?(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']):'';
    $compatible=$actual===$allowed[$ext] || ($ext==='mov' && in_array($actual,['video/quicktime','video/mp4'],true)) || ($ext==='mp4' && in_array($actual,['video/mp4','application/mp4'],true));
    if($checked['ext']!==$ext || !$compatible)return ['path'=>'','name'=>'','temporary'=>false,'error'=>'The photo or video type could not be verified.'];
    $dir=dreminex_contact_mail_media_dir();
    if((!is_dir($dir) && !wp_mkdir_p($dir)) || !is_writable($dir))return ['path'=>'','name'=>'','temporary'=>false,'error'=>'Private attachment storage is unavailable.'];
    @chmod($dir,0700);
    $stored=wp_generate_uuid4().'.'.$ext;
    $path=$dir.'/'.$stored;
    if(!move_uploaded_file($file['tmp_name'],$path))return ['path'=>'','name'=>'','temporary'=>false,'error'=>'The attachment could not be saved.'];
    @chmod($path,0600);
    return ['path'=>$path,'stored'=>$stored,'name'=>$name,'temporary'=>true,'error'=>''];
}
function dreminex_contact_mail_resolve($field,$status){
    $custom=dreminex_contact_mail_upload($field);
    if($custom['error'] || $custom['path'])return $custom;
    $path=dreminex_contact_mail_path($status);
    $all=dreminex_contact_mail_defaults();
    return ['path'=>$path,'name'=>$path?($all[$status]['name']??basename($path)):'','temporary'=>false,'error'=>''];
}
function dreminex_contact_mail_cleanup($media){
    if(!empty($media['temporary']) && !empty($media['path']) && is_file($media['path']))@unlink($media['path']);
}
function dreminex_contact_mail_media_admin_page(){
    if(!current_user_can('manage_options'))wp_die('Access denied.',403);
    $saved=dreminex_contact_mail_defaults();
    echo '<div class="wrap"><h1>Default photo or video for Contact emails</h1><p>Save one optional file for each status. If you do not upload a file while sending a status update or manual reply, the saved file for that request status is attached. The email still sends without an attachment when none is saved. Files are private and are not placed in the product Media Library.</p>';
    if(isset($_GET['saved']))echo '<div class="notice notice-success"><p>Default attachment settings saved.</p></div>';
    foreach(['new'=>'New','in_progress'=>'In progress','resolved'=>'Resolved'] as $status=>$label){
        echo '<h2>'.esc_html($label).'</h2><p>Current file: '.esc_html($saved[$status]['name']??'None').'</p>';
        echo '<form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_contact_media_default"><input type="hidden" name="status" value="'.esc_attr($status).'">';
        wp_nonce_field('dreminex_contact_media_default_'.$status);
        echo '<p><label>Replace with a photo or video (JPG, PNG, WebP, MP4, MOV or WebM, up to 10 MB)<br><input type="file" name="default_media" accept=".jpg,.jpeg,.png,.webp,.mp4,.mov,.webm,image/jpeg,image/png,image/webp,video/mp4,video/quicktime,video/webm"></label></p>';
        echo '<p><label><input type="checkbox" name="remove_default" value="1"> Remove saved file</label></p>';
        submit_button('Save '.$label.' default','secondary');
        echo '</form>';
    }
    echo '</div>';
}
add_action('admin_post_dreminex_contact_media_default',function(){
    if(!current_user_can('manage_options'))wp_die('Access denied.',403);
    $status=isset($_POST['status'])?sanitize_key(wp_unslash($_POST['status'])):'';
    if(!in_array($status,['new','in_progress','resolved'],true))wp_die('Invalid status.',400);
    check_admin_referer('dreminex_contact_media_default_'.$status);
    $remove=!empty($_POST['remove_default']);
    if($remove && isset($_FILES['default_media']) && ($_FILES['default_media']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE)wp_die('Choose either replace or remove.',400);
    $upload=$remove?['path'=>'','error'=>'']:dreminex_contact_mail_upload('default_media');
    if($upload['error'])wp_die(esc_html($upload['error']),400);
    $all=dreminex_contact_mail_defaults();
    $old=dreminex_contact_mail_path($status);
    if($remove)unset($all[$status]);
    elseif($upload['path'])$all[$status]=['stored'=>$upload['stored'],'name'=>$upload['name']];
    if(!update_option('dreminex_contact_mail_defaults',$all,false) && get_option('dreminex_contact_mail_defaults',[])!==$all){
        dreminex_contact_mail_cleanup($upload);
        wp_die('Could not save default attachment.',500);
    }
    if(($remove || $upload['path']) && $old && is_file($old))@unlink($old);
    wp_safe_redirect(admin_url('admin.php?page=dreminex-contact-mail-media&saved=1'),303);
    exit;
});

Dreminex_Suite_Contact_Trash::boot();
