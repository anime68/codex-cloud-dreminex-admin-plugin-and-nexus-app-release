<?php
if (!defined('ABSPATH')) { exit; }
/* Dreminex: private WordPress admin alert for new WooCommerce orders.
 * Each admin has a separate seen marker. No customer data appears to visitors.
 * This dashboard notice is separate from the off-site order email alert.
 */
if ( ! function_exists( 'dreminex_admin_recent_orders' ) ) {
	function dreminex_admin_recent_orders() {
		$statuses = array( 'pending', 'on-hold', 'processing', 'completed' );
		if ( function_exists( 'dreminex_order_workflow_statuses' ) ) {
			foreach ( array_keys( dreminex_order_workflow_statuses() ) as $slug ) {
				$statuses[] = substr( $slug, 3 );
			}
		}
		$orders = wc_get_orders( array(
			'type' => 'shop_order', 'limit' => 5, 'orderby' => 'date', 'order' => 'DESC',
			'status' => $statuses,
		) );
		return array_values( array_filter( $orders, function ( $order ) {
			return $order instanceof WC_Order && 'shop_order' === $order->get_type();
		} ) );
	}
}
add_action( 'admin_notices', function () {
    if(!Dreminex_Suite_Features::enabled('admin_order_alert','notice'))return;
	if ( ! current_user_can( 'manage_woocommerce' ) || ! function_exists( 'wc_get_orders' ) ) return;
	$orders = dreminex_admin_recent_orders();
	if ( ! $orders ) return;
	$user_id = get_current_user_id();
	$last = get_user_meta( $user_id, '_dreminex_last_seen_order_id', true );
	if ( '' === $last ) {
		// Start from now when this feature is first enabled; old orders are not "new".
		update_user_meta( $user_id, '_dreminex_last_seen_order_id', (int) $orders[0]->get_id() );
		return;
	}
	$unseen = array_values( array_filter( $orders, function ( $order ) use ( $last ) {
		return $order->get_id() > (int) $last;
	} ) );
	if ( ! $unseen ) return;
	echo Dreminex_Suite_Setup::text('<div class="notice notice-info" style="border-left-color:#00B4D8;background:#F8F9FA;color:#212529;padding:10px 16px">');
	echo Dreminex_Suite_Control::tr(Dreminex_Suite_Setup::text("<h3 style=\"margin:4px 0;color:#212529\">Dreminex Fashion: New orders ("), Dreminex_Suite_Setup::text('<h3 style="margin:4px 0;color:#212529">Dreminex Fashion: নতুন অর্ডার এসেছে (')) . esc_html( count( $unseen ) ) . ')</h3>';
	foreach ( $unseen as $order ) {
		$names = array();
		foreach ( $order->get_items( 'line_item' ) as $item ) $names[] = $item->get_name() . ' × ' . $item->get_quantity();
		echo '<p><strong><a href="' . esc_url( $order->get_edit_order_url() ) . Dreminex_Suite_Control::tr("\">Order #", '">অর্ডার #') . esc_html( $order->get_order_number() ) . '</a></strong> — ';
		echo esc_html( trim( $order->get_formatted_billing_full_name() ) ?: 'Customer' ) . ', ' . esc_html( $order->get_billing_phone() ) . ', ' . esc_html( $order->get_billing_email() ) . '<br>';
		echo esc_html( implode( ', ', array_filter( array( $order->get_billing_address_1(), $order->get_billing_city(), $order->get_billing_state() ) ) ) ) . '<br>';
		echo esc_html( implode( ', ', $names ) ) . ' · ' . wp_kses_post( $order->get_formatted_order_total() ) . '</p>';
	}
	$url = wp_nonce_url( admin_url( 'admin-post.php?action=dreminex_ack_orders&id=' . (int) $orders[0]->get_id() ), 'dreminex_ack_orders' );
	echo '<p><a class="button" href="' . esc_url( $url ) . Dreminex_Suite_Control::tr("\">Mark as seen</a> — Click the order number to view its details.</p>", '">দেখেছি</a> — অর্ডারের বিস্তারিত দেখতে অর্ডার নম্বরে চাপুন।</p>');
	echo '</div>';
} );
add_action( 'admin_post_dreminex_ack_orders', function () {
	if ( ! current_user_can( 'manage_woocommerce' ) ) wp_die( 'Not allowed', 403 );
	check_admin_referer( 'dreminex_ack_orders' );
	$id = absint( $_GET['id'] ?? 0 );
	$order = $id ? wc_get_order( $id ) : false;
	if ( $order instanceof WC_Order && 'shop_order' === $order->get_type() ) {
		$old = (int) get_user_meta( get_current_user_id(), '_dreminex_last_seen_order_id', true );
		update_user_meta( get_current_user_id(), '_dreminex_last_seen_order_id', max( $old, $id ) );
	}
	wp_safe_redirect( wp_get_referer() ?: admin_url( 'admin.php?page=wc-orders' ) );
	exit;
} );
add_action( 'wp_dashboard_setup', function () {
    if(!Dreminex_Suite_Features::enabled('admin_order_alert','widget'))return;
	if ( ! current_user_can( 'manage_woocommerce' ) ) return;
	wp_add_dashboard_widget( 'dreminex_recent_orders', Dreminex_Suite_Control::tr(Dreminex_Suite_Setup::text("Dreminex Fashion — Recent orders"), Dreminex_Suite_Setup::text('Dreminex Fashion — সাম্প্রতিক অর্ডার')), function () {
		$orders = dreminex_admin_recent_orders();
		if ( ! $orders ) { echo Dreminex_Suite_Control::tr("<p>No orders yet.</p>", '<p>এখনো কোনো অর্ডার নেই।</p>'); return; }
		echo '<ul>';
		foreach ( $orders as $order ) {
			$products = array();
			foreach ( $order->get_items( 'line_item' ) as $item ) $products[] = $item->get_name() . ' × ' . $item->get_quantity();
			echo '<li><a href="' . esc_url( $order->get_edit_order_url() ) . '">#' . esc_html( $order->get_order_number() ) . '</a> — ';
			echo esc_html( $order->get_formatted_billing_full_name() ) . ' · ' . esc_html( $order->get_billing_phone() ) . ' · ' . esc_html( $order->get_billing_email() ) . '<br>';
			echo esc_html( implode( ', ', $products ) ) . ' · ' . wp_kses_post( $order->get_formatted_order_total() ) . '</li>';
		}
		echo '</ul>';
	} );
} );
