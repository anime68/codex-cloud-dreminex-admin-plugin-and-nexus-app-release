<?php
// Delivery Advance & Wallet provider layer. Legacy class/gateway IDs remain for order compatibility.
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! defined( 'DREMINEX_PAYMENT_MODULE_ENABLED' ) ) {
	define( 'DREMINEX_PAYMENT_MODULE_ENABLED', true );
}
if ( ! DREMINEX_PAYMENT_MODULE_ENABLED || defined( 'DREMINEX_SUITE_PAYMENTS_LOADED' ) || defined( 'DREMINEX_PAYMENTS_LOADED' ) ) { return; }
define( 'DREMINEX_PAYMENTS_LOADED', true );

define( 'DREMINEX_PAYMENTS_VERSION', '0.2.0' );




final class Dreminex_Payments_Bootstrap {
	private static $initialized=false;
	public static function init() {
		if(self::$initialized)return;self::$initialized=true;
		if ( ! class_exists( 'WooCommerce' ) || ! class_exists( 'WC_Payment_Gateway' ) ) { return; }
		Dreminex_Payments_Provider_Registry::register_built_in_slots();
        Dreminex_Payments_Provider_Registry::register(new Dreminex_Bkash_V2_Provider());
		add_filter( 'woocommerce_payment_gateways', array( __CLASS__, 'register_gateway' ) );
		add_action( 'rest_api_init', array( 'Dreminex_Payments_Rest_Controller', 'register_routes' ) );
		add_action( 'admin_menu', array( 'Dreminex_Payments_Config_Admin', 'register_menu' ) );
		add_action( 'admin_post_dreminex_payment_connection_test', array( 'Dreminex_Payments_Config_Admin', 'connection_test' ) );
		add_action( 'admin_post_dreminex_payment_save_profile', array( 'Dreminex_Payments_Config_Admin', 'save_profile' ) );
		add_action( 'admin_post_dreminex_payment_toggle_profile', array( 'Dreminex_Payments_Config_Admin', 'toggle_profile' ) );
		add_action('admin_post_dreminex_payment_query_order',['Dreminex_Payments_Order_View','query']);
        add_action('woocommerce_admin_order_data_after_order_details',['Dreminex_Payments_Order_View','admin']);
        add_action('woocommerce_before_thankyou',static function($id){Dreminex_Payments_Order_View::summary(wc_get_order($id));},5);
        add_action('woocommerce_email_after_order_table',static function($order,$admin,$plain){Dreminex_Payments_Order_View::summary($order,$plain);},25,3);
        add_action('admin_post_dreminex_payment_delete_profile',array('Dreminex_Payments_Config_Admin','delete_profile'));
	}
	public static function register_gateway( $gateways ) { $gateways[] = 'Dreminex_WC_Gateway_Mobile_Payment'; return $gateways; }
}

interface Dreminex_Payment_Provider_Interface {
	public function id();
	public function label();
	public function is_profile_configured( $profile_id );
	public function capabilities( $profile_id );
	public function create_payment( array $context, $profile_id );
	public function verify_payment( array $context, $profile_id );
	public function query_payment( $payment_id, $profile_id );
	public function parse_callback( WP_REST_Request $request, $profile_id );
	public function verify_callback( array $callback, $profile_id );
	public function refund( array $context, $profile_id );
}

final class Dreminex_Payments_Unconfigured_Provider implements Dreminex_Payment_Provider_Interface {
	private $provider_id; private $provider_label;
	public function __construct( $id, $label ) { $this->provider_id = $id; $this->provider_label = $label; }
	public function id() { return $this->provider_id; }
	public function label() { return $this->provider_label; }
	public function is_profile_configured( $profile_id ) { return false; }
	public function capabilities( $profile_id ) { return array(); }
	private function unavailable() { return new WP_Error( 'dreminex_provider_unconfigured', __( 'Awaiting official API configuration.', 'dreminex-payments' ) ); }
	public function create_payment( array $context, $profile_id ) { return $this->unavailable(); }
	public function verify_payment( array $context, $profile_id ) { return $this->unavailable(); }
	public function query_payment( $payment_id, $profile_id ) { return $this->unavailable(); }
	public function parse_callback( WP_REST_Request $request, $profile_id ) { return $this->unavailable(); }
	public function verify_callback( array $callback, $profile_id ) { return false; }
	public function refund( array $context, $profile_id ) { return $this->unavailable(); }
}

final class Dreminex_Payments_Provider_Registry {
	private static $providers = array();
	public static function register_built_in_slots() {
		foreach ( array( 'bkash' => 'bKash', 'nagad' => 'Nagad', 'rocket' => 'Rocket' ) as $id => $label ) {
			self::register( new Dreminex_Payments_Unconfigured_Provider( $id, $label ) );
		}
		do_action( 'dreminex_payments_register_providers', __CLASS__ );
	}
	public static function register( Dreminex_Payment_Provider_Interface $provider ) { self::$providers[ sanitize_key( $provider->id() ) ] = $provider; }
	public static function get( $id ) { return isset( self::$providers[ sanitize_key( $id ) ] ) ? self::$providers[ sanitize_key( $id ) ] : null; }
	public static function all() { return self::$providers; }
}

final class Dreminex_Payments_Connection_Profile_Repository {
	const OPTION = 'dreminex_payment_profiles';
 public static function expected_environment() {
  $site=function_exists('wp_get_environment_type')?wp_get_environment_type():'production';
  return $site==='production'?'live':'sandbox';
 }
	public function all() { $profiles = get_option( self::OPTION, array() ); return is_array( $profiles ) ? $profiles : array(); }
	public function get( $id ) { $all = $this->all(); return isset( $all[ $id ] ) && is_array( $all[ $id ] ) ? $all[ $id ] : null; }
	public function available_for( $provider_id ) {
		$found = array();
		foreach ( $this->all() as $id => $profile ) {
			if ( empty( $profile['enabled'] ) || ( $profile['provider_id'] ?? '' ) !== $provider_id || ( $profile['health_status'] ?? 'Unknown' ) !== 'Healthy' ) { continue; }
			$provider = Dreminex_Payments_Provider_Registry::get( $provider_id );
			// Production can use only live credentials. Staging/development/local
			// sites can use only sandbox profiles, so a copied live profile cannot
			// create real checkout requests from a test environment.
			if (($profile['environment']??'sandbox') !== self::expected_environment()) continue;
            if ( $provider && $provider->is_profile_configured( $id ) ) { $found[ $id ] = $profile; }
		}
		return $found;
	}
}

final class Dreminex_Payments_Amount_Engine {
	public static function calculate( $total, $mode, $settings ) {
		$total = max( 0, (float) $total ); $pay = 0.0;
		switch ( $mode ) {
			case 'full': $pay = $total; break;
			case 'delivery_advance': $pay = isset( $settings['delivery_advance_amount'] ) ? (float) $settings['delivery_advance_amount'] : 0; break;
			case 'fixed_advance': $pay = isset( $settings['fixed_advance_amount'] ) ? (float) $settings['fixed_advance_amount'] : 0; break;
			case 'percentage_advance': $percent = isset( $settings['advance_percentage'] ) ? (float) $settings['advance_percentage'] : 0; $pay = $total * min( 100, max( 0, $percent ) ) / 100; break;
			default: return new WP_Error( 'dreminex_invalid_mode', __( 'Invalid payment mode.', 'dreminex-payments' ) );
		}
		$pay = min( $total, max( 0, $pay ) );
		return array( 'payable_now' => wc_format_decimal( $pay, wc_get_price_decimals() ), 'remaining_due' => wc_format_decimal( $total - $pay, wc_get_price_decimals() ) );
	}
}

final class Dreminex_Payments_Order_Service {
	const STATE_META = '_dreminex_payment_state';
	public function create_attempt( WC_Order $order, $provider_id, $profile_id, $mode, $amounts ) {
		if ( $order->get_meta( '_dreminex_idempotency_key' ) && in_array( $order->get_meta( self::STATE_META ), array( 'pending', 'unknown', 'verified' ), true ) ) {
			return new WP_Error( 'dreminex_attempt_active', __( 'An existing payment attempt is active or already verified.', 'dreminex-payments' ) );
		}
		$key = wp_generate_uuid4();
		$order->update_meta_data( '_dreminex_payment_provider', sanitize_key( $provider_id ) );
		$order->update_meta_data( '_dreminex_payment_profile_id', sanitize_text_field( $profile_id ) );
		$order->update_meta_data( '_dreminex_payment_mode', sanitize_key( $mode ) );
		$order->update_meta_data( '_dreminex_provider_due', $amounts['payable_now'] );
		$order->update_meta_data( '_dreminex_paid_amount', '0' );
		if ( ! $order->meta_exists( '_dreminex_remaining_due' ) ) $order->update_meta_data( '_dreminex_remaining_due', $amounts['remaining_due'] );
		$order->update_meta_data( '_dreminex_idempotency_key', $key );
		$order->update_meta_data( self::STATE_META, 'pending' );
		$order->update_meta_data('_dreminex_attempt_total',wc_format_decimal($order->get_total(),2));
        $order->update_meta_data( '_dreminex_gateway_version', DREMINEX_PAYMENTS_VERSION );
		$order->save();
		return $key;
	}
	public function mark_unverified( WC_Order $order, $reason ) {
		$order->update_meta_data( self::STATE_META, 'review_required' );
		$order->add_order_note( sprintf( __( 'Dreminex payment remains unverified: %s', 'dreminex-payments' ), sanitize_text_field( $reason ) ) );
		$order->update_status( 'pending' );
	}
	public function finalize_verified( WC_Order $order, array $verified ) {
		$required = array( 'verified' => false, 'amount' => null, 'currency' => null, 'profile_id' => null, 'provider_payment_id' => null );
		$verified = array_merge( $required, $verified );
		$expected_profile = (string) $order->get_meta( '_dreminex_payment_profile_id' );
		$expected = (float) ( $order->get_meta( '_dreminex_provider_due' ) ?: $order->get_meta( '_dreminex_payable_now' ) );
        $payment_id=(string)$order->get_meta('_dreminex_provider_payment_id');
        if(!is_numeric($verified['amount']??null)||(float)$verified['amount']<=0||wc_format_decimal($order->get_meta('_dreminex_attempt_total'),2)!==wc_format_decimal($order->get_total(),2))return new WP_Error('dreminex_amount_changed','Order amount changed or payment amount invalid.');
        if ($payment_id === '' || $payment_id !== (string)($verified['provider_payment_id']??'') || empty($verified['transaction_id'])) return new WP_Error('dreminex_payment_identity','Payment identity does not match.');
		if ( true !== $verified['verified'] || null === $verified['amount'] || null === $verified['currency'] || null === $verified['profile_id'] || null === $verified['provider_payment_id'] || abs( $expected - (float) $verified['amount'] ) > 0.00001 || $order->get_currency() !== strtoupper( (string) $verified['currency'] ) || $expected_profile !== (string) $verified['profile_id'] ) {
			$this->mark_unverified( $order, 'provider verification fields or transaction identity mismatch; manual review required' );
			return new WP_Error( 'dreminex_payment_mismatch', __( 'Payment requires review.', 'dreminex-payments' ) );
		}
		if ( 'verified' === $order->get_meta( self::STATE_META ) ) { return true; }
		$wallet_paid = (float) $order->get_meta( '_dreminex_wallet_reserved' );
		$order->update_meta_data( '_dreminex_paid_amount', wc_format_decimal( (float) $verified['amount'] + $wallet_paid ) );
		$order->update_meta_data( '_dreminex_provider_payment_id', sanitize_text_field( $verified['provider_payment_id'] ) );
		$order->update_meta_data( '_dreminex_provider_transaction_id', sanitize_text_field( $verified['transaction_id'] ?? '' ) );
		$order->update_meta_data( '_dreminex_payment_verified_at', gmdate( 'c' ) );
		$order->update_meta_data( self::STATE_META, 'verified' );
		$order->save();
		if ( class_exists( 'Dreminex_Customer_Wallet' ) ) {
			$wallet = Dreminex_Customer_Wallet::commit_order( $order );
			if ( is_wp_error( $wallet ) ) { $this->mark_unverified( $order, $wallet->get_error_message() ); return $wallet; }
		}
        if ((float)$order->get_meta('_dreminex_remaining_due') > 0) {
          $order->set_transaction_id(sanitize_text_field($verified['transaction_id']));$order->save();
          $order->update_status('on-hold','Verified advance received; remaining balance is due. The full order is not marked paid.');
        } else { $order->payment_complete(sanitize_text_field($verified['transaction_id'])); }
		if(class_exists('Dreminex_Nexus_App'))Dreminex_Nexus_App::notify('payments','advance_verified','Delivery advance verified','A delivery advance was verified successfully.',['resource_type'=>'order','resource_id'=>$order->get_id(),'order_id'=>$order->get_id(),'screen'=>'operations/payments'],'advance-verified-'.$order->get_id());
		return true;
	}
}

final class Dreminex_Payments_Logger {
	public static function log( $level, $message, array $context = array() ) {
		if ( ! function_exists( 'wc_get_logger' ) ) { return; }
		$context = self::redact( $context );
		wc_get_logger()->log( sanitize_key( $level ), sanitize_text_field( $message ), array_merge( array( 'source' => 'dreminex-payments' ), $context ) );
	}
	private static function redact( $value ) {
		if ( ! is_array( $value ) ) { return is_scalar( $value ) ? $value : '[redacted]'; }
		$out = array();
		foreach ( $value as $key => $item ) { $out[ $key ] = preg_match( '/secret|token|password|authorization|pin|otp|credential|payload|app_key|api_key/i', (string) $key ) ? '[redacted]' : self::redact( $item ); }
		return $out;
	}
}

final class Dreminex_WC_Gateway_Mobile_Payment extends WC_Payment_Gateway {
	private $profiles;
	public function __construct() {
		$this->id = 'dreminex_mobile_payment';
		$this->method_title = __( 'Delivery Advance & Wallet', 'dreminex-payments' );
		$this->method_description = __( 'Customer wallet plus verified provider payment for delivery advance or full payment.', 'dreminex-payments' );
		$this->has_fields = true;
		$this->supports = array( 'products' );
		$this->profiles = new Dreminex_Payments_Connection_Profile_Repository();
		$this->init_form_fields(); $this->init_settings();
		if(class_exists('Dreminex_Suite_Routing')&&Dreminex_Suite_Routing::enabled('delivery_advance')){$this->settings['full']='yes';$this->settings['delivery_advance']='yes';$this->settings['fixed_advance']='no';$this->settings['percentage_advance']='no';}
		$this->enabled = $this->get_option( 'enabled', 'yes' );
		$this->title = $this->get_option( 'title', __( 'Delivery Advance & Wallet', 'dreminex-payments' ) );
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_checkout_script' ) );
	}
	public function init_form_fields() {
		$this->form_fields = array(
			'enabled' => array( 'title' => __( 'Enable/Disable', 'dreminex-payments' ), 'type' => 'checkbox', 'label' => __( 'Enable Delivery Advance & Wallet', 'dreminex-payments' ), 'default' => 'yes' ),
			'title' => array( 'title' => __( 'Title', 'dreminex-payments' ), 'type' => 'text', 'default' => __( 'Delivery Advance & Wallet', 'dreminex-payments' ) ),
			'description' => array( 'title' => __( 'Description', 'dreminex-payments' ), 'type' => 'textarea', 'default' => '' ),
			'full' => array( 'title' => __( 'Full payment', 'dreminex-payments' ), 'type' => 'checkbox', 'default' => 'yes' ),
			'delivery_advance' => array( 'title' => __( 'Delivery advance', 'dreminex-payments' ), 'type' => 'checkbox', 'default' => 'no' ),
			'delivery_advance_info' => array('title'=>'Delivery advance calculation','type'=>'title','description'=>'Uses the order shipping total plus shipping tax; it is not a manually fixed delivery amount.'),
			'fixed_advance' => array( 'title' => __( 'Fixed advance', 'dreminex-payments' ), 'type' => 'checkbox', 'default' => 'no' ),
			'fixed_advance_amount' => array( 'title' => __( 'Fixed advance amount', 'dreminex-payments' ), 'type' => 'price', 'default' => '0' ),
			'percentage_advance' => array( 'title' => __( 'Percentage advance', 'dreminex-payments' ), 'type' => 'checkbox', 'default' => 'no' ),
			'advance_percentage' => array( 'title' => __( 'Advance percentage', 'dreminex-payments' ), 'type' => 'number', 'default' => '30', 'custom_attributes' => array( 'min' => 0, 'max' => 100, 'step' => '0.01' ) ),
			'customer_surcharge' => array( 'title' => __( 'Customer surcharge', 'dreminex-payments' ), 'type' => 'checkbox', 'default' => 'no', 'description' => __( 'Reserved; no surcharge is applied by this release.', 'dreminex-payments' ) ),
		);
	}
	public function is_available() {
		if (get_woocommerce_currency()!=='BDT' || !parent::is_available()) { return false; }
		foreach ( Dreminex_Payments_Provider_Registry::all() as $provider ) { if ( $this->profiles->available_for( $provider->id() ) ) { return true; } }
		return false;
	}
	public function payment_fields() {
		$choices = array();
		foreach ( Dreminex_Payments_Provider_Registry::all() as $provider ) { if ( $this->profiles->available_for( $provider->id() ) ) { $choices[ $provider->id() ] = $provider->label(); } }
		$customer_balance = is_user_logged_in() && class_exists('Dreminex_Customer_Wallet') ? (float)(Dreminex_Customer_Wallet::balances(get_current_user_id())['total']??0) : 0;
		if ( ! $choices && $customer_balance <= 0 ) { echo '<p>' . esc_html__( 'No payment provider or customer wallet balance is currently available.', 'dreminex-payments' ) . '</p>'; return; }
		if ( $this->description ) { echo wp_kses_post( wpautop( $this->description ) ); }
		$options = array(); if('yes'===$this->get_option('full','yes')) $options['full']=__('Full payment','dreminex-payments');
		foreach ( array( 'delivery_advance', 'fixed_advance', 'percentage_advance' ) as $mode ) { if ( 'yes' === $this->get_option( $mode, 'no' ) ) { $options[ $mode ] = ucwords( str_replace( '_', ' ', $mode ) ); } }
		woocommerce_form_field( 'dreminex_payment_mode', array( 'type' => 'select', 'label' => __( 'Payment mode', 'dreminex-payments' ), 'options' => $options, 'required' => true ), array_key_first($options) );
		if($customer_balance>0)woocommerce_form_field('dreminex_api_use_wallet',array('type'=>'checkbox','label'=>sprintf(__('Use customer wallet first (available %s)','dreminex-payments'),wp_strip_all_tags(wc_price($customer_balance))),'required'=>false),1);
		if($choices)woocommerce_form_field( 'dreminex_provider', array( 'type' => 'select', 'label' => __( 'External payment provider', 'dreminex-payments' ), 'options' => array(''=>__('Choose provider','dreminex-payments'))+$choices, 'required' => false ), '' );
		$total = WC()->cart ? (float) WC()->cart->get_total( 'edit' ) : 0;
		echo '<p class="dreminex-payment-amounts" data-delivery-total="'.esc_attr((string)(WC()->cart?(float)WC()->cart->get_shipping_total()+(float)WC()->cart->get_shipping_tax():0)).'" data-order-total="' . esc_attr( (string) $total ) . '"></p>';
	}
	private function public_amount_settings() { return array( 'fixed' => (float) $this->get_option( 'fixed_advance_amount', 0 ), 'delivery' => WC()->cart ? (float)WC()->cart->get_shipping_total()+(float)WC()->cart->get_shipping_tax() : 0, 'percent' => (float) $this->get_option( 'advance_percentage', 30 ), 'currency' => get_woocommerce_currency() ); }
	public function enqueue_checkout_script() {
		if ( ! $this->is_available() || ! is_checkout() || is_order_received_page() ) { return; }
		if ( ! WC()->cart ) { return; }
		wp_enqueue_script( 'jquery' );
		wp_add_inline_script( 'jquery', 'window.DreminexPaymentSettings = ' . wp_json_encode( $this->public_amount_settings() ) . ';', 'before' );
		$script = <<<'JS'
(function ($) {
  'use strict';
  function updateDreminexAmount() {
    var $box = $('.dreminex-payment-amounts');
    if (!$box.length || !window.DreminexPaymentSettings) return;
    var settings = window.DreminexPaymentSettings;
    var total = Number($box.attr('data-order-total')) || 0;
    var $form = $box.closest('.payment_box');
    var mode = $form.find('[name="dreminex_payment_mode"]').val() || 'full';
    var now = total;
    if (mode === 'fixed_advance') now = Math.min(total, Number(settings.fixed) || 0);
    if (mode === 'delivery_advance') now = Math.min(total, Number($box.attr('data-delivery-total')) || 0);
    if (mode === 'percentage_advance') now = total * Math.min(100, Math.max(0, Number(settings.percent) || 0)) / 100;
    var fmt = new Intl.NumberFormat(undefined, { style: 'currency', currency: settings.currency || 'BDT' });
    $box.text('Pay now: ' + fmt.format(now) + ' · Remaining due: ' + fmt.format(Math.max(0, total - now)));
  }
  $(document.body).on('change', '[name="dreminex_payment_mode"]', updateDreminexAmount);
  $(document.body).on('updated_checkout', updateDreminexAmount);
  $(updateDreminexAmount);
})(jQuery);
JS;
		wp_add_inline_script( 'jquery', $script, 'after' );
	}
	public function validate_fields() {
		$mode = isset( $_POST['dreminex_payment_mode'] ) ? sanitize_key( wp_unslash( $_POST['dreminex_payment_mode'] ) ) : '';
		$provider_id = isset( $_POST['dreminex_provider'] ) ? sanitize_key( wp_unslash( $_POST['dreminex_provider'] ) ) : '';
		if ( ! in_array( $mode, array( 'full', 'delivery_advance', 'fixed_advance', 'percentage_advance' ), true ) || 'yes' !== $this->get_option( $mode, $mode==='full'?'yes':'no' ) ) { wc_add_notice( __( 'Select a valid payment mode.', 'dreminex-payments' ), 'error' ); return false; }
		$total=WC()->cart?(float)WC()->cart->get_total('edit'):0;$shipping=WC()->cart?(float)WC()->cart->get_shipping_total()+(float)WC()->cart->get_shipping_tax():0;
		$amounts=Dreminex_Payments_Amount_Engine::calculate($total,$mode,['delivery_advance_amount'=>$shipping]);$wallet=!empty($_POST['dreminex_api_use_wallet'])&&is_user_logged_in()&&class_exists('Dreminex_Customer_Wallet')?(float)(Dreminex_Customer_Wallet::balances(get_current_user_id())['total']??0):0;
		if(is_wp_error($amounts)||max(0,(float)$amounts['payable_now']-$wallet)>0.00001&&!$this->profiles->available_for($provider_id)){wc_add_notice(__('Choose an available external payment provider for the amount not covered by the customer wallet.','dreminex-payments'),'error');return false;}
		return true;
	}
	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id ); if ( ! $order instanceof WC_Order || $order->get_payment_method()!==$this->id ) { wc_add_notice( __( 'Order could not be loaded.', 'dreminex-payments' ), 'error' ); return array( 'result' => 'failure' ); }
		if($order->is_paid())return ['result'=>'success','redirect'=>$this->get_return_url($order)];
        $provider_id = sanitize_key( wp_unslash( $_POST['dreminex_provider'] ?? '' ) );
		$mode = sanitize_key( wp_unslash( $_POST['dreminex_payment_mode'] ?? '' ) );
		if (!in_array($mode,['full','delivery_advance','fixed_advance','percentage_advance'],true) || 'yes' !== $this->get_option($mode,$mode==='full'?'yes':'no')) return ['result'=>'failure'];
        $available = $this->profiles->available_for( $provider_id );
		$amounts = Dreminex_Payments_Amount_Engine::calculate( $order->get_total(), $mode, array( 'delivery_advance_amount' => (float)$order->get_shipping_total()+(float)$order->get_shipping_tax(), 'fixed_advance_amount' => $this->get_option( 'fixed_advance_amount', 0 ), 'advance_percentage' => $this->get_option( 'advance_percentage', 0 ) ) );
		if ( is_wp_error( $amounts ) ) { wc_add_notice( __( 'The payable amount is not valid.', 'dreminex-payments' ), 'error' ); return array( 'result' => 'failure' ); }
		$wallet_available=!empty($_POST['dreminex_api_use_wallet'])&&$order->get_customer_id()&&class_exists('Dreminex_Customer_Wallet')?(float)(Dreminex_Customer_Wallet::balances($order->get_customer_id())['total']??0):0;
		$wallet_amount=min((float)$amounts['payable_now'],$wallet_available);$provider_amount=max(0,(float)$amounts['payable_now']-$wallet_amount);
		$order->update_meta_data('_dreminex_payment_plan',$mode);$order->update_meta_data('_dreminex_payable_now',wc_format_decimal($amounts['payable_now']));$order->update_meta_data('_dreminex_remaining_due',wc_format_decimal($amounts['remaining_due']));$order->update_meta_data('_dreminex_wallet_requested',wc_format_decimal($wallet_amount));$order->update_meta_data('_dreminex_external_due',wc_format_decimal($provider_amount));$order->save();
		if($wallet_amount>0){$reserved=Dreminex_Customer_Wallet::reserve_order($order,$wallet_amount);if(is_wp_error($reserved)){wc_add_notice($reserved->get_error_message(),'error');return ['result'=>'failure'];}}
		if($provider_amount<=0.00001){$done=Dreminex_Customer_Wallet::commit_order($order);if(is_wp_error($done)){wc_add_notice($done->get_error_message(),'error');return ['result'=>'failure'];}$order->update_meta_data('_dreminex_payment_state','verified');$order->update_meta_data('_dreminex_paid_amount',wc_format_decimal($amounts['payable_now']));$order->save();if($mode==='full')$order->payment_complete('WALLET-'.$order_id);else $order->update_status('on-hold','Delivery advance paid from wallet; product balance remains due at delivery.');return ['result'=>'success','redirect'=>$this->get_return_url($order)];}
		if ( ! $available ) { wc_add_notice( __( 'No verified provider connection is available.', 'dreminex-payments' ), 'error' ); Dreminex_Customer_Wallet::release_order($order_id); return array( 'result' => 'failure' ); }
		uasort( $available, function( $a, $b ) { return (int) ( $a['priority'] ?? 0 ) <=> (int) ( $b['priority'] ?? 0 ); } );
		$profile_id = (string) array_key_first( $available );
		$provider_amounts=['payable_now'=>wc_format_decimal($provider_amount),'remaining_due'=>$amounts['remaining_due']];
		if(!Dreminex_Payments_Security::lock($order_id)) {wc_add_notice('A payment request is already being processed.','error');return ['result'=>'failure'];}
        try {
        $order_service = new Dreminex_Payments_Order_Service();
		$attempt = $order_service->create_attempt( $order, $provider_id, $profile_id, $mode, $provider_amounts );
		if ( is_wp_error( $attempt ) ) { wc_add_notice( $attempt->get_error_message(), 'error' ); return array( 'result' => 'failure' ); }
        $provider=Dreminex_Payments_Provider_Registry::get($provider_id);
        $state=bin2hex(random_bytes(32));
        $order->update_meta_data('_dreminex_callback_state',hash('sha256',$state));$order->save();
        $invoice='DREMINEX-'.$order_id.'-'.substr(str_replace('-','',$attempt),0,12);
        $callback=rest_url('dreminex-payments/v1/return/'.$provider_id.'/'.$profile_id.'/'.$order_id.'/'.$state);
		$context=['amount'=>$provider_amounts['payable_now'],'currency'=>$order->get_currency(),'invoice'=>$invoice,'callback_url'=>$callback,'payer_reference'=>'ORDER-'.$order_id];
        $created=$provider->create_payment($context,$profile_id);
        if(is_wp_error($created)) { $order_service->mark_unverified($order,'Create request not confirmed; no automatic retry. Review payment status.');wc_add_notice('Payment could not be confirmed. Contact us before trying again.','error');return ['result'=>'failure']; }
        $order->update_meta_data('_dreminex_provider_payment_id',$created['payment_id']);
        $order->update_meta_data('_dreminex_provider_signature',$created['signature']);
        $order->update_meta_data('_dreminex_payment_invoice',$invoice);$order->save();
        return ['result'=>'success','redirect'=>$created['redirect']];
        } finally { Dreminex_Payments_Security::unlock($order_id); }
	}
}

final class Dreminex_Payments_Rest_Controller {
	public static function register_routes() {
		foreach ( array( 'callback', 'return', 'cancel' ) as $kind ) {
			$route='/' . $kind . '/(?P<provider>[a-z0-9_-]+)/(?P<profile>[a-zA-Z0-9_-]+)';
            foreach([$route,$route.'/(?P<order_id>[0-9]+)/(?P<state>[a-f0-9]{64})'] as $path) register_rest_route( 'dreminex-payments/v1', $path, array(
				'methods' => array( 'GET', 'POST' ), 'callback' => array( 'Dreminex_Payments_Callback', 'handle' ), 'permission_callback' => '__return_true',
				'args' => array( 'provider' => array( 'validate_callback' => function( $v ) { return (bool) preg_match( '/^[a-z0-9_-]+$/', $v ); } ), 'profile' => array( 'validate_callback' => function( $v ) { return (bool) preg_match( '/^[a-zA-Z0-9_-]+$/', $v ); } ) ),
			) );
		}
	}
	public static function unconfigured_route( WP_REST_Request $request ) {
		$provider = Dreminex_Payments_Provider_Registry::get( $request['provider'] );
		if ( ! $provider || ! $provider->is_profile_configured( $request['profile'] ) ) { return new WP_Error( 'dreminex_route_unconfigured', __( 'Provider connection is not configured; payment not verified.', 'dreminex-payments' ), array( 'status' => 503 ) ); }
		// Custom adapters must supply official parsing and server-side verification before finalizing an order.
		return new WP_Error( 'dreminex_verification_unavailable', __( 'Verification is unavailable; payment remains unverified.', 'dreminex-payments' ), array( 'status' => 503 ) );
	}
}


require_once __DIR__ . '/dreminex_delivery_advance_api_config.php';
if (did_action('plugins_loaded')) Dreminex_Payments_Bootstrap::init();
else add_action('plugins_loaded',array('Dreminex_Payments_Bootstrap','init'),20);
