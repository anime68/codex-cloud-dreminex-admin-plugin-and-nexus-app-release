<?php
if (!defined('ABSPATH')) { exit; }
/** Delivery Advance & Wallet. The store does not offer a WooCommerce COD gateway. */

function dreminex_advance_provider_labels(){return ['bkash'=>'bKash','nagad'=>'Nagad','rocket'=>'Rocket','upay'=>'Upay'];}
function dreminex_advance_wallets(){
	$out=[];foreach(dreminex_advance_provider_labels() as $key=>$label){
		$number=Dreminex_Suite_Control::setting('delivery_advance','wallet_'.$key.'_number','__unset__');
		$type=Dreminex_Suite_Control::setting('delivery_advance','wallet_'.$key.'_type','personal');
		$enabled=Dreminex_Suite_Control::setting('delivery_advance','wallet_'.$key.'_enabled',$key==='upay'?0:1);
		if($number==='__unset__'&&$key!=='upay'){$number=Dreminex_Suite_Control::setting('delivery_advance','wallet_number','');$type=Dreminex_Suite_Control::setting('delivery_advance','account_type','personal');$enabled=1;}
		if($enabled&&preg_match('/^01[3-9][0-9]{8}$/D',(string)$number)&&in_array($type,['personal','merchant'],true))$out[$key]=['label'=>$label,'number'=>$number,'type'=>$type];
	}return $out;
}
function dreminex_advance_methods(){$out=[];foreach(dreminex_advance_wallets() as $key=>$wallet)$out[$key]=$wallet['label'];return $out;}
function dreminex_advance_is_checkout(){return function_exists('WC')&&WC()->cart&&!WC()->cart->is_empty();}
function dreminex_advance_txid_exists($txid){if($txid===''||!function_exists('wc_get_orders'))return false;return (bool)wc_get_orders(['type'=>'shop_order','limit'=>1,'return'=>'ids','meta_key'=>'_dreminex_advance_txid','meta_value'=>$txid]);}
function dreminex_advance_amounts($total,$shipping,$plan){$total=max(0,(float)$total);$shipping=min($total,max(0,(float)$shipping));$now=$plan==='full'?$total:$shipping;return ['payable_now'=>$now,'remaining_due'=>max(0,$total-$now)];}
function dreminex_checkout_wallet_use($data){return is_user_logged_in()&&!empty($data['dreminex_use_wallet']);}
function dreminex_checkout_wallet_available(){if(!is_user_logged_in()||!class_exists('Dreminex_Customer_Wallet')||!Dreminex_Customer_Wallet::enabled())return 0;$b=Dreminex_Customer_Wallet::balances(get_current_user_id());return (float)($b['total']??0);}

$wallet_file=__DIR__.'/dreminex_customer_wallet.php';if(is_readable($wallet_file))require_once $wallet_file;unset($wallet_file);

add_filter('woocommerce_gateway_title',function($title,$id){return $id==='bacs'?Dreminex_Suite_Control::setting('delivery_advance','gateway_title','Delivery Advance & Wallet'):$title;},20,2);
add_filter('woocommerce_bacs_process_payment_order_status',function($status,$order){if(!$order instanceof WC_Order||!$order->get_meta('_dreminex_payment_plan'))return $status;if($order->get_meta('_dreminex_payment_state')!=='verified')return 'pending';return $order->get_meta('_dreminex_payment_plan')==='full'?'processing':'on-hold';},20,2);
add_action('woocommerce_product_options_general_product_data',function(){woocommerce_wp_checkbox(['id'=>'_dreminex_cod_only','label'=>'COD-only product','description'=>'Offer Cash on Delivery only when the cart contains COD-only products.']);});
add_action('woocommerce_admin_process_product_object',function($product){if(!$product instanceof WC_Product)return;$product->update_meta_data('_dreminex_cod_only',isset($_POST['_dreminex_cod_only'])?'yes':'no');});
add_action('woocommerce_checkout_create_order',function($order){if($order instanceof WC_Order&&Dreminex_Suite_Routing::cod_cart_state()==='all'){$order->update_meta_data('_dreminex_payment_plan','cod_only');$order->update_meta_data('_dreminex_payment_state','due_at_delivery');$order->update_meta_data('_dreminex_remaining_due',wc_format_decimal($order->get_total()));}},5);

add_filter('woocommerce_checkout_fields',function($fields){
	$fields['order']['dreminex_payment_plan']=['type'=>'select','label'=>'Payment plan','options'=>['delivery_advance'=>'Delivery charge now; product balance at delivery','full'=>'Full payment now'],'required'=>true,'class'=>['form-row-wide'],'priority'=>13];
	if(is_user_logged_in())$fields['order']['dreminex_use_wallet']=['type'=>'checkbox','label'=>'Use available wallet balance first','required'=>false,'default'=>dreminex_checkout_wallet_available()>0?1:0,'class'=>['form-row-wide'],'priority'=>14];
	$fields['order']['dreminex_advance_method']=['type'=>'select','label'=>'Pay the amount still due with','options'=>[''=>'Choose a configured payment provider']+dreminex_advance_methods(),'required'=>false,'class'=>['form-row-wide'],'priority'=>15];
	$fields['order']['dreminex_advance_txid']=['type'=>'text','label'=>'Payment transaction ID','placeholder'=>'Enter the transaction ID shown in your app','required'=>false,'class'=>['form-row-wide'],'priority'=>16];return $fields;
},10001);

add_filter('woocommerce_gateway_description',function($description,$id){
	if($id!=='bacs'||!dreminex_advance_is_checkout())return $description;if(get_woocommerce_currency()!=='BDT')return '<p>This payment workflow currently requires BDT.</p>';
	$total=(float)WC()->cart->get_total('edit');$shipping=(float)WC()->cart->get_shipping_total()+(float)WC()->cart->get_shipping_tax();$available=dreminex_checkout_wallet_available();$items='';
	foreach(dreminex_advance_wallets() as $item)$items.='<li><strong>'.esc_html($item['label']).':</strong> '.esc_html($item['number']).' ('.esc_html(ucfirst($item['type'])).')</li>';
	$intro=Dreminex_Suite_Control::setting('delivery_advance','gateway_description','Pay the delivery charge now to confirm the order, then pay the product balance at delivery. You may also pay the full order now.');
	return '<p>'.esc_html($intro).'</p><p>Order total: <strong>'.wc_price($total).'</strong> · Delivery charge: <strong>'.wc_price($shipping).'</strong>'.($available>0?' · Wallet available: <strong>'.wc_price($available).'</strong>':'').'</p>'.($items?'<ul class="dreminex-wallet-instructions">'.$items.'</ul>':'');
},20,2);

add_action('woocommerce_review_order_after_order_total',function(){if(!dreminex_advance_is_checkout())return;$total=(float)WC()->cart->get_total('edit');$shipping=(float)WC()->cart->get_shipping_total()+(float)WC()->cart->get_shipping_tax();echo '<tr class="dreminex-advance-due"><th>Delivery advance</th><td>'.wp_kses_post(wc_price($shipping)).'</td></tr><tr class="dreminex-balance-due"><th>Product balance at delivery</th><td>'.wp_kses_post(wc_price(max(0,$total-$shipping))).'</td></tr>';});

add_action('woocommerce_after_checkout_validation',function($data,$errors){
	if(($data['payment_method']??'')!=='bacs')return;if(get_woocommerce_currency()!=='BDT'){$errors->add('dreminex_wallet_currency','Delivery Advance & Wallet requires BDT.');return;}
	$plan=sanitize_key($data['dreminex_payment_plan']??'delivery_advance');if(!in_array($plan,['delivery_advance','full'],true)){$errors->add('dreminex_plan','Choose a valid payment plan.');return;}
	$total=WC()->cart?(float)WC()->cart->get_total('edit'):0;$shipping=WC()->cart?(float)WC()->cart->get_shipping_total()+(float)WC()->cart->get_shipping_tax():0;$amounts=dreminex_advance_amounts($total,$shipping,$plan);
	if($plan==='delivery_advance'&&WC()->cart&&WC()->cart->needs_shipping()&&!WC()->cart->has_calculated_shipping()){$errors->add('dreminex_shipping',Dreminex_Suite_Control::message('delivery_advance','msg_shipping','Select an available delivery method before placing the order.'));return;}
	$wallet=dreminex_checkout_wallet_use($data)?min($amounts['payable_now'],dreminex_checkout_wallet_available()):0;$external=max(0,$amounts['payable_now']-$wallet);if($external<=0.00001)return;
	$wallets=dreminex_advance_wallets();if(!$wallets){$errors->add('dreminex_wallet_unconfigured',Dreminex_Suite_Control::message('delivery_advance','msg_wallet_unconfigured','Manual payment is not configured.'));return;}
	$method=sanitize_key($data['dreminex_advance_method']??'');$txid=strtoupper(trim(sanitize_text_field($data['dreminex_advance_txid']??'')));
	if(!isset($wallets[$method]))$errors->add('dreminex_method',Dreminex_Suite_Control::message('delivery_advance','msg_method','Select a configured payment provider.'));
	if(!preg_match('/^[A-Z0-9-]{5,40}$/D',$txid))$errors->add('dreminex_txid',Dreminex_Suite_Control::message('delivery_advance','msg_txid','Enter a valid payment transaction ID (5–40 letters, numbers or hyphens).'));
	if($txid!==''&&(int)Dreminex_Suite_Control::setting('delivery_advance','txid_unique',1)===1&&dreminex_advance_txid_exists($txid))$errors->add('dreminex_txid_used','This transaction ID is already linked to another order.');
},20,2);

add_action('woocommerce_checkout_create_order',function($order,$data){
	if(($data['payment_method']??'')!=='bacs')return;$plan=sanitize_key($data['dreminex_payment_plan']??'delivery_advance');if(!in_array($plan,['delivery_advance','full'],true))$plan='delivery_advance';
	$amounts=dreminex_advance_amounts($order->get_total(),(float)$order->get_shipping_total()+(float)$order->get_shipping_tax(),$plan);$wallet_amount=dreminex_checkout_wallet_use($data)?min($amounts['payable_now'],dreminex_checkout_wallet_available()):0;$external=max(0,$amounts['payable_now']-$wallet_amount);
	$method=sanitize_key($data['dreminex_advance_method']??'');$txid=strtoupper(trim(sanitize_text_field($data['dreminex_advance_txid']??'')));$wallets=dreminex_advance_wallets();
	foreach(['_dreminex_payable_now'=>$amounts['payable_now'],'_dreminex_remaining_due'=>$amounts['remaining_due'],'_dreminex_advance_due'=>$amounts['payable_now'],'_dreminex_balance_due'=>$amounts['remaining_due'],'_dreminex_wallet_requested'=>$wallet_amount,'_dreminex_external_due'=>$external] as $key=>$value)$order->update_meta_data($key,Dreminex_Customer_Wallet::format($value));
	$order->update_meta_data('_dreminex_payment_plan',$plan);if($external>0&&isset($wallets[$method])&&preg_match('/^[A-Z0-9-]{5,40}$/D',$txid)){$order->update_meta_data('_dreminex_advance_method',$method);$order->update_meta_data('_dreminex_advance_receiver',$wallets[$method]['number']);$order->update_meta_data('_dreminex_advance_account_type',$wallets[$method]['type']);$order->update_meta_data('_dreminex_advance_txid',$txid);}
	$order->update_meta_data('_dreminex_advance_verified','no');$order->update_meta_data('_dreminex_payment_state','pending');$order->update_meta_data('_dreminex_advance_recorded_at',gmdate('c'));
},20,2);

add_action('woocommerce_checkout_order_processed',function($order_id){
	$order=wc_get_order($order_id);if(!$order instanceof WC_Order||$order->get_payment_method()!=='bacs'||!$order->get_meta('_dreminex_payment_plan'))return;$requested=(float)$order->get_meta('_dreminex_wallet_requested');
	if($requested>0){$reserved=Dreminex_Customer_Wallet::reserve_order($order,$requested);if(is_wp_error($reserved)){$order->update_meta_data('_dreminex_payment_state','review_required');$order->add_order_note('Wallet reservation failed: '.$reserved->get_error_message());$order->save();return;}}
	if((float)$order->get_meta('_dreminex_external_due')<=0.00001){$done=Dreminex_Customer_Wallet::commit_order($order);if(is_wp_error($done)){$order->update_meta_data('_dreminex_payment_state','review_required');$order->add_order_note('Wallet debit requires review: '.$done->get_error_message());$order->save();return;}$order->update_meta_data('_dreminex_advance_verified','yes');$order->update_meta_data('_dreminex_payment_state','verified');$order->update_meta_data('_dreminex_paid_amount',$order->get_meta('_dreminex_payable_now'));$order->save();if($order->get_meta('_dreminex_payment_plan')==='full')$order->payment_complete('WALLET-'.$order_id);else $order->update_status('on-hold','Delivery advance paid from wallet; product balance remains due at delivery.');}
},30);

function dreminex_advance_finalize_manual($order,$source='admin'){
	if(!$order instanceof WC_Order||$order->get_meta('_dreminex_payment_state')==='verified')return true;$commit=Dreminex_Customer_Wallet::commit_order($order);if(is_wp_error($commit))return $commit;
	$order->update_meta_data('_dreminex_advance_verified','yes');$order->update_meta_data('_dreminex_payment_state','verified');$order->update_meta_data('_dreminex_advance_verified_at',gmdate('c'));$order->update_meta_data('_dreminex_advance_verified_by',get_current_user_id());$order->update_meta_data('_dreminex_paid_amount',$order->get_meta('_dreminex_payable_now'));$order->save();
	if($order->get_meta('_dreminex_payment_plan')==='full'||(float)$order->get_meta('_dreminex_remaining_due')<=0)$order->payment_complete((string)$order->get_meta('_dreminex_advance_txid'));elseif($order->has_status('pending'))$order->update_status('on-hold','Delivery advance verified; product balance remains due at delivery.');
	$order->add_order_note('Payment manually verified via '.$source.'. '.((float)$order->get_meta('_dreminex_remaining_due')>0?'Collect the product balance at delivery.':'The full order amount is paid.'));return true;
}
function dreminex_payment_plan_label($plan){return $plan==='full'?'Full payment':($plan==='cod_only'?'Cash on Delivery':'Delivery advance');}
function dreminex_advance_summary($order){if(!$order instanceof WC_Order||!$order->get_meta('_dreminex_payment_plan'))return;$plan=(string)$order->get_meta('_dreminex_payment_plan');$method=$order->get_meta('_dreminex_advance_method');$labels=dreminex_advance_provider_labels();echo '<h3>'.esc_html($plan==='cod_only'?'Cash on Delivery':'Delivery Advance & Wallet').'</h3><p><strong>Plan:</strong> '.esc_html(dreminex_payment_plan_label($plan)).'<br>';if($plan!=='cod_only')echo '<strong>Wallet reserved/used:</strong> '.wp_kses_post(wc_price((float)$order->get_meta('_dreminex_wallet_reserved'),['currency'=>$order->get_currency()])).'<br>';if(isset($labels[$method]))echo '<strong>External provider:</strong> '.esc_html($labels[$method]).'<br><strong>Transaction ID:</strong> '.esc_html($order->get_meta('_dreminex_advance_txid')).'<br>';if($plan!=='cod_only')echo '<strong>Verification:</strong> '.esc_html($order->get_meta('_dreminex_payment_state')==='verified'?'Verified':'Awaiting verification').'<br><strong>Pay now:</strong> '.wp_kses_post(wc_price($order->get_meta('_dreminex_payable_now'),['currency'=>$order->get_currency()])).'<br>';echo '<strong>'.esc_html($plan==='cod_only'?'Amount due at delivery':'Product balance at delivery').':</strong> '.wp_kses_post(wc_price($order->get_meta('_dreminex_remaining_due'),['currency'=>$order->get_currency()])).'</p>';}
add_action('woocommerce_admin_order_data_after_billing_address','dreminex_advance_summary');add_action('woocommerce_order_details_after_order_table','dreminex_advance_summary');
add_filter('woocommerce_order_actions',function($actions,$order=null){if($order instanceof WC_Order&&$order->get_meta('_dreminex_payment_plan')&&$order->get_meta('_dreminex_payment_state')!=='verified'&&(float)$order->get_meta('_dreminex_external_due')>0)$actions['dreminex_verify_delivery_advance']='Mark payment verified';return $actions;},20,2);
add_action('woocommerce_order_action_dreminex_verify_delivery_advance',function($order){$result=dreminex_advance_finalize_manual($order,'WooCommerce order action');if(is_wp_error($result))$order->add_order_note('Verification failed: '.$result->get_error_message());});
add_action('woocommerce_email_after_order_table',function($order,$admin,$plain){if(!$order instanceof WC_Order||!$order->get_meta('_dreminex_payment_plan'))return;$plan=(string)$order->get_meta('_dreminex_payment_plan');if($plain)echo "\nPayment plan: ".dreminex_payment_plan_label($plan).($plan==='cod_only'?"\nAmount due at delivery: ":"\nPay now: ".wp_strip_all_tags(wc_price($order->get_meta('_dreminex_payable_now'),['currency'=>$order->get_currency()]))."\nProduct balance at delivery: ").wp_strip_all_tags(wc_price($order->get_meta('_dreminex_remaining_due'),['currency'=>$order->get_currency()]))."\n";else dreminex_advance_summary($order);},20,3);

add_action('wp_enqueue_scripts',function(){if(!dreminex_advance_is_checkout())return;wp_enqueue_script('jquery');$available=dreminex_checkout_wallet_available();$js="(function($){function s(){var a=$('[name=payment_method]:checked').val()==='bacs',u=a&&$('#dreminex_use_wallet').is(':checked'),p=$('#dreminex_payment_plan').val()||'delivery_advance',t=parseFloat($('.order-total .amount').first().text().replace(/[^0-9.]/g,''))||0,d=parseFloat($('.dreminex-advance-due .amount').first().text().replace(/[^0-9.]/g,''))||0,e=Math.max(0,(p==='full'?t:d)-(u?".(float)$available.":0)),r=a&&e>.001;$('#dreminex_payment_plan_field,#dreminex_use_wallet_field').toggle(a);$('#dreminex_advance_method_field,#dreminex_advance_txid_field').toggle(r).toggleClass('validate-required',r).find('input,select').prop('required',r)}$(document.body).on('change','[name=payment_method],#dreminex_payment_plan,#dreminex_use_wallet',s).on('updated_checkout',s);$(s)})(jQuery);";wp_add_inline_script('jquery',$js,'after');});

// Legacy gateway and metadata IDs stay internal for historical order/profile compatibility.
$api_file=__DIR__.'/dreminex_delivery_advance_api.php';if(is_readable($api_file))require_once $api_file;unset($api_file);
