<?php
if (!defined('ABSPATH')) exit;

/**
 * Compares phone-produced supplier image fingerprints with local WooCommerce
 * media. Supplier URLs are never fetched by WordPress.
 */
final class Dreminex_Supplier_Visual {
 private static function dhash($bytes) {
  if(!function_exists('imagecreatefromstring')||strlen($bytes)>5000000||strlen($bytes)<100)return '';
  $source=@imagecreatefromstring($bytes);if(!$source)return '';
  $tiny=imagecreatetruecolor(9,8);imagecopyresampled($tiny,$source,0,0,0,0,9,8,imagesx($source),imagesy($source));imagedestroy($source);
  $bits='';for($y=0;$y<8;$y++)for($x=0;$x<8;$x++){$a=imagecolorat($tiny,$x,$y);$b=imagecolorat($tiny,$x+1,$y);$ag=((($a>>16)&255)*299+(($a>>8)&255)*587+($a&255)*114);$bg=((($b>>16)&255)*299+(($b>>8)&255)*587+($b&255)*114);$bits.=$ag>$bg?'1':'0';}imagedestroy($tiny);return $bits;
 }
 private static function hamming($a,$b){if(!preg_match('/^[01]{64}$/',$a)||!preg_match('/^[01]{64}$/',$b))return 65;$n=0;for($i=0;$i<64;$i++)if($a[$i]!==$b[$i])$n++;return $n;}
 private static function local_fingerprint($attachment_id){$file=get_attached_file($attachment_id);if(!$file||!is_readable($file)||filesize($file)>5000000)return null;$bytes=file_get_contents($file);if($bytes===false)return null;return ['sha256'=>hash('sha256',$bytes),'dhash'=>self::dhash($bytes)];}
 public static function compare($product_id,$host,$images) {
  $product=wc_get_product($product_id);if(!$product||!$product->is_type('variable')||!is_array($images)||count($images)>20)return ['status'=>'unsupported'];
  $candidates=[];foreach($product->get_children() as $variation_id){$variation=wc_get_product($variation_id);if(!$variation||!$variation->get_image_id())continue;$color='';foreach($variation->get_attributes() as $key=>$value)if(stripos($key,'color')!==false||stripos($key,'colour')!==false)$color=sanitize_title((string)$value);if($color==='')continue;$image_id=(int)$variation->get_image_id();$candidates[$image_id]['color']=$color;$candidates[$image_id]['variations'][]=(int)$variation_id;}
  foreach($candidates as $image_id=>&$entry)$entry['fingerprint']=self::local_fingerprint($image_id);unset($entry);if(!$candidates)return ['status'=>'unmapped'];
  $matches=[];$uncertain=[];$seen=0;$expected=count($images);$allowed_host=str_replace('www.','',strtolower((string)$host));
  foreach($images as $image){if(!is_array($image))continue;$url=esc_url_raw((string)($image['url']??''));$parts=wp_parse_url($url);if(!$parts||strtolower($parts['scheme']??'')!=='https'||str_replace('www.','',strtolower($parts['host']??''))!==$allowed_host)continue;$sha=strtolower((string)($image['sha256']??''));$dhash=(string)($image['dhash']??'');if(!preg_match('/^[a-f0-9]{64}$/',$sha)&&!preg_match('/^[01]{64}$/',$dhash))continue;$seen++;$rank=[];foreach($candidates as $image_id=>$entry){$fingerprint=$entry['fingerprint']??null;if(!$fingerprint)continue;if($sha!==''&&hash_equals($fingerprint['sha256'],$sha)){$rank[$image_id]=0;continue;}$rank[$image_id]=self::hamming($fingerprint['dhash'],$dhash);}asort($rank,SORT_NUMERIC);$ids=array_keys($rank);$best=$ids[0]??0;$second=$ids[1]??0;if($best&&($rank[$best]===0||($rank[$best]<=4&&(!$second||$rank[$second]-$rank[$best]>=2))))$matches[$url]=['image_id'=>$best,'color'=>$candidates[$best]['color'],'variation_ids'=>array_values(array_unique($candidates[$best]['variations'])),'distance'=>$rank[$best]];else $uncertain[]=$url;}
  if(!$seen||$seen!==$expected)return ['status'=>'incomplete','seen'=>$seen,'expected'=>$expected];return ['status'=>'ok','matches'=>$matches,'uncertain'=>$uncertain,'seen'=>$seen];
 }
}
