<?php
if (!defined('ABSPATH')) { exit; }
/* Dreminex | Show WooCommerce checkout errors in an accessible popup.
 * PHP Code Snippets entry, run everywhere. Native notices remain available.
 */
add_action( 'wp_footer', function () {
	if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page() ) return;
	$title = Dreminex_Suite_Control::setting( 'checkout_experience', 'title', 'Your order cannot be placed yet' );
	$message = Dreminex_Suite_Control::setting( 'checkout_experience', 'message', '' );
	$button = Dreminex_Suite_Control::setting( 'checkout_experience', 'button_text', 'Understood' );
	?>
	<style>
	#dreminex-checkout-dialog[hidden]{display:none!important}
	#dreminex-checkout-dialog{position:fixed;inset:0;z-index:999999;background:rgba(33,37,41,.65);display:flex;align-items:center;justify-content:center;padding:20px}
	#dreminex-checkout-dialog .dreminex-dialog-box{background:#F8F9FA;border-top:5px solid #00B4D7;border-radius:8px;color:#212529;max-width:480px;width:100%;padding:22px;box-shadow:0 16px 45px rgba(0,0,0,.24)}
	#dreminex-checkout-dialog h2{margin:0 0 12px;font-size:21px;color:#212529}
	#dreminex-checkout-dialog .dreminex-dialog-message{margin:0 0 12px;line-height:1.5;color:#465962}
	#dreminex-checkout-dialog ul{margin:0 0 18px;padding-left:20px;max-height:45vh;overflow:auto}
	#dreminex-checkout-dialog li{margin-bottom:8px}
	#dreminex-checkout-dialog button{background:#212529;color:#fff;border:0;border-radius:4px;padding:10px 22px;cursor:pointer}
	</style>
	<div id="dreminex-checkout-dialog" hidden role="dialog" aria-modal="true" aria-labelledby="dreminex-dialog-title">
	 <div class="dreminex-dialog-box"><h2 id="dreminex-dialog-title"><?php echo esc_html($title ?: 'Your order cannot be placed yet'); ?></h2><?php if($message!==''): ?><p class="dreminex-dialog-message"><?php echo esc_html($message); ?></p><?php endif; ?><ul></ul><button type="button"><?php echo esc_html($button ?: 'Understood'); ?></button></div>
	</div>
	<script>
	(function(){
	 var dialog=document.getElementById('dreminex-checkout-dialog');
	 if(!dialog)return;
	 var list=dialog.querySelector('ul'), close=dialog.querySelector('button'), lastFocus, lastSignature='', timer;
	 var noticeSelector='.woocommerce-error, .woocommerce-NoticeGroup-checkout, .wc-block-components-notice-banner.is-error';
	 function dismiss(){dialog.hidden=true; if(lastFocus&&lastFocus.focus)lastFocus.focus();}
	 function messagesFrom(root){
	  var items=root.querySelectorAll('.woocommerce-error li, .woocommerce-NoticeGroup-checkout li, .wc-block-components-notice-banner.is-error li');
	  if(!items.length)items=root.querySelectorAll(noticeSelector);
	  var seen={}, result=[];
	  items.forEach(function(node){var line=node.textContent.trim();if(line&&!seen[line]){seen[line]=true;result.push(line);}});
	  return result;
	 }
	 function show(raw){
	  var messages=[];
	  if(typeof raw==='string'&&raw.trim()){
	   var fragment=document.createElement('div');fragment.innerHTML=raw;
	   messages=messagesFrom(fragment);
	   if(!messages.length&&fragment.textContent.trim())messages=[fragment.textContent.trim()];
	  }
	  if(!messages.length)messages=messagesFrom(document);
	  if(!messages.length)return;
	  var signature=messages.join('\n');
	  if(signature===lastSignature)return;
	  lastSignature=signature;
	  list.replaceChildren();messages.forEach(function(line){var li=document.createElement('li');li.textContent=line;list.appendChild(li);});
	  lastFocus=document.activeElement;dialog.hidden=false;close.focus();
	 }
	 function schedule(raw){window.clearTimeout(timer);timer=window.setTimeout(function(){show(raw);},60);}
	 close.addEventListener('click',dismiss);
	 dialog.addEventListener('click',function(e){if(e.target===dialog)dismiss();});
	 document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!dialog.hidden)dismiss();});
	 dialog.addEventListener('keydown',function(e){if(e.key!=='Tab'||dialog.hidden)return;var focusable=dialog.querySelectorAll('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])');if(!focusable.length)return;var first=focusable[0],last=focusable[focusable.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}});
	 document.addEventListener('click',function(e){if(e.target.closest('#place_order'))lastSignature='';});
	 document.addEventListener('submit',function(e){if(e.target.matches('form.checkout'))lastSignature='';},true);
	 if(window.jQuery)window.jQuery(document.body).on('checkout_error',function(event,raw){schedule(raw);});
	 new MutationObserver(function(changes){
	  for(var i=0;i<changes.length;i++){
	   for(var j=0;j<changes[i].addedNodes.length;j++){
	    var node=changes[i].addedNodes[j];
	    if(node.nodeType!==1||dialog.contains(node))continue;
	    if(node.matches(noticeSelector)||node.querySelector(noticeSelector)){schedule();return;}
	   }
	  }
	 }).observe(document.body,{childList:true,subtree:true});
	 if(document.querySelector(noticeSelector))schedule();
	})();
	</script>
	<?php
}, 30 );
