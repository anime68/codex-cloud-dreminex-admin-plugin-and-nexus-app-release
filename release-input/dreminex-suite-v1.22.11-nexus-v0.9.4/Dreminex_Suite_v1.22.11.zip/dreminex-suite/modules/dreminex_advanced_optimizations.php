<?php
if (!defined('ABSPATH')) exit;
/** Load Suite-owned admin CSS on Suite screens only when optimization is enabled. */
add_action('admin_enqueue_scripts',function(){
 $optimized=(int)Dreminex_Suite_Control::setting('advanced_optimizations','asset_optimization',1);
 $screen=function_exists('get_current_screen')?get_current_screen():null;
 $suite_screen=$screen && strpos($screen->id,'dreminex-suite')!==false;
 if($optimized && !$suite_screen)return;
 wp_enqueue_style('dreminex-suite-admin',plugins_url('../assets/suite-admin.css',__FILE__),array(),DREMINEX_SUITE_VERSION);
});
