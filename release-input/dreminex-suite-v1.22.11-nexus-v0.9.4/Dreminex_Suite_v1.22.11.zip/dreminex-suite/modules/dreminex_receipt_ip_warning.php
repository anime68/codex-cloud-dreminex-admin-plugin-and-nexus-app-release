<?php
if (!defined('ABSPATH')) { exit; }
/* Dreminex: optional receipt IP transparency and [show_ip] shortcode.
 * Use only the WooCommerce recorded order IP, not spoofable forwarded headers.
 */
if(!function_exists('dreminex_receipt_ip_display')){
 function dreminex_receipt_ip_display($ip){
  $mode=Dreminex_Suite_Control::setting('checkout_protection','ip_display','masked');
  if($mode==='hidden'||!filter_var($ip,FILTER_VALIDATE_IP))return '';
  if($mode==='full')return $ip;
  if(filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)){ $parts=explode('.',$ip);$parts[3]='×';return implode('.',$parts); }
  $parts=explode(':',$ip);return implode(':',array_slice($parts,0,3)).':…';
 }
}
add_shortcode( 'show_ip', function () {
	if ( ! class_exists( 'WC_Geolocation' ) ) return '';
	$ip = WC_Geolocation::get_ip_address();
		return esc_html(dreminex_receipt_ip_display($ip));
} );
add_action( 'woocommerce_before_thankyou', function ( $order_id ) {
	if ( ! $order_id || ! function_exists( 'is_order_received_page' ) || ! is_order_received_page() ) return;
	$order = wc_get_order( $order_id );
	if ( ! $order instanceof WC_Order ) return;
	$ip = $order->get_customer_ip_address();
	if ( ! $ip || ! filter_var( $ip, FILTER_VALIDATE_IP ) ) return;
	echo Dreminex_Suite_Setup::text('<p style="background:#F8F9FA;color:#212529;border-left:4px solid #00B4D7;padding:12px 16px;margin:12px 0">');
		$shown=dreminex_receipt_ip_display($ip);$default=$shown!==''?Dreminex_Suite_Control::tr('The connection IP has been recorded for order security: <code>{ip}</code>. We may contact you to verify your identity or payment.', 'অর্ডার নিরাপত্তার জন্য সংযোগের IP রেকর্ড করা হয়েছে: <code>{ip}</code>। আপনার পরিচয় বা পেমেন্ট নিশ্চিত করতে প্রয়োজনে আমরা যোগাযোগ করতে পারি।'):Dreminex_Suite_Control::tr('Connection information has been recorded for order security. We may contact you to verify your identity or payment.','অর্ডার নিরাপত্তার জন্য connection information রেকর্ড করা হয়েছে। আপনার পরিচয় বা payment যাচাই করতে প্রয়োজনে যোগাযোগ করা হতে পারে।');
		echo wp_kses_post( str_replace( '{ip}', $shown!==''?'<code>' . esc_html( $shown ) . '</code>':'', Dreminex_Suite_Control::message( 'checkout_protection', 'msg_ip_warning', $default ) ) );
	echo '</p>';
}, 6 );
