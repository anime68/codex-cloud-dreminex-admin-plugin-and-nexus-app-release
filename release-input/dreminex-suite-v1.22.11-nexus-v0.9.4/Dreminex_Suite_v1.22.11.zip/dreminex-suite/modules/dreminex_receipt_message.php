<?php
if (!defined('ABSPATH')) { exit; }
/* Dreminex: branded order-received message, independently switchable. */
add_action( 'woocommerce_before_thankyou', function ( $order_id ) {
	if ( ! $order_id || ! function_exists( 'is_order_received_page' ) || ! is_order_received_page() ) {
		return;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order instanceof WC_Order ) {
		return;
	}
	echo Dreminex_Suite_Setup::text('<section class="dreminex-receipt-note" style="background:#F8F9FA;border-left:4px solid #00B4D7;color:#212529;padding:16px;margin:20px 0">');
	$default = Dreminex_Suite_Control::tr("<strong>Your order has been received.</strong> We will verify the delivery advance and contact you to confirm the order. Do not send payment twice for the same order.", '<strong>আপনার অর্ডারটি গ্রহণ করা হয়েছে।</strong> অগ্রিম delivery charge যাচাই করে অর্ডার নিশ্চিত করতে আমরা যোগাযোগ করব। একই অর্ডারের জন্য দ্বিতীয়বার টাকা পাঠাবেন না।');
	echo wp_kses_post( Dreminex_Suite_Control::message( 'checkout_experience', 'msg_receipt', $default ) );
	echo '</section>';
}, 5 );
