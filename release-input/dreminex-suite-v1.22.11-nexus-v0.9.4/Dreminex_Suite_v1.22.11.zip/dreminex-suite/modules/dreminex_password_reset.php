<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * WooCommerce rejects a reset link for account B when account A is signed in.
 * Validate the link before switching away from A; WooCommerce then continues
 * its normal reset cookie, redirect, and password form.
 */
add_action( 'template_redirect', function () {
	if ( ! function_exists( 'is_account_page' ) || ! is_account_page() || ! is_user_logged_in() ) return;
	if ( ! isset( $_GET['key'] ) || ( ! isset( $_GET['id'] ) && ! isset( $_GET['login'] ) ) ) return;
	$key = sanitize_text_field( wp_unslash( $_GET['key'] ) );
	if ( ! $key || strlen( $key ) > 200 ) return;
	$user = isset( $_GET['login'] )
		? get_user_by( 'login', sanitize_user( wp_unslash( $_GET['login'] ) ) )
		: get_user_by( 'id', absint( $_GET['id'] ) );
	if ( ! $user || (int) $user->ID === get_current_user_id() ) return;
	$verified = check_password_reset_key( $key, $user->user_login );
	if ( is_wp_error( $verified ) || (int) $verified->ID !== (int) $user->ID ) return;
	wp_logout();
}, 9 );
