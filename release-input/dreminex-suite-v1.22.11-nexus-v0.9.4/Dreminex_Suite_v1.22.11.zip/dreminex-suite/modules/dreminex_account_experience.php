<?php
if (!defined('ABSPATH')) exit;
/** Responsive account/registration presentation and password recovery under one parent module. */
$dreminex_modules=(array)get_option('dreminex_suite_modules',[]);
if(!empty($dreminex_modules['registration_email'])){
 if((int)Dreminex_Suite_Control::setting('registration_email','registration_core_enabled',1)===1)require_once __DIR__.'/dreminex_registration_email.php';
 if((int)Dreminex_Suite_Control::setting('registration_email','password_reset_enabled',1)===1)require_once __DIR__.'/dreminex_password_reset.php';
}
unset($dreminex_modules);
