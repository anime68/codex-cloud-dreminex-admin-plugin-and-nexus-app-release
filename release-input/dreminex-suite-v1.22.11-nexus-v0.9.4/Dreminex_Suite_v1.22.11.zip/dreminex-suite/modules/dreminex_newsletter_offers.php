<?php
/**
 * Dreminex newsletter and confirmed-subscriber coupon.
 * Loaded by the Novamira sandbox loader.
 */
if (!defined('ABSPATH')) exit;
// Place the automatic offer inside the existing Elementor footer, between its
// newsletter row and the logo/app row. The footer builder remains authoritative.
add_action('init', static function(){
    remove_action('get_footer', [Dreminex_Suite_Experience::class, 'automatic_offers'], 5);
}, 99);
add_filter('elementor/frontend/the_content', 'dreminex_offer_footer_placement', 50);
function dreminex_offer_footer_placement($html){
    if (!is_string($html) || is_admin() || wp_doing_ajax() || !Dreminex_Suite_Features::enabled('newsletter_offers','offers')
        || !get_option('dreminex_suite_auto_newsletter',1) || Dreminex_Suite_Experience::offer_seen()) return $html;
    $marker = '<div class="elementor-element elementor-element-ec98571';
    if (!str_contains($html, 'elementor-element-34d774f') || !str_contains($html, $marker)) return $html;
    $placeholder = dreminex_news_live_placeholder('offers');
    if (!$placeholder) return $html;
    $section = '<section class="dreminex-auto-offers" aria-label="Current offers">'.$placeholder.'</section>';
    return preg_replace('/(?=<div class="elementor-element elementor-element-ec98571\\b)/', $section, $html, 1);
}
add_action('wp_enqueue_scripts',static function(){
    if (!Dreminex_Suite_Features::enabled('newsletter_offers','offers') && !Dreminex_Suite_Features::enabled('newsletter_offers','newsletter')) return;
    wp_register_style('dreminex-offer-placement', false, [], DREMINEX_SUITE_VERSION);
    wp_enqueue_style('dreminex-offer-placement');
    wp_add_inline_style('dreminex-offer-placement', '.site-footer .dreminex-auto-offers{box-sizing:border-box;width:min(1200px,calc(100% - 32px));margin:16px auto 0;padding:0}.site-footer:has(.dreminex-auto-offers) .elementor-element-ec98571>.e-con-inner{padding-top:24px}.dreminex-offer-copy,.dreminex-newsletter-copy{max-height:190px;overflow-y:auto;overscroll-behavior:contain;scrollbar-color:#00B4D7 #F8F9FA;scrollbar-width:thin;border:1px solid #DEE2E6;border-radius:8px;background:#FFFFFF;padding:12px 14px;line-height:1.55}.dreminex-newsletter-copy{max-height:100px;margin-top:10px}.dreminex-offer-copy p:first-child{margin-top:0}.dreminex-offer-copy small{display:block}.dreminex-offer-copy:focus-visible,.dreminex-newsletter-copy:focus-visible{outline:2px solid #00B4D7;outline-offset:2px}@media(max-width:600px){.site-footer .dreminex-auto-offers{width:calc(100% - 32px)}}');
},35);
/**
 * Footer templates can be page-cached before the visitor's login state is known.
 * Keep personalized coupon HTML out of cached pages; load it through an
 * authenticated, non-cacheable same-origin request instead.
 */
function dreminex_news_live_placeholder($part) {
    if(!in_array($part,['heading','signup','offers'],true))return '';
    $feature=$part==='offers'?'offers':'newsletter';
    if(!Dreminex_Suite_Features::enabled('newsletter_offers',$feature))return '';
    $id='dreminex-news-live-'.$part;
    if($part==='signup'||$part==='offers')wp_enqueue_script('dreminex-news-live',plugins_url('assets/newsletter-live.js',DREMINEX_SUITE_PATH.'dreminex-suite.php'),[],DREMINEX_SUITE_VERSION,true);
    return '<div id="'.esc_attr($id).'" class="dreminex-news-live" aria-live="polite" data-endpoint="'.esc_url(admin_url('admin-ajax.php')).'">'.($part!=='heading'?'<noscript>Please enable JavaScript to view this section.</noscript>':'').'</div>';
}
add_action('wp_ajax_dreminex_news_live_panel','dreminex_news_live_response');
add_action('wp_ajax_nopriv_dreminex_news_live_panel','dreminex_news_live_response');
function dreminex_news_live_response(){
    nocache_headers();
    header('Cache-Control: private, no-store, max-age=0',true);
    define('DREMINEX_NEWS_RENDER_PRIVATE',true);
    wp_send_json_success([
        'heading'=>do_shortcode('[dreminex_newsletter_heading]'),
        'signup'=>do_shortcode('[dreminex_newsletter_signup]'),
        'offers'=>do_shortcode('[dreminex_active_offers]')
    ]);
}
function dreminex_news_settings() {
    $defaults=[
        'enabled'=>1,'coupon_enabled'=>0,'coupon_existing_customers'=>0,'amount'=>30,'minimum'=>0,'days'=>30,
        'confirmation_intro'=>Dreminex_Suite_Setup::text('Thank you for signing up for Dreminex Fashion updates.'),
        'coupon_intro'=>'Thanks for confirming your email. Your personal coupon code is:',
        'welcome_intro'=>Dreminex_Suite_Setup::text('Thanks for confirming your email. You are subscribed to Dreminex Fashion updates.')
    ];
    $saved=get_option('dreminex_newsletter_settings',[]);
    $settings=array_merge($defaults,is_array($saved)?$saved:[]);
    // The welcome promotion is for new customers on any eligible regular-price order.
    // Legacy settings may have allowed existing customers or a larger discount.
    $settings['coupon_existing_customers']=0;
    $settings['amount']=min(30,max(1,(int)$settings['amount']));
    $settings['minimum']=0;
    $settings['enabled']=Dreminex_Suite_Features::enabled('newsletter_offers','newsletter')?1:0;
    return $settings;
}
function dreminex_news_coupon_eligible($user_id,$existing_coupon=0) {
    $settings=dreminex_news_settings();
    if(empty($settings['coupon_enabled'])||$existing_coupon||!function_exists('wc_get_orders'))return false;
    $user=get_userdata((int)$user_id);
    if(!$user||!is_email($user->user_email))return false;
    // Check both registered and earlier guest purchases. Woo's order query supports
    // both legacy order storage and HPOS; cancelled/failed/pending are not purchases.
    $statuses=array_values(array_diff(array_keys(wc_get_order_statuses()),['wc-pending','wc-failed','wc-cancelled','wc-checkout-draft']));
    if(!$statuses)return false;
    $query=['type'=>'shop_order','status'=>$statuses,'limit'=>1,'return'=>'ids'];
    try {
        if(wc_get_orders($query+['customer_id'=>(int)$user_id]))return false;
        if(wc_get_orders($query+['billing_email'=>$user->user_email]))return false;
    } catch (Throwable $e) { return false; }
    return true;
}
add_shortcode('dreminex_newsletter_heading',function(){
    if(!Dreminex_Suite_Features::enabled('newsletter_offers','newsletter'))return '';
    if(!defined('DREMINEX_NEWS_RENDER_PRIVATE'))return dreminex_news_live_placeholder('heading');
    $s=dreminex_news_settings();
    $confirmed=false;
    if(is_user_logged_in()){
        global $wpdb;
        $user=wp_get_current_user();
        $confirmed=(bool)$wpdb->get_var($wpdb->prepare('SELECT id FROM '.dreminex_news_table()." WHERE user_id=%d AND email=%s AND status='confirmed' LIMIT 1",$user->ID,strtolower($user->user_email)));
    }
    if($confirmed){
        // The offer panel prints its own heading only for eligible subscribers.
        return '';
    }else{
        if(empty($s['enabled']))return '';
        $coupon=dreminex_news_coupon_eligible(get_current_user_id());
        $title=$coupon ? str_replace('৳',get_woocommerce_currency_symbol(),'Join our newsletter for <span>৳').esc_html($s['amount']).'</span> off' : 'Join our newsletter';
        $description=$coupon ? 'Subscribe to receive updates and a welcome coupon after confirming your email.' : Dreminex_Suite_Setup::text('Subscribe to receive Dreminex Fashion updates.');
    }
    return '<div class="dreminex-news-heading"><h2>'.$title.'</h2><p>'.esc_html($description).Dreminex_Suite_Setup::text('</p></div><style>.dreminex-news-heading h2{font-size:24px;line-height:1.35;font-weight:500;color:#212529;margin:0 0 8px}.dreminex-news-heading h2 span{font-weight:700;color:#00b4d7}.dreminex-news-heading p{margin:0;color:#606975}@media(max-width:767px){.dreminex-news-heading h2{font-size:21px}}</style>');
});
function dreminex_news_table() {
    global $wpdb;
    return $wpdb->prefix . 'dreminex_newsletter';
}
add_action('init', function () {
    if (get_option('dreminex_newsletter_schema') === '2') return;
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $table = dreminex_news_table();
    $collate = $wpdb->get_charset_collate();
    dbDelta("CREATE TABLE {$table} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        email varchar(254) NOT NULL,
        user_id bigint(20) unsigned NOT NULL DEFAULT 0,
        status varchar(20) NOT NULL DEFAULT 'pending',
        created_at datetime NOT NULL,
        confirmed_at datetime DEFAULT NULL,
        confirmation_hash char(64) NOT NULL DEFAULT '',
        confirmation_expires bigint(20) unsigned NOT NULL DEFAULT 0,
        unsubscribe_hash char(64) NOT NULL DEFAULT '',
        coupon_id bigint(20) unsigned NOT NULL DEFAULT 0,
        coupon_code varchar(100) NOT NULL DEFAULT '',
        last_email_status varchar(20) NOT NULL DEFAULT '',
        last_email_at datetime DEFAULT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY email (email),
        KEY user_id (user_id)
    ) {$collate};");
    if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table) {
        foreach ($wpdb->get_results("SELECT id,email,coupon_id FROM {$table} WHERE user_id=0") as $row) {
            $user=get_user_by('email',$row->email);
            if ($user) {
                $wpdb->update($table,['user_id'=>$user->ID],['id'=>$row->id],['%d'],['%d']);
                if ($row->coupon_id) update_post_meta($row->coupon_id,'_dreminex_owner_user_id',$user->ID);
            }
        }
        update_option('dreminex_newsletter_schema','2',false);
    }
});
function dreminex_news_url($status) {
    return add_query_arg('newsletter', $status, Dreminex_Suite_Setup::page_url('newsletter')) . '#dreminex-newsletter';
}
function dreminex_news_redirect($status) {
    wp_safe_redirect(dreminex_news_url($status),303);
    exit;
}
function dreminex_news_mail($email, $subject, $heading, $html) {
    if (function_exists('WC') && WC()) {
        $mailer = WC()->mailer();
        $html = $mailer->wrap_message($heading,$html);
        $emails = $mailer->get_emails();
        $first = reset($emails);
        if ($first && method_exists($first,'style_inline')) $html = $first->style_inline($html);
    } else {
        $html = '<html><body><h1>' . esc_html($heading) . '</h1>' . $html . '</body></html>';
    }
    return wp_mail($email,$subject,$html,[
        'Content-Type: text/html; charset=UTF-8',
        Dreminex_Suite_Setup::text('From: Dreminex Fashion <hello@dreminexfashion.store>'),
        Dreminex_Suite_Setup::text('Reply-To: Dreminex Fashion <hello@dreminexfashion.store>')
    ]);
}
add_shortcode('dreminex_newsletter_signup', function () {
    if(!defined('DREMINEX_NEWS_RENDER_PRIVATE'))return dreminex_news_live_placeholder('signup');
    $s=dreminex_news_settings();
    if (is_user_logged_in()) {
        global $wpdb;
        $account=wp_get_current_user();
        $confirmed=(bool)$wpdb->get_var($wpdb->prepare('SELECT id FROM '.dreminex_news_table()." WHERE user_id=%d AND email=%s AND status='confirmed' LIMIT 1",$account->ID,strtolower($account->user_email)));
        if ($confirmed) return '';
    }
    if (empty($s['enabled'])) return '';
    if (!is_user_logged_in()) return '<div id="dreminex-newsletter"><p>Log in or create an account to subscribe and claim your one-time welcome coupon.</p><a class="button" href="'.esc_url(wc_get_page_permalink('myaccount')).'">Log in / Register</a></div>';
    $account=wp_get_current_user();
    $status = isset($_GET['newsletter']) ? sanitize_key(wp_unslash($_GET['newsletter'])) : '';
    $messages = [
        'check_email'=>'Please check your inbox and confirm your email address to receive your coupon. Check Spam if needed.',
        'confirmed'=>'Your email is confirmed. Please check your inbox for the welcome email or coupon; check Spam if needed.',
        'mail_problem'=>'Your subscription is saved, but the coupon email was not accepted by the mail server. Please contact us.',
        'already'=>'This email is already subscribed. If you need your coupon again, please contact us.',
        'pending'=>'A confirmation email was recently requested. Please check your inbox or try again later.',
        'invalid'=>'Enter a valid email address and agree to receive promotional emails.',
        'unsubscribed'=>'You have been unsubscribed from promotional emails.',
        'error'=>'We could not process your request. Please try again later.',
        'account_email_only'=>'Use the email address on your Dreminex account. Another email cannot claim a welcome coupon for this account.',
    ];
    ob_start(); ?>
    <div id="dreminex-newsletter" class="dreminex-newsletter">
      <?php if (isset($messages[$status])) : ?><p class="dreminex-newsletter-message" role="status"><?php echo esc_html($messages[$status]); ?></p><?php endif; ?>
      <?php if ($status==='account_email_only') : ?><div class="dreminex-news-modal" role="alertdialog" aria-modal="true" aria-label="Account email required"><div><p><?php echo esc_html($messages[$status]); ?></p><button type="button" onclick="this.closest('.dreminex-news-modal').remove()">OK</button></div></div><?php endif; ?>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="dreminex_newsletter_signup">
        <?php wp_nonce_field('dreminex_newsletter_signup','dreminex_news_nonce'); ?>
        <label class="screen-reader-text" for="dreminex-news-email">Email address</label>
        <div class="dreminex-newsletter-fields">
          <input id="dreminex-news-email" name="newsletter_email" type="email" value="<?php echo esc_attr($account->user_email); ?>" readonly required>
          <button type="submit">Subscribe</button>
        </div>
        <label class="dreminex-news-consent"><input type="checkbox" name="newsletter_consent" value="1" required> I agree to receive promotional emails from Dreminex Fashion. I can unsubscribe anytime.</label>
        <input type="text" name="dreminex_news_website" class="dreminex-news-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
      <div class="dreminex-newsletter-copy" tabindex="0" role="region" aria-label="Welcome offer terms"><small><?php if (dreminex_news_coupon_eligible($account->ID)) : ?>Confirm your email for <?php echo esc_html(get_woocommerce_currency_symbol()); ?><?php echo esc_html($s['amount']); ?> off one eligible regular-price order. For new customers only; no minimum spend, once per registered account and one use, valid for <?php echo esc_html($s['days']); ?> days. Sale items and Flash Sale items are excluded; cannot combine with another coupon.<?php else : ?>Confirm your email to receive updates. Welcome coupons are for new customers without a prior order.<?php endif; ?> <a href="<?php echo esc_url(get_privacy_policy_url()); ?>">Privacy Policy</a></small></div>
      </form>
    </div>
    <style>
      .dreminex-newsletter{width:100%;}.dreminex-newsletter-fields{display:flex;gap:10px;width:100%;}
      .dreminex-newsletter-fields input{box-sizing:border-box;flex:1;min-width:0;padding:13px 15px;border:1px solid #cbd5da;border-radius:6px;background:#fff;color:#212529;font:inherit;}
      .dreminex-newsletter-fields button{cursor:pointer;min-width:135px;padding:12px 18px;border:1px solid #00b4d7;border-radius:6px;background:#00b4d7;color:#212529;font:inherit;font-weight:600;}
      .dreminex-newsletter-fields button:hover,.dreminex-newsletter-fields button:focus{background:#008fae;border-color:#008fae;}
      .dreminex-news-consent{display:flex;align-items:flex-start;gap:8px;margin:10px 0 5px;font-size:13px;line-height:1.45;color:#4b5563;}
      .dreminex-news-consent input{margin-top:3px;flex:none;}.dreminex-newsletter small{display:block;line-height:1.5;color:#606975;}
      .dreminex-newsletter-message{padding:10px 12px;background:#e7f7fa;border-radius:6px;color:#174b55;}
      .dreminex-news-hp{position:absolute!important;left:-9999px!important;width:1px!important;height:1px!important;}
      .dreminex-news-modal{position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;padding:20px}.dreminex-news-modal>div{background:#fff;padding:25px;border-radius:8px;max-width:430px;color:#212529}.dreminex-news-modal button{background:#00b4d7;color:#212529;border:0;border-radius:5px;padding:9px 22px;cursor:pointer}
      @media(max-width:600px){.dreminex-newsletter-fields{flex-direction:column;}.dreminex-newsletter-fields button{width:100%;}}
    </style>
    <?php return ob_get_clean();
});
add_action('admin_post_nopriv_dreminex_newsletter_signup','dreminex_news_signup');
add_action('admin_post_dreminex_newsletter_signup','dreminex_news_signup');
function dreminex_news_signup() {
    if (!is_user_logged_in()) dreminex_news_redirect('account_email_only');
    $user=wp_get_current_user();
    if (empty(dreminex_news_settings()['enabled'])) dreminex_news_redirect('error');
    if (!isset($_POST['dreminex_news_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dreminex_news_nonce'])),'dreminex_newsletter_signup')) dreminex_news_redirect('invalid');
    if (!empty($_POST['dreminex_news_website'])) dreminex_news_redirect('check_email');
    $email = isset($_POST['newsletter_email']) ? strtolower(sanitize_email(wp_unslash($_POST['newsletter_email']))) : '';
    if (!is_email($email) || empty($_POST['newsletter_consent'])) dreminex_news_redirect('invalid');
    if (strtolower($user->user_email)!==$email) dreminex_news_redirect('account_email_only');
    $key = 'dreminex_news_rate_' . md5((string)($_SERVER['REMOTE_ADDR']??'unknown'));
    if (get_transient($key) >= 5) dreminex_news_redirect('pending');
    global $wpdb;
    $table=dreminex_news_table();
    $owned=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE user_id=%d ORDER BY id ASC LIMIT 1",$user->ID));
    if ($owned && $owned->email!==$email) dreminex_news_redirect('account_email_only');
    $item=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE email=%s",$email));
    if ($item && $item->user_id && (int)$item->user_id!==$user->ID) dreminex_news_redirect('account_email_only');
    if ($item && $item->status==='confirmed') dreminex_news_redirect('already');
    if ($item && $item->status==='pending' && $item->last_email_status==='accepted' && $item->last_email_at && strtotime($item->last_email_at)>time()-600) dreminex_news_redirect('pending');
    $token=bin2hex(random_bytes(32));
    $data=['user_id'=>$user->ID,'status'=>'pending','confirmation_hash'=>hash('sha256',$token),'confirmation_expires'=>time()+2*DAY_IN_SECONDS,'last_email_at'=>current_time('mysql',true),'last_email_status'=>'pending'];
    if ($item) {
        $ok=$wpdb->update($table,$data,['id'=>$item->id]);
        $id=(int)$item->id;
    } else {
        $ok=$wpdb->insert($table,array_merge(['email'=>$email,'created_at'=>current_time('mysql',true)],$data));
        $id=(int)$wpdb->insert_id;
    }
    if ($ok===false || !$id) dreminex_news_redirect('error');
    set_transient($key,(int)get_transient($key)+1,HOUR_IN_SECONDS);
    $link=add_query_arg(['action'=>'dreminex_newsletter_confirm','id'=>$id,'token'=>$token],admin_url('admin-post.php'));
    $settings=dreminex_news_settings();
    $eligible=dreminex_news_coupon_eligible($user->ID,$item->coupon_id??0);
    $body='<p>'.esc_html($settings['confirmation_intro']).'</p><p>Confirm your email'.($eligible?' to receive your personal coupon':' to subscribe').':</p><p><a href="'.esc_url($link).'">Confirm my email</a></p><p>This confirmation link expires in 48 hours.</p>'.($eligible?str_replace('৳',get_woocommerce_currency_symbol(),'<p>The coupon is for ৳').esc_html($settings['amount']).' off one regular-price order, with no minimum spend, and is valid for '.esc_html($settings['days']).' days. One use per email; sale items and Flash Sale items are excluded; cannot combine with another coupon.</p>':'').'<p>If you did not sign up, you can ignore this email.</p>';
    $sent=dreminex_news_mail($email,Dreminex_Suite_Setup::text('Confirm your Dreminex Fashion newsletter signup'),'Confirm your email',$body);
    $wpdb->update($table,['last_email_status'=>$sent?'accepted':'failed'],['id'=>$id]);
    dreminex_news_redirect($sent?'check_email':'error');
}
add_action('admin_post_nopriv_dreminex_newsletter_confirm','dreminex_news_confirm');
add_action('admin_post_dreminex_newsletter_confirm','dreminex_news_confirm');
function dreminex_news_confirm() {
    if (empty(dreminex_news_settings()['enabled'])) dreminex_news_redirect('error');
    $id=isset($_GET['id'])?absint($_GET['id']):0;
    $token=isset($_GET['token'])?sanitize_text_field(wp_unslash($_GET['token'])):'';
    global $wpdb;
    $table=dreminex_news_table();
    $item=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d",$id));
    if (!$item || $item->status!=='pending' || strlen($token)!==64 || !hash_equals($item->confirmation_hash,hash('sha256',$token)) || (int)$item->confirmation_expires<time()) dreminex_news_redirect('error');
    $owner=get_userdata((int)$item->user_id);
    if (!$owner || strtolower($owner->user_email)!==strtolower($item->email)) dreminex_news_redirect('error');
    $settings=dreminex_news_settings();
    $claim=$wpdb->query($wpdb->prepare("UPDATE {$table} SET status='issuing' WHERE id=%d AND status='pending' AND confirmation_hash=%s",$id,$item->confirmation_hash));
    if ($claim!==1) dreminex_news_redirect('error');
    $coupon_id=0; $code='';
    if (dreminex_news_coupon_eligible($item->user_id,$item->coupon_id)) {
        if (!class_exists('WC_Coupon')) {
            $wpdb->update($table,['status'=>'pending'],['id'=>$id]);
            dreminex_news_redirect('error');
        }
        $code='DREMINEX'.(int)$settings['amount'].'-'.strtoupper(bin2hex(random_bytes(5)));
        $coupon=new WC_Coupon();
        $coupon->set_code($code);
        $coupon->set_discount_type('fixed_cart');
        $coupon->set_amount((int)$settings['amount']);
        $coupon->set_individual_use(true);
        $coupon->set_exclude_sale_items(true);
        $coupon->set_usage_limit(1);
        $coupon->set_usage_limit_per_user(1);
        $coupon->set_email_restrictions([$item->email]);
        $coupon->set_minimum_amount((int)$settings['minimum']);
        $coupon->set_date_expires(time()+(int)$settings['days']*DAY_IN_SECONDS);
        $coupon->update_meta_data('_dreminex_owner_user_id',(int)$item->user_id);
        try { $coupon_id=$coupon->save(); } catch (Throwable $e) { $coupon_id=0; }
        if (!$coupon_id) {
            $wpdb->update($table,['status'=>'pending'],['id'=>$id]);
            dreminex_news_redirect('error');
        }
    }
    $unsub=bin2hex(random_bytes(32));
    $data=[
        'status'=>'confirmed','confirmed_at'=>current_time('mysql',true),
        'confirmation_hash'=>'','confirmation_expires'=>0,
        'unsubscribe_hash'=>hash('sha256',$unsub)
    ];
    if ($coupon_id) { $data['coupon_id']=$coupon_id; $data['coupon_code']=$code; }
    $ok=$wpdb->update($table,$data,['id'=>$id,'status'=>'issuing']);
    if ($ok!==1) {
        if ($coupon_id) wp_delete_post($coupon_id,true);
        $wpdb->update($table,['status'=>'pending'],['id'=>$id,'status'=>'issuing']);
        dreminex_news_redirect('error');
    }
    $sent=dreminex_news_send_coupon($id,$unsub,(bool)$coupon_id);
    dreminex_news_redirect($sent?'confirmed':'mail_problem');
}
function dreminex_news_send_coupon($id,$unsub='',$include_coupon=true) {
    global $wpdb;
    $table=dreminex_news_table();
    $item=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d",$id));
    if (!$item || $item->status!=='confirmed') return false;
    $settings=dreminex_news_settings();
    $has_coupon=$include_coupon && $item->coupon_id && get_post($item->coupon_id);
    if ($unsub==='') {
        $unsub=bin2hex(random_bytes(32));
        $wpdb->update($table,['unsubscribe_hash'=>hash('sha256',$unsub)],['id'=>$id]);
    }
    $link=add_query_arg(['action'=>'dreminex_newsletter_unsubscribe','id'=>$id,'token'=>$unsub],admin_url('admin-post.php'));
    if ($has_coupon) {
        $coupon=new WC_Coupon($item->coupon_id);
        $amount=$coupon->get_amount();
        $minimum=$coupon->get_minimum_amount();
        $expiry=$coupon->get_date_expires();
        $body='<p>'.esc_html($settings['coupon_intro']).'</p><p style="font-size:24px;font-weight:700;letter-spacing:1px">'.esc_html($item->coupon_code).'</p>';
        $body.=str_replace('৳',get_woocommerce_currency_symbol(),'<p>Use it for ৳').esc_html($amount).' off'.($minimum>0?str_replace('৳',get_woocommerce_currency_symbol(),' an order of at least ৳').esc_html($minimum):' one order with no minimum spend').'. One use with this email address; Flash Sale items are excluded; cannot combine with another coupon.'.($coupon->get_exclude_sale_items()?' Sale items are excluded.':'').($expiry?' Expires on '.esc_html(wc_format_datetime($expiry,'j F Y')).'.':'').'</p>';
        $subject=Dreminex_Suite_Setup::text('Your Dreminex Fashion coupon');
        $heading='Your welcome coupon';
    } else {
        $body='<p>'.esc_html($settings['welcome_intro']).'</p>';
        $subject=Dreminex_Suite_Setup::text('Welcome to Dreminex Fashion updates');
        $heading='Subscription confirmed';
    }
    $body.='<p>Shop: <a href="'.esc_url(wc_get_page_permalink('shop')).Dreminex_Suite_Setup::text('">Dreminex Fashion</a></p><p><a href="').esc_url($link).'">Unsubscribe from promotional emails</a></p>';
    $sent=dreminex_news_mail($item->email,$subject,$heading,$body);
    $wpdb->update($table,['last_email_status'=>$sent?'accepted':'failed','last_email_at'=>current_time('mysql',true)],['id'=>$id]);
    return $sent;
}
add_action('admin_post_nopriv_dreminex_newsletter_unsubscribe','dreminex_news_unsubscribe');
add_action('admin_post_dreminex_newsletter_unsubscribe','dreminex_news_unsubscribe');
function dreminex_news_unsubscribe() {
    $id=isset($_GET['id'])?absint($_GET['id']):0;
    $token=isset($_GET['token'])?sanitize_text_field(wp_unslash($_GET['token'])):'';
    global $wpdb;
    $item=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.dreminex_news_table().' WHERE id=%d',$id));
    if (!$item || strlen($token)!==64 || !hash_equals($item->unsubscribe_hash,hash('sha256',$token))) dreminex_news_redirect('error');
    $wpdb->update(dreminex_news_table(),['status'=>'unsubscribed','unsubscribe_hash'=>''],['id'=>$id]);
    dreminex_news_redirect('unsubscribed');
}
function dreminex_news_admin_page() {
    if (!current_user_can('manage_options')) wp_die('Access denied.',403);
    global $wpdb;
    $table=dreminex_news_table();
    $page=max(1,isset($_GET['paged'])?absint($_GET['paged']):1);
    $total=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$table}");
    $items=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} ORDER BY id DESC LIMIT 20 OFFSET %d",($page-1)*20));
    echo '<div class="wrap"><h1>Newsletter Subscribers</h1><p><a class="button" href="'.esc_url(admin_url('admin.php?page=dreminex-newsletter-settings')).'">Newsletter settings</a></p><p>Subscriber records are stored in WordPress independently of email delivery. One coupon is issued per eligible email when confirmed.</p>';
    if (isset($_GET['deleted'])) echo '<div class="notice notice-success"><p>Subscriber removed and coupon revoked.</p></div>';
    if (isset($_GET['resent'])) echo '<div class="notice '.($_GET['resent']==='accepted'?'notice-success':'notice-error').'"><p>Coupon email: '.esc_html($_GET['resent']).' by mail server.</p></div>';
    echo '<table class="widefat striped"><thead><tr><th>Date (UTC)</th><th>Email</th><th>Status</th><th>Confirmed (UTC)</th><th>Coupon</th><th>Last email</th><th>Action</th></tr></thead><tbody>';
    foreach ($items as $item) {
        echo '<tr><td>'.esc_html($item->created_at).'</td><td>'.esc_html($item->email).'</td><td>'.esc_html($item->status).'</td><td>'.esc_html($item->confirmed_at?:'—').'</td><td>'.esc_html($item->coupon_code?:'—').'</td><td>'.esc_html($item->last_email_status?:'—').'</td><td>';
        if ($item->status==='confirmed') {
            $url=wp_nonce_url(admin_url('admin-post.php?action=dreminex_newsletter_resend&id='.$item->id),'dreminex_newsletter_resend_'.$item->id);
            echo '<a class="button" href="'.esc_url($url).'">Resend welcome email</a>';
        }
        $delete=wp_nonce_url(admin_url('admin-post.php?action=dreminex_newsletter_delete&id='.$item->id),'dreminex_newsletter_delete_'.$item->id);
        echo ' <a class="button button-link-delete" href="'.esc_url($delete).'" onclick="return confirm(&quot;Delete this subscriber and revoke their coupon permanently?&quot;);">Delete and revoke</a>';
        echo '</td></tr>';
    }
    if (!$items) echo '<tr><td colspan="7">No subscribers yet.</td></tr>';
    echo '</tbody></table>';
    if ($total>20) echo '<p>'.wp_kses_post(paginate_links(['base'=>add_query_arg('paged','%#%'),'current'=>$page,'total'=>(int)ceil($total/20)])).'</p>';
    echo '</div>';
}
add_action('admin_post_dreminex_newsletter_resend',function(){
    if (!current_user_can('manage_options')) wp_die('Access denied.',403);
    $id=isset($_GET['id'])?absint($_GET['id']):0;
    check_admin_referer('dreminex_newsletter_resend_'.$id);
    $sent=dreminex_news_send_coupon($id);
    wp_safe_redirect(admin_url('admin.php?page=dreminex-newsletter&resent='.($sent?'accepted':'failed')),303);
    exit;
});
function dreminex_news_settings_page() {
    if (!current_user_can('manage_options')) wp_die('Access denied.',403);
    $s=dreminex_news_settings();
    echo '<div class="wrap"><h1>Newsletter Settings</h1><p>Welcome coupons are for confirmed new customers without a prior order: up to ৳30 off once, no minimum spend, no sale/Flash Sale items, and no other coupons. Audit existing catalog margins before enabling the newsletter feature. Settings apply to future coupons; existing coupons remain manageable under Marketing → Coupons.</p>';
    if (isset($_GET['saved'])) echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_newsletter_settings">';
    wp_nonce_field('dreminex_newsletter_settings');
    echo '<table class="form-table"><tbody>';
    echo '<tr><th>Newsletter / Offers On-Off</th><td><a href="'.esc_url(admin_url('admin.php?page=dreminex-suite&module=newsletter_offers')).'">Manage independent feature switches</a></td></tr>';
    foreach (['coupon_enabled'=>'Issue a welcome coupon after confirmation'] as $key=>$label) {
        echo '<tr><th>'.esc_html($label).'</th><td><label><input type="checkbox" name="'.esc_attr($key).'" value="1" '.checked(!empty($s[$key]),true,false).'> Enabled</label></td></tr>';
    }
    foreach (['amount'=>'Coupon amount (store currency)','days'=>'Coupon validity (days)'] as $key=>$label) {
        echo '<tr><th><label for="news-'.esc_attr($key).'">'.esc_html($label).'</label></th><td><input id="news-'.esc_attr($key).'" type="number" name="'.esc_attr($key).'" min="1" max="'.($key==='amount'?30:365).'" value="'.esc_attr($s[$key]).'" required></td></tr>';
    }
    foreach (['confirmation_intro'=>'Confirmation email introduction','coupon_intro'=>'Coupon email introduction','welcome_intro'=>'Welcome email introduction (without coupon)'] as $key=>$label) {
        echo '<tr><th><label for="news-'.esc_attr($key).'">'.esc_html($label).'</label></th><td><textarea id="news-'.esc_attr($key).'" name="'.esc_attr($key).'" rows="3" maxlength="2000" style="width:100%;max-width:650px">'.esc_textarea($s[$key]).'</textarea></td></tr>';
    }
    echo '</tbody></table>';
    submit_button('Save newsletter settings');
    echo '</form></div>';
}
add_action('admin_post_dreminex_newsletter_settings',function(){
    if (!current_user_can('manage_options')) wp_die('Access denied.',403);
    check_admin_referer('dreminex_newsletter_settings');
    $s=['enabled'=>Dreminex_Suite_Features::enabled('newsletter_offers','newsletter')?1:0,'coupon_enabled'=>!empty($_POST['coupon_enabled'])?1:0,'coupon_existing_customers'=>0,'minimum'=>0];
    foreach (['amount'=>[1,30],'days'=>[1,365]] as $key=>$bounds) {
        $n=isset($_POST[$key])?absint($_POST[$key]):-1;
        if ($n<$bounds[0]||$n>$bounds[1]) wp_die('Invalid newsletter setting.',400);
        $s[$key]=$n;
    }
    foreach (['confirmation_intro','coupon_intro','welcome_intro'] as $key) {
        $s[$key]=isset($_POST[$key])?sanitize_textarea_field(wp_unslash($_POST[$key])):'';
        if (strlen($s[$key])>2000) wp_die('Email text is too long.',400);
    }
    update_option('dreminex_newsletter_settings',$s,false);
    wp_safe_redirect(admin_url('admin.php?page=dreminex-newsletter-settings&saved=1'),303);
    exit;
});
add_action('admin_post_dreminex_newsletter_delete',function(){
    if (!current_user_can('manage_options')) wp_die('Access denied.',403);
    $id=isset($_GET['id'])?absint($_GET['id']):0;
    check_admin_referer('dreminex_newsletter_delete_'.$id);
    global $wpdb;
    $table=dreminex_news_table();
    $item=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d",$id));
    if (!$item) wp_die('Subscriber not found.',404);
    if ($item->coupon_id && get_post($item->coupon_id)) wp_delete_post($item->coupon_id,true);
    $wpdb->delete($table,['id'=>$id],['%d']);
    wp_safe_redirect(admin_url('admin.php?page=dreminex-newsletter&deleted=1'),303);
    exit;
});
add_filter('woocommerce_coupon_is_valid',function($valid,$coupon){
    if (!$valid || !is_object($coupon)) return $valid;
    $owner=(int)$coupon->get_meta('_dreminex_owner_user_id',true);
    if ($owner && get_current_user_id()!==$owner) return false;
    return $valid;
},10,2);
// Flash Sale's own coupon switch may be changed later; welcome coupons never
// discount its dynamic cart prices, even when other coupons are allowed there.
add_filter('woocommerce_coupon_get_items_to_apply',function($items,$coupon){
    if(!is_object($coupon)||(int)$coupon->get_meta('_dreminex_owner_user_id',true)<=0)return $items;
    return array_filter($items,static function($item){
        return !is_array($item->object??null)||!isset($item->object['_dreminex_flash']);
    });
},20,2);
add_filter('woocommerce_coupon_is_valid_for_product',function($valid,$product,$coupon,$values){
    if(!$valid||!is_object($coupon)||(int)$coupon->get_meta('_dreminex_owner_user_id',true)<=0)return $valid;
    return !isset($values['_dreminex_flash']);
},20,4);


/* ---- Module boundary ---- */

/** Dreminex account-based promotional campaigns. */
if (!defined('ABSPATH')) exit;
function dreminex_offers_table(){global $wpdb;return $wpdb->prefix.'dreminex_offers';}
function dreminex_offer_claims_table(){global $wpdb;return $wpdb->prefix.'dreminex_offer_claims';}
function dreminex_offer_notification_image($offer){
    $id=(int)($offer->notification_image_id??0);
    return $id && wp_attachment_is_image($id) ? (wp_get_attachment_image_url($id,'large')?:'') : '';
}
add_action('admin_enqueue_scripts',function(){
    $page=isset($_GET['page'])?sanitize_key(wp_unslash($_GET['page'])):'';
    $section=isset($_GET['section'])?sanitize_key(wp_unslash($_GET['section'])):'';
    if($page!=='dreminex-offers' && !($page==='dreminex-newsletter' && $section==='offers'))return;
    wp_enqueue_media();
    wp_enqueue_script('dreminex-offer-admin-media',plugins_url('assets/offer-admin-media.js',DREMINEX_SUITE_PATH.'dreminex-suite.php'),[],DREMINEX_SUITE_VERSION,true);
});
add_action('init',function(){
    if(get_option('dreminex_offers_schema')==='2')return;
    global $wpdb; require_once ABSPATH.'wp-admin/includes/upgrade.php';
    $a=dreminex_offers_table();$b=dreminex_offer_claims_table();$collate=$wpdb->get_charset_collate();
    dbDelta("CREATE TABLE {$a} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        title varchar(200) NOT NULL,
        description text NOT NULL,
        amount decimal(12,2) NOT NULL DEFAULT 0,
        minimum decimal(12,2) NOT NULL DEFAULT 0,
        validity_days int(11) NOT NULL DEFAULT 30,
        start_date date NOT NULL,
        end_date date NOT NULL,
        product_ids text NOT NULL,
        notification_image_id bigint(20) unsigned NOT NULL DEFAULT 0,
        status varchar(20) NOT NULL DEFAULT 'draft',
        created_at datetime NOT NULL,
        PRIMARY KEY  (id)
    ) {$collate};");
    dbDelta("CREATE TABLE {$b} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        offer_id bigint(20) unsigned NOT NULL,
        user_id bigint(20) unsigned NOT NULL,
        email varchar(254) NOT NULL,
        coupon_id bigint(20) unsigned NOT NULL DEFAULT 0,
        coupon_code varchar(100) NOT NULL DEFAULT '',
        status varchar(20) NOT NULL DEFAULT 'issuing',
        created_at datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY offer_user (offer_id,user_id)
    ) {$collate};");
    if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$a))===$a && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$b))===$b && $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM {$a} LIKE %s",'notification_image_id'))!==null)update_option('dreminex_offers_schema','2',false);
});
function dreminex_offer_active($o){
    $today=current_time('Y-m-d');
    return $o && $o->status==='active' && $o->start_date<=$today && $o->end_date>=$today;
}
function dreminex_offer_coupon_available($coupon_id){
    if(!$coupon_id || get_post_status($coupon_id)!=='publish')return false;
    try{$coupon=new WC_Coupon($coupon_id);}catch(Throwable $e){return false;}
    $expiry=$coupon->get_date_expires();
    if($expiry && $expiry->getTimestamp()<time())return false;
    $limit=(int)$coupon->get_usage_limit();
    if($limit && (int)$coupon->get_usage_count()>=$limit)return false;
    return true;
}
function dreminex_offer_eligible($account){
    if(!$account || !$account->ID)return false;
    if((int)get_user_meta($account->ID,'_dreminex_email_confirmed',true)>0)return true;
    global $wpdb;return (bool)$wpdb->get_var($wpdb->prepare('SELECT id FROM '.dreminex_news_table()." WHERE user_id=%d AND email=%s AND status='confirmed' LIMIT 1",$account->ID,strtolower($account->user_email)));
}
function dreminex_latest_active_offer(){
    global $wpdb;
    $today=current_time('Y-m-d');
    return $wpdb->get_row($wpdb->prepare('SELECT * FROM '.dreminex_offers_table()." WHERE status='active' AND start_date<=%s AND end_date>=%s ORDER BY id DESC LIMIT 1",$today,$today));
}
add_shortcode('dreminex_active_offers',function(){
    if(!Dreminex_Suite_Features::enabled('newsletter_offers','offers'))return '';
    global $wpdb;
    $latest=dreminex_latest_active_offer();
    $user=is_user_logged_in()?wp_get_current_user():null;
    $uid=$user?(int)$user->ID:0;
    $eligible=$user?dreminex_offer_eligible($user):false;
    $claim=null;$outstanding=[];
    if($user){
        $claims=$wpdb->get_results($wpdb->prepare('SELECT offer_id,coupon_id,coupon_code,status FROM '.dreminex_offer_claims_table()." WHERE user_id=%d AND status='claimed' ORDER BY offer_id DESC LIMIT 30",$uid));
        foreach((array)$claims as $one){
            if(!dreminex_offer_coupon_available((int)$one->coupon_id))continue;
            if($latest && (int)$one->offer_id===(int)$latest->id)$claim=$one;
            else $outstanding[]=$one;
        }
        // A used/expired claim remains in history, but should not block a later eligible offer.
        $latest_record=$latest?$wpdb->get_var($wpdb->prepare('SELECT id FROM '.dreminex_offer_claims_table().' WHERE offer_id=%d AND user_id=%d LIMIT 1',$latest->id,$uid)):null;
        if($latest_record && !$claim)$latest=null;
    }
    // No active offer and no unexpired unused coupon means no offer message at all.
    if(!$latest && !$outstanding)return '';
    $msg=isset($_GET['offer_result'])?sanitize_key(wp_unslash($_GET['offer_result'])):'';
    $messages=['claimed'=>'Your offer coupon is ready below. A copy was sent to your account email.','mail_problem'=>'Your offer code is ready below, but the email could not be sent. You can retry sending it.','existing'=>'This offer was already claimed for your account.','login'=>'Log in and confirm your email to claim this offer.','verified'=>'Your email is confirmed. You can now claim the offer.','verification_sent'=>'Check your account email and click the verification link to claim this offer.','unavailable'=>'This offer is not currently available.','error'=>'The offer could not be claimed. Please try again.'];
    ob_start();?>
    <section id="dreminex-offers" class="dreminex-offers"><h3>Current offers</h3>
      <?php if(isset($messages[$msg])):?><p role="status"><?php echo esc_html($messages[$msg]);?></p><?php endif;?>
      <?php if($latest):$products=array_filter(array_map('absint',explode(',',$latest->product_ids)));?>
      <article class="dreminex-offer-card">
        <h4><?php echo esc_html($latest->title);?></h4><div class="dreminex-offer-copy" tabindex="0" role="region" aria-label="Offer details"><p><?php echo esc_html($latest->description);?></p>
        <small><?php echo esc_html(get_woocommerce_currency_symbol()); ?><?php echo esc_html(wc_format_decimal($latest->amount,0));?> off<?php if((float)$latest->minimum>0):?> orders of at least <?php echo esc_html(get_woocommerce_currency_symbol()); ?><?php echo esc_html(wc_format_decimal($latest->minimum,0));?><?php endif;?><?php if($products):?> on selected products<?php endif;?>. One claim and one use per account. Offer ends <?php echo esc_html($latest->end_date);?>.</small></div>
        <?php if(!$user):?><p><a class="button" href="<?php echo esc_url(wc_get_page_permalink('myaccount'));?>">Log in / Register to claim</a></p>
        <?php elseif(!$eligible):?><p>Confirm your account email to claim this offer. This confirmation does not subscribe you to the newsletter.</p>
          <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>"><input type="hidden" name="action" value="dreminex_offer_verify"><input type="hidden" name="offer_id" value="<?php echo esc_attr($latest->id);?>"><?php wp_nonce_field('dreminex_offer_verify_'.$latest->id);?><button type="submit">Email me a verification link</button></form>
        <?php elseif($claim):?>
          <p>Your code: <strong><?php echo esc_html($claim->coupon_code);?></strong></p>
          <?php if(get_post_meta($claim->coupon_id,'_dreminex_offer_mail_status',true)==='failed'):?><p>The email could not be sent. Your code remains available here.</p><form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>"><input type="hidden" name="action" value="dreminex_offer_resend"><input type="hidden" name="offer_id" value="<?php echo esc_attr($latest->id);?>"><?php wp_nonce_field('dreminex_offer_resend_'.$latest->id);?><button type="submit">Retry email</button></form><?php endif;?>
        <?php else:?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>"><input type="hidden" name="action" value="dreminex_offer_claim"><input type="hidden" name="offer_id" value="<?php echo esc_attr($latest->id);?>"><?php wp_nonce_field('dreminex_offer_claim_'.$latest->id);?><button type="submit">Claim offer</button></form><?php endif;?>
      </article><?php endif;?>
      <?php if($outstanding):?><div class="dreminex-outstanding-offers"><h4>Your unused offer codes</h4><?php foreach($outstanding as $old):$past=$wpdb->get_var($wpdb->prepare('SELECT title FROM '.dreminex_offers_table().' WHERE id=%d',$old->offer_id));$coupon=new WC_Coupon((int)$old->coupon_id);$expires=$coupon->get_date_expires();?>
        <div class="dreminex-outstanding-row"><span><?php echo esc_html($past?:'Previous offer');?></span>: <strong><?php echo esc_html($old->coupon_code);?></strong><?php if($expires):?><small>Valid until <?php echo esc_html(wc_format_datetime($expires,'j F Y'));?></small><?php endif;?>
        <?php if(get_post_meta($old->coupon_id,'_dreminex_offer_mail_status',true)==='failed'):?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>"><input type="hidden" name="action" value="dreminex_offer_resend"><input type="hidden" name="offer_id" value="<?php echo esc_attr($old->offer_id);?>"><?php wp_nonce_field('dreminex_offer_resend_'.$old->offer_id);?><button type="submit">Retry email</button></form><?php endif;?></div>
      <?php endforeach;?></div><?php endif;?>
    </section><style>.dreminex-offers{margin:22px auto;max-width:1200px}.dreminex-offers h3{font-size:20px}.dreminex-offer-card{padding:20px;margin:12px 0;border:1px solid #d5e8ec;border-radius:12px;background:#f7fcfd;box-shadow:0 8px 24px rgba(19,75,90,.05)}.dreminex-offer-card h4{margin:0 0 8px;font-size:18px}.dreminex-offer-card p{margin:7px 0}.dreminex-offer-card small{display:block;line-height:1.55;color:#4b5563}.dreminex-offer-card button,.dreminex-offers .button,.dreminex-outstanding-offers button{margin-top:12px;padding:10px 18px;color:#212529;background:#00b4d7;border:0;border-radius:8px;cursor:pointer;text-decoration:none}.dreminex-outstanding-offers{margin-top:18px;padding-top:12px;border-top:1px solid #d5e8ec}.dreminex-outstanding-offers h4{font-size:16px;margin:0 0 8px}.dreminex-outstanding-row{padding:10px 0;line-height:1.5}.dreminex-outstanding-row+.dreminex-outstanding-row{border-top:1px solid #d5e8ec}</style>
    <?php return ob_get_clean();
});

// Offer verification is independent from newsletter consent and the newsletter feature switch.
add_action('admin_post_dreminex_offer_verify',function(){
    if(!is_user_logged_in())dreminex_offer_redirect('login');
    $id=absint($_POST['offer_id']??0);check_admin_referer('dreminex_offer_verify_'.$id);
    $offer=dreminex_latest_active_offer();if(!$offer||(int)$offer->id!==$id)dreminex_offer_redirect('unavailable');
    $user=wp_get_current_user();if(dreminex_offer_eligible($user))dreminex_offer_redirect('verified');
    $last=(int)get_user_meta($user->ID,'_dreminex_offer_verify_sent',true);if($last&&time()-$last<60)dreminex_offer_redirect('login');
    try{$token=bin2hex(random_bytes(32));}catch(Throwable $e){dreminex_offer_redirect('error');}
    update_user_meta($user->ID,'_dreminex_offer_verify_hash',hash('sha256',$token));update_user_meta($user->ID,'_dreminex_offer_verify_expires',time()+2*DAY_IN_SECONDS);update_user_meta($user->ID,'_dreminex_offer_verify_sent',time());
    $link=add_query_arg(['action'=>'dreminex_offer_verify_confirm','uid'=>$user->ID,'token'=>$token],admin_url('admin-post.php'));
    $body='<p>Confirm the email address on your Dreminex Fashion account to claim the available offer.</p><p><a href="'.esc_url($link).'">Confirm my email</a></p><p>This link expires in 48 hours. This confirmation does not subscribe you to marketing emails.</p>';
    if(!dreminex_news_mail($user->user_email,'Confirm your email to claim a Dreminex offer','Confirm your email',$body))dreminex_offer_redirect('error');
    dreminex_offer_redirect('verification_sent');
});
$dreminex_offer_confirm=static function(){
    $uid=absint($_GET['uid']??0);$token=sanitize_text_field(wp_unslash($_GET['token']??''));$hash=get_user_meta($uid,'_dreminex_offer_verify_hash',true);$expires=(int)get_user_meta($uid,'_dreminex_offer_verify_expires',true);
    $ok=$uid&&strlen($token)===64&&$hash&&$expires>=time()&&hash_equals($hash,hash('sha256',$token));
    if($ok){update_user_meta($uid,'_dreminex_email_confirmed',time());delete_user_meta($uid,'_dreminex_offer_verify_hash');delete_user_meta($uid,'_dreminex_offer_verify_expires');}
    wp_safe_redirect(add_query_arg('offer_result',$ok?'verified':'error',Dreminex_Suite_Setup::page_url('newsletter')).'#dreminex-offers',303);exit;
};
add_action('admin_post_dreminex_offer_verify_confirm',$dreminex_offer_confirm);
add_action('admin_post_nopriv_dreminex_offer_verify_confirm',$dreminex_offer_confirm);
function dreminex_offer_redirect($result){
    wp_safe_redirect(add_query_arg('offer_result',$result,Dreminex_Suite_Setup::page_url('newsletter')).'#dreminex-offers',303);exit;
}
add_action('admin_post_nopriv_dreminex_offer_claim',function(){dreminex_offer_redirect('login');});
add_action('admin_post_dreminex_offer_claim',function(){
    if(!Dreminex_Suite_Features::enabled('newsletter_offers','offers'))dreminex_offer_redirect('unavailable');
    if(!is_user_logged_in())dreminex_offer_redirect('login');
    $id=isset($_POST['offer_id'])?absint($_POST['offer_id']):0;
    check_admin_referer('dreminex_offer_claim_'.$id);
    global $wpdb;$table=dreminex_offers_table();$claims=dreminex_offer_claims_table();
    $offer=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d",$id));
    $latest=dreminex_latest_active_offer();
    if(!dreminex_offer_active($offer) || !$latest || (int)$latest->id!==$id)dreminex_offer_redirect('unavailable');
    $user=wp_get_current_user();$uid=(int)$user->ID;
    $subscriber=$wpdb->get_row($wpdb->prepare('SELECT id,email FROM '.dreminex_news_table()." WHERE user_id=%d AND status='confirmed' LIMIT 1",$uid));
    if(!dreminex_offer_eligible($user))dreminex_offer_redirect('login');
    $existing=$wpdb->get_row($wpdb->prepare("SELECT id FROM {$claims} WHERE offer_id=%d AND user_id=%d",$id,$uid));
    if($existing)dreminex_offer_redirect('existing');
    $ok=$wpdb->insert($claims,['offer_id'=>$id,'user_id'=>$uid,'email'=>$user->user_email,'created_at'=>current_time('mysql',true),'status'=>'issuing'],['%d','%d','%s','%s','%s']);
    if(!$ok)dreminex_offer_redirect('existing');
    $claim_id=(int)$wpdb->insert_id;
    $code='DREMO'.$id.'-'.strtoupper(bin2hex(random_bytes(5)));
    $coupon=new WC_Coupon();
    $coupon->set_code($code);$coupon->set_discount_type('fixed_cart');$coupon->set_amount($offer->amount);
    $coupon->set_minimum_amount($offer->minimum);$coupon->set_individual_use(true);
    $coupon->set_usage_limit(1);$coupon->set_usage_limit_per_user(1);
    $coupon->set_email_restrictions([$user->user_email]);
    // Offer claim window and coupon redemption window are separate.
    $limit=time()+(int)$offer->validity_days*DAY_IN_SECONDS;
    $coupon->set_date_expires($limit);
    $products=array_values(array_filter(array_map('absint',explode(',',$offer->product_ids))));
    if($products)$coupon->set_product_ids($products);
    $coupon->update_meta_data('_dreminex_owner_user_id',$uid);
    $coupon->update_meta_data('_dreminex_offer_id',$id);
    try{$coupon_id=$coupon->save();}catch(Throwable $e){$coupon_id=0;}
    if(!$coupon_id){$wpdb->delete($claims,['id'=>$claim_id],['%d']);dreminex_offer_redirect('error');}
    $updated=$wpdb->update($claims,['status'=>'claimed','coupon_id'=>$coupon_id,'coupon_code'=>$code],['id'=>$claim_id]);
    if($updated!==1){wp_delete_post($coupon_id,true);$wpdb->delete($claims,['id'=>$claim_id]);dreminex_offer_redirect('error');}
    $body=Dreminex_Suite_Setup::text('<p>Your Dreminex Fashion offer coupon is ready:</p><h2>').esc_html($code).'</h2><p>'.esc_html($offer->title).str_replace('৳',get_woocommerce_currency_symbol(),'</p><p>৳').esc_html($offer->amount).' off'.((float)$offer->minimum>0?str_replace('৳',get_woocommerce_currency_symbol(),' orders of at least ৳').esc_html($offer->minimum):'').'. One use for your account email; cannot combine with another coupon. Expires '.esc_html(wp_date('j F Y',$limit)).'.</p>';
    if($products)$body.='<p>Valid on selected products only. See the offer on our website for details.</p>';
    $sent=dreminex_news_mail($user->user_email,Dreminex_Suite_Setup::text('Your Dreminex Fashion offer code'),'Your offer coupon',$body);
    update_post_meta($coupon_id,'_dreminex_offer_mail_status',$sent?'accepted':'failed');
    update_post_meta($coupon_id,'_dreminex_offer_mail_attempt',time());
    dreminex_offer_redirect($sent?'claimed':'mail_problem');
});
add_action('admin_post_dreminex_offer_resend',function(){
    if(!is_user_logged_in())dreminex_offer_redirect('login');
    $id=isset($_POST['offer_id'])?absint($_POST['offer_id']):0;
    check_admin_referer('dreminex_offer_resend_'.$id);
    global $wpdb;
    $user=wp_get_current_user();
    $subscriber=$wpdb->get_row($wpdb->prepare('SELECT id FROM '.dreminex_news_table()." WHERE user_id=%d AND email=%s AND status='confirmed' LIMIT 1",$user->ID,strtolower($user->user_email)));
    if(!dreminex_offer_eligible($user))dreminex_offer_redirect('login');
    $claim=$wpdb->get_row($wpdb->prepare('SELECT coupon_id,coupon_code FROM '.dreminex_offer_claims_table()." WHERE offer_id=%d AND user_id=%d AND status='claimed' LIMIT 1",$id,$user->ID));
    if(!$claim || !$claim->coupon_id || !get_post($claim->coupon_id))dreminex_offer_redirect('error');
    $coupon=new WC_Coupon($claim->coupon_id);
    if((int)$coupon->get_meta('_dreminex_owner_user_id',true)!==(int)$user->ID)dreminex_offer_redirect('error');
    $last=(int)get_post_meta($claim->coupon_id,'_dreminex_offer_mail_attempt',true);
    if($last && time()-$last<60)dreminex_offer_redirect('mail_problem');
    $offer=$wpdb->get_row($wpdb->prepare('SELECT title FROM '.dreminex_offers_table().' WHERE id=%d',$id));
    $body=Dreminex_Suite_Setup::text('<p>Your Dreminex Fashion offer coupon:</p><h2>').esc_html($claim->coupon_code).'</h2><p>'.esc_html($offer?$offer->title:'Offer').'</p><p>One use for your account email; cannot combine with another coupon.';
    $expiry=$coupon->get_date_expires();
    if($expiry)$body.=' Expires '.esc_html(wc_format_datetime($expiry,'j F Y')).'.';
    $body.='</p>';
    $sent=dreminex_news_mail($user->user_email,Dreminex_Suite_Setup::text('Your Dreminex Fashion offer code'),'Your offer coupon',$body);
    update_post_meta($claim->coupon_id,'_dreminex_offer_mail_status',$sent?'accepted':'failed');
    update_post_meta($claim->coupon_id,'_dreminex_offer_mail_attempt',time());
    dreminex_offer_redirect($sent?'claimed':'mail_problem');
});
function dreminex_offers_admin_page(){
    if(!current_user_can('manage_options'))wp_die('Access denied.',403);
    global $wpdb;$table=dreminex_offers_table();$claims=dreminex_offer_claims_table();
    $id=isset($_GET['edit'])?absint($_GET['edit']):0;
    $offer=$id?$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d",$id)):null;
    if($id&&!$offer)wp_die('Offer not found.',404);
    echo '<div class="wrap"><h1>Promotional Offers</h1><p>Welcome coupons are controlled under Newsletter Settings. These offers are separate. Publish a banner or blog link to <code>'.esc_html(home_url('/#dreminex-offers')).'</code> when an offer is active. Changes apply to future claims; existing coupons keep their original terms. The selected notification image is sent with a newly active offer when Dreminex PWA push is enabled; changing an already sent offer does not notify subscribers again. The small app icon remains your brand icon.</p>';
    if(isset($_GET['saved']))echo '<div class="notice notice-success"><p>Offer saved.</p></div>';
    if(isset($_GET['deleted']))echo '<div class="notice notice-success"><p>Selected offer(s) permanently deleted. Issued customer coupons remain valid until their existing expiry.</p></div>';
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline-block;margin:10px 0"><input type="hidden" name="action" value="dreminex_offer_quick_create">';
    wp_nonce_field('dreminex_offer_quick_create');
    echo '<button class="button button-primary" name="publish" value="0">Create default draft</button> <button class="button" name="publish" value="1" onclick="return confirm(\'Publish the default offer now?\')">Create &amp; publish</button></form>';
    $items=$wpdb->get_results("SELECT * FROM {$table} ORDER BY id DESC LIMIT 100");
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" onsubmit="return confirm(\'Permanently delete selected offers? Existing issued coupons will remain valid.\')"><input type="hidden" name="action" value="dreminex_offer_delete">';
    wp_nonce_field('dreminex_offer_delete');
    echo '<table class="widefat striped"><thead><tr><th><input type="checkbox" aria-label="Select all offers" onclick="this.closest(\'table\').querySelectorAll(\'tbody input[type=checkbox]\').forEach(e=>e.checked=this.checked)"></th><th>Offer</th><th>Discount</th><th>Dates</th><th>Status</th><th>Claims</th></tr></thead><tbody>';
    foreach($items as $o){
        $count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$claims} WHERE offer_id=%d AND status='claimed'",$o->id));
        $url=admin_url('admin.php?page=dreminex-offers&edit='.$o->id);
        echo '<tr><td><input type="checkbox" name="offer_ids[]" value="'.esc_attr($o->id).'" aria-label="Select '.esc_attr($o->title).'"></td><td><a href="'.esc_url($url).'">'.esc_html($o->title).str_replace('৳',get_woocommerce_currency_symbol(),'</a></td><td>৳').esc_html($o->amount).str_replace('৳',get_woocommerce_currency_symbol(),' / min ৳').esc_html($o->minimum).'</td><td>'.esc_html($o->start_date.' — '.$o->end_date).'</td><td>'.esc_html($o->status).'</td><td>'.esc_html($count).'</td></tr>';
    }
    if(!$items)echo '<tr><td colspan="6">No offers. Create one below when you are ready.</td></tr>';
    echo '</tbody></table><p><button class="button" type="submit">Permanently delete selected</button></p></form><h2>'.($offer?'Edit offer':'Create a future offer').'</h2>';
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_offer_save"><input type="hidden" name="offer_id" value="'.esc_attr($id).'">';
    wp_nonce_field('dreminex_offer_save_'.$id);
    echo '<table class="form-table"><tbody>';
    $fields=['title'=>['Title','text'],'description'=>['Description','textarea'],'amount'=>['Discount (store currency)','number'],'minimum'=>['Minimum product total (store currency)','number'],'validity_days'=>['Coupon validity (days)','number'],'start_date'=>['Start date','date'],'end_date'=>['End date','date'],'product_ids'=>['Product IDs, comma separated (optional)','text']];
    foreach($fields as $key=>$f){
        $value=$offer?$offer->$key:($key==='validity_days'?30:($key==='start_date'?current_time('Y-m-d'):($key==='end_date'?date('Y-m-d',strtotime('+30 days')):'')));
        echo '<tr><th><label for="offer-'.esc_attr($key).'">'.esc_html($f[0]).'</label></th><td>';
        if($f[1]==='textarea')echo '<textarea id="offer-'.esc_attr($key).'" name="'.esc_attr($key).'" rows="3" style="width:100%;max-width:650px">'.esc_textarea($value).'</textarea>';
        else echo '<input id="offer-'.esc_attr($key).'" name="'.esc_attr($key).'" type="'.esc_attr($f[1]).'" value="'.esc_attr($value).'" '.($key==='amount'?'min="1" max="5000" step="1"':($key==='minimum'?'min="0" max="100000" step="1"':($key==='validity_days'?'min="1" max="365"':''))).' style="width:100%;max-width:450px"'.($key==='product_ids'?'':' required').'>';
        echo '</td></tr>';
    }
    $image_id=(int)($offer->notification_image_id??0);
    $image=$offer?dreminex_offer_notification_image($offer):'';
    echo '<tr><th scope="row"><label for="dreminex-offer-image-id">Notification thumbnail</label></th><td><div class="dreminex-offer-media" style="max-width:360px;padding:16px;border:1px solid #cbd5e1;border-radius:10px;background:#fff"><img class="dreminex-offer-media-preview" src="'.esc_url($image).'" alt="Selected offer notification image" style="display:'.($image?'block':'none').';width:100%;max-height:190px;object-fit:contain;border-radius:6px;margin-bottom:12px"><input id="dreminex-offer-image-id" type="hidden" name="notification_image_id" value="'.esc_attr($image_id).'"><button type="button" class="button dreminex-offer-media-choose">Choose image</button> <button type="button" class="button dreminex-offer-media-remove" '.($image_id?'':'disabled').'>Remove</button><p class="description">Choose a landscape image from this site’s Media Library. Used as the large notification picture for future sends. If empty, the selected product image or site icon is used.</p></div></td></tr>';
    echo '<tr><th>Status</th><td><select name="status"><option value="draft" '.selected($offer?$offer->status:'draft','draft',false).'>Draft / disabled</option><option value="active" '.selected($offer?$offer->status:'draft','active',false).'>Active</option></select></td></tr></tbody></table>';
    submit_button('Save offer');echo '</form></div>';
}
add_action('admin_post_dreminex_offer_save',function(){
    if(!current_user_can('manage_options'))wp_die('Access denied.',403);
    $id=isset($_POST['offer_id'])?absint($_POST['offer_id']):0;check_admin_referer('dreminex_offer_save_'.$id);
    $title=isset($_POST['title'])?sanitize_text_field(wp_unslash($_POST['title'])):'';
    $description=isset($_POST['description'])?sanitize_textarea_field(wp_unslash($_POST['description'])):'';
    $amount=isset($_POST['amount'])?absint($_POST['amount']):0;
    $minimum=isset($_POST['minimum'])?absint($_POST['minimum']):0;
    $days=isset($_POST['validity_days'])?absint($_POST['validity_days']):0;
    $start=isset($_POST['start_date'])?sanitize_text_field(wp_unslash($_POST['start_date'])):'';
    $end=isset($_POST['end_date'])?sanitize_text_field(wp_unslash($_POST['end_date'])):'';
    $status=isset($_POST['status'])?sanitize_key(wp_unslash($_POST['status'])):'draft';
    $image_id=isset($_POST['notification_image_id'])?absint($_POST['notification_image_id']):0;
    $products=isset($_POST['product_ids'])?sanitize_text_field(wp_unslash($_POST['product_ids'])):'';
    $ids=array_values(array_unique(array_filter(array_map('absint',explode(',',$products)))));
    if(!$title || strlen($title)>200 || strlen($description)>5000 || $amount<1 || $amount>5000 || $minimum>100000 || $days<1 || $days>365 || !in_array($status,['draft','active'],true) || !preg_match('/^\d{4}-\d{2}-\d{2}$/',$start) || !preg_match('/^\d{4}-\d{2}-\d{2}$/',$end) || $end<$start || count($ids)>30)wp_die('Invalid offer details.',400);
    foreach($ids as $pid){if(get_post_type($pid)!=='product')wp_die('One of the product IDs is invalid.',400);}
    if($image_id && !wp_attachment_is_image($image_id))wp_die('Select a valid image from this site’s Media Library.',400);
    global $wpdb;$table=dreminex_offers_table();
    $data=['title'=>$title,'description'=>$description,'amount'=>$amount,'minimum'=>$minimum,'validity_days'=>$days,'start_date'=>$start,'end_date'=>$end,'product_ids'=>implode(',',$ids),'notification_image_id'=>$image_id,'status'=>$status];
    if($id){if(!$wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE id=%d",$id)))wp_die('Offer not found.',404);$ok=$wpdb->update($table,$data,['id'=>$id]);}
    else{$data['created_at']=current_time('mysql',true);$ok=$wpdb->insert($table,$data);}
    if($ok===false)wp_die('Could not save offer.',500);
    wp_safe_redirect(admin_url('admin.php?page=dreminex-offers&saved=1'),303);exit;
});
add_action('admin_post_dreminex_offer_quick_create',function(){
    if(!current_user_can('manage_options'))wp_die('Access denied.',403);
    check_admin_referer('dreminex_offer_quick_create');
    global $wpdb;
    $today=current_time('Y-m-d');$end=wp_date('Y-m-d',strtotime($today.' +30 days'));
    $published=isset($_POST['publish']) && '1'===sanitize_text_field(wp_unslash($_POST['publish']));
    $data=['title'=>Dreminex_Suite_Setup::text(str_replace('৳',get_woocommerce_currency_symbol(),'Dreminex Fashion · ৳50 off ৳399+ · ')).wp_date('d M Y H:i:s'),'description'=>str_replace('৳',get_woocommerce_currency_symbol(),'Get ৳50 off when your eligible product total is at least ৳399. Claim one personal coupon per account and use it once. Claim by ').$end.'; your coupon remains valid for 30 days from the day you claim it. Cannot combine with another coupon.','amount'=>50,'minimum'=>399,'validity_days'=>30,'start_date'=>$today,'end_date'=>$end,'product_ids'=>'','status'=>$published?'active':'draft','created_at'=>current_time('mysql',true)];
    if(false===$wpdb->insert(dreminex_offers_table(),$data))wp_die('Could not create offer.',500);
    wp_safe_redirect(admin_url('admin.php?page=dreminex-offers&edit='.$wpdb->insert_id.'&saved=1'),303);exit;
});
add_action('admin_post_dreminex_offer_delete',function(){
    if(!current_user_can('manage_options'))wp_die('Access denied.',403);
    check_admin_referer('dreminex_offer_delete');
    $ids=isset($_POST['offer_ids'])&&is_array($_POST['offer_ids'])?array_values(array_unique(array_filter(array_map('absint',wp_unslash($_POST['offer_ids']))))):[];
    if(!$ids||count($ids)>100)wp_die('Select up to 100 offers.',400);
    global $wpdb;$table=dreminex_offers_table();
    foreach($ids as $id){if(false===$wpdb->delete($table,['id'=>$id],['%d']))wp_die('Could not delete every selected offer.',500);}
    wp_safe_redirect(admin_url('admin.php?page=dreminex-offers&deleted=1'),303);exit;
});
