<?php
if (!defined('ABSPATH')) { exit; }
/* Dreminex: consent-based unfinished checkout record with configurable retention.
 * It never creates a WooCommerce order and never prints personal data on a receipt.
 */
if(!function_exists('dreminex_partial_retention_hours')){function dreminex_partial_retention_hours(){return max(24,min(168,(int)Dreminex_Suite_Control::setting('checkout_protection','retention_hours',48)));}}
add_action( 'init', function () {
	register_post_type( 'dreminex_partial', array(
		'labels' => array( 'name' => 'Partial Checkouts', 'singular_name' => 'Partial Checkout' ),
		'public' => false, 'show_ui' => true, 'show_in_menu' => 'dreminex-suite',
		'menu_icon' => 'dashicons-clipboard', 'menu_position' => 27,
		'show_in_rest' => false, 'exclude_from_search' => true,
		'supports' => array( 'title' ),
		'capabilities' => array( 'create_posts' => 'do_not_allow' ),
		'map_meta_cap' => true,
	) );
	if ( ! wp_next_scheduled( 'dreminex_purge_partial_checkouts' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'dreminex_purge_partial_checkouts' );
	}
} );
add_action( 'dreminex_purge_partial_checkouts', function () {
	$ids = get_posts( array(
		'post_type' => 'dreminex_partial', 'post_status' => 'private',
		'fields' => 'ids', 'posts_per_page' => 100,
		'meta_query' => array( array( 'key' => '_dreminex_expires', 'value' => time(), 'compare' => '<=', 'type' => 'NUMERIC' ) ),
	) );
	foreach ( $ids as $id ) wp_delete_post( $id, true );
} );

// The customer must actively opt in. The box is unchecked by default.
add_action( 'woocommerce_after_checkout_billing_form', function () {
	if ( ! is_checkout() || is_order_received_page() ) return;
	$policy = get_privacy_policy_url();
	echo Dreminex_Suite_Setup::text('<p class="form-row form-row-wide" style="background:#F8F9FA;color:#212529;border-left:4px solid #00B4D7;padding:12px">');
	echo '<label><input id="dreminex_partial_consent" type="checkbox" autocomplete="off"> '; 
		$hours=dreminex_partial_retention_hours();echo esc_html(sprintf(Dreminex_Suite_Control::tr('I agree to store my name, phone, address, cart items and IP address for one follow-up about an unfinished order. Information is kept for up to %d hours and removed sooner when the order is placed.','অসম্পূর্ণ order বিষয়ে একবার follow-up করার জন্য আমার নাম, ফোন, ঠিকানা, cart items ও IP সংরক্ষণে সম্মতি দিচ্ছি। তথ্য সর্বোচ্চ %d ঘণ্টা রাখা হবে এবং order হলে আগেই মুছে যাবে।'),$hours));
	echo '</label>';
	if ( $policy ) echo ' <a href="' . esc_url( $policy ) . '" target="_blank" rel="noopener">Privacy policy</a>';
	echo '</p>';
} );

if ( ! function_exists( 'dreminex_partial_session_key' ) ) {
	function dreminex_partial_session_key() {
		if ( ! function_exists( 'WC' ) || ! WC()->session ) return '';
		$id = WC()->session->get_customer_id();
		return $id ? hash_hmac( 'sha256', (string) $id, wp_salt( 'auth' ) ) : '';
	}
}
if ( ! function_exists( 'dreminex_partial_find' ) ) {
	function dreminex_partial_find( $key ) {
		$ids = get_posts( array(
			'post_type' => 'dreminex_partial', 'post_status' => 'private', 'fields' => 'ids', 'posts_per_page' => 1,
			'meta_query' => array( array( 'key' => '_dreminex_session', 'value' => $key ) ),
		) );
		return $ids ? (int) $ids[0] : 0;
	}
}
add_action( 'wp_ajax_dreminex_partial_checkout', 'dreminex_partial_ajax' );
add_action( 'wp_ajax_nopriv_dreminex_partial_checkout', 'dreminex_partial_ajax' );
if ( ! function_exists( 'dreminex_partial_ajax' ) ) {
	function dreminex_partial_ajax() {
		if ( ! check_ajax_referer( 'dreminex_partial_checkout', 'nonce', false ) ) wp_send_json_error( 'Invalid request', 403 );
		$key = dreminex_partial_session_key();
		if ( ! $key ) wp_send_json_error( 'Checkout session unavailable', 400 );
		$id = dreminex_partial_find( $key );
		if ( 'delete' === sanitize_key( wp_unslash( $_POST['mode'] ?? '' ) ) ) {
			if ( $id ) wp_delete_post( $id, true );
			wp_send_json_success();
		}
		if ( 'yes' !== ( $_POST['consent'] ?? '' ) ) wp_send_json_error( 'Consent required', 400 );
		$name = mb_substr( sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ), 0, 100 );
		$phone = preg_replace( '/\D+/', '', (string) wp_unslash( $_POST['phone'] ?? '' ) );
		$address = mb_substr( sanitize_text_field( wp_unslash( $_POST['address'] ?? '' ) ), 0, 220 );
		if ( ! $name || ! preg_match( '/^01[3-9][0-9]{8}$/D', $phone ) || ! $address ) wp_send_json_error( 'Incomplete details', 400 );
		$throttle = 'dreminex_partial_rate_' . substr( $key, 0, 32 );
		if ( get_transient( $throttle ) ) wp_send_json_success();
		set_transient( $throttle, 1, 3 );
		$products = array();
		if ( WC()->cart ) {
			foreach ( WC()->cart->get_cart() as $line ) {
				$products[] = array( 'product_id' => (int) $line['product_id'], 'variation_id' => (int) ( $line['variation_id'] ?? 0 ), 'quantity' => (int) $line['quantity'] );
			}
		}
		if ( ! $products ) wp_send_json_error( 'Cart unavailable', 400 );
		if ( ! $id ) {
			$id = wp_insert_post( array( 'post_type' => 'dreminex_partial', 'post_status' => 'private', 'post_title' => 'Unfinished checkout ' . wp_date( 'Y-m-d H:i' ) ), true );
			if ( is_wp_error( $id ) ) wp_send_json_error( 'Could not save', 500 );
			update_post_meta( $id, '_dreminex_session', $key );
		}
		update_post_meta( $id, '_dreminex_name', $name );
		update_post_meta( $id, '_dreminex_phone', $phone );
		update_post_meta( $id, '_dreminex_address', $address );
		$ip = class_exists( 'WC_Geolocation' ) ? WC_Geolocation::get_ip_address() : '';
		update_post_meta( $id, '_dreminex_ip', filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '' );
		update_post_meta( $id, '_dreminex_products', $products );
		if ( ! get_post_meta( $id, '_dreminex_followup', true ) ) update_post_meta( $id, '_dreminex_followup', 'new' );
			if ( ! get_post_meta( $id, '_dreminex_expires', true ) ) update_post_meta( $id, '_dreminex_expires', time() + dreminex_partial_retention_hours() * HOUR_IN_SECONDS );
		wp_send_json_success();
	}
}
add_action( 'woocommerce_checkout_order_created', function () {
	$key = dreminex_partial_session_key();
	if ( $key && ( $id = dreminex_partial_find( $key ) ) ) wp_delete_post( $id, true );
} );
add_action( 'add_meta_boxes_dreminex_partial', function () {
	add_meta_box( 'dreminex_partial_details', 'Checkout details', function ( $post ) {
		foreach ( array( 'Name' => '_dreminex_name', 'Phone' => '_dreminex_phone', 'Address' => '_dreminex_address', 'IP address' => '_dreminex_ip' ) as $label => $key ) {
			echo '<p><strong>' . esc_html( $label ) . ':</strong> ' . esc_html( get_post_meta( $post->ID, $key, true ) ) . '</p>';
		}
		$products = get_post_meta( $post->ID, '_dreminex_products', true );
		if ( is_array( $products ) ) foreach ( $products as $line ) {
			$product = wc_get_product( $line['variation_id'] ?: $line['product_id'] );
			if ( $product ) echo '<p><a href="' . esc_url( get_edit_post_link( $product->get_parent_id() ?: $product->get_id() ) ) . '" target="_blank" rel="noopener">' . esc_html( $product->get_name() ) . '</a> × ' . esc_html( (int) $line['quantity'] ) . ' · ' . wp_kses_post( wc_price( (float) $product->get_price() * (int) $line['quantity'] ) ) . '</p>';
		}
			echo '<p><small>'.esc_html(sprintf(Dreminex_Suite_Control::tr('Current product prices are shown. Consented information is kept for up to %d hours from first capture and deleted by the next WP-Cron purge.','বর্তমান product price দেখানো হয়। সম্মত তথ্য প্রথম capture থেকে সর্বোচ্চ %d ঘণ্টা রাখা হয় এবং পরবর্তী WP-Cron purge-এ মুছে যায়।'),dreminex_partial_retention_hours())).'</small></p>';
	}, 'dreminex_partial' );
} );

add_filter( 'manage_dreminex_partial_posts_columns', function ( $columns ) {
	return array( 'cb' => $columns['cb'] ?? '', 'title' => 'Checkout', 'dreminex_phone' => 'Phone', 'dreminex_ip' => 'IP', 'dreminex_address' => 'Address', 'dreminex_products' => 'Products', 'dreminex_followup' => 'Follow-up', 'date' => 'Date' );
} );
add_action( 'manage_dreminex_partial_posts_custom_column', function ( $column, $post_id ) {
	if ( in_array( $column, array( 'dreminex_phone', 'dreminex_address', 'dreminex_ip' ), true ) ) {
		echo esc_html( get_post_meta( $post_id, '_'.$column, true ) );
	} elseif ( 'dreminex_products' === $column ) {
		$lines = get_post_meta( $post_id, '_dreminex_products', true );
		if ( is_array( $lines ) ) foreach ( $lines as $line ) {
			$product = wc_get_product( (int) ( $line['variation_id'] ?: $line['product_id'] ) );
			if ( $product ) echo '<div>' . esc_html( $product->get_name() . ' × ' . (int) $line['quantity'] ) . '</div>';
		}
	} elseif ( 'dreminex_followup' === $column ) {
		$status = get_post_meta( $post_id, '_dreminex_followup', true ) ?: 'new';
		echo esc_html( ucfirst( $status ) );
	}
}, 10, 2 );
add_action( 'add_meta_boxes_dreminex_partial', function () {
	add_meta_box( 'dreminex_partial_followup', 'Follow-up', function ( $post ) {
		$status = get_post_meta( $post->ID, '_dreminex_followup', true ) ?: 'new';
		wp_nonce_field( 'dreminex_partial_followup_' . $post->ID, 'dreminex_partial_followup_nonce' );
		echo '<label for="dreminex_partial_followup_status">Status</label> <select id="dreminex_partial_followup_status" name="dreminex_partial_followup_status">';
		foreach ( array( 'new' => 'New', 'contacted' => 'Contacted', 'declined' => 'Declined' ) as $value => $label ) {
			echo '<option value="' . esc_attr( $value ) . '" ' . selected( $status, $value, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select><p><small>Save via Update. An order placed in this session removes this partial record automatically.</small></p>';
	}, 'dreminex_partial', 'side' );
} );
add_action( 'save_post_dreminex_partial', function ( $post_id ) {
	if ( ! current_user_can( 'edit_post', $post_id ) || ! isset( $_POST['dreminex_partial_followup_nonce'] ) ||
		! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['dreminex_partial_followup_nonce'] ) ), 'dreminex_partial_followup_' . $post_id ) ) return;
	$status = sanitize_key( wp_unslash( $_POST['dreminex_partial_followup_status'] ?? '' ) );
	if ( in_array( $status, array( 'new', 'contacted', 'declined' ), true ) ) update_post_meta( $post_id, '_dreminex_followup', $status );
} );

add_action( 'wp_footer', function () {
	if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page() ) return;
	?>
	<script>
	(function () {
		const form = document.querySelector('form.checkout');
		const box = document.getElementById('dreminex_partial_consent');
		if (!form || !box) return;
		let timer, last = '';
		const url = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
		const nonce = <?php echo wp_json_encode( wp_create_nonce( 'dreminex_partial_checkout' ) ); ?>;
		function send(mode) {
			const data = new URLSearchParams({action:'dreminex_partial_checkout', nonce, mode, consent:box.checked?'yes':'no',
				name:form.querySelector('[name="billing_first_name"]')?.value || '',
				phone:form.querySelector('[name="billing_phone"]')?.value || '',
				address:form.querySelector('[name="billing_address_1"]')?.value || ''});
			fetch(url, {method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:data.toString()}).catch(() => {});
		}
		form.addEventListener('input', function () {
			if (!box.checked) return;
			clearTimeout(timer);
			timer = setTimeout(function () {
				const current = ['billing_first_name','billing_phone','billing_address_1'].map(n => form.querySelector('[name="'+n+'"]')?.value || '').join('|');
				if (current !== last) { last = current; send('save'); }
			}, 2000);
		});
		box.addEventListener('change', function () { clearTimeout(timer); last = ''; send(box.checked ? 'save' : 'delete'); });
	})();
	</script>
	<?php
}, 30 );
