<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Customer wallet ledger used by Delivery Advance & Wallet.
 *
 * Cash and promotional credits are separate lots. Promotional lots expire and
 * can never be withdrawn. Reservations keep checkout and withdrawal requests
 * idempotent without changing the WooCommerce order total.
 */
final class Dreminex_Customer_Wallet {
	const DB_VERSION = 1;
	const DB_OPTION  = 'dreminex_wallet_db_version';
	const ENDPOINT   = 'wallet';

	public static function boot() {
		self::install();
		if (!self::enabled()) { return; }
		add_action('init', [__CLASS__, 'endpoint']);
		add_action('init', [__CLASS__, 'maybe_flush'], 30);
		add_filter('woocommerce_account_menu_items', [__CLASS__, 'menu'], 35);
		add_action('woocommerce_account_' . self::ENDPOINT . '_endpoint', [__CLASS__, 'render']);
		add_action('template_redirect', [__CLASS__, 'handle_customer_actions']);
		add_action('wp_enqueue_scripts', [__CLASS__, 'assets']);
		add_action('woocommerce_coupon_options_usage_restriction', [__CLASS__, 'coupon_fields']);
		add_action('woocommerce_coupon_options_save', [__CLASS__, 'save_coupon_fields'],10,2);
		add_action('dreminex_wallet_expire', [__CLASS__, 'expire_credits']);
		add_action('woocommerce_order_status_cancelled', [__CLASS__, 'release_order']);
		add_action('woocommerce_order_status_failed', [__CLASS__, 'release_order']);
		add_action('woocommerce_order_status_refunded', [__CLASS__, 'release_order']);
		if (!wp_next_scheduled('dreminex_wallet_expire')) {
			wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', 'dreminex_wallet_expire');
		}
	}
	public static function enabled() { return (int) Dreminex_Suite_Control::setting('delivery_advance','wallet_enabled',1) === 1; }

	private static function tables() {
		global $wpdb;
		return [
			'lots' => $wpdb->prefix . 'dreminex_wallet_lots',
			'entries' => $wpdb->prefix . 'dreminex_wallet_entries',
			'withdrawals' => $wpdb->prefix . 'dreminex_wallet_withdrawals',
			'topups' => $wpdb->prefix . 'dreminex_wallet_topups',
		];
	}

	public static function install() {
		if ((int) get_option(self::DB_OPTION, 0) >= self::DB_VERSION) { return; }
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t = self::tables();
		$c = $wpdb->get_charset_collate();
		dbDelta("CREATE TABLE {$t['lots']} (
			id bigint unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint unsigned NOT NULL,
			source varchar(20) NOT NULL,
			amount decimal(18,2) NOT NULL DEFAULT 0,
			remaining decimal(18,2) NOT NULL DEFAULT 0,
			reserved decimal(18,2) NOT NULL DEFAULT 0,
			withdrawable tinyint(1) NOT NULL DEFAULT 0,
			expires_at datetime NULL,
			reference_type varchar(40) NOT NULL DEFAULT '',
			reference_id varchar(191) NOT NULL DEFAULT '',
			idempotency_key varchar(191) NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY (id), UNIQUE KEY idempotency_key (idempotency_key),
			KEY user_available (user_id,expires_at), KEY source (source)
		) $c;");
		dbDelta("CREATE TABLE {$t['entries']} (
			id bigint unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint unsigned NOT NULL,
			lot_id bigint unsigned NOT NULL DEFAULT 0,
			kind varchar(32) NOT NULL,
			amount decimal(18,2) NOT NULL DEFAULT 0,
			order_id bigint unsigned NOT NULL DEFAULT 0,
			reference varchar(191) NOT NULL DEFAULT '',
			idempotency_key varchar(191) NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY (id), UNIQUE KEY idempotency_key (idempotency_key),
			KEY user_created (user_id,created_at), KEY order_id (order_id)
		) $c;");
		dbDelta("CREATE TABLE {$t['withdrawals']} (
			id bigint unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint unsigned NOT NULL,
			amount decimal(18,2) NOT NULL DEFAULT 0,
			provider varchar(30) NOT NULL,
			account_ref varchar(80) NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'requested',
			allocations longtext NOT NULL,
			admin_note text NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY (id), KEY user_status (user_id,status), KEY status_created (status,created_at)
		) $c;");
		dbDelta("CREATE TABLE {$t['topups']} (
			id bigint unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint unsigned NOT NULL,
			amount decimal(18,2) NOT NULL DEFAULT 0,
			provider varchar(30) NOT NULL,
			transaction_id varchar(80) NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'requested',
			admin_note text NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY (id), UNIQUE KEY provider_txid (provider,transaction_id),
			KEY user_status (user_id,status), KEY status_created (status,created_at)
		) $c;");
		update_option(self::DB_OPTION, self::DB_VERSION, false);update_option('dreminex_wallet_flush_rewrite',1,false);
	}

	public static function endpoint() { add_rewrite_endpoint(self::ENDPOINT, EP_ROOT | EP_PAGES); }
	public static function maybe_flush(){if((int)get_option('dreminex_wallet_flush_rewrite',0)!==1)return;flush_rewrite_rules(false);delete_option('dreminex_wallet_flush_rewrite');}
	public static function assets(){if(!function_exists('is_account_page')||!is_account_page())return;wp_enqueue_style('dreminex-wallet',plugins_url('../assets/wallet.css',__FILE__),[],DREMINEX_SUITE_VERSION);}
	public static function coupon_fields(){
		woocommerce_wp_checkbox(['id'=>'_dreminex_wallet_credit_enabled','label'=>'Wallet promotional credit','description'=>'Customer claims this coupon into the Wallet as purchase-only, nonwithdrawable credit.']);
		woocommerce_wp_text_input(['id'=>'_dreminex_wallet_credit_amount','label'=>'Wallet credit amount','type'=>'number','custom_attributes'=>['min'=>'0','step'=>'0.01'],'description'=>'Leave blank to use the coupon amount.']);
		woocommerce_wp_text_input(['id'=>'_dreminex_wallet_credit_days','label'=>'Wallet credit validity (days)','type'=>'number','custom_attributes'=>['min'=>'1','max'=>'3650','step'=>'1'],'description'=>'Used only when the coupon has no expiry date.']);
	}
	public static function save_coupon_fields($post_id,$coupon){if(!$coupon instanceof WC_Coupon)$coupon=new WC_Coupon($post_id);if(!$coupon->get_id())return;$coupon->update_meta_data('_dreminex_wallet_credit_enabled',isset($_POST['_dreminex_wallet_credit_enabled'])?'yes':'no');$amount=wc_format_decimal(wp_unslash($_POST['_dreminex_wallet_credit_amount']??''));$days=max(1,min(3650,absint($_POST['_dreminex_wallet_credit_days']??30)));$coupon->update_meta_data('_dreminex_wallet_credit_amount',$amount);$coupon->update_meta_data('_dreminex_wallet_credit_days',$days);$coupon->save();}
	public static function menu($items) {
		$logout = $items['customer-logout'] ?? null;
		unset($items['customer-logout']);
		$items[self::ENDPOINT] = __('Wallet', 'dreminex-suite');
		if ($logout !== null) { $items['customer-logout'] = $logout; }
		return $items;
	}

	private static function lock($user_id) {
		$key = 'dreminex_wallet_user_' . absint($user_id);
		return class_exists('Dreminex_Payments_Security') ? Dreminex_Payments_Security::lock_named($key, 60) : add_option($key, (string) time(), '', false);
	}
	private static function unlock($user_id) {
		$key = 'dreminex_wallet_user_' . absint($user_id);
		if (class_exists('Dreminex_Payments_Security')) { Dreminex_Payments_Security::release_named_lock($key); }
		else { delete_option($key); }
	}
	private static function money($value) { return round(max(0, (float) $value), wc_get_price_decimals()); }

	public static function expire_credits($user_id = 0) {
		global $wpdb;
		$t = self::tables();
		$where = "source='promo' AND expires_at IS NOT NULL AND expires_at<=UTC_TIMESTAMP() AND remaining>0";
		if ($user_id) { $where .= $wpdb->prepare(' AND user_id=%d', absint($user_id)); }
		$rows = $wpdb->get_results("SELECT id,user_id,remaining,reserved FROM {$t['lots']} WHERE $where", ARRAY_A); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		foreach ((array) $rows as $row) {
			if ((float) $row['reserved'] > 0) { continue; }
			$key = 'expire-lot-' . absint($row['id']);
			$wpdb->query('START TRANSACTION');
			$changed = $wpdb->query($wpdb->prepare("UPDATE {$t['lots']} SET remaining=0 WHERE id=%d AND remaining>0 AND reserved=0", $row['id']));
			if ($changed) { self::entry($row['user_id'], $row['id'], 'expire', $row['remaining'], 0, 'Promotional credit expired', $key); }
			$wpdb->query('COMMIT');
		}
	}

	public static function balances($user_id) {
		if (!self::enabled()) { return ['total'=>'0.00','cash'=>'0.00','promo'=>'0.00','withdrawable'=>'0.00','reserved'=>'0.00']; }
		global $wpdb;
		$user_id = absint($user_id);
		self::expire_credits($user_id);
		$t = self::tables();
		$rows = $wpdb->get_results($wpdb->prepare("SELECT source,withdrawable,SUM(GREATEST(remaining-reserved,0)) available,SUM(reserved) reserved FROM {$t['lots']} WHERE user_id=%d AND remaining>0 AND (expires_at IS NULL OR expires_at>UTC_TIMESTAMP()) GROUP BY source,withdrawable", $user_id), ARRAY_A);
		$out = ['total' => 0.0, 'cash' => 0.0, 'promo' => 0.0, 'withdrawable' => 0.0, 'reserved' => 0.0];
		foreach ((array) $rows as $row) {
			$available = (float) $row['available'];
			$out['total'] += $available;
			$out[$row['source'] === 'promo' ? 'promo' : 'cash'] += $available;
			if ((int) $row['withdrawable'] === 1) { $out['withdrawable'] += $available; }
			$out['reserved'] += (float) $row['reserved'];
		}
		return array_map([__CLASS__, 'format'], $out);
	}
	public static function format($amount) { return wc_format_decimal($amount, wc_get_price_decimals()); }

	private static function entry($user_id, $lot_id, $kind, $amount, $order_id, $reference, $key) {
		global $wpdb;
		$t = self::tables();
		return $wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$t['entries']} (user_id,lot_id,kind,amount,order_id,reference,idempotency_key,created_at) VALUES (%d,%d,%s,%s,%d,%s,%s,UTC_TIMESTAMP())", absint($user_id), absint($lot_id), sanitize_key($kind), self::format($amount), absint($order_id), sanitize_text_field($reference), sanitize_text_field($key)));
	}

	public static function credit($user_id, $amount, $source, $reference_type, $reference_id, $idempotency_key, $expires_at = null) {
		global $wpdb;
		if (!self::enabled()) { return new WP_Error('wallet_disabled', 'Wallet is disabled for this store.'); }
		$user_id = absint($user_id); $amount = self::money($amount); $source = $source === 'promo' ? 'promo' : 'cash';
		if (!$user_id || $amount <= 0 || !$idempotency_key) { return new WP_Error('wallet_credit_invalid', 'Wallet credit data is invalid.'); }
		$t = self::tables();
		$expires = $source === 'promo' && $expires_at ? gmdate('Y-m-d H:i:s', strtotime($expires_at)) : null;
		$inserted = $wpdb->insert($t['lots'],[
			'user_id'=>$user_id,'source'=>$source,'amount'=>self::format($amount),'remaining'=>self::format($amount),'reserved'=>'0',
			'withdrawable'=>$source === 'cash' ? 1 : 0,'expires_at'=>$expires,'reference_type'=>sanitize_key($reference_type),
			'reference_id'=>sanitize_text_field($reference_id),'idempotency_key'=>sanitize_text_field($idempotency_key),'created_at'=>current_time('mysql',true),
		],['%d','%s','%s','%s','%s','%d','%s','%s','%s','%s','%s']);
		if (!$inserted) {
			$existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['lots']} WHERE idempotency_key=%s", $idempotency_key));
			return $existing ? absint($existing) : new WP_Error('wallet_credit_failed', 'Wallet credit could not be recorded.');
		}
		$lot = (int) $wpdb->insert_id;
		self::entry($user_id, $lot, 'credit', $amount, 0, $reference_type . ':' . $reference_id, 'credit-' . $idempotency_key);
		return $lot;
	}

	private static function reserve_from_lots($user_id, $amount, $kind, $reference_id, $withdrawable_only = false) {
		global $wpdb;
		$t = self::tables(); $amount = self::money($amount); $left = $amount; $allocations = [];
		$where = $withdrawable_only ? ' AND withdrawable=1' : '';
		$order = $withdrawable_only ? 'created_at ASC,id ASC' : "CASE WHEN source='promo' THEN 0 ELSE 1 END ASC, CASE WHEN expires_at IS NULL THEN 1 ELSE 0 END ASC, expires_at ASC, created_at ASC, id ASC";
		$wpdb->query('START TRANSACTION');
		$rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['lots']} WHERE user_id=%d AND remaining>reserved AND (expires_at IS NULL OR expires_at>UTC_TIMESTAMP()) $where ORDER BY $order FOR UPDATE", absint($user_id)), ARRAY_A); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		foreach ((array) $rows as $row) {
			if ($left <= 0) { break; }
			$use = min($left, max(0, (float) $row['remaining'] - (float) $row['reserved']));
			if ($use <= 0) { continue; }
			$wpdb->query($wpdb->prepare("UPDATE {$t['lots']} SET reserved=reserved+%s WHERE id=%d", self::format($use), $row['id']));
			$allocations[] = ['lot_id' => (int) $row['id'], 'amount' => self::format($use), 'source' => $row['source']];
			self::entry($user_id, $row['id'], 'reserve', $use, $kind === 'order' ? absint($reference_id) : 0, $kind . ':' . $reference_id, 'reserve-' . $kind . '-' . $reference_id . '-' . $row['id']);
			$left = self::money($left - $use);
		}
		if ($left > 0) { $wpdb->query('ROLLBACK'); return new WP_Error('wallet_balance_low', 'Wallet balance is not sufficient.'); }
		$wpdb->query('COMMIT');
		return $allocations;
	}

	public static function reserve_order(WC_Order $order, $amount) {
		if (!self::enabled()) { return new WP_Error('wallet_disabled', 'Wallet is disabled for this store.'); }
		$user_id = $order->get_customer_id(); $amount = self::money($amount);
		if (!$user_id || $amount <= 0) { return []; }
		if ($order->get_meta('_dreminex_wallet_allocation', true)) { return (array) $order->get_meta('_dreminex_wallet_allocation', true); }
		if (!self::lock($user_id)) { return new WP_Error('wallet_busy', 'Wallet is being updated. Please try again.'); }
		try {
			$allocations = self::reserve_from_lots($user_id, $amount, 'order', $order->get_id());
			if (!is_wp_error($allocations)) {
				$order->update_meta_data('_dreminex_wallet_allocation', $allocations);
				$order->update_meta_data('_dreminex_wallet_reserved', self::format($amount));
				$order->update_meta_data('_dreminex_wallet_state', 'reserved');
				$order->save();
			}
			return $allocations;
		} finally { self::unlock($user_id); }
	}

	private static function settle_allocations($user_id, $allocations, $mode, $reference_id, $order_id = 0) {
		global $wpdb;
		$t = self::tables(); $wpdb->query('START TRANSACTION');
		foreach ((array) $allocations as $a) {
			$lot = absint($a['lot_id'] ?? 0); $amount = self::money($a['amount'] ?? 0);
			if (!$lot || $amount <= 0) { $wpdb->query('ROLLBACK'); return new WP_Error('wallet_allocation_invalid', 'Wallet allocation is invalid.'); }
			if ($mode === 'commit') { $sql = "UPDATE {$t['lots']} SET remaining=remaining-%s,reserved=reserved-%s WHERE id=%d AND user_id=%d AND reserved>=%s AND remaining>=%s"; }
			else { $sql = "UPDATE {$t['lots']} SET reserved=reserved-%s WHERE id=%d AND user_id=%d AND reserved>=%s"; }
			$args = $mode === 'commit' ? [self::format($amount), self::format($amount), $lot, $user_id, self::format($amount), self::format($amount)] : [self::format($amount), $lot, $user_id, self::format($amount)];
			if ((int) $wpdb->query($wpdb->prepare($sql, ...$args)) !== 1) { $wpdb->query('ROLLBACK'); return new WP_Error('wallet_allocation_changed', 'Wallet allocation changed; manual review is required.'); }
			self::entry($user_id, $lot, $mode === 'commit' ? 'debit' : 'release', $amount, $order_id, $reference_id, $mode . '-' . $reference_id . '-' . $lot);
		}
		$wpdb->query('COMMIT'); return true;
	}

	public static function commit_order($order) {
		if (!$order instanceof WC_Order) { $order = wc_get_order($order); }
		if (!$order instanceof WC_Order || $order->get_meta('_dreminex_wallet_state') === 'debited') { return true; }
		$user_id = $order->get_customer_id(); $allocations = (array) $order->get_meta('_dreminex_wallet_allocation', true);
		if (!$user_id || !$allocations) { return true; }
		if (!self::lock($user_id)) { return new WP_Error('wallet_busy', 'Wallet is being updated.'); }
		try {
			$result = self::settle_allocations($user_id, $allocations, 'commit', 'order-' . $order->get_id(), $order->get_id());
			if (!is_wp_error($result)) { $order->update_meta_data('_dreminex_wallet_state', 'debited'); $order->update_meta_data('_dreminex_wallet_debited_at', gmdate('c')); $order->save(); }
			return $result;
		} finally { self::unlock($user_id); }
	}

	public static function release_order($order_id) {
		$order = wc_get_order($order_id);
		if (!$order instanceof WC_Order || $order->get_meta('_dreminex_wallet_state') !== 'reserved') { return true; }
		$user_id = $order->get_customer_id(); if (!$user_id || !self::lock($user_id)) { return false; }
		try {
			$result = self::settle_allocations($user_id, (array) $order->get_meta('_dreminex_wallet_allocation', true), 'release', 'order-' . $order->get_id(), $order->get_id());
			if (!is_wp_error($result)) { $order->update_meta_data('_dreminex_wallet_state', 'released'); $order->save(); }
			return $result;
		} finally { self::unlock($user_id); }
	}

	public static function request_topup($user_id, $amount, $provider, $txid) {
		global $wpdb; $t = self::tables();
		if (!self::enabled()) { return new WP_Error('wallet_disabled', 'Wallet is disabled for this store.'); }
		$amount = self::money($amount); $provider = sanitize_key($provider); $txid = strtoupper(trim(sanitize_text_field($txid)));
		$minimum=max(1,(float)Dreminex_Suite_Control::setting('delivery_advance','wallet_min_topup',10));
		if ($amount < $minimum || !in_array($provider, array_keys(dreminex_advance_provider_labels()), true) || !preg_match('/^[A-Z0-9-]{5,40}$/D', $txid)) { return new WP_Error('topup_invalid', 'Enter a valid amount, provider and transaction ID.'); }
		$ok = $wpdb->insert($t['topups'], ['user_id' => absint($user_id), 'amount' => self::format($amount), 'provider' => $provider, 'transaction_id' => $txid, 'status' => 'requested', 'created_at' => current_time('mysql', true), 'updated_at' => current_time('mysql', true)], ['%d','%s','%s','%s','%s','%s','%s']);
		return $ok ? (int) $wpdb->insert_id : new WP_Error('topup_duplicate', 'This transaction ID is already in review.');
	}

	public static function transition_topup($id, $status, $note = '') {
		if (!self::enabled()) { return new WP_Error('wallet_disabled', 'Wallet is disabled.'); }
		global $wpdb; $t = self::tables(); $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['topups']} WHERE id=%d", absint($id)), ARRAY_A);
		if (!$row || !in_array($status, ['verified','rejected'], true) || !in_array($row['status'], ['requested','review'], true)) { return new WP_Error('topup_transition_invalid', 'Top-up transition is not allowed.'); }
		if ($status === 'verified') {
			$credit = self::credit($row['user_id'], $row['amount'], 'cash', 'topup', $row['id'], 'topup-' . $row['id']);
			if (is_wp_error($credit)) { return $credit; }
		}
		$wpdb->update($t['topups'], ['status' => $status, 'admin_note' => sanitize_textarea_field($note), 'updated_at' => current_time('mysql', true)], ['id' => $row['id']], ['%s','%s','%s'], ['%d']);
		return true;
	}

	public static function request_withdrawal($user_id, $amount, $provider, $account) {
		global $wpdb; $t = self::tables(); $user_id = absint($user_id); $amount = self::money($amount);
		if (!self::enabled()) { return new WP_Error('wallet_disabled', 'Wallet is disabled for this store.'); }
		$provider = sanitize_key($provider); $account = preg_replace('/\D+/', '', (string) $account);
		$minimum=max(1,(float)Dreminex_Suite_Control::setting('delivery_advance','wallet_min_withdrawal',10));
		if ($amount < $minimum || !in_array($provider, array_keys(dreminex_advance_provider_labels()), true) || !preg_match('/^01[3-9][0-9]{8}$/D', $account)) { return new WP_Error('withdrawal_invalid', 'Enter a valid withdrawal amount and mobile account.'); }
		if (!self::lock($user_id)) { return new WP_Error('wallet_busy', 'Wallet is being updated.'); }
		try {
			$temp = 'new-' . wp_generate_uuid4();
			$allocations = self::reserve_from_lots($user_id, $amount, 'withdrawal', $temp, true);
			if (is_wp_error($allocations)) { return $allocations; }
			$ok = $wpdb->insert($t['withdrawals'], ['user_id'=>$user_id,'amount'=>self::format($amount),'provider'=>$provider,'account_ref'=>$account,'status'=>'requested','allocations'=>wp_json_encode($allocations),'created_at'=>current_time('mysql',true),'updated_at'=>current_time('mysql',true)], ['%d','%s','%s','%s','%s','%s','%s','%s']);
			if (!$ok) { self::settle_allocations($user_id, $allocations, 'release', 'withdrawal-' . $temp); return new WP_Error('withdrawal_failed', 'Withdrawal request could not be saved.'); }
			return (int) $wpdb->insert_id;
		} finally { self::unlock($user_id); }
	}

	public static function transition_withdrawal($id, $status, $note = '') {
		if (!self::enabled()) { return new WP_Error('wallet_disabled', 'Wallet is disabled.'); }
		global $wpdb; $t = self::tables(); $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['withdrawals']} WHERE id=%d", absint($id)), ARRAY_A);
		if (!$row || !in_array($status, ['approved','paid','rejected'], true)) { return new WP_Error('withdrawal_transition_invalid', 'Withdrawal transition is not allowed.'); }
		$allowed = ['requested'=>['approved','rejected'],'approved'=>['paid','rejected']];
		if (!in_array($status, $allowed[$row['status']] ?? [], true)) { return new WP_Error('withdrawal_transition_invalid', 'Withdrawal transition is not allowed from its current status.'); }
		if (!self::lock($row['user_id'])) { return new WP_Error('wallet_busy', 'Wallet is being updated.'); }
		try {
			if ($status === 'paid' || $status === 'rejected') {
				$result = self::settle_allocations($row['user_id'], json_decode($row['allocations'], true) ?: [], $status === 'paid' ? 'commit' : 'release', 'withdrawal-' . $row['id']);
				if (is_wp_error($result)) { return $result; }
			}
			$wpdb->update($t['withdrawals'], ['status'=>$status,'admin_note'=>sanitize_textarea_field($note),'updated_at'=>current_time('mysql',true)], ['id'=>$row['id']], ['%s','%s','%s'], ['%d']);
			return true;
		} finally { self::unlock($row['user_id']); }
	}

	public static function claim_coupon($user_id, $code) {
		if (!self::enabled()) { return new WP_Error('wallet_disabled', 'Wallet is disabled for this store.'); }
		$code = wc_format_coupon_code($code); $coupon = new WC_Coupon($code);
		if (!$coupon->get_id() || $coupon->get_meta('_dreminex_wallet_credit_enabled') !== 'yes') { return new WP_Error('wallet_coupon_invalid', 'This wallet offer code is not valid.'); }
		$expires = $coupon->get_date_expires();
		if ($expires && $expires->getTimestamp() <= time()) { return new WP_Error('wallet_coupon_expired', 'This wallet offer has expired.'); }
		$amount = self::money($coupon->get_meta('_dreminex_wallet_credit_amount') ?: $coupon->get_amount());
		if ($amount <= 0) { return new WP_Error('wallet_coupon_empty', 'This wallet offer has no credit value.'); }
		$expiry = $expires ? gmdate('Y-m-d H:i:s', $expires->getTimestamp()) : gmdate('Y-m-d H:i:s', time() + max(1, absint($coupon->get_meta('_dreminex_wallet_credit_days') ?: 30)) * DAY_IN_SECONDS);
		return self::credit($user_id, $amount, 'promo', 'coupon', $coupon->get_id(), 'coupon-' . $coupon->get_id() . '-user-' . absint($user_id), $expiry);
	}

	public static function lists($user_id = 0) {
		global $wpdb; $t = self::tables(); $where = $user_id ? $wpdb->prepare(' WHERE user_id=%d', absint($user_id)) : '';
		return [
			'lots' => $wpdb->get_results("SELECT id,user_id,source,amount,remaining,reserved,withdrawable,expires_at,reference_type,reference_id,created_at FROM {$t['lots']}{$where} ORDER BY id DESC LIMIT 100", ARRAY_A), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			'withdrawals' => $wpdb->get_results("SELECT * FROM {$t['withdrawals']}{$where} ORDER BY id DESC LIMIT 100", ARRAY_A), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			'topups' => $wpdb->get_results("SELECT * FROM {$t['topups']}{$where} ORDER BY id DESC LIMIT 100", ARRAY_A), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		];
	}

	public static function handle_customer_actions() {
		if (!is_user_logged_in() || empty($_POST['dreminex_wallet_action'])) { return; }
		$action = sanitize_key(wp_unslash($_POST['dreminex_wallet_action']));
		if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? '')), 'dreminex_wallet_' . $action)) { wc_add_notice('Wallet request expired. Try again.', 'error'); return; }
		$user = get_current_user_id(); $result = null;
		if ($action === 'topup') { $result = self::request_topup($user, wp_unslash($_POST['amount'] ?? 0), wp_unslash($_POST['provider'] ?? ''), wp_unslash($_POST['transaction_id'] ?? '')); }
		elseif ($action === 'withdraw') { $result = self::request_withdrawal($user, wp_unslash($_POST['amount'] ?? 0), wp_unslash($_POST['provider'] ?? ''), wp_unslash($_POST['account'] ?? '')); }
		elseif ($action === 'claim') { $result = self::claim_coupon($user, wp_unslash($_POST['code'] ?? '')); }
		if ($result !== null) { wc_add_notice(is_wp_error($result) ? $result->get_error_message() : 'Wallet request received.', is_wp_error($result) ? 'error' : 'success'); wp_safe_redirect(wc_get_account_endpoint_url(self::ENDPOINT)); exit; }
	}

	public static function render() {
		if (!is_user_logged_in()) { echo '<p>Please sign in to use your wallet.</p>'; return; }
		$user = get_current_user_id(); $b = self::balances($user); $data = self::lists($user); $providers = dreminex_advance_provider_labels();
		echo '<section class="dreminex-wallet"><h2>My wallet</h2><div class="dreminex-wallet-cards">';
		foreach (['total'=>'Available','cash'=>'Cash','promo'=>'Offer credit','withdrawable'=>'Withdrawable','reserved'=>'Reserved'] as $key=>$label) { echo '<article><span>'.esc_html($label).'</span><strong>'.wp_kses_post(wc_price($b[$key])).'</strong></article>'; }
		echo '</div><p>Offer credit can be used for purchases until its shown expiry date. It cannot be withdrawn.</p>';
		self::form('topup', 'Add cash balance', '<input type="number" min="10" step="0.01" name="amount" required placeholder="Amount">'.self::provider_select($providers).'<input name="transaction_id" maxlength="40" required placeholder="Transaction ID">');
		self::form('claim', 'Claim an offer code', '<input name="code" required placeholder="Offer code">');
		self::form('withdraw', 'Request withdrawal', '<input type="number" min="10" step="0.01" name="amount" required placeholder="Amount">'.self::provider_select($providers).'<input name="account" pattern="01[3-9][0-9]{8}" required placeholder="Mobile account number">');
		echo '<h3>Active balances</h3><table class="shop_table"><thead><tr><th>Type</th><th>Available</th><th>Expiry</th></tr></thead><tbody>';
		foreach ((array) $data['lots'] as $lot) { $available=max(0,(float)$lot['remaining']-(float)$lot['reserved']); if($available<=0)continue; echo '<tr><td>'.esc_html($lot['source']==='promo'?'Offer credit':'Cash').'</td><td>'.wp_kses_post(wc_price($available)).'</td><td>'.esc_html($lot['expires_at']?:'No expiry').'</td></tr>'; }
		echo '</tbody></table><h3>Requests</h3><table class="shop_table"><thead><tr><th>Type</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead><tbody>';
		foreach (array_merge((array)$data['topups'],(array)$data['withdrawals']) as $row) { $type=isset($row['transaction_id'])?'Add funds':'Withdrawal'; echo '<tr><td>'.esc_html($type).'</td><td>'.wp_kses_post(wc_price($row['amount'])).'</td><td>'.esc_html(ucfirst($row['status'])).'</td><td>'.esc_html($row['created_at']).'</td></tr>'; }
		echo '</tbody></table></section>';
	}
	private static function provider_select($providers) { $html='<select name="provider" required><option value="">Choose provider</option>'; foreach($providers as $key=>$label)$html.='<option value="'.esc_attr($key).'">'.esc_html($label).'</option>'; return $html.'</select>'; }
	private static function form($action,$title,$fields) { echo '<details class="dreminex-wallet-action"><summary>'.esc_html($title).'</summary><form method="post">'.wp_nonce_field('dreminex_wallet_'.$action,'_wpnonce',true,false).'<input type="hidden" name="dreminex_wallet_action" value="'.esc_attr($action).'">'.$fields.'<button class="button" type="submit">'.esc_html($title).'</button></form></details>'; }
}

Dreminex_Customer_Wallet::boot();
