<?php
if (!defined('ABSPATH')) { exit; }
/* Dreminex: normalize and validate Bangladeshi billing mobile numbers. */
if(!function_exists('dreminex_normalize_bd_phone')){
 function dreminex_normalize_bd_phone($value){$digits=preg_replace('/\D+/','',(string)$value);if(strpos($digits,'8801')===0&&strlen($digits)===13)$digits=substr($digits,2);return $digits;}
}
add_filter('woocommerce_checkout_posted_data',function($data){if(isset($data['billing_phone']))$data['billing_phone']=dreminex_normalize_bd_phone($data['billing_phone']);return $data;},20);
add_action( 'woocommerce_after_checkout_validation', function ( $data, $errors ) {
	$phone = dreminex_normalize_bd_phone( sanitize_text_field( wp_unslash( $data['billing_phone'] ?? '' ) ) );
	if ( '' !== $phone && ! preg_match( '/^01[3-9][0-9]{8}$/D', $phone ) ) {
		$errors->add( 'dreminex_billing_phone', Dreminex_Suite_Control::message( 'checkout_protection', 'msg_phone_invalid', Dreminex_Suite_Control::tr("Enter a valid Bangladesh mobile number (01XXXXXXXXX).", 'সঠিক বাংলাদেশি মোবাইল নম্বর দিন (01XXXXXXXXX)।') ) );
	}
}, 30, 2 );
