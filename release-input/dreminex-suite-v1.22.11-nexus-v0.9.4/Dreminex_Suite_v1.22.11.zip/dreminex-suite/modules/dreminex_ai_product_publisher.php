<?php
/** Dreminex Suite's optional AI Product Publisher module. */

if (!defined('ABSPATH')) { return; }
require_once __DIR__ . '/class-dreminex-ai-workflow-projects.php';
final class Dreminex_Suite_AI_Product_Publisher {
    private const OPTION = 'dreminex_ai_publisher_settings';
    private const NAMESPACE = 'dreminex-products';
    private const MAX_VARIATION_ROWS = 564;
    private const VARIATION_BATCH_SIZE = 12;
    private const MAX_PREFIX_LENGTH = 24;
    private const ADMIN_PAGE = 'dreminex-ai-product-publisher';

    public static function boot(): void {
        Dreminex_AI_Workflow_Projects::boot();
        $modules = (array)get_option('dreminex_suite_modules', []);
        $standalone = in_array('dreminex-ai-product-publisher/dreminex-ai-product-publisher.php', (array)get_option('active_plugins', []), true);
        if (class_exists('Dreminex_Native_MCP') && Dreminex_Native_MCP::enabled() && !$standalone) {
            add_action('wp_abilities_api_categories_init', [self::class, 'category']);
            add_action('wp_abilities_api_init', [self::class, 'abilities'], 30);
            add_filter('rtwpvs_variation_attribute_options_html', [self::class, 'image_swatches_html'], 20, 2);
            add_action('wp_enqueue_scripts', [self::class, 'swatch_styles'], 40);
        }
        add_action('admin_post_dreminex_publisher_settings', [self::class, 'save_settings']);
    }

    private static function config(): array {
        $stored = get_option(self::OPTION, false);
        $modules = (array)get_option('dreminex_suite_modules', []);
        $existing_active_install = is_array($stored) || !empty($modules['ai_product_publisher']);
        $config = wp_parse_args(is_array($stored) ? $stored : [], [
            'color_attribute' => 'pa_solid-color',
            'size_attribute' => 'pa_for-men-size',
            'auto_terms' => 1,
            'max_upload_mb' => 12,
            'max_variation_rows' => 64,
            'auto_sku' => 0,
            'sku_prefix' => 'DRX',
            'brand_from_label' => 1,
            'require_image_match' => 1,
            'require_stock_for_variants' => 0,
            'allow_publish' => 1,
            'optional_prompt_seconds' => 10,
            'ability_access_mode' => $existing_active_install ? 'full_access' : 'read_only',
            'ability_states' => [],
        ]);
        $config['max_variation_rows'] = max(1, min(self::MAX_VARIATION_ROWS, absint($config['max_variation_rows'])));
        $config['ability_access_mode'] = in_array($config['ability_access_mode'], ['read_only','full_access'], true) ? $config['ability_access_mode'] : 'read_only';
        $config['ability_states'] = is_array($config['ability_states']) ? $config['ability_states'] : [];
        $prefixes = self::parse_prefixes((string)$config['sku_prefix']);
        if (is_wp_error($prefixes) || !$prefixes) $prefixes = ['DRX-'];
        $config['sku_prefixes'] = $prefixes;
        $config['default_sku_prefix'] = in_array(($config['default_sku_prefix'] ?? ''),$prefixes,true) ? $config['default_sku_prefix'] : $prefixes[0];
        $config['sku_prefix'] = implode(' / ', $prefixes);
        return $config;
    }

    private static function parse_prefixes(string $value) {
        if (preg_match('/[\x00-\x1F\x7F]/u',$value)) return new WP_Error('invalid_sku_prefix','SKU prefixes cannot contain control characters or new lines.');
        $out=[];
        foreach(explode('/',$value) as $part){
            $part=strtoupper(trim(wp_strip_all_tags($part)));
            if($part==='')continue;
            if(mb_strlen($part)>self::MAX_PREFIX_LENGTH)return new WP_Error('invalid_sku_prefix','Each SKU prefix can contain at most 24 visible characters.');
            if(!in_array($part,$out,true))$out[]=$part;
        }
        if(!$out||count($out)>5)return new WP_Error('invalid_sku_prefix','Supply one to five SKU prefixes separated with /.');
        return $out;
    }

    public static function variation_capacity(): int {
        return (int)self::config()['max_variation_rows'];
    }

    public static function app_settings(): array {
        return array_intersect_key(self::config(), array_flip(['color_attribute','size_attribute','auto_terms','max_upload_mb','max_variation_rows','auto_sku','sku_prefix','sku_prefixes','default_sku_prefix','brand_from_label','require_image_match','require_stock_for_variants','allow_publish','ability_access_mode','ability_states']));
    }

    public static function update_app_settings(array $input) {
        $current = self::config();
        if (isset($input['max_variation_rows'])) $current['max_variation_rows'] = max(1, min(self::MAX_VARIATION_ROWS, absint($input['max_variation_rows'])));
        if (isset($input['sku_prefix']) || isset($input['sku_prefixes'])) {
            $raw=isset($input['sku_prefixes'])&&is_array($input['sku_prefixes'])?implode(' / ',$input['sku_prefixes']):(string)$input['sku_prefix'];
            $prefixes=self::parse_prefixes($raw);if(is_wp_error($prefixes))return $prefixes;
            $current['sku_prefix']=implode(' / ',$prefixes);$current['sku_prefixes']=$prefixes;
            $requested=strtoupper(trim(sanitize_text_field((string)($input['default_sku_prefix']??$prefixes[0]))));
            $current['default_sku_prefix']=in_array($requested,$prefixes,true)?$requested:$prefixes[0];
        }
        foreach (['color_attribute','size_attribute'] as $key) if (isset($input[$key])) $current[$key] = sanitize_title((string)$input[$key]);
        foreach (['auto_terms','auto_sku','brand_from_label','require_image_match','require_stock_for_variants','allow_publish'] as $key) if (array_key_exists($key,$input)) $current[$key] = !empty($input[$key]) ? 1 : 0;
        if (isset($input['ability_access_mode'])) $current['ability_access_mode'] = in_array($input['ability_access_mode'],['read_only','full_access'],true)?$input['ability_access_mode']:$current['ability_access_mode'];
        if (isset($input['ability_states']) && is_array($input['ability_states'])) { $states=[]; foreach($input['ability_states'] as $name=>$enabled) if(isset(self::operations()[$name]))$states[$name]=!empty($enabled)?1:0; $current['ability_states']=$states; }
        update_option(self::OPTION,$current,false);return self::app_settings();
    }

    private static function operations(): array {
        return [
            'catalog' => ['Inspect product attributes, categories and duplicate slugs.', 'catalog'],
            'preparation-snapshot' => ['Read a bounded same-site preparation snapshot: exact product title/slug and SKU collisions, catalog, recent media and published related candidates; no writes or visual-match claims.', 'preparation_snapshot'],
            'identity-plan' => ['Plan a distinct new-product name, slug and prefix-based parent SKU against the selected site without writing.', 'identity_plan'],
            'handoff-preflight' => ['Validate a complete Preparation handoff, separating hard blockers from safe Publisher prerequisites without writing product data.', 'handoff_preflight'],
            'attribute-ensure' => ['Idempotently reuse or create one exact WooCommerce global product attribute and its supplied terms.', 'attribute_ensure'],
            'handoff-execute' => ['Resolve allowlisted handoff prerequisites, rerun preflight, apply or resume the same product operation and return verified readback.', 'handoff_execute'],
            'category-ensure' => ['Reuse or create a product category under a verified parent; return its ID.', 'category_ensure'],
            'media-find' => ['Find existing Media Library images by exact supplied filename and report incoming files.', 'media_find'],
            'media-candidates' => ['List same-site Media Library image candidates for visual verification; read-only.', 'media_candidates'],
            'media-visual-match' => ['Rank same-site Media Library images against a cropped supplier screenshot photo; suggestions require visual confirmation.', 'media_visual_match'],
            'media-import' => ['Import one supplied image from the dedicated incoming directory.', 'media_import'],
            'media-upload' => ['Import supplied base64 image bytes directly into the Media Library when the assistant can access the attachment bytes.', 'media_upload'],
            'media-batch-upload' => ['Import up to 10 original image files in one call from accessible base64 bytes, incoming filenames or HTTPS URLs; return IDs and a resumable partial result.', 'media_batch_upload'],
            'media-url-import' => ['Import a supplied public HTTPS product image URL into the Media Library.', 'media_url_import'],
            'media-update' => ['Update an image attachment title, alt text, caption or description.', 'media_update'],
            'listing-apply' => ['Apply prepared WooCommerce listing fields and accessible original images in one call. Only mode=update with the exact product_id updates an existing listing; mode=draft, mode=publish, or omitted mode creates a new listing. Exact title or slug collisions block creation and never trigger an update.', 'listing_apply'],
            'draft-complete' => ['Legacy complete listing ability. Defaults to operation=create; set operation=resume with product_id only to resume a partial Draft created by this same listing run. Never use this ability to update an existing listing; use listing-apply with mode=update for an explicit Update request.', 'draft_complete'],
            'draft-create' => ['Create a new Draft only when the exact product title and slug are unused; collisions stop creation and never update an existing product.', 'draft_create'],
            'variations-upsert' => ['Create or update an internal batch of explicit color and size combinations.', 'variations_upsert'],
            'colors-reconcile' => ['Move an existing draft to exact-HEX global color swatches.', 'colors_reconcile'],
            'color-swatch-set' => ['Assign or clear one product-specific representative image swatch for each colour; retain every detail image in the product gallery.', 'color_swatch_set'],
            'product-read' => ['Read back product, SEO, media and variations.', 'product_read'],
            'supplier-source-read' => ['Read this product’s Supplier Monitor source and last authenticated scan status.', 'supplier_source_read'],
            'supplier-source-set' => ['Connect an exact ShopBaseBD or ResellKori supplier URL to an existing product. The Supplier Monitor scans it separately.', 'supplier_source_set'],
            'listing-update' => ['Apply only an explicitly requested Update to its exact existing product_id; update supplied fields without replacing unrelated fields.', 'listing_update'],
            'variation-update' => ['Update the verified image, price, SKU or stock of an existing purchasable variation.', 'variation_update'],
            'draft-brand-set' => ['Set a verified image-label brand on a draft.', 'draft_brand_set'],
            'brand-set' => ['Set a verified label brand on an existing Draft or Published listing.', 'draft_brand_set'],
            'draft-inventory-set' => ['Set verified SKU and stock on a draft or its variations.', 'draft_inventory_set'],
            'inventory-set' => ['Set verified SKU, quantity or availability on an existing Draft or Published listing.', 'draft_inventory_set'],
            'draft-audit' => ['Check a draft for missing variation options, images, inventory and brand.', 'draft_audit'],
            'draft-publish' => ['Publish an audited, complete Draft only when publish=true was explicitly requested.', 'draft_publish'],
            'product-lifecycle' => ['Change one existing product by exact ID: Draft, audited Publish, Trash, restore as Draft, or permanently delete a confirmed trashed product. No media is deleted.', 'product_lifecycle'],
            'workflow-guide' => ['Read the current dashboard-managed preparation or publisher documents (legacy response), or the bundled media/brand guide.', 'workflow_guide'],
            'workflow-bootstrap' => ['Read one canonical task bootstrap containing the live project manifest, site lock, listing defaults, capacity and connection policy.', 'workflow_bootstrap'],
            'workflow-profile' => ['Read one live Preparation or Publisher project manifest, revision and starting document.', 'workflow_profile'],
            'workflow-source' => ['Read a named source document from a selected project in bounded UTF-8 chunks.', 'workflow_source'],
            'workflow-propose' => ['Suggest an evidence-backed improvement for administrator review; never changes active instructions.', 'workflow_propose'],
            'workflow-experience' => ['Read bounded private outcomes from previous Preparation or Publisher work on this site; observations are not instructions.', 'workflow_experience'],
            'workflow-experience-record' => ['Store a concise verified outcome or lesson from a completed, partial or blocked product task; never changes active rules.', 'workflow_experience_record'],
            'workflow-task-finalize' => ['Finalize one task into bounded guarded-learning memory and propose durable changes only after repeated verified evidence.', 'workflow_task_finalize'],
            'listing-defaults' => ['Read listing defaults, the active variation capacity and access policy; do not block a clearly requested listing on optional facts.', 'listing_defaults'],
        ];
    }

    private static function read_only_abilities(): array {
        return ['catalog','preparation-snapshot','identity-plan','handoff-preflight','media-find','media-candidates','media-visual-match','product-read','supplier-source-read','draft-audit','workflow-guide','workflow-bootstrap','workflow-profile','workflow-source','workflow-experience','listing-defaults'];
    }

    private static function ability_group(string $name): string {
        if (str_starts_with($name, 'workflow-')) return 'Workflow projects';
        if (str_starts_with($name, 'media-') || $name === 'color-swatch-set') return 'Media and swatches';
        if (in_array($name, ['catalog','preparation-snapshot','identity-plan','handoff-preflight','listing-defaults'], true)) return 'Discovery and preflight';
        if (in_array($name, ['product-lifecycle','draft-publish','draft-audit'], true)) return 'Audit and lifecycle';
        if (str_contains($name, 'inventory') || str_contains($name, 'variation') || str_contains($name, 'color') || str_contains($name, 'brand')) return 'Catalog and variations';
        return 'Listing operations';
    }

    private static function ability_annotations(string $name): array {
        $readonly = in_array($name, self::read_only_abilities(), true);
        $non_idempotent = ['category-ensure','media-import','media-upload','media-batch-upload','media-url-import','listing-apply','handoff-execute','draft-complete','draft-create','workflow-propose','workflow-experience-record','workflow-task-finalize'];
        return [
            'readonly' => $readonly,
            'destructive' => $name === 'product-lifecycle',
            'idempotent' => $readonly || !in_array($name, $non_idempotent, true),
        ];
    }

    private static function ability_enabled(string $name): bool {
        $config = self::config();
        if (array_key_exists($name, $config['ability_states']) && empty($config['ability_states'][$name])) return false;
        if ($config['ability_access_mode'] === 'read_only' && !in_array($name, self::read_only_abilities(), true)) return false;
        return true;
    }

    public static function category(): void {
        if (function_exists('wp_register_ability_category')) {
            wp_register_ability_category(self::NAMESPACE, [
                'label' => 'Dreminex Product Publisher',
                'description' => 'WooCommerce product listing, media, variation, inventory and publication operations.',
            ]);
        }
    }

    public static function abilities(): void {
        if (!function_exists('wp_register_ability') || !class_exists('WooCommerce')) { return; }
        foreach (self::operations() as $name => [$description, $method]) {
            if (!self::ability_enabled($name)) continue;
            wp_register_ability(self::NAMESPACE . '/' . $name, [
                'label' => ucwords(str_replace('-', ' ', $name)),
                'description' => $description,
                'category' => self::NAMESPACE,
                'input_schema' => self::schema($name),
                'output_schema' => ['type' => 'object', 'additionalProperties' => true],
                'execute_callback' => static function (array $input) use ($name, $method) {
                    if (!self::ability_enabled($name)) return self::fail('This ability is disabled by the AI Product Publisher access policy.', 'ability_disabled');
                    $result = self::$method($input);
                    if (in_array($name, ['listing-apply', 'handoff-execute', 'listing-update', 'supplier-source-set', 'variation-update', 'media-update', 'product-lifecycle', 'draft-publish', 'variations-upsert', 'color-swatch-set'], true)) {
                        Dreminex_AI_Workflow_Projects::record_operation($name, $input, $result);
                    }
                    if (in_array($name, ['listing-apply','handoff-execute'], true) && is_wp_error($result)) {
                        return ['success' => false, 'error_code' => $result->get_error_code(), 'error_message' => $result->get_error_message(), 'product_id' => null];
                    }
                    return $result;
                },
                'permission_callback' => static function () use ($name): bool {
                    return self::ability_enabled($name) && current_user_can('manage_woocommerce') && (!in_array($name, ['media-import','media-upload','media-batch-upload','media-url-import','media-update','handoff-execute'], true) || current_user_can('upload_files'));
                },
                'annotations' => self::ability_annotations($name),
                'meta' => ['annotations' => self::ability_annotations($name), 'show_in_rest' => true, 'mcp' => ['public' => true]],
            ]);
        }
    }

    private static function schema(string $name): array {
        $id = ['type' => 'integer', 'minimum' => 1];
        $properties = [
            'catalog' => ['slug' => ['type' => 'string', 'description' => 'Requested product URL slug for duplicate check.']],
            'preparation-snapshot' => [
                'name' => ['type' => 'string', 'description' => 'Exact proposed product name to check against existing product titles.'],
                'slug' => ['type' => 'string', 'description' => 'Exact product slug to inspect for an existing listing.'],
                'sku' => ['type' => 'string', 'description' => 'Exact parent SKU to inspect for an existing listing.'],
                'size_attribute' => ['type' => 'string', 'description' => 'Optional existing global size taxonomy to include its terms.'],
                'category_ids' => ['type' => 'array', 'items' => $id, 'maxItems' => 5, 'description' => 'Known product categories to narrow published related candidates.'],
                'related_search' => ['type' => 'string', 'description' => 'Optional short title keyword for published related candidates.'],
                'related_limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 12],
                'media_page' => ['type' => 'integer', 'minimum' => 1],
                'media_per_page' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 80],
            ],
            'identity-plan' => [
                'proposed_name' => ['type' => 'string', 'description' => 'Supplier-grounded proposed product name.'],
                'differentiators' => ['type' => 'array', 'items' => ['type' => 'string'], 'maxItems' => 8, 'description' => 'Verified material, design, fit, set type, audience or style facts that may distinguish a collision.'],
                'sku_prefix' => ['type' => 'string', 'description' => 'Optional owner prefix (maximum 24 visible characters); dashboard default is the fallback.'],
                'supplier_source_url' => ['type' => 'string'],
                'evidence_sha256' => ['type' => 'string', 'description' => 'Optional SHA-256 of the supplied evidence manifest for stable collision suffixing.'],
            ],
            'handoff-preflight' => ['handoff' => ['type' => 'object', 'description' => 'The complete PUBLISHER HANDOFF JSON object. This ability is read-only.']],
            'workflow-bootstrap' => ['profile' => ['type' => 'string', 'enum' => ['preparation', 'publisher']]],
            'attribute-ensure' => [
                'label' => ['type' => 'string', 'description' => 'Exact global attribute label, such as Kids Size.'],
                'slug' => ['type' => 'string', 'description' => 'Attribute slug with or without pa_ prefix.'],
                'type' => ['type' => 'string', 'description' => 'WooCommerce attribute type; defaults to select.'],
                'terms' => ['type' => 'array', 'items' => ['type' => 'string'], 'maxItems' => 100],
                'handoff_hash' => ['type' => 'string', 'description' => 'Normalized handoff hash that authorized this prerequisite.'],
            ],
            'handoff-execute' => [
                'handoff' => ['type' => 'object', 'description' => 'Complete versioned PUBLISHER HANDOFF.'],
                'resume_product_id' => ['type' => 'integer', 'minimum' => 1],
                'resume_token' => ['type' => 'string'],
                'variation_offset' => ['type' => 'integer', 'minimum' => 0],
            ],
            'category-ensure' => ['name' => ['type' => 'string'], 'slug' => ['type' => 'string'], 'parent_id' => ['type' => 'integer', 'minimum' => 0], 'description' => ['type' => 'string']],
            'media-find' => ['filenames' => ['type' => 'array', 'items' => ['type' => 'string'], 'minItems' => 1, 'maxItems' => 40]],
            'media-candidates' => ['page' => ['type' => 'integer', 'minimum' => 1], 'per_page' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 100], 'search' => ['type' => 'string', 'description' => 'Optional attachment title keyword. Empty lists recent image attachments.']],
            'media-visual-match' => ['reference_base64' => ['type' => 'string', 'description' => 'One option: JPEG/PNG/WebP bytes of the cropped supplier product photo (no browser chrome or SKU panel), base64 encoded; not stored, max 2 MB.'], 'reference_dhash' => ['type' => 'string', 'description' => 'Alternative to image bytes: 64-character 0/1 horizontal dHash from a cropped supplier photo, prepared with grayscale resize to 9x8 pixels. Ranking still requires visual review of the source reference.'], 'candidate_ids' => ['type' => 'array', 'items' => $id, 'maxItems' => 40, 'description' => 'Optional exact same-site attachment IDs to compare, up to 40; otherwise page through recent image attachments.'], 'page' => ['type' => 'integer', 'minimum' => 1], 'per_page' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 40], 'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 10]],
            'media-import' => ['path' => ['type' => 'string', 'description' => 'Basename of image already transferred to uploads/dreminex-ai-incoming. A chat attachment alone is not a server file.'], 'alt' => ['type' => 'string'], 'title' => ['type' => 'string']],
            'media-upload' => ['filename' => ['type' => 'string', 'description' => 'Image filename including the verified color name.'], 'content_base64' => ['type' => 'string', 'description' => 'Actual JPEG, PNG or WebP file bytes encoded as base64; the assistant must have access to the original file bytes.'], 'alt' => ['type' => 'string'], 'title' => ['type' => 'string']],
            'media-batch-upload' => ['images' => ['type' => 'array', 'minItems' => 1, 'maxItems' => 10, 'description' => 'Each image has filename and exactly one of content_base64, incoming_path, url or image_id. Real bytes or a reachable URL are required; a chat preview is insufficient.', 'items' => ['type' => 'object', 'properties' => ['filename' => ['type' => 'string'], 'content_base64' => ['type' => 'string'], 'incoming_path' => ['type' => 'string'], 'url' => ['type' => 'string'], 'image_id' => $id, 'alt' => ['type' => 'string'], 'title' => ['type' => 'string']]]]],
            'media-url-import' => ['url' => ['type' => 'string', 'description' => 'Public HTTPS URL of the actual user-supplied product image.'], 'filename' => ['type' => 'string', 'description' => 'Filename containing the color name, e.g. emerald-green.jpg.'], 'alt' => ['type' => 'string'], 'title' => ['type' => 'string']],
            'media-update' => ['image_id' => $id, 'alt' => ['type' => 'string'], 'title' => ['type' => 'string'], 'slug' => ['type' => 'string', 'description' => 'Attachment permalink slug only; does not rename the original media filename or change its file URL.'], 'caption' => ['type' => 'string'], 'description' => ['type' => 'string']],
            'draft-create' => self::product_fields(),
            'listing-apply' => array_merge(self::product_fields(), [
                'product_id' => ['type' => ['integer','null'], 'minimum' => 1, 'description' => 'Null for a new hand-off; an integer is required only for mode=update.'],
                'supplier_source_url' => ['type' => ['string','null'], 'format' => 'uri', 'description' => 'Optional exact supplier product URL, connected after product save.'],
                'mode' => ['type' => 'string', 'enum' => ['draft','publish','update'], 'description' => 'Only mode=update updates an existing product and requires its exact product_id. Omitted mode defaults to draft and creates a new product even if a product_id was supplied; draft/publish are create modes.'],
                'brand' => ['type' => ['string','null']],
                'sale_price' => ['type' => ['string','null']],
                'sizes' => ['type' => 'array', 'items' => ['type' => ['string','object']], 'description' => 'Complete PUBLISHER HANDOFF may carry measurement objects; preflight extracts each name before saving.'],
                'stock_status' => ['type' => 'string', 'enum' => ['instock','outofstock','onbackorder','In stock'], 'description' => 'Complete hand-off normalizes an owner-stated In stock to instock before saving.'],
                'category_names' => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'Exact existing category names or new category names; category_ids take precedence.'],
                'category_parent_id' => ['type' => 'integer', 'minimum' => 0],
                'images' => ['type' => 'array', 'description' => 'Exactly one media source per image (image_id OR url). Existing same-site URLs reuse attachments. Use one verified supplier code per colour, not a different code per view.', 'items' => ['type' => 'object', 'properties' => ['filename' => ['type' => 'string'], 'content_base64' => ['type' => 'string'], 'incoming_path' => ['type' => 'string'], 'url' => ['type' => 'string'], 'image_id' => $id, 'import_external' => ['type' => 'boolean'], 'alt' => ['type' => 'string'], 'title' => ['type' => 'string'], 'slug' => ['type' => 'string', 'description' => 'Optional attachment permalink slug, applied only with update_media_metadata=true; does not rename the file.'], 'color' => ['type' => 'string'], 'supplier_sku' => ['type' => 'string', 'description' => 'Optional confirmed colour-level supplier code; the same code must be used for every view of this colour.']]]],
                'featured_image_index' => ['type' => ['integer','null'], 'minimum' => 0],
                'update_media_metadata' => ['type' => 'boolean'],
                'label_image_index' => ['type' => 'integer', 'minimum' => 0, 'description' => 'Zero-based images entry showing the legible brand label.'],
                'variants' => ['type' => 'array', 'maxItems' => self::MAX_VARIATION_ROWS, 'items' => ['type' => 'object'], 'description' => 'Only offered combinations, up to the dashboard-configured capacity (hard maximum 564). A verified screenshot supplier code is appended to the existing internal child SKU; without a code the internal child SKU is unchanged.'],
                'full_matrix' => ['type' => 'boolean', 'description' => 'True only when every supplied color/size pair is actually offered.'],
                'resume_product_id' => ['type' => 'integer', 'minimum' => 1, 'description' => 'Same-operation partial product ID returned by listing-apply.'],
                'resume_token' => ['type' => 'string', 'description' => 'Opaque same-operation recovery token returned by listing-apply.'],
                'variation_offset' => ['type' => 'integer', 'minimum' => 0, 'description' => 'Exact next variation index returned by a partial listing-apply.'],
            ]),
            'draft-complete' => array_merge(self::product_fields(), ['product_id' => $id, 'operation' => ['type' => 'string', 'enum' => ['create','resume'], 'description' => 'Defaults to create and ignores product_id. Use resume with the exact ID only for a partial Draft created by this same listing run.'], 'variants' => ['type' => 'array', 'description' => 'Explicit purchasable color/size combinations. Each row can contain image_id, SKU, prices and stock status/quantity.', 'items' => ['type' => 'object']], 'full_matrix' => ['type' => 'boolean', 'description' => 'Only when every color/size combination is offered; derive rows with parent prices. Stock is never assumed.'], 'publish' => ['type' => 'boolean', 'description' => 'Set true only when the user has explicitly requested publication; requires successful audit.']]),
            'variations-upsert' => ['product_id' => $id, 'variants' => ['type' => 'array', 'items' => ['type' => 'object'], 'minItems' => 1, 'maxItems' => 12]],
            'colors-reconcile' => ['product_id' => $id, 'color_attribute' => ['type' => 'string', 'description' => 'Exact global colour taxonomy returned by product-read.'], 'colors' => ['type' => 'array', 'items' => ['type' => 'object']]],
            'color-swatch-set' => ['product_id' => $id, 'color_attribute' => ['type' => 'string', 'description' => 'Exact global colour taxonomy returned by product-read or catalog.'], 'colors' => ['type' => 'array', 'minItems' => 1, 'maxItems' => 40, 'items' => ['type' => 'object', 'properties' => ['name' => ['type' => 'string'], 'image_id' => $id, 'mode' => ['type' => 'string', 'enum' => ['image','color']]]]]],
            'product-read' => ['product_id' => $id],
            'supplier-source-read' => ['product_id' => $id],
            'supplier-source-set' => ['product_id' => $id, 'supplier_source_url' => ['type' => 'string', 'format' => 'uri', 'description' => 'Exact HTTPS product URL on ShopBaseBD or ResellKori.']],
            'listing-update' => array_merge(self::product_fields(), ['product_id' => array_merge($id, ['description' => 'Use only for an explicitly requested Update or a same-run partial listing recovery.']), 'supplier_source_url' => ['type' => 'string', 'format' => 'uri']]),
            'variation-update' => ['product_id' => $id, 'variation_id' => $id, 'image_id' => $id, 'regular_price' => ['type' => 'string'], 'sale_price' => ['type' => 'string'], 'sku' => ['type' => 'string'], 'stock_quantity' => ['type' => 'integer', 'minimum' => 0], 'stock_status' => ['type' => 'string', 'enum' => ['instock','outofstock','onbackorder']]],
            'draft-brand-set' => ['product_id' => $id, 'label_brand' => ['type' => 'string'], 'label_image_id' => $id, 'label_verified' => ['type' => 'boolean']],
            'brand-set' => ['product_id' => $id, 'label_brand' => ['type' => 'string'], 'label_image_id' => $id, 'label_verified' => ['type' => 'boolean']],
            'draft-inventory-set' => ['product_id' => $id, 'sku' => ['type' => 'string'], 'stock_quantity' => ['type' => 'integer', 'minimum' => 0], 'variations' => ['type' => 'array', 'items' => ['type' => 'object']]],
            'inventory-set' => ['product_id' => $id, 'sku' => ['type' => 'string'], 'stock_quantity' => ['type' => 'integer', 'minimum' => 0], 'stock_status' => ['type' => 'string', 'enum' => ['instock','outofstock','onbackorder']], 'variations' => ['type' => 'array', 'items' => ['type' => 'object']]],
            'draft-audit' => ['product_id' => $id],
            'draft-publish' => ['product_id' => $id, 'publish' => ['type' => 'boolean', 'description' => 'Must be true when the user expressly asked to publish.']],
            'product-lifecycle' => [
                'product_id' => $id,
                'action' => ['type' => 'string', 'enum' => ['draft','publish','trash','restore','delete'], 'description' => 'Exact requested action. Restore always returns a Draft; publish uses the readiness audit. Delete is permanent and only works from Trash.'],
                'expected_status' => ['type' => 'string', 'enum' => ['draft','publish','trash'], 'description' => 'Optional optimistic concurrency check to avoid changing a product that changed since readback.'],
                'confirm_product_id' => $id,
            ],
            'workflow-guide' => ['guide' => ['type' => 'string', 'enum' => ['preparation', 'publishing', 'media-brand']]],
            'workflow-profile' => ['profile' => ['type' => 'string', 'enum' => ['preparation', 'publisher']]],
            'workflow-source' => ['profile' => ['type' => 'string', 'enum' => ['preparation', 'publisher']], 'filename' => ['type' => 'string'], 'offset' => ['type' => 'integer', 'minimum' => 0], 'max_bytes' => ['type' => 'integer', 'minimum' => 4, 'maximum' => 49152]],
            'workflow-propose' => ['profile' => ['type' => 'string', 'enum' => ['preparation', 'publisher']], 'proposed_rule' => ['type' => 'string', 'maxLength' => 1600], 'evidence' => ['type' => 'string', 'maxLength' => 1000]],
            'workflow-experience' => ['profile' => ['type' => 'string', 'enum' => ['preparation', 'publisher']], 'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 20]],
            'workflow-experience-record' => ['profile' => ['type' => 'string', 'enum' => ['preparation', 'publisher']], 'action' => ['type' => 'string', 'maxLength' => 50], 'outcome' => ['type' => 'string', 'enum' => ['completed','partial','blocked']], 'product_id' => ['type' => 'integer', 'minimum' => 0], 'observation' => ['type' => 'string', 'maxLength' => 700], 'evidence' => ['type' => 'string', 'maxLength' => 500]],
            'workflow-task-finalize' => ['profile' => ['type' => 'string', 'enum' => ['preparation', 'publisher']], 'task_id' => ['type' => 'string', 'maxLength' => 80], 'action' => ['type' => 'string', 'maxLength' => 50], 'outcome' => ['type' => 'string', 'enum' => ['completed','partial','blocked']], 'product_id' => ['type' => 'integer', 'minimum' => 0], 'issue_code' => ['type' => 'string', 'maxLength' => 80], 'resolution_code' => ['type' => 'string', 'maxLength' => 80], 'evidence_hash' => ['type' => 'string', 'maxLength' => 64], 'observation' => ['type' => 'string', 'maxLength' => 700], 'proposed_rule' => ['type' => 'string', 'maxLength' => 1600]],
            'listing-defaults' => ['sku' => ['type' => 'string'], 'stock_quantity' => ['type' => 'integer', 'minimum' => 0]],
        ];
        return ['type' => 'object', 'properties' => $properties[$name] ?? [], 'additionalProperties' => true];
    }

    private static function product_fields(): array {
        $id = ['type' => 'integer', 'minimum' => 1];
        return [
            'type' => ['type' => 'string', 'enum' => ['simple','variable']],
            'name' => ['type' => 'string'], 'slug' => ['type' => 'string'],
            'category_ids' => ['type' => 'array', 'items' => ['type' => 'integer']],
            'colors' => ['type' => 'array', 'description' => 'Colour objects or names. A verified images[].color automatically selects its first image as the product-specific swatch unless a colour explicitly sets swatch_image_id, swatch_image_index, or mode=color.', 'items' => ['type' => ['object','string'], 'properties' => ['name' => ['type' => 'string'], 'hex' => ['type' => 'string'], 'swatch_image_id' => $id, 'swatch_image_index' => ['type' => 'integer', 'minimum' => 0], 'mode' => ['type' => 'string', 'enum' => ['image','color']]]]],
            'sizes' => ['type' => 'array', 'items' => ['type' => 'string']],
            'size_attribute' => ['type' => 'string', 'description' => 'Verified global size taxonomy for this product.'],
            'color_attribute' => ['type' => 'string', 'description' => 'Verified global colour taxonomy for this product, such as pa_colour, pa_polo-shirt-color or pa_solid-color. Use the exact taxonomy returned by catalog/preparation; omit only when the configured default is correct.'],
            'color_supplier_skus' => ['type' => 'object', 'additionalProperties' => ['type' => 'string'], 'description' => 'One confirmed supplier code keyed by colour name; gallery views do not create extra supplier codes.'],
            'image_ids' => ['type' => 'array', 'items' => ['type' => 'integer']],
            'upsell_ids' => ['type' => 'array', 'items' => ['type' => 'integer']],
            'cross_sell_ids' => ['type' => 'array', 'items' => ['type' => 'integer']],
            'upsell_skus' => ['type' => 'array', 'items' => ['type' => 'string']],
            'cross_sell_skus' => ['type' => 'array', 'items' => ['type' => 'string']],
            'regular_price' => ['type' => 'string'], 'sale_price' => ['type' => 'string'], 'selling_price' => ['type' => 'string', 'description' => 'Optional alias for the explicitly supplied lower sale price when regular_price is also supplied.'],
            'sku' => ['type' => 'string'], 'stock_quantity' => ['type' => 'integer', 'minimum' => 0],
            'stock_status' => ['type' => 'string', 'enum' => ['instock','outofstock','onbackorder'], 'description' => 'Availability without a quantity; do not invent a count.'],
            'brand' => ['type' => 'string'], 'label_brand' => ['type' => 'string'],
            'label_image_id' => ['type' => 'integer'], 'label_verified' => ['type' => 'boolean'],
            'description' => ['type' => 'string'], 'short_description' => ['type' => 'string'],
            'tags' => ['type' => 'array', 'items' => ['type' => 'string']],
            'seo' => ['type' => 'object', 'properties' => [
                'title' => ['type' => 'string'], 'meta_title' => ['type' => 'string'],
                'description' => ['type' => 'string'], 'meta_description' => ['type' => 'string'],
                'focus_keyphrase' => ['type' => 'string'], 'keyphrase' => ['type' => 'string'],
                'secondary_keyphrases' => ['type' => 'array', 'items' => ['type' => 'string']],
            ]], 'facts' => ['type' => 'object'],
        ];
    }

    public static function admin_menu(): void {
        add_submenu_page('edit.php?post_type=product', 'AI Product Publisher', 'AI Product Publisher', 'manage_options', self::ADMIN_PAGE, [self::class, 'admin_page']);
    }

    public static function admin_assets(): void {
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($page !== self::ADMIN_PAGE || !current_user_can('manage_options')) return;
        wp_enqueue_style('dreminex-suite-admin', plugins_url('../assets/suite-admin.css', __FILE__), [], DREMINEX_SUITE_VERSION . '-ui5');
        wp_enqueue_style('dreminex-ai-workflows', plugins_url('../assets/ai-workflow-projects.css', __FILE__), ['dreminex-suite-admin'], DREMINEX_SUITE_VERSION . '-publisher-ui2');
        wp_enqueue_script('dreminex-ai-workflows', plugins_url('../assets/ai-workflow-projects.js', __FILE__), [], DREMINEX_SUITE_VERSION . '-publisher-ui2', true);
    }

    private static function page_link(string $tab = 'overview', array $extra = []): string {
        return add_query_arg(array_merge(['post_type' => 'product', 'page' => self::ADMIN_PAGE, 'tab' => $tab], $extra), admin_url('edit.php'));
    }

    public static function admin_page(): void {
        if (!current_user_can('manage_options')) wp_die('Access denied.', 403);
        $tabs = ['overview' => 'Overview', 'workflows' => 'Workflow Projects', 'abilities' => 'Abilities & Access', 'listing' => 'Listing Controls', 'help' => 'Help & Release'];
        $tab = sanitize_key(wp_unslash($_GET['tab'] ?? 'overview'));
        if (!isset($tabs[$tab])) $tab = 'overview';
        $config = self::config();
        $modules = (array)get_option('dreminex_suite_modules', []);
        $module_active = !empty($modules['ai_product_publisher']);
        $enabled_count = count(array_filter(array_keys(self::operations()), static fn($name) => self::ability_enabled($name)));
        echo '<div class="wrap dreminex-suite ds-publisher-app"><h1 class="screen-reader-text">AI Product Publisher</h1>';
        echo '<header class="ds-publisher-hero"><div><span class="ds-eyebrow">DREMINEX FASHION · WOOCOMMERCE PRODUCTS</span><div class="ds-publisher-title" role="heading" aria-level="1">AI Product Publisher</div><p>Prepare, validate and apply complete product handoffs with controlled abilities, accurate variation mapping and verified readback.</p></div><div class="ds-publisher-hero-status"><span class="ds-state '.($module_active?'is-on':'is-off').'">'.($module_active?'Module on':'Module off').'</span><strong>v'.esc_html(DREMINEX_SUITE_VERSION).'</strong></div></header>';
        if (isset($_GET['saved'])) echo '<div class="notice notice-success inline"><p>AI Product Publisher settings saved. Ability registration updates on the next request.</p></div>';
        echo '<nav class="ds-publisher-tabs" aria-label="AI Product Publisher sections">';
        foreach ($tabs as $key => $label) echo '<a '.($tab === $key ? 'aria-current="page" ' : '').'href="'.esc_url(self::page_link($key)).'">'.esc_html($label).'</a>';
        echo '</nav>';
        if ($tab === 'overview') {
            echo '<section class="ds-publisher-kpis"><article><span>Available abilities</span><strong>'.esc_html((string)$enabled_count).' <small>/ '.count(self::operations()).'</small></strong><p>After individual switches and the server access policy.</p></article><article><span>Variation capacity</span><strong>'.esc_html((string)$config['max_variation_rows']).'</strong><p>Rows per product · hard maximum '.self::MAX_VARIATION_ROWS.'</p></article><article><span>Server access</span><strong>'.esc_html($config['ability_access_mode'] === 'full_access' ? 'Full access' : 'Read only').'</strong><p>New products stay Draft unless Publish is explicit.</p></article></section>';
            echo '<section class="ds-publisher-grid"><article class="ds-publisher-card"><span class="ds-card-number">01</span><h2>One-pass Preparation</h2><p>Builds one evidence ledger, checks identity collisions and produces the complete handoff without product or media writes.</p><a class="button" href="'.esc_url(self::page_link('workflows', ['project' => 'preparation'])).'">Open Preparation files</a></article><article class="ds-publisher-card"><span class="ds-card-number">02</span><h2>Safe prerequisites</h2><p>Separates genuine external blockers from declared global-attribute and supplied-media setup that Publisher can resolve.</p><code>dreminex-products/handoff-preflight</code></article><article class="ds-publisher-card"><span class="ds-card-number">03</span><h2>Execute &amp; verify</h2><p>Locks the site, resolves safe setup, applies or resumes in batches of '.self::VARIATION_BATCH_SIZE.' and compares the exact readback.</p><code>dreminex-products/handoff-execute</code></article></section>';
            echo '<section class="ds-publisher-notice"><strong>Advanced Hybrid operating path</strong><p>Use <code>handoff-execute</code> for a complete handoff. Hard blockers perform zero product writes; safe prerequisites are resolved before a fresh preflight. New listings remain Draft unless Publish is explicit.</p></section>';
        } elseif ($tab === 'workflows') {
            Dreminex_AI_Workflow_Projects::render();
        } elseif ($tab === 'abilities') {
            self::render_abilities_settings($config);
        } elseif ($tab === 'listing') {
            self::render_listing_settings($config);
        } else {
            self::render_help();
        }
        echo '</div>';
    }

    private static function render_abilities_settings(array $config): void {
        echo '<section class="ds-publisher-section"><div class="ds-section-copy"><span class="ds-eyebrow">SERVER POLICY</span><h2>Abilities &amp; access</h2><p>Every ability can be turned on or off. Read only registers discovery, preflight and verification abilities while withholding every WordPress write ability.</p></div>';
        echo '<div class="ds-permission-grid"><article><strong>Default</strong><span>ChatGPT client guidance</span><p>Commands normally run in the client sandbox. WordPress cannot force this client setting.</p></article><article><strong>Auto-review</strong><span>ChatGPT client guidance</span><p>The client may review elevated requests automatically. WordPress cannot enable it.</p></article><article class="'.($config['ability_access_mode']==='read_only'?'is-active':'').'"><strong>Read only</strong><span>Server enforced</span><p>Write abilities are not registered and cannot execute.</p></article><article class="'.($config['ability_access_mode']==='full_access'?'is-active':'').'"><strong>Full access</strong><span>Server enforced</span><p>Enabled abilities may run under WordPress and WooCommerce capabilities.</p></article></div>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="ds-publisher-form ds-abilities-form"><input type="hidden" name="action" value="dreminex_publisher_settings"><input type="hidden" name="settings_section" value="abilities">';
        wp_nonce_field('dreminex_publisher_settings');
        echo '<fieldset><legend>Server access mode</legend><label class="ds-access-choice"><input type="radio" name="settings[ability_access_mode]" value="read_only" '.checked($config['ability_access_mode'], 'read_only', false).'><span><strong>Read only</strong><small>Safe for inspection, preparation support, preflight and readback.</small></span></label><label class="ds-access-choice"><input type="radio" name="settings[ability_access_mode]" value="full_access" '.checked($config['ability_access_mode'], 'full_access', false).'><span><strong>Full access</strong><small>Allows enabled write abilities when the connected account has permission.</small></span></label></fieldset>';
        $groups = [];
        foreach (self::operations() as $name => $definition) $groups[self::ability_group($name)][$name] = $definition;
        foreach ($groups as $group => $abilities) {
            echo '<fieldset class="ds-ability-group"><legend>'.esc_html($group).'</legend><div class="ds-ability-list">';
            foreach ($abilities as $name => [$description]) {
                $annotations = self::ability_annotations($name);
                $on = !array_key_exists($name, $config['ability_states']) || !empty($config['ability_states'][$name]);
                echo '<label class="ds-ability-row"><input type="checkbox" name="settings[ability_states]['.esc_attr($name).']" value="1" '.checked($on, true, false).'><span><span class="ds-ability-title"><code>'.esc_html(self::NAMESPACE.'/'.$name).'</code><em>'.($annotations['readonly']?'Read':'Write').'</em>'.($annotations['destructive']?'<em class="is-risk">Destructive</em>':'').'</span><small>'.esc_html($description).'</small></span></label>';
            }
            echo '</div></fieldset>';
        }
        submit_button('Save ability access');
        echo '</form></section>';
    }

    private static function render_listing_settings(array $config): void {
        echo '<section class="ds-publisher-section"><div class="ds-section-copy"><span class="ds-eyebrow">LISTING POLICY</span><h2>Listing controls</h2><p>These values are enforced by both handoff preflight and the create/update layer.</p></div>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="ds-publisher-form"><input type="hidden" name="action" value="dreminex_publisher_settings"><input type="hidden" name="settings_section" value="listing">';
        wp_nonce_field('dreminex_publisher_settings');
        echo '<fieldset><legend>Capacity and media</legend><div class="ds-publisher-fields"><label><span>Variation rows per product</span><input type="number" min="1" max="'.self::MAX_VARIATION_ROWS.'" name="settings[max_variation_rows]" value="'.esc_attr((string)$config['max_variation_rows']).'" required><small>Default 64 · hard maximum '.self::MAX_VARIATION_ROWS.' · no silent truncation.</small></label><label><span>Maximum image size (MB)</span><input type="number" min="1" max="30" name="settings[max_upload_mb]" value="'.esc_attr((string)$config['max_upload_mb']).'" required></label></div></fieldset>';
        echo '<fieldset><legend>Catalog mapping</legend><div class="ds-publisher-fields">';
        foreach (['color_attribute' => 'Global colour taxonomy', 'size_attribute' => 'Global size taxonomy'] as $field => $label) echo '<label><span>'.esc_html($label).'</span><input type="text" name="settings['.esc_attr($field).']" value="'.esc_attr($config[$field]).'" required><small>Existing WooCommerce attribute taxonomy (pa_…)</small></label>';
        echo '</div><p class="description">Each colour uses one representative original product image as its swatch. Other verified views of that colour stay in the ordered gallery.</p></fieldset>';
        echo '<fieldset><legend>SKU and inventory</legend><div class="ds-publisher-fields"><label><span>SKU prefixes</span><input type="text" name="settings[sku_prefix]" maxlength="144" value="'.esc_attr($config['sku_prefix']).'" required><small>Each prefix may contain up to 24 visible characters. Separate alternatives with / — for example DRX-SBB- / DRX-RSK-.</small></label></div>';
        self::checkbox('auto_sku','Generate a unique SKU when none is supplied',$config);
        self::checkbox('require_stock_for_variants','Flag variations without a stock quantity during audit',$config);
        echo '</fieldset><fieldset><legend>Product safeguards</legend>';
        self::checkbox('auto_terms','Create missing global colour and size terms',$config);
        self::checkbox('brand_from_label','Use a verified image-label brand ahead of the supplied brand',$config);
        self::checkbox('require_image_match','Require verified colour mapping for variation images',$config);
        self::checkbox('allow_publish','Allow audited Drafts to be published when explicitly requested',$config);
        echo '<p class="description">Complete handoffs require professional short/long descriptions, title/slug/tags and core SEO. New products remain Draft unless Publish is explicit.</p></fieldset>';
        submit_button('Save listing controls'); echo '</form></section>';
    }

    private static function render_help(): void {
        echo '<section class="ds-publisher-section"><div class="ds-section-copy"><span class="ds-eyebrow">RELEASE '.esc_html(DREMINEX_SUITE_VERSION).'</span><h2>Help &amp; release workflow</h2><p>The bundled A-to-Z handoff is the maintenance source of truth for this module.</p></div><div class="ds-publisher-grid"><article class="ds-publisher-card"><h3>1. Change</h3><p>Update code, ability schema, settings and the affected live workflow source together.</p></article><article class="ds-publisher-card"><h3>2. Validate</h3><p>Lint locally, test capacity boundaries on staging, then compare normalized preflight data with saved readback.</p></article><article class="ds-publisher-card"><h3>3. Release</h3><p>Update the A-to-Z handoff, changelog, validation evidence, rollback notes and SHA-256 checksums in the same release.</p></article></div><div class="ds-publisher-notice"><strong>Client permission note</strong><p>Default and Auto-review belong to the ChatGPT/Codex client. This WordPress module enforces its own Read only or Full access policy and standard account capabilities.</p></div></section>';
    }

    public static function settings_panel($module): void {
        if ($module !== 'ai_product_publisher' || !current_user_can('manage_options')) return;
        $config = self::config();
        echo '<section class="ds-publisher ds-publisher-route"><h3>AI Product Publisher dashboard</h3><p>The full dashboard now lives under <strong>Products → AI Product Publisher</strong>. Variation capacity is currently <strong>'.esc_html((string)$config['max_variation_rows']).'</strong> rows and server access is <strong>'.esc_html($config['ability_access_mode'] === 'full_access' ? 'Full access' : 'Read only').'</strong>.</p><a class="button button-primary" href="'.esc_url(self::page_link()).'">Open AI Product Publisher</a></section>';
    }

    private static function checkbox(string $field, string $label, array $config): void {
        echo '<label class="ds-publisher-check"><input type="checkbox" name="settings['.esc_attr($field).']" value="1" '.checked((bool)$config[$field], true, false).'><span>'.esc_html($label).'</span></label>';
    }

    public static function save_settings(): void {
        if (!current_user_can('manage_options')) { wp_die('Access denied.', 403); }
        check_admin_referer('dreminex_publisher_settings');
        $input = isset($_POST['settings']) && is_array($_POST['settings']) ? wp_unslash($_POST['settings']) : [];
        $config = self::config();
        $section = sanitize_key(wp_unslash($_POST['settings_section'] ?? 'listing'));
        if ($section === 'abilities') {
            $mode = sanitize_key((string)($input['ability_access_mode'] ?? ''));
            if (!in_array($mode, ['read_only','full_access'], true)) wp_die('Choose Read only or Full access.', 400);
            $config['ability_access_mode'] = $mode;
            $submitted = is_array($input['ability_states'] ?? null) ? $input['ability_states'] : [];
            $states = [];
            foreach (array_keys(self::operations()) as $name) $states[$name] = empty($submitted[$name]) ? 0 : 1;
            $config['ability_states'] = $states;
            update_option(self::OPTION, $config, false);
            wp_safe_redirect(self::page_link('abilities', ['saved' => 'abilities']), 303); exit;
        }
        foreach (['color_attribute','size_attribute'] as $field) {
            $candidate = sanitize_key($input[$field] ?? '');
            if (!str_starts_with($candidate, 'pa_') || !taxonomy_exists($candidate)) { wp_die('Choose an existing WooCommerce attribute taxonomy.', 400); }
            $config[$field] = $candidate;
        }
        if ($config['color_attribute'] === $config['size_attribute']) { wp_die('Color and size taxonomies must differ.', 400); }
        $limit = absint($input['max_upload_mb'] ?? 0);
        if ($limit < 1 || $limit > 30) { wp_die('Image limit must be 1–30 MB.', 400); }
        $config['max_upload_mb'] = $limit;
        $variation_limit = absint($input['max_variation_rows'] ?? 0);
        if ($variation_limit < 1 || $variation_limit > self::MAX_VARIATION_ROWS) wp_die('Variation row limit must be between 1 and '.self::MAX_VARIATION_ROWS.'.', 400);
        $config['max_variation_rows'] = $variation_limit;
        $config['optional_prompt_seconds'] = 0; // Legacy option; prepared listings never prompt for optional fields.
        $prefixes=self::parse_prefixes((string)($input['sku_prefix']??''));
        if(is_wp_error($prefixes))wp_die(esc_html($prefixes->get_error_message()),400);
        $config['sku_prefix']=implode(' / ',$prefixes);$config['sku_prefixes']=$prefixes;$config['default_sku_prefix']=$prefixes[0];
        foreach (['auto_terms','auto_sku','brand_from_label','require_image_match','require_stock_for_variants','allow_publish'] as $field) { $config[$field] = empty($input[$field]) ? 0 : 1; }
        update_option(self::OPTION, $config, false);
        wp_safe_redirect(self::page_link('listing', ['saved' => 'listing']), 303); exit;
    }

    private static function fail(string $message, string $code = 'invalid_product'): WP_Error {
        return new WP_Error($code, $message);
    }

    private static function variation_capacity_error(int $count): WP_Error {
        $limit = self::variation_capacity();
        return new WP_Error(
            'variation_capacity_exceeded',
            sprintf('This handoff contains %d variation rows, but the current site limit is %d (hard maximum %d). Increase the dashboard limit or reduce the confirmed offered rows; nothing was saved.', $count, $limit, self::MAX_VARIATION_ROWS),
            ['variation_count' => $count, 'configured_limit' => $limit, 'hard_limit' => self::MAX_VARIATION_ROWS]
        );
    }

    private static function expand_variation_rows(array $input, array $rows) {
        if ($rows || empty($input['full_matrix'])) return $rows;
        $colors = [];
        foreach ((array)($input['colors'] ?? []) as $color) {
            $name = is_array($color) ? trim((string)($color['name'] ?? '')) : trim((string)$color);
            if ($name === '') return self::fail('A confirmed full matrix needs every colour name.', 'missing_matrix_options');
            $colors[] = $name;
        }
        $sizes = [];
        foreach ((array)($input['sizes'] ?? []) as $size) {
            $name = is_array($size) ? trim((string)($size['name'] ?? '')) : trim((string)$size);
            if ($name === '') return self::fail('A confirmed full matrix needs every size name.', 'missing_matrix_options');
            $sizes[] = $name;
        }
        if (!$colors || !$sizes) return self::fail('A confirmed full matrix needs named colours and sizes.', 'missing_matrix_options');
        $expanded = [];
        foreach ($colors as $color) {
            foreach ($sizes as $size) {
                $row = ['color' => $color, 'size' => $size];
                foreach (['regular_price','sale_price','stock_status'] as $field) {
                    if (array_key_exists($field, $input)) $row[$field] = $input[$field];
                }
                $expanded[] = $row;
            }
        }
        return $expanded;
    }

    private static function validate_variation_capacity(string $type, array $rows, bool $required) {
        if ($type === 'simple' && $rows) return self::fail('A Simple product must not include variation rows.', 'type_conflict');
        if ($type === 'variable' && $required && !$rows) return self::fail('A Variable Create handoff needs at least one confirmed offered variation row.', 'missing_variants');
        if (count($rows) > self::variation_capacity()) return self::variation_capacity_error(count($rows));
        return true;
    }

    /** Reject malformed or duplicate rows before a product write. */
    private static function validate_variation_rows_input(array $rows, array $input) {
        $seen = [];
        foreach ($rows as $index => $row) {
            if (!is_array($row)) return self::fail("Variation {$index} must be an object.", 'invalid_variant');
            $color = sanitize_title((string)($row['color'] ?? ''));
            $size = sanitize_title((string)($row['size'] ?? ''));
            $key = $color . '|' . $size;
            if ($color === '' || $size === '' || isset($seen[$key])) {
                return self::fail("Variation {$index} needs one nonempty, unique colour/size pair.", 'duplicate_variant');
            }
            $seen[$key] = true;
            $regular = wc_format_decimal($row['regular_price'] ?? $input['regular_price'] ?? '');
            $sale = wc_format_decimal($row['sale_price'] ?? $input['sale_price'] ?? '');
            if ($regular === '' || (float)$regular <= 0 || ($sale !== '' && (float)$sale >= (float)$regular)) {
                return self::fail("Variation {$index} has invalid prices.", 'invalid_variant_price');
            }
            if (isset($row['image_index'])) {
                $image_index = filter_var($row['image_index'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
                if ($image_index === false) return self::fail("Variation {$index} has an invalid image index.", 'invalid_image_index');
                $sources = array_key_exists('images', $input) ? $input['images'] : ($input['image_ids'] ?? []);
                if (!is_array($sources) || !array_key_exists($image_index, $sources)) {
                    return self::fail("Variation {$index} image index does not resolve in the supplied ordered images.", 'invalid_image_index');
                }
            }
            if (isset($row['stock_status']) && !in_array(strtolower(str_replace(' ', '', (string)$row['stock_status'])), ['instock','outofstock','onbackorder'], true)) {
                return self::fail("Variation {$index} has an invalid stock status.", 'invalid_stock');
            }
            if (isset($row['supplier_sku']) && is_wp_error(self::supplier_code($row['supplier_sku']))) {
                return self::fail("Variation {$index} has an invalid supplier SKU.", 'invalid_supplier_sku');
            }
        }
        return true;
    }

    private static function normalize_seo($seo): array {
        if (!is_array($seo)) return [];
        if (empty($seo['title']) && !empty($seo['meta_title'])) $seo['title'] = $seo['meta_title'];
        if (empty($seo['description']) && !empty($seo['meta_description'])) $seo['description'] = $seo['meta_description'];
        if (empty($seo['focus_keyphrase']) && !empty($seo['keyphrase'])) $seo['focus_keyphrase'] = $seo['keyphrase'];
        unset($seo['meta_title'], $seo['meta_description'], $seo['keyphrase']);
        return $seo;
    }

    private static function exact_h3_matches_name(string $html, string $name): bool {
        if (!preg_match('/\A\s*<h3\b[^>]*>(.*?)<\/h3>/isu', $html, $match)) return false;
        $heading = html_entity_decode(wp_strip_all_tags($match[1]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $expected = html_entity_decode(wp_strip_all_tags($name), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return trim(preg_replace('/\s+/u', ' ', $heading)) === trim(preg_replace('/\s+/u', ' ', $expected));
    }

    private static function customer_copy_violation(array $input): string {
        $seo=self::normalize_seo($input['seo']??[]);$parts=[(string)($input['name']??''),(string)($input['short_description']??''),(string)($input['description']??''),(string)($seo['title']??''),(string)($seo['description']??''),implode(' ',array_map('strval',(array)($input['tags']??[])))];
        foreach((array)($input['images']??[]) as $image)if(is_array($image)){$parts[]=(string)($image['alt']??'');$parts[]=(string)($image['title']??'');}
        $text=html_entity_decode(wp_strip_all_tags(implode("\n",$parts)),ENT_QUOTES|ENT_HTML5,'UTF-8');
        return preg_match('/\b(?:supplier|wholesale(?:r)?|resell(?:er|kori)?|drop\s*ship(?:ping)?|sourcing|procurement|shopbasebd)\b|https?:\/\//iu',$text)?'Customer-facing content exposes supplier, sourcing, reseller or internal source information. Keep it only in private operational metadata.':'';
    }

    private static function scoped_handoff_preflight(array $handoff, string $site): ?array {
        if (($handoff['scope'] ?? '') !== 'short_description_and_description_only') return null;
        $errors = [];
        if (empty($handoff['site_url']) || untrailingslashit(esc_url_raw((string)$handoff['site_url'])) !== $site) $errors[] = 'The handoff site_url does not match this connected WordPress site.';
        $id = absint($handoff['product_id'] ?? 0);
        $product = $id ? wc_get_product($id) : null;
        if (!$product || !in_array($product->get_status(), ['draft','publish'], true)) $errors[] = 'A scoped description update requires an existing Draft or Published product ID.';
        $short = trim((string)($handoff['short_description'] ?? ''));
        $long = trim((string)($handoff['description'] ?? ''));
        if ($short === '' || $long === '') $errors[] = 'Both short_description and description are required for this scoped update.';
        if($message=self::customer_copy_violation($handoff))$errors[]=$message;
        $name = trim((string)($handoff['product_name'] ?? ($product ? $product->get_name() : '')));
        if ($long !== '' && $name !== '' && !self::exact_h3_matches_name($long, $name)) $errors[] = 'The long description must begin with one H3 containing the exact product name.';
        $parameters = $errors ? null : ['mode' => 'update', 'product_id' => $id, 'short_description' => $short, 'description' => $long];
        return [
            'ready' => !$errors, 'scope' => 'short_description_and_description_only',
            'next_action' => $errors ? 'return_to_preparation' : 'apply_and_verify',
            'errors' => $errors, 'warnings' => [], 'listing_parameters' => $parameters,
            'normalized_variation_count' => 0,
            'variation_capacity' => ['configured_limit' => self::variation_capacity(), 'hard_limit' => self::MAX_VARIATION_ROWS],
            'checked_site' => home_url('/'),
        ];
    }

    private static function taxonomy(string $type): string {
        return self::config()[$type . '_attribute'];
    }

    /** Resolve this product's own global colour taxonomy; do not assume all garments use pa_solid-color. */
    private static function color_taxonomy(?WC_Product $product = null, array $input = []) {
        $requested = sanitize_key((string)($input['color_attribute'] ?? ''));
        $saved = $product ? sanitize_key((string)get_post_meta($product->get_id(), '_dreminex_ai_color_taxonomy', true)) : '';
        $attributes = $product ? $product->get_attributes() : [];
        if ($requested === '' && $saved !== '') { $requested = $saved; }
        if ($requested === '' && isset($attributes[self::taxonomy('color')])) { $requested = self::taxonomy('color'); }
        if ($requested === '' && $product) {
            $candidates = [];
            foreach ($attributes as $name => $attribute) {
                if (!$attribute->is_taxonomy()) { continue; }
                $label = function_exists('wc_attribute_label') ? wc_attribute_label($name) : $name;
                if (preg_match('/colou?r|\\bshade\\b|রং/u', $name . ' ' . $label)) { $candidates[] = $name; }
            }
            $candidates = array_values(array_unique($candidates));
            if (count($candidates) === 1) { $requested = $candidates[0]; }
            elseif (count($candidates) > 1) { return self::fail('Several global colour attributes exist; specify color_attribute in the handoff.', 'ambiguous_color_attribute'); }
        }
        if ($requested === '' && !$product) { $requested = self::taxonomy('color'); }
        if ($requested === '' && $product) { return ''; }
        if ($requested === '' || !str_starts_with($requested, 'pa_') || !taxonomy_exists($requested) || self::attribute_id($requested) < 1) {
            return self::fail('A verified global colour attribute is required for this product.', 'missing_color_attribute');
        }
        if ($product && !isset($attributes[$requested])) {
            return self::fail('The selected global colour attribute is not assigned to this product.', 'missing_color_attribute');
        }
        return $requested;
    }

    /** Preserve existing attribute choices, with an explicit override for a new product or safe migration. */
    private static function size_taxonomy(?WC_Product $product = null, array $input = []) {
        $requested = sanitize_key((string)($input['size_attribute'] ?? ''));
        if ($requested !== '') {
            $color_tax = self::color_taxonomy($product, $input);
            if (!str_starts_with($requested, 'pa_') || !taxonomy_exists($requested) || self::attribute_id($requested) < 1
                || (!is_wp_error($color_tax) && $requested === $color_tax)
                || !preg_match('/size|মাপ/u', $requested . ' ' . wc_attribute_label($requested))) {
                return self::fail('Choose an existing WooCommerce global size attribute.', 'invalid_size_attribute');
            }
            return $requested;
        }
        if ($product) {
            $saved = sanitize_key((string)get_post_meta($product->get_id(), '_dreminex_ai_size_taxonomy', true));
            if ($saved && taxonomy_exists($saved) && self::attribute_id($saved) > 0) { return $saved; }
            $attributes = $product->get_attributes();
            $default = self::taxonomy('size');
            if (isset($attributes[$default])) { return $default; }
            foreach ($attributes as $name => $attribute) {
                if (str_starts_with($name, 'pa_') && str_contains($name, 'size') && $attribute->get_variation()) { return $name; }
            }
        }
        return self::taxonomy('size');
    }

    private static function has_womens_category(array $ids): bool {
        foreach ($ids as $id) {
            $term = get_term((int)$id, 'product_cat');
            while ($term && !is_wp_error($term)) {
                if (preg_match('/women|ladies/i', $term->slug . ' ' . $term->name)) { return true; }
                $term = $term->parent ? get_term((int)$term->parent, 'product_cat') : null;
            }
        }
        return false;
    }

    private static function check_size_category(array $input, ?WC_Product $product = null) {
        if (empty($input['sizes']) && empty($input['size_attribute']) && !$product) { return true; }
        $taxonomy = self::size_taxonomy($product, $input);
        if (is_wp_error($taxonomy)) { return $taxonomy; }
        $categories = array_key_exists('category_ids', $input) ? array_map('absint', (array)$input['category_ids']) : ($product ? $product->get_category_ids() : []);
        $women = self::has_womens_category($categories) || (bool)preg_match('/women|ladies/i', implode(' ', (array)($input['category_names'] ?? [])));
        $attributes = $product ? $product->get_attributes() : [];
        if (preg_match('/(?:^|[-_])men[-_]size$/', $taxonomy) && $women && (!empty($input['sizes']) || isset($attributes[$taxonomy]))) {
            return self::fail('Women’s sizes need an explicit non-men size_attribute from the selected site.', 'size_attribute_required');
        }
        return true;
    }

    private static function attribute_id(string $taxonomy): int {
        return (int)wc_attribute_taxonomy_id_by_name(preg_replace('/^pa_/', '', $taxonomy));
    }

    private static function is_color_taxonomy(string $taxonomy): bool {
        $label = function_exists('wc_attribute_label') ? wc_attribute_label($taxonomy) : $taxonomy;
        return (bool)preg_match('/colou?r|\\bshade\\b|রং/u', $taxonomy . ' ' . $label);
    }

    private static function term(string $taxonomy, string $name, ?string $hex = null, array &$warnings = []) {
        $name = trim($name);
        if ($name === '' || !taxonomy_exists($taxonomy)) { return self::fail('Invalid attribute taxonomy or term.'); }
        $term = get_term_by('name', $name, $taxonomy);
        if (!$term) { $term = get_term_by('slug', sanitize_title($name), $taxonomy); }
        $hex = $hex ? sanitize_hex_color($hex) : null;
        if ($hex && self::is_color_taxonomy($taxonomy) && $term) {
            $current = get_term_meta($term->term_id, 'product_attribute_color', true);
            if (strtolower((string)$current) !== strtolower($hex)) {
                if (empty(self::config()['auto_terms'])) { return self::fail('Exact HEX swatch is missing: ' . $name, 'missing_term'); }
                $suffix = strtoupper(substr($hex, 1));
                $unique_slug = sanitize_title($name) . '-' . strtolower($suffix);
                $separate = get_term_by('slug', $unique_slug, $taxonomy);
                if (!$separate) {
                    $created = wp_insert_term($name . ' (' . $suffix . ')', $taxonomy, ['slug' => $unique_slug]);
                    if (is_wp_error($created)) { return $created; }
                    $separate = get_term((int)$created['term_id'], $taxonomy);
                    update_term_meta($separate->term_id, 'product_attribute_color', $hex);
                    update_term_meta($separate->term_id, '_dreminex_ai_base_color_name', $name);
                    $warnings[] = sprintf('Created separate %s swatch %s; shared %s swatch remains unchanged.', $name, $hex, (string)$current);
                } elseif (strtolower((string)get_term_meta($separate->term_id, 'product_attribute_color', true)) !== strtolower($hex)) {
                    return self::fail('Existing HEX-specific slug has a different swatch value.', 'swatch_conflict');
                }
                return $separate;
            }
        }
        if (!$term) {
            if (empty(self::config()['auto_terms'])) { return self::fail('Missing global term: ' . $name, 'missing_term'); }
            $created = wp_insert_term($name, $taxonomy, ['slug' => sanitize_title($name)]);
            if (is_wp_error($created)) { return $created; }
            $term = get_term((int)$created['term_id'], $taxonomy);
            if ($hex && self::is_color_taxonomy($taxonomy)) { update_term_meta($term->term_id, 'product_attribute_color', $hex); }
        }
        return $term;
    }

    private static function base_color($term): string {
        return (string)(get_term_meta($term->term_id, '_dreminex_ai_base_color_name', true) ?: $term->name);
    }

    public static function catalog(array $input): array {
        $config = self::config();
        $result = ['config' => $config, 'categories' => [], 'attributes' => [], 'available_size_attributes' => [], 'available_color_attributes' => [], 'duplicate' => null];
        foreach ((array)wc_get_attribute_taxonomies() as $attribute) {
            $entry = ['taxonomy' => wc_attribute_taxonomy_name($attribute->attribute_name), 'label' => $attribute->attribute_label, 'id' => (int)$attribute->attribute_id];
            if (stripos($attribute->attribute_name . ' ' . $attribute->attribute_label, 'size') !== false) { $result['available_size_attributes'][] = $entry; }
            if (preg_match('/colou?r|shade|রং/u', $attribute->attribute_name . ' ' . $attribute->attribute_label)) { $result['available_color_attributes'][] = $entry; }
        }
        foreach (get_terms(['taxonomy' => 'product_cat', 'hide_empty' => false]) as $term) {
            $result['categories'][] = ['id' => $term->term_id, 'name' => $term->name, 'parent' => $term->parent];
        }
        foreach (['color', 'size'] as $kind) {
            $taxonomy = self::taxonomy($kind);
            $result['attributes'][$kind] = ['taxonomy' => $taxonomy, 'id' => self::attribute_id($taxonomy), 'terms' => []];
            if (taxonomy_exists($taxonomy)) {
                foreach (get_terms(['taxonomy' => $taxonomy, 'hide_empty' => false]) as $term) {
                    $result['attributes'][$kind]['terms'][] = ['id' => $term->term_id, 'name' => $term->name, 'slug' => $term->slug, 'hex' => get_term_meta($term->term_id, 'product_attribute_color', true)];
                }
            }
        }
        if (!empty($input['slug'])) {
            $post = get_page_by_path(sanitize_title($input['slug']), OBJECT, 'product');
            $result['duplicate'] = $post ? ['id' => $post->ID, 'status' => $post->post_status, 'title' => $post->post_title] : null;
        }
        return $result;
    }

    /** Exact identity candidates for Preparation and a final Create collision guard. */
    private static function exact_product_identity_matches(string $name, string $slug): array {
        $statuses = ['publish', 'draft', 'pending', 'private', 'future'];
        $fields_by_id = [];
        foreach ([['title', trim($name)], ['name', sanitize_title($slug)]] as [$field, $value]) {
            if ($value === '') { continue; }
            $query = [
                'post_type' => 'product', 'post_status' => $statuses, 'posts_per_page' => 20,
                'fields' => 'ids', 'no_found_rows' => true, 'orderby' => 'ID', 'order' => 'DESC',
                'update_post_meta_cache' => false, 'update_post_term_cache' => false,
                $field => $value,
            ];
            foreach (get_posts($query) as $raw_id) {
                $id = absint($raw_id);
                if (!$id) { continue; }
                $fields_by_id[$id] = $fields_by_id[$id] ?? [];
                $fields_by_id[$id][] = $field === 'title' ? 'name' : 'slug';
            }
        }
        $matches = [];
        foreach ($fields_by_id as $id => $fields) {
            $product = wc_get_product((int)$id);
            if (!$product) { continue; }
            $matches[] = [
                'id' => (int)$id, 'name' => $product->get_name(),
                'slug' => (string)get_post_field('post_name', (int)$id),
                'status' => $product->get_status(), 'matched_on' => array_values(array_unique($fields)),
            ];
        }
        return $matches;
    }

    /** One bounded, read-only site snapshot for Preparation; visual identity is never inferred. */
    public static function preparation_snapshot(array $input): array {
        $name = trim(sanitize_text_field((string)($input['name'] ?? '')));
        $slug_value = trim((string)($input['slug'] ?? ''));
        $slug = sanitize_title($slug_value !== '' ? $slug_value : $name);
        $sku = sanitize_text_field((string)($input['sku'] ?? ''));
        $catalog = self::catalog($slug ? ['slug' => $slug] : []);
        $size_taxonomy = sanitize_key((string)($input['size_attribute'] ?? ''));
        $size_terms = [];
        if ($size_taxonomy && taxonomy_exists($size_taxonomy) && str_starts_with($size_taxonomy, 'pa_')) {
            $terms = get_terms(['taxonomy' => $size_taxonomy, 'hide_empty' => false]);
            if (!is_wp_error($terms)) {
                foreach ($terms as $term) { $size_terms[] = ['id' => (int)$term->term_id, 'name' => $term->name, 'slug' => $term->slug]; }
            }
        }
        $category_ids = array_values(array_unique(array_filter(array_map('absint', array_slice((array)($input['category_ids'] ?? []), 0, 5)))));
        $search = trim(sanitize_text_field((string)($input['related_search'] ?? '')));
        $search = function_exists('mb_substr') ? mb_substr($search, 0, 120) : substr($search, 0, 120);
        $related = [];
        if ($category_ids || $search !== '') {
            $args = ['post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => max(1, min(12, absint($input['related_limit'] ?? 8))),
                'fields' => 'ids', 'no_found_rows' => true, 'orderby' => 'date', 'order' => 'DESC'];
            if ($search !== '') { $args['s'] = $search; }
            if ($category_ids) { $args['tax_query'] = [['taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => $category_ids]]; }
            foreach (get_posts($args) as $id) {
                $product = wc_get_product($id);
                if (!$product || $product->get_status() !== 'publish' || !current_user_can('edit_post', $id)) { continue; }
                $related[] = ['id' => (int)$id, 'name' => $product->get_name(), 'sku' => $product->get_sku(),
                    'price' => $product->get_price(), 'permalink' => get_permalink($id)];
            }
        }
        return ['site_url' => home_url('/'), 'catalog' => $catalog,
            'product_identity_matches' => ($name !== '' || $slug !== '') ? self::exact_product_identity_matches($name, $slug ?: sanitize_title($name)) : [],
            'exact_parent_sku_product_id' => $sku !== '' ? (int)wc_get_product_id_by_sku($sku) : null,
            'requested_size_attribute' => $size_taxonomy ?: null, 'requested_size_terms' => $size_terms,
            'media' => self::media_candidates(['page' => max(1, absint($input['media_page'] ?? 1)),
                'per_page' => max(1, min(80, absint($input['media_per_page'] ?? 60)))]),
            'related_candidates' => $related,
            'note' => 'Read-only candidates. product_identity_matches reports exact product-title and slug collisions, not a reason to update. Inspect original photos against every SKU-bearing screenshot and verify related-product relevance before hand-off. Page media further if uploads are older.'];
    }

    /** Deterministic, read-only new-product identity planning for Preparation. */
    public static function identity_plan(array $input) {
        $proposed = trim(sanitize_text_field((string)($input['proposed_name'] ?? '')));
        if ($proposed === '' || strlen($proposed) > 180) return self::fail('Supply a proposed product name of at most 180 characters.', 'invalid_product_name');
        $differentiators = [];
        foreach (array_slice((array)($input['differentiators'] ?? []), 0, 8) as $value) {
            $value = trim(sanitize_text_field((string)$value));
            if ($value !== '' && strlen($value) <= 80 && strcasecmp($value, $proposed) !== 0) $differentiators[strtolower($value)] = $value;
        }
        $seed = trim((string)($input['supplier_source_url'] ?? '')) . '|' . strtolower((string)($input['evidence_sha256'] ?? '')) . '|' . home_url('/') . '|' . $proposed;
        $stable = strtoupper(substr(hash('sha256', $seed), 0, 6));
        $candidates = [$proposed];
        foreach ($differentiators as $value) $candidates[] = $proposed . ' – ' . $value;
        if (count($differentiators) > 1) $candidates[] = $proposed . ' – ' . implode(' ', array_slice(array_values($differentiators), 0, 2));
        $selected_name = ''; $selected_slug = ''; $collisions = [];
        foreach (array_values(array_unique($candidates)) as $candidate) {
            $slug = sanitize_title($candidate);
            $matches = self::exact_product_identity_matches($candidate, $slug);
            if (!$matches) { $selected_name = $candidate; $selected_slug = $slug; break; }
            $collisions[] = ['name' => $candidate, 'slug' => $slug, 'matches' => $matches];
        }
        if ($selected_name === '') {
            $selected_name = $proposed . ' – ' . $stable;
            $selected_slug = sanitize_title($selected_name);
            if (self::exact_product_identity_matches($selected_name, $selected_slug)) return self::fail('A distinct factual product identity could not be planned automatically.', 'identity_collision_unresolved');
        }
        $configured=self::config();$prefixInput=(string)($input['sku_prefix']??$configured['default_sku_prefix']);
        $prefixList=self::parse_prefixes($prefixInput);if(is_wp_error($prefixList))return $prefixList;
        $prefix=$prefixList[0];$token=self::short_sku_token($selected_name,$stable);
        $base_sku = rtrim($prefix, '-') . '-' . $token;
        $sku = $base_sku;
        $sku_collisions = [];
        $owner = (int)wc_get_product_id_by_sku($sku);
        if ($owner) { $sku_collisions[] = $owner; $sku = substr($base_sku, 0, 92) . '-' . $stable; }
        for ($suffix = 2; ($owner = (int)wc_get_product_id_by_sku($sku)) && $suffix <= 99; $suffix++) {
            $sku_collisions[] = $owner;
            $sku = substr($base_sku, 0, 96) . '-' . str_pad((string)$suffix, 2, '0', STR_PAD_LEFT);
        }
        if ((int)wc_get_product_id_by_sku($sku)) return self::fail('A unique parent SKU could not be planned automatically.', 'sku_collision_unresolved');
        return [
            'site_url' => home_url('/'), 'mode' => 'draft', 'product_id' => null,
            'name' => $selected_name, 'slug' => $selected_slug, 'sku' => $sku, 'sku_prefix' => $prefix,
            'identity_collisions_checked' => $collisions, 'sku_collision_product_ids' => array_values(array_unique($sku_collisions)),
            'stable_suffix' => $stable, 'ready_for_preparation' => true,
            'rule' => 'Create remains a new Draft. The selected name, slug and parent SKU are distinct on this site at read time; preflight rechecks them before write.',
        ];
    }

    public static function category_ensure(array $input) {
        $name = trim(sanitize_text_field((string)($input['name'] ?? '')));
        $parent = absint($input['parent_id'] ?? 0);
        if ($name === '' || strlen($name) > 120) { return self::fail('Supply a category name.', 'invalid_category'); }
        if ($parent && !term_exists($parent, 'product_cat')) { return self::fail('Parent category does not exist.', 'invalid_category'); }
        $slug = sanitize_title((string)($input['slug'] ?? $name));
        if (!$slug) { return self::fail('Category slug is invalid.', 'invalid_category'); }
        $existing = get_term_by('slug', $slug, 'product_cat');
        if ($existing) {
            if ((int)$existing->parent !== $parent || strcasecmp($existing->name, $name) !== 0) {
                return self::fail('Category slug is already used by a different name or parent.', 'category_conflict');
            }
            return ['id' => (int)$existing->term_id, 'name' => $existing->name, 'slug' => $existing->slug, 'parent_id' => (int)$existing->parent, 'created' => false];
        }
        $same_name = get_terms(['taxonomy' => 'product_cat', 'name' => $name, 'parent' => $parent, 'hide_empty' => false]);
        if (!is_wp_error($same_name) && $same_name) {
            $term = reset($same_name);
            return ['id' => (int)$term->term_id, 'name' => $term->name, 'slug' => $term->slug, 'parent_id' => (int)$term->parent, 'created' => false];
        }
        $created = wp_insert_term($name, 'product_cat', ['slug' => $slug, 'parent' => $parent, 'description' => sanitize_textarea_field((string)($input['description'] ?? ''))]);
        if (is_wp_error($created)) { return $created; }
        return ['id' => (int)$created['term_id'], 'name' => $name, 'slug' => $slug, 'parent_id' => $parent, 'created' => true];
    }

    private static function register_attribute_taxonomy_for_request(string $taxonomy, string $label): void {
        if (taxonomy_exists($taxonomy)) return;
        register_taxonomy($taxonomy, apply_filters('woocommerce_taxonomy_objects_' . $taxonomy, ['product']), apply_filters('woocommerce_taxonomy_args_' . $taxonomy, [
            'labels' => ['name' => $label, 'singular_name' => $label, 'menu_name' => $label, 'all_items' => 'All ' . $label, 'edit_item' => 'Edit ' . $label, 'update_item' => 'Update ' . $label, 'add_new_item' => 'Add new ' . $label, 'new_item_name' => 'New ' . $label],
            'hierarchical' => true, 'show_ui' => false, 'query_var' => true, 'rewrite' => false,
            'public' => false, 'show_in_nav_menus' => false, 'show_admin_column' => false,
            'capabilities' => ['manage_terms' => 'manage_product_terms', 'edit_terms' => 'edit_product_terms', 'delete_terms' => 'delete_product_terms', 'assign_terms' => 'assign_product_terms'],
        ]));
    }

    /** Exact and idempotent global attribute/term setup for an authorized Publisher prerequisite. */
    public static function attribute_ensure(array $input) {
        $label = trim(sanitize_text_field((string)($input['label'] ?? '')));
        $raw_slug = sanitize_title(preg_replace('/^pa_/', '', (string)($input['slug'] ?? $label)));
        $type = sanitize_key((string)($input['type'] ?? 'select')) ?: 'select';
        $handoff_hash = strtolower(trim((string)($input['handoff_hash'] ?? '')));
        if ($label === '' || strlen($label) > 100 || $raw_slug === '' || strlen($raw_slug) > 28) return self::fail('Attribute label and a valid slug of at most 28 characters are required.', 'invalid_attribute');
        if ($handoff_hash !== '' && !preg_match('/^[a-f0-9]{64}$/D', $handoff_hash)) return self::fail('The authorizing handoff hash is invalid.', 'invalid_handoff_hash');
        $allowed_types = function_exists('wc_get_attribute_types') ? array_keys((array)wc_get_attribute_types()) : ['select'];
        if (!in_array($type, $allowed_types, true)) return self::fail('The requested WooCommerce attribute type is unavailable.', 'invalid_attribute_type');
        $taxonomy = wc_attribute_taxonomy_name($raw_slug);
        $record = null;
        foreach ((array)wc_get_attribute_taxonomies() as $attribute) {
            if (sanitize_title((string)$attribute->attribute_name) === $raw_slug) { $record = $attribute; break; }
        }
        $created = false;
        if ($record) {
            if (strcasecmp((string)$record->attribute_label, $label) !== 0 || (string)$record->attribute_type !== $type) {
                return self::fail('Attribute slug already belongs to a different label or type.', 'attribute_conflict');
            }
            $attribute_id = (int)$record->attribute_id;
        } else {
            $attribute_id = wc_create_attribute(['name' => $label, 'slug' => $raw_slug, 'type' => $type, 'order_by' => 'menu_order', 'has_archives' => false]);
            if (is_wp_error($attribute_id)) return $attribute_id;
            $attribute_id = (int)$attribute_id; $created = true;
            delete_transient('wc_attribute_taxonomies');
            if (class_exists('WC_Cache_Helper')) WC_Cache_Helper::invalidate_cache_group('woocommerce-attributes');
        }
        self::register_attribute_taxonomy_for_request($taxonomy, $label);
        if (!taxonomy_exists($taxonomy)) return self::fail('The global attribute exists but its taxonomy could not be registered for this operation.', 'attribute_taxonomy_unavailable');
        $term_results = [];
        foreach (array_values(array_unique(array_filter(array_map(static fn($term) => trim(sanitize_text_field((string)$term)), (array)($input['terms'] ?? []))))) as $name) {
            if (strlen($name) > 100) return self::fail('Attribute term names must be at most 100 characters.', 'invalid_attribute_term');
            $term = get_term_by('name', $name, $taxonomy) ?: get_term_by('slug', sanitize_title($name), $taxonomy);
            $term_created = false;
            if (!$term) {
                $inserted = wp_insert_term($name, $taxonomy, ['slug' => sanitize_title($name)]);
                if (is_wp_error($inserted)) return $inserted;
                $term = get_term((int)$inserted['term_id'], $taxonomy); $term_created = true;
            }
            $term_results[] = ['id' => (int)$term->term_id, 'name' => $term->name, 'slug' => $term->slug, 'created' => $term_created];
        }
        return ['attribute_id' => $attribute_id, 'taxonomy' => $taxonomy, 'label' => $label, 'type' => $type, 'created' => $created, 'terms' => $term_results, 'handoff_hash' => $handoff_hash ?: null, 'verified' => self::attribute_id($taxonomy) === $attribute_id && taxonomy_exists($taxonomy)];
    }

    public static function media_find(array $input) {
        global $wpdb;
        $names = $input['filenames'] ?? [];
        if (!is_array($names) || !$names || count($names) > 40) { return self::fail('Supply 1–40 exact image filenames.'); }
        $incoming = wp_normalize_path(wp_get_upload_dir()['basedir'] . '/dreminex-ai-incoming');
        $result = [];
        foreach ($names as $name) {
            $filename = basename((string)$name);
            if ($filename === '' || !preg_match('/\.(jpe?g|png|webp)$/i', $filename)) { return self::fail('Supply JPEG, PNG or WebP filenames.'); }
            $query = $wpdb->prepare(
                "SELECT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} m ON m.post_id=p.ID WHERE p.post_type='attachment' AND p.post_mime_type LIKE 'image/%%' AND m.meta_key='_wp_attached_file' AND m.meta_value LIKE %s ORDER BY p.ID DESC LIMIT 15",
                '%' . $wpdb->esc_like($filename)
            );
            $images = [];
            foreach ($wpdb->get_col($query) as $id) {
                if (basename((string)get_attached_file((int)$id)) !== $filename) { continue; }
                $images[] = ['id' => (int)$id, 'url' => wp_get_attachment_url((int)$id), 'alt' => get_post_meta((int)$id, '_wp_attachment_image_alt', true)];
            }
            $result[] = ['filename' => $filename, 'media' => $images, 'incoming' => is_file($incoming . '/' . $filename)];
        }
        return ['images' => $result, 'hint' => 'Reuse an exact Media Library attachment ID; if incoming is true call media-import. Otherwise transfer the image to the incoming folder first. Chat attachments do not appear there automatically.'];
    }

    /** Candidate images are bounded and belong to this WordPress site. No media metadata is changed. */
    public static function media_candidates(array $input) {
        $page = max(1, min(1000, absint($input['page'] ?? 1)));
        $per_page = max(1, min(100, absint($input['per_page'] ?? 60)));
        $search = sanitize_text_field((string)($input['search'] ?? ''));
        $query = new WP_Query(['post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image',
            'posts_per_page' => $per_page, 'paged' => $page, 'orderby' => 'ID', 'order' => 'DESC',
            's' => $search, 'fields' => 'ids', 'no_found_rows' => false]);
        $items = [];
        foreach ($query->posts as $id) {
            if (!current_user_can('edit_post', $id) || !wp_attachment_is_image($id)) { continue; }
            $items[] = self::media_candidate((int)$id);
        }
        return ['page' => $page, 'pages' => (int)$query->max_num_pages, 'total' => (int)$query->found_posts,
            'candidates' => $items, 'verified' => false];
    }

    private static function media_candidate(int $id): array {
        $thumb = wp_get_attachment_image_src($id, 'thumbnail');
        $path = get_attached_file($id);
        return ['image_id' => $id, 'url' => wp_get_attachment_url($id), 'thumbnail_url' => $thumb ? $thumb[0] : null,
            'filename' => $path ? basename($path) : null, 'title' => get_the_title($id), 'uploaded' => get_post_time('c', true, $id)];
    }

    /** 64-bit horizontal difference hash; useful for ranking, never proof of identity. */
    private static function visual_hash($image): string {
        $resized = imagecreatetruecolor(9, 8);
        imagecopyresampled($resized, $image, 0, 0, 0, 0, 9, 8, imagesx($image), imagesy($image));
        $bits = '';
        for ($y = 0; $y < 8; $y++) {
            for ($x = 0; $x < 8; $x++) {
                $left = imagecolorat($resized, $x, $y);
                $right = imagecolorat($resized, $x + 1, $y);
                $luma_left = (($left >> 16) & 255) * 299 + (($left >> 8) & 255) * 587 + ($left & 255) * 114;
                $luma_right = (($right >> 16) & 255) * 299 + (($right >> 8) & 255) * 587 + ($right & 255) * 114;
                $bits .= $luma_left > $luma_right ? '1' : '0';
            }
        }
        imagedestroy($resized);
        return $bits;
    }

    private static function visual_source(int $id) {
        $path = get_attached_file($id);
        $meta = wp_get_attachment_metadata($id);
        // WordPress thumbnails can be square crops; medium preserves the original framing.
        $medium = is_array($meta) ? ($meta['sizes']['medium']['file'] ?? '') : '';
        $candidate = $path && $medium ? dirname($path) . '/' . basename($medium) : '';
        if ($candidate && is_readable($candidate)) { $path = $candidate; }
        if (!$path || !is_readable($path) || filesize($path) > 12 * 1024 * 1024) { return false; }
        // Large originals without a medium derivative can exhaust PHP memory and request time.
        $dimensions = @getimagesize($path);
        if (!$dimensions || $dimensions[0] * $dimensions[1] > 6000000) { return false; }
        $bytes = file_get_contents($path);
        return $bytes === false ? false : @imagecreatefromstring($bytes);
    }

    public static function media_visual_match(array $input) {
        if (!extension_loaded('gd')) { return self::fail('GD is required for visual matching.', 'gd_unavailable'); }
        $encoded = (string)($input['reference_base64'] ?? '');
        $hash = (string)($input['reference_dhash'] ?? '');
        if (($encoded === '') === ($hash === '')) {
            return self::fail('Supply exactly one cropped reference image or a 64-bit dHash.', 'invalid_reference');
        }
        if ($hash !== '' && !preg_match('/^[01]{64}$/D', $hash)) {
            return self::fail('Reference dHash must contain exactly 64 bits.', 'invalid_reference');
        }
        if ($encoded !== '') {
            if (strlen($encoded) > 2800000 || preg_match('/[^A-Za-z0-9+\/=]/', $encoded)) {
                return self::fail('Supply a cropped JPEG/PNG/WebP reference image under 2 MB.', 'invalid_reference');
            }
            $bytes = base64_decode($encoded, true);
            $info = $bytes === false ? false : @getimagesizefromstring($bytes);
            if ($bytes === false || strlen($bytes) > 2 * 1024 * 1024 || !$info
                || !in_array($info['mime'], ['image/jpeg','image/png','image/webp'], true)
                || $info[0] * $info[1] > 6000000) {
                return self::fail('Reference image bytes are invalid or too large.', 'invalid_reference');
            }
            $reference = @imagecreatefromstring($bytes);
            if (!$reference) { return self::fail('Reference image could not be decoded.', 'invalid_reference'); }
            $hash = self::visual_hash($reference);
            imagedestroy($reference);
        }
        $ids = $input['candidate_ids'] ?? null;
        if ($ids !== null && (!is_array($ids) || !$ids || count($ids) > 40)) {
            return self::fail('Supply 1–40 attachment IDs.', 'invalid_candidates');
        }
        if ($ids === null) {
            $page = max(1, min(1000, absint($input['page'] ?? 1)));
            $per_page = max(1, min(40, absint($input['per_page'] ?? 30)));
            $query = new WP_Query(['post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image',
                'posts_per_page' => $per_page, 'paged' => $page, 'orderby' => 'ID', 'order' => 'DESC',
                'fields' => 'ids', 'no_found_rows' => false]);
            $ids = $query->posts;
            $pages = (int)$query->max_num_pages;
        } else { $page = 1; $pages = 1; }
        $ranked = []; $skipped = 0;
        foreach (array_unique(array_map('absint', $ids)) as $id) {
            if (!$id || !current_user_can('edit_post', $id) || !wp_attachment_is_image($id)) { $skipped++; continue; }
            $source = self::visual_source($id);
            if (!$source) { $skipped++; continue; }
            $candidate_hash = self::visual_hash($source);
            imagedestroy($source);
            $distance = 0;
            for ($bit = 0; $bit < 64; $bit++) { $distance += $hash[$bit] !== $candidate_hash[$bit] ? 1 : 0; }
            $ranked[] = ['distance' => $distance] + self::media_candidate($id);
        }
        usort($ranked, static fn($a, $b) => ($a['distance'] <=> $b['distance']) ?: ($b['image_id'] <=> $a['image_id']));
        return ['page' => $page, 'pages' => $pages, 'inspected' => count($ranked), 'skipped' => $skipped,
            'matches' => array_slice($ranked, 0, max(1, min(10, absint($input['limit'] ?? 5)))),
            'verified' => false, 'note' => 'Ranking is only a suggestion. Compare the actual attachment with the screenshot, product design, colour and supplier code before handoff.'];
    }

    public static function media_import(array $input) {
        $relative = ltrim((string)($input['path'] ?? ''), '/');
        $basename = basename($relative);
        if (!$basename || !preg_match('/\.(jpe?g|png|webp)$/i', $basename)) { return self::fail('A JPEG, PNG, or WebP file is required.'); }
        $uploads = wp_get_upload_dir();
        $incoming = wp_normalize_path($uploads['basedir'] . '/dreminex-ai-incoming');
        $path = realpath($incoming . '/' . $basename);
        if (!$path || !str_starts_with(wp_normalize_path($path), $incoming . '/') || !is_file($path)) { return self::fail('File is not in the dedicated incoming directory.'); }
        if ((int)filesize($path) > (int)self::config()['max_upload_mb'] * 1048576) { return self::fail('Image exceeds configured size limit.'); }
        $info = @getimagesize($path);
        if (!$info || !in_array($info['mime'], ['image/jpeg', 'image/png', 'image/webp'], true)) { return self::fail('Invalid image bytes.'); }
        $expected = wp_check_filetype($basename)['type'];
        if ($expected !== $info['mime']) { return self::fail('Image filename and MIME type differ.'); }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        $id = media_handle_sideload(['name' => $basename, 'type' => $info['mime'], 'tmp_name' => $path, 'error' => 0, 'size' => filesize($path)], 0, sanitize_text_field($input['title'] ?? pathinfo($basename, PATHINFO_FILENAME)));
        if (is_wp_error($id)) { return $id; }
        update_post_meta($id, '_wp_attachment_image_alt', sanitize_text_field($input['alt'] ?? ''));
        return ['id' => $id, 'url' => wp_get_attachment_url($id), 'alt' => get_post_meta($id, '_wp_attachment_image_alt', true), 'width' => $info[0], 'height' => $info[1]];
    }

    private static function import_bytes(string $filename, string $bytes, array $input) {
        $filename = sanitize_file_name(basename($filename));
        if (!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9._-]*\.(jpe?g|png|webp)$/i', $filename)) { return self::fail('A color-named JPEG, PNG or WebP filename is required.', 'invalid_image'); }
        $max = (int)self::config()['max_upload_mb'] * 1048576;
        if ($bytes === '' || strlen($bytes) > $max) { return self::fail('Image is empty or exceeds the configured size limit.', 'invalid_image'); }
        $info = @getimagesizefromstring($bytes);
        if (!$info || !in_array($info['mime'], ['image/jpeg','image/png','image/webp'], true)
            || $info['mime'] !== wp_check_filetype($filename)['type'] || $info[0] > 10000 || $info[1] > 10000) {
            return self::fail('Invalid image bytes, dimensions or file extension.', 'invalid_image');
        }
        $incoming = wp_get_upload_dir()['basedir'] . '/dreminex-ai-incoming';
        if (!wp_mkdir_p($incoming)) { return self::fail('Incoming image folder is not writable.', 'upload_failed'); }
        $filename = wp_unique_filename($incoming, $filename);
        $path = $incoming . '/' . $filename;
        if (file_put_contents($path, $bytes, LOCK_EX) !== strlen($bytes)) { @unlink($path); return self::fail('Could not save image before import.', 'upload_failed'); }
        $imported = self::media_import(['path' => $filename, 'alt' => $input['alt'] ?? '', 'title' => $input['title'] ?? pathinfo($filename, PATHINFO_FILENAME)]);
        if (is_wp_error($imported)) { @unlink($path); }
        return $imported;
    }

    public static function media_upload(array $input) {
        $encoded = (string)($input['content_base64'] ?? '');
        if ($encoded === '' || strlen($encoded) > ((int)self::config()['max_upload_mb'] * 1398102) + 16) { return self::fail('Base64 image is empty or exceeds the configured size limit.', 'invalid_image'); }
        $bytes = base64_decode($encoded, true);
        if ($bytes === false) { return self::fail('Invalid base64 image bytes.', 'invalid_image'); }
        return self::import_bytes((string)($input['filename'] ?? ''), $bytes, $input);
    }

    /** Batch import avoids a separate connector round trip for every color. */
    public static function media_batch_upload(array $input) {
        $images = $input['images'] ?? null;
        if (!is_array($images) || count($images) < 1 || count($images) > 10) { return self::fail('Supply 1–10 images.', 'invalid_image_batch'); }
        $total = 0;
        foreach ($images as $entry) {
            if (!is_array($entry)) { return self::fail('Each image must be an object.', 'invalid_image_batch'); }
            $sources = 0;
            foreach (['content_base64','incoming_path','url','image_id'] as $source) { $sources += isset($entry[$source]) && $entry[$source] !== '' ? 1 : 0; }
            if ($sources !== 1) { return self::fail('Every image needs exactly one source: bytes, incoming path, HTTPS URL, or an existing image ID.', 'invalid_image_batch'); }
            if (empty($entry['image_id']) && empty($entry['url']) && empty($entry['filename'])) { return self::fail('Imported images need a filename.', 'invalid_image_batch'); }
            $total += strlen((string)($entry['content_base64'] ?? ''));
        }
        if ($total > 40 * 1048576) { return self::fail('Batch base64 payload exceeds 40 MB; split it into smaller calls.', 'invalid_image_batch'); }
        $done = [];
        foreach ($images as $index => $entry) {
            $result = null;
            if (isset($entry['image_id'])) {
                $id = self::checked_image($entry['image_id']);
                $result = is_wp_error($id) ? $id : ['id' => $id, 'url' => wp_get_attachment_url($id), 'reused' => true];
            } elseif (isset($entry['url']) && empty($entry['import_external'])) {
                $result = self::resolve_media_url((string)$entry['url']);
            } else {
                $filename = sanitize_file_name(basename((string)($entry['filename'] ?? wp_parse_url((string)($entry['url'] ?? ''), PHP_URL_PATH))));
                if (!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9._-]*\.(jpe?g|png|webp)$/i', $filename)) { $result = self::fail('Invalid color-named image filename.', 'invalid_image'); }
                if (!$result && isset($entry['content_base64'])) {
                    $encoded = (string)$entry['content_base64'];
                    $limit = (int)self::config()['max_upload_mb'] * 1398102 + 16;
                    $bytes = strlen($encoded) <= $limit ? base64_decode($encoded, true) : false;
                    $result = $bytes === false ? self::fail('Invalid or oversized image bytes.', 'invalid_image') : self::find_matching_image($filename, $bytes);
                    if ($result === null) { $result = self::import_bytes($filename, $bytes, $entry); }
                } elseif (!$result && isset($entry['incoming_path'])) {
                    if (basename((string)$entry['incoming_path']) !== $filename) { $result = self::fail('Incoming path and color filename must match.', 'invalid_image'); }
                    else { $result = self::media_import(['path' => $filename, 'alt' => $entry['alt'] ?? '', 'title' => $entry['title'] ?? '']); }
                } elseif (!$result) {
                    $result = self::media_url_import($entry);
                }
            }
            if (is_wp_error($result)) {
                return ['partial' => true, 'image_ids' => array_column($done, 'id'), 'images' => $done, 'failed_index' => $index, 'error_code' => $result->get_error_code(), 'error' => $result->get_error_message(), 'resume' => 'Retry from failed_index using the returned image_ids. Reuse them as image_id entries; do not reupload successful files.'];
            }
            $done[] = ['index' => $index, 'filename' => $entry['filename'] ?? '', 'id' => $result['id'], 'url' => $result['url'], 'reused' => !empty($result['reused']), 'resolved_by' => $result['resolved_by'] ?? (isset($entry['image_id']) ? 'image_id' : 'import')];
        }
        return ['partial' => false, 'image_ids' => array_column($done, 'id'), 'images' => $done];
    }

    private static function find_matching_image(string $filename, string $bytes): ?array {
        $found = self::media_find(['filenames' => [$filename]]);
        if (is_wp_error($found)) { return null; }
        $digest = hash('sha256', $bytes);
        foreach ($found['images'][0]['media'] ?? [] as $candidate) {
            $path = get_attached_file((int)$candidate['id']);
            if ($path && is_file($path) && hash_file('sha256', $path) === $digest) {
                return ['id' => $candidate['id'], 'url' => $candidate['url'], 'reused' => true];
            }
        }
        return null;
    }

    /** Resolve only an attachment already belonging to this WordPress uploads directory. Never fetch a URL. */
    private static function resolve_media_url(string $url) {
        global $wpdb;
        $url = html_entity_decode(trim($url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $parts = wp_parse_url($url);
        $uploads = wp_get_upload_dir();
        $base = wp_parse_url($uploads['baseurl']);
        if (!is_array($parts) || !is_array($base) || !in_array(strtolower((string)($parts['scheme'] ?? '')), ['https','http'], true)
            || strcasecmp((string)($parts['host'] ?? ''), (string)($base['host'] ?? '')) !== 0
            || (int)($parts['port'] ?? 0) !== (int)($base['port'] ?? 0)
            || !empty($parts['user']) || !empty($parts['pass'])) {
            return self::fail('Media URL is not on the selected site.', 'media_url_not_in_target_library');
        }
        $path = rawurldecode((string)($parts['path'] ?? ''));
        $prefix = rtrim(rawurldecode((string)($base['path'] ?? '')), '/') . '/';
        if (!str_starts_with($path, $prefix) || str_contains($path, '\\') || preg_match('~(?:^|/)\.{1,2}(?:/|$)|[\x00-\x1f]~', $path)) {
            return self::fail('Invalid uploads path.', 'invalid_media_url');
        }
        $relative = substr($path, strlen($prefix));
        if (!$relative || !preg_match('/\.(jpe?g|png|webp)$/i', $relative)) { return self::fail('An image Media URL is required.', 'invalid_media_url'); }
        $canonical = rtrim($uploads['baseurl'], '/') . '/' . implode('/', array_map('rawurlencode', explode('/', $relative)));
        $candidates = [];
        $native = attachment_url_to_postid($canonical);
        if (!$native) { $native = attachment_url_to_postid(rtrim($uploads['baseurl'], '/') . '/' . $relative); }
        if ($native) { $candidates[] = (int)$native; }
        $exact = $wpdb->get_col($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_wp_attached_file' AND meta_value=%s", $relative));
        $candidates = array_merge($candidates, array_map('intval', $exact));
        // WP-generated thumbnails and scaled originals resolve only through verified attachment metadata.
        if (!$candidates) {
            $filename = basename($relative);
            $stem = pathinfo($filename, PATHINFO_FILENAME);
            $stem = preg_replace('/-(?:[0-9]+x[0-9]+|scaled)$/', '', $stem);
            $directory = dirname($relative);
            $common = explode('-', $stem);
            $common = implode('-', array_slice($common, 0, min(5, count($common))));
            $like = ($directory === '.' ? '' : $directory . '/') . $common;
            $ids = $wpdb->get_col($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_wp_attached_file' AND meta_value LIKE %s LIMIT 40", $wpdb->esc_like($like) . '%'));
            foreach ($ids as $candidate) {
                $attached = (string)get_post_meta((int)$candidate, '_wp_attached_file', true);
                if (dirname($attached) !== $directory) { continue; }
                $actual = pathinfo(basename($attached), PATHINFO_FILENAME);
                $normalized = preg_replace('/-(?:[0-9]+x[0-9]+|scaled)$/', '', $actual);
                $requested_tokens = array_unique(explode('-', $stem));
                $actual_tokens = array_unique(explode('-', $normalized));
                $sequence = preg_match('/-([0-9]{2})$/', $stem, $request_match)
                    && preg_match('/-' . preg_quote($request_match[1], '/') . '(?:-[0-9]+)?$/', $normalized);
                $overlap = count(array_intersect($requested_tokens, $actual_tokens));
                if (($normalized === $stem || preg_match('/^' . preg_quote($stem, '/') . '-[0-9]+$/', $normalized)
                    || str_ends_with($normalized, '-' . $stem) || ($sequence && $overlap >= 6))
                    && strtolower(pathinfo($attached, PATHINFO_EXTENSION)) === strtolower(pathinfo($relative, PATHINFO_EXTENSION))) {
                    $candidates[] = (int)$candidate;
                }
            }
        }
        $valid = [];
        $resolved_by = [];
        foreach (array_unique($candidates) as $candidate) {
            $checked = self::checked_image($candidate);
            if (is_wp_error($checked) || !current_user_can('edit_post', $candidate)) { continue; }
            $actual = (string)get_post_meta($candidate, '_wp_attached_file', true);
            if (dirname($actual) !== dirname($relative)) { continue; }
            $metadata = wp_get_attachment_metadata($candidate);
            $subsizes = is_array($metadata) ? array_column((array)($metadata['sizes'] ?? []), 'file') : [];
            if ($actual === $relative || in_array(basename($relative), $subsizes, true)
                || (!$exact && !$native && in_array($candidate, $candidates, true))) {
                $valid[] = $candidate;
                $resolved_by[$candidate] = $actual === $relative ? 'exact' : (in_array(basename($relative), $subsizes, true) ? 'generated_size' : 'verified_fallback');
            }
        }
        if (count($valid) > 1) { return new WP_Error('ambiguous_media_url', 'Multiple attachments match this Media URL.', ['candidate_ids' => $valid]); }
        if (!$valid) { return self::fail('Media URL was not found in the selected site library.', 'media_url_not_in_target_library'); }
        return ['id' => $valid[0], 'url' => wp_get_attachment_url($valid[0]), 'reused' => true, 'resolved_by' => $resolved_by[$valid[0]]];
    }

    public static function listing_defaults(array $input): array {
        $config = self::config();
        $missing = [];
        if (!isset($input['sku']) || trim((string)$input['sku']) === '') { $missing[] = 'sku'; }
        if (!array_key_exists('stock_quantity', $input)) { $missing[] = 'stock_quantity'; }
        return [
            'missing_optional' => $missing,
            'prompt_window_seconds' => 0,
            'prompt_is_advisory' => false,
            'defaults' => ['sku' => $config['auto_sku'] ? 'Generate using configured prefix' : 'Leave blank', 'stock_quantity' => 'Do not invent a count; leave unmanaged', 'publication' => 'Draft unless explicitly requested'],
            'variation_capacity' => ['configured_limit' => (int)$config['max_variation_rows'], 'hard_limit' => self::MAX_VARIATION_ROWS, 'batch_size' => self::VARIATION_BATCH_SIZE],
            'ability_access_mode' => $config['ability_access_mode'],
            'instruction' => 'Use supplied prepared fields and proceed without optional questions.',
        ];
    }

    public static function media_url_import(array $input) {
        $url = (string)($input['url'] ?? '');
        if (strtolower((string)wp_parse_url($url, PHP_URL_SCHEME)) !== 'https' || !wp_http_validate_url($url)) { return self::fail('A public HTTPS image URL is required.', 'invalid_image_url'); }
        $response = wp_safe_remote_get($url, ['timeout' => 20, 'redirection' => 2, 'limit_response_size' => ((int)self::config()['max_upload_mb'] * 1048576) + 1]);
        if (is_wp_error($response)) { return $response; }
        if (wp_remote_retrieve_response_code($response) !== 200) { return self::fail('Image URL did not return HTTP 200.', 'image_fetch_failed'); }
        return self::import_bytes((string)($input['filename'] ?? ''), (string)wp_remote_retrieve_body($response), $input);
    }

    public static function media_update(array $input) {
        $id = absint($input['image_id'] ?? 0);
        if (!$id || !wp_attachment_is_image($id) || !current_user_can('edit_post', $id)) { return self::fail('Editable image attachment is required.', 'invalid_image'); }
        $post = ['ID' => $id];
        foreach (['title' => 'post_title', 'caption' => 'post_excerpt', 'description' => 'post_content'] as $field => $key) {
            if (array_key_exists($field, $input)) { $post[$key] = sanitize_text_field((string)$input[$field]); }
        }
        if (array_key_exists('slug', $input)) {
            $slug = sanitize_title((string)$input['slug']);
            if ($slug === '' || wp_unique_post_slug($slug, $id, 'inherit', 'attachment', 0) !== $slug) {
                return self::fail('Attachment slug is empty or already in use.', 'media_slug_conflict');
            }
            $post['post_name'] = $slug;
        }
        if (count($post) > 1) {
            $saved = wp_update_post($post, true);
            if (is_wp_error($saved)) { return $saved; }
        }
        if (array_key_exists('alt', $input)) { update_post_meta($id, '_wp_attachment_image_alt', sanitize_text_field((string)$input['alt'])); }
        $updated = get_post($id);
        return ['image_id' => $id, 'url' => wp_get_attachment_url($id), 'title' => $updated->post_title, 'slug' => $updated->post_name, 'caption' => $updated->post_excerpt, 'description' => $updated->post_content, 'alt' => get_post_meta($id, '_wp_attachment_image_alt', true)];
    }

    private static function checked_image($id) {
        $id = absint($id);
        $file = $id ? get_attached_file($id) : false;
        return $id && get_post_type($id) === 'attachment' && wp_attachment_is_image($id) && $file && is_file($file)
            && in_array(get_post_mime_type($id), ['image/jpeg','image/png','image/webp'], true)
            ? $id : self::fail('Image attachment ID is invalid or file is missing.', 'invalid_image');
    }

    private static function image_has_color(int $image_id, string $color): bool {
        $file = get_attached_file($image_id);
        if (!$file) { return false; }
        $stem = sanitize_title(pathinfo($file, PATHINFO_FILENAME));
        $needle = sanitize_title(preg_replace('/\b(and)\b/i', '', $color));
        $stem = preg_replace('/(?:^|-)and(?:-|$)/', '-', $stem);
        return $needle !== '' && (bool)preg_match('/(?:^|-)' . preg_quote($needle, '/') . '(?:-|$)/', $stem);
    }

    private static function image_for_color(array $image_ids, string $color): int {
        foreach ($image_ids as $image_id) {
            if (self::image_has_color((int)$image_id, $color)) { return (int)$image_id; }
        }
        return 0;
    }

    private static function sku(array $input, string $fallback): string {
        $sku = strtoupper(trim(sanitize_text_field((string)($input['sku'] ?? ''))));
        if ($sku === '' && !empty(self::config()['auto_sku'])) {
            $config=self::config();$sku=rtrim($config['default_sku_prefix'],'-').'-'.self::short_sku_token($fallback,strtoupper(substr(hash('sha256',$fallback.'|'.home_url('/')),0,6)));
        }
        return $sku;
    }

    private static function short_sku_token(string $name,string $fallback): string {
        $raw=strtoupper((string)preg_replace('/[^A-Za-z0-9]+/',' ',remove_accents($name)));
        $stop=['THE','AND','FOR','WITH','FROM','STYLE','FASHION','PRODUCT'];$words=[];
        foreach(preg_split('/\s+/',trim($raw)) as $word){if($word===''||in_array($word,$stop,true))continue;$words[]=$word;if(count($words)===3)break;}
        if(!$words)return 'ITEM-'.$fallback;
        $parts=[];foreach($words as $word)$parts[]=strlen($word)<=5?$word:substr($word,0,5);
        $token=implode('-',$parts);return strlen($token)>20?substr($token,0,20):$token;
    }

    /** Supplier codes are input facts, never OCR or guessed from a colour/filename. */
    private static function supplier_code($value) {
        $code = strtoupper(trim(sanitize_text_field((string)$value)));
        if ($code !== '' && (strlen($code) > 40 || !preg_match('/^[A-Z0-9][A-Z0-9._-]*$/', $code))) {
            return self::fail('Supplier SKU must be 1–40 letters, digits, dots, underscores or hyphens.', 'invalid_supplier_sku');
        }
        return $code;
    }

    private static function supplier_color_map(array $input) {
        $map = [];
        if (isset($input['color_supplier_skus']) && !is_array($input['color_supplier_skus'])) {
            return self::fail('Colour supplier SKUs must be an object keyed by colour.', 'invalid_supplier_color_map');
        }
        foreach (($input['color_supplier_skus'] ?? []) as $name => $value) {
            $color = sanitize_title((string)$name);
            $code = self::supplier_code($value);
            if (is_wp_error($code)) { return $code; }
            if ($color === '' || $code === '') { return self::fail('Each colour supplier SKU needs a colour and a confirmed code.', 'invalid_supplier_color_map'); }
            if (isset($map[$color]) && $map[$color] !== $code) { return self::fail('Conflicting supplier SKUs for color ' . $color . '.', 'supplier_sku_color_conflict'); }
            $map[$color] = $code;
        }
        foreach (['colors', 'images'] as $field) {
            foreach (($input[$field] ?? []) as $entry) {
                if (!is_array($entry) || !array_key_exists('supplier_sku', $entry)) { continue; }
                $code = self::supplier_code($entry['supplier_sku']);
                if (is_wp_error($code)) { return $code; }
                if ($code === '') { continue; }
                $color = sanitize_title((string)($field === 'colors' ? ($entry['name'] ?? '') : ($entry['color'] ?? '')));
                if ($color === '') { return self::fail('A supplier SKU needs an explicit matching color.', 'supplier_sku_missing_color'); }
                if (isset($map[$color]) && $map[$color] !== $code) { return self::fail('Conflicting supplier SKUs for color ' . $color . '.', 'supplier_sku_color_conflict'); }
                $map[$color] = $code;
            }
        }
        return $map;
    }

    private static function variation_supplier_sku(string $internal_sku, string $code) {
        if ($internal_sku === '') { return self::fail('An internal child SKU is required before adding a supplier code.', 'missing_variant_sku'); }
        $sku = str_ends_with($internal_sku, '-' . $code) ? $internal_sku : $internal_sku . '-' . $code;
        if (strlen($sku) > 100 || !preg_match('/^[A-Z0-9._-]+$/', $sku)) {
            return self::fail('Composed variation SKU is invalid or exceeds 100 characters.', 'invalid_sku');
        }
        return $sku;
    }

    private static function validate_sku(string $sku, int $current_id = 0) {
        if ($sku === '') { return true; }
        if (strlen($sku) > 100 || !preg_match('/^[A-Z0-9._-]+$/', $sku)) { return self::fail('SKU must use letters, digits, dots, underscores or hyphens (maximum 100 characters).', 'invalid_sku'); }
        $owner = (int)wc_get_product_id_by_sku($sku);
        return $owner && $owner !== $current_id ? self::fail('SKU already belongs to product ' . $owner . '.', 'duplicate_sku') : true;
    }

    private static function stock($product, array $input) {
        if (!array_key_exists('stock_quantity', $input) || $input['stock_quantity'] === null || $input['stock_quantity'] === '') {
            if (!empty($input['manage_stock'])) { return self::fail('Stock quantity is required when stock management is requested.', 'invalid_stock'); }
            if (array_key_exists('stock_status', $input)) {
                if (!in_array($input['stock_status'], ['instock','outofstock','onbackorder'], true)) { return self::fail('Unknown stock status.', 'invalid_stock'); }
                $product->set_manage_stock(false);
                $product->set_stock_status($input['stock_status']);
                $product->set_backorders('no');
            }
            return true;
        }
        $quantity = filter_var($input['stock_quantity'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
        if ($quantity === false) { return self::fail('Stock quantity must be a nonnegative whole number.', 'invalid_stock'); }
        $product->set_manage_stock(true);
        $product->set_stock_quantity($quantity);
        $product->set_stock_status($quantity > 0 ? 'instock' : 'outofstock');
        $product->set_backorders('no');
        return true;
    }

    private static function brand_evidence(array $input, array $image_ids) {
        $label = trim(sanitize_text_field((string)($input['label_brand'] ?? '')));
        if ($label === '') { return null; }
        $image_id = absint($input['label_image_id'] ?? 0);
        if (empty($input['label_verified']) || !$image_id || !in_array($image_id, array_map('intval', $image_ids), true)) {
            return self::fail('Verified label brand requires label_verified=true and a product image attachment ID.', 'unverified_brand');
        }
        return ['name' => $label, 'image_id' => $image_id];
    }

    private static function assign_brand(int $product_id, string $name, ?int $label_image_id = null) {
        if (!taxonomy_exists('product_brand')) { return self::fail('WooCommerce product_brand taxonomy is unavailable.', 'missing_brand_taxonomy'); }
        $name = trim(sanitize_text_field($name));
        if ($name === '' || strlen($name) > 120) { return self::fail('Valid brand name is required.', 'invalid_brand'); }
        $term = get_term_by('name', $name, 'product_brand');
        if (!$term) {
            $created = wp_insert_term($name, 'product_brand');
            if (is_wp_error($created)) { return $created; }
            $term = get_term((int)$created['term_id'], 'product_brand');
        }
        $assigned = wp_set_object_terms($product_id, [(int)$term->term_id], 'product_brand');
        if (is_wp_error($assigned)) { return $assigned; }
        if ($label_image_id) { update_post_meta($product_id, '_dreminex_ai_label_brand_evidence', ['name' => $name, 'image_id' => $label_image_id]); }
        return ['id' => (int)$term->term_id, 'name' => $term->name, 'label_image_id' => $label_image_id];
    }

    public static function draft_create(array $input) {
        $type = $input['type'] ?? '';
        $name = trim((string)($input['name'] ?? ''));
        $slug_value = trim((string)($input['slug'] ?? ''));
        $slug = sanitize_title($slug_value !== '' ? $slug_value : $name);
        if (!in_array($type, ['simple', 'variable'], true) || !$name || !$slug) { return self::fail('Type, name, and slug are required.'); }
        // Fail exact identity collisions; never let WordPress's auto-suffixed slug mask a duplicate.
        if (self::exact_product_identity_matches($name, $slug)) {
            return self::fail('Create stopped because an exact product title or slug already exists. Keep this as a new product: prepare a unique name and slug, then retry. Do not update the matching listing unless the owner explicitly requested an Update.', 'duplicate_product_identity');
        }
        $sku = self::sku($input, $slug);
        $sku_check = self::validate_sku($sku);
        if (is_wp_error($sku_check)) { return $sku_check; }
        if ($type === 'variable' && array_key_exists('stock_quantity', $input)) { return self::fail('Supply stock quantities on each variation, not the variable parent.', 'invalid_stock'); }
        $category_ids = array_map('absint', $input['category_ids'] ?? []);
        foreach ($category_ids as $id) { if (!term_exists($id, 'product_cat')) { return self::fail('Unknown category ID.'); } }
        if (!$category_ids) { return self::fail('At least one explicit category ID is required.'); }
        $size_tax = self::size_taxonomy(null, $input);
        if (is_wp_error($size_tax)) { return $size_tax; }
        $color_tax = self::color_taxonomy(null, $input);
        if (!empty($input['colors']) && is_wp_error($color_tax)) { return $color_tax; }
        $size_check = self::check_size_category($input);
        if (is_wp_error($size_check)) { return $size_check; }
        if ($type === 'variable' && ((!empty($input['colors']) && self::attribute_id($color_tax) < 1)
            || (!empty($input['sizes']) && self::attribute_id($size_tax) < 1))) { return self::fail('Configured global attributes are missing.'); }
        $warnings = [];
        $colors = []; $sizes = [];
        foreach (($input['colors'] ?? []) as $entry) {
            $term = self::term($color_tax, (string)($entry['name'] ?? ''), $entry['hex'] ?? null, $warnings);
            if (is_wp_error($term)) { return $term; }
            $colors[$term->slug] = $term;
        }
        foreach (($input['sizes'] ?? []) as $entry) {
            $term = self::term($size_tax, (string)$entry, null, $warnings);
            if (is_wp_error($term)) { return $term; }
            $sizes[$term->slug] = $term;
        }
        if ($type === 'variable' && !$colors && !$sizes) { return self::fail('Variable listings need at least one selectable colour or size.'); }
        if ($type === 'simple' && (count($colors) > 1 || count($sizes) > 1)) { return self::fail('Several selectable options require a Variable product.', 'simple_size_selection'); }
        $image_ids = [];
        foreach (($input['image_ids'] ?? []) as $id) {
            $checked = self::checked_image($id);
            if (is_wp_error($checked)) { return $checked; }
            $image_ids[] = $checked;
        }
        if ($image_ids && !empty(self::config()['require_image_match'])) {
            foreach ($colors as $color) {
                if (!self::image_for_color($image_ids, self::base_color($color))) { return self::fail('No filename matches color ' . self::base_color($color) . '.', 'image_color_mismatch'); }
            }
        }
        $primary_image = $colors ? self::image_for_color($image_ids, self::base_color(reset($colors))) : 0;
        if (!$primary_image && $image_ids) { $primary_image = $image_ids[0]; }
        $image_ids = $image_ids ? array_values(array_unique(array_merge([$primary_image], $image_ids))) : [];
        $evidence = self::brand_evidence($input, $image_ids);
        if (is_wp_error($evidence)) { return $evidence; }
        $brand_name = $evidence && !empty(self::config()['brand_from_label']) ? $evidence['name'] : trim(sanitize_text_field((string)($input['brand'] ?? '')));
        if ($brand_name === '' && $evidence) { $brand_name = $evidence['name']; }
        if ($brand_name !== '' && !taxonomy_exists('product_brand')) { return self::fail('WooCommerce product_brand taxonomy is unavailable.', 'missing_brand_taxonomy'); }
        $regular = wc_format_decimal($input['regular_price'] ?? '');
        $sale = wc_format_decimal($input['sale_price'] ?? '');
        if (($type === 'simple' && ($regular === '' || (float)$regular <= 0))
            || ($regular !== '' && (float)$regular <= 0)
            || ($sale !== '' && ($regular === '' || (float)$sale >= (float)$regular))) { return self::fail('Regular price must be positive and sale price lower.'); }
        $product = $type === 'variable' ? new WC_Product_Variable() : new WC_Product_Simple();
        $product->set_name(wp_strip_all_tags($name));
        $product->set_slug($slug);
        $product->set_status('draft');
        $product->set_description(wp_kses_post((string)($input['description'] ?? '')));
        $product->set_short_description(wp_kses_post((string)($input['short_description'] ?? '')));
        $product->set_category_ids($category_ids);
        if ($image_ids) { $product->set_image_id($image_ids[0]); }
        $product->set_gallery_image_ids(array_slice($image_ids, 1));
        $product->set_manage_stock(false);
        if ($sku !== '') { $product->set_sku($sku); }
        if ($type === 'simple') {
            $stock = self::stock($product, $input);
            if (is_wp_error($stock)) { return $stock; }
        }
        if ($type === 'simple') { $product->set_regular_price($regular); $product->set_sale_price($sale); }
        $attributes = [];
        foreach (['color' => $colors, 'size' => $sizes] as $kind => $terms) {
            if (!$terms) { continue; }
            $taxonomy = $kind === 'size' ? $size_tax : $color_tax;
            $attribute = new WC_Product_Attribute();
            $attribute->set_id(self::attribute_id($taxonomy));
            $attribute->set_name($taxonomy);
            $attribute->set_options(array_map(static fn($term) => (int)$term->term_id, array_values($terms)));
            $attribute->set_visible(true);
            $attribute->set_variation($type === 'variable');
            $attributes[] = $attribute;
        }
        $has_brand_fact = false;
        foreach (($input['facts'] ?? []) as $label => $value) {
            $label = sanitize_text_field((string)$label);
            $value = sanitize_text_field((string)$value);
            if (strcasecmp($label, 'Brand') === 0) { $has_brand_fact = true; if ($brand_name !== '') { $value = $brand_name; } }
            if ($label === '' || $value === '') { continue; }
            $attribute = new WC_Product_Attribute();
            $attribute->set_name($label);
            $attribute->set_options([$value]);
            $attribute->set_visible(true);
            $attribute->set_variation(false);
            $attributes[] = $attribute;
        }
        if ($brand_name !== '' && !$has_brand_fact) {
            $attribute = new WC_Product_Attribute(); $attribute->set_name('Brand'); $attribute->set_options([$brand_name]); $attribute->set_visible(true); $attribute->set_variation(false); $attributes[] = $attribute;
        }
        $product->set_attributes($attributes);
        $id = $product->save();
        if (!$id) { return self::fail('WooCommerce could not save the draft.'); }
        if ($sizes) { update_post_meta($id, '_dreminex_ai_size_taxonomy', $size_tax); }
        if ($colors) { update_post_meta($id, '_dreminex_ai_color_taxonomy', $color_tax); }
        if (!empty($input['tags'])) { wp_set_object_terms($id, array_map('sanitize_text_field', $input['tags']), 'product_tag'); }
        if ($brand_name !== '') {
            $brand = self::assign_brand($id, $brand_name, $evidence && $brand_name === $evidence['name'] ? $evidence['image_id'] : null);
            if (is_wp_error($brand)) { $warnings[] = $brand->get_error_message(); }
            if ($evidence && strcasecmp((string)($input['brand'] ?? ''), $brand_name) !== 0) { $warnings[] = 'Verified image-label brand used as supplied in preparation.'; }
        }
        $seo = $input['seo'] ?? [];
        foreach (['title' => '_yoast_wpseo_title', 'description' => '_yoast_wpseo_metadesc', 'focus_keyphrase' => '_yoast_wpseo_focuskw'] as $field => $meta_key) {
            if (!empty($seo[$field])) { update_post_meta($id, $meta_key, sanitize_text_field($seo[$field])); }
        }
        if (!empty($seo['secondary_keyphrases'])) { update_post_meta($id, '_dreminex_ai_secondary_keyphrases', array_map('sanitize_text_field', $seo['secondary_keyphrases'])); }
        if ($type === 'variable' && $regular !== '') { update_post_meta($id, '_dreminex_ai_reference_price', ['regular' => $regular, 'sale' => $sale]); }
        return ['id' => $id, 'status' => 'draft', 'type' => $type, 'slug' => $slug, 'sku' => $sku, 'manage_stock' => $product->get_manage_stock(), 'stock_quantity' => $product->get_stock_quantity(), 'brand' => $brand_name, 'permalink' => get_permalink($id), 'color_slugs' => array_keys($colors), 'size_slugs' => array_keys($sizes), 'warnings' => $warnings];
    }

    /** One assisted operation, with a safe resume point after every saved batch. */
    public static function draft_complete(array $input) {
        $started = microtime(true);
        $operation = sanitize_key((string)($input['operation'] ?? 'create'));
        if (!in_array($operation, ['create','resume'], true)) { return self::fail('Choose Create or resume a partial Draft from this same listing run.', 'invalid_operation'); }
        $requested_product_id = absint($input['product_id'] ?? 0);
        $id = $operation === 'resume' ? $requested_product_id : 0;
        if ($operation === 'resume' && !$id) { return self::fail('Resume needs the exact product ID returned by the partial Create.', 'invalid_product_id'); }
        if (!$id && empty($input['slug']) && !empty($input['name'])) { $input['slug'] = sanitize_title((string)$input['name']); }
        if (!$id && empty($input['type'])) {
            $input['type'] = !empty($input['variants']) || count($input['colors'] ?? []) > 1 || count($input['sizes'] ?? []) > 1 ? 'variable' : 'simple';
        }
        $type = $id ? (wc_get_product($id)?->get_type() ?? '') : ($input['type'] ?? '');
        if (!in_array($type, ['simple','variable'], true)) { return self::fail('Choose a simple or variable Draft product.'); }
        if ($id && wc_get_product($id)->get_status() === 'publish' && !empty($input['publish'])) {
            return ['id' => $id, 'status' => 'publish', 'permalink' => get_permalink($id), 'already_published' => true, 'product' => self::product_read(['product_id' => $id])];
        }
        if ($id && (!wc_get_product($id) || wc_get_product($id)->get_status() !== 'draft')) { return self::fail('Resume requires an existing Draft product ID.'); }
        $rows = $input['variants'] ?? [];
        if (!is_array($rows)) { return self::fail('Variants must be an array.'); }
        $rows = self::expand_variation_rows($input, $rows);
        if (is_wp_error($rows)) return $rows;
        foreach ($rows as &$row) {
            if (is_array($row) && isset($row['stock_status'])) {
                $row['stock_status'] = strtolower(str_replace(' ', '', (string)$row['stock_status']));
            }
        }
        unset($row);
        $capacity_check = self::validate_variation_capacity($type, $rows, !$id);
        if (is_wp_error($capacity_check)) return $capacity_check;
        $supplier_map = self::supplier_color_map($input);
        if (is_wp_error($supplier_map)) { return $supplier_map; }
        $normalized = []; $seen = []; $skus = [];
        foreach ($rows as $row) {
            if (!is_array($row)) { return self::fail('Each variation must be an object.'); }
            $key = sanitize_title((string)($row['color'] ?? '')) . '|' . sanitize_title((string)($row['size'] ?? ''));
            if ($key === '|' || isset($seen[$key])) { return self::fail('Variation color and size must be unique and nonempty.', 'duplicate_variant'); }
            $seen[$key] = true;
            if (!isset($row['regular_price'])) { $row['regular_price'] = $input['regular_price'] ?? ''; }
            if (!isset($row['sale_price'])) { $row['sale_price'] = $input['sale_price'] ?? ''; }
            $regular = wc_format_decimal($row['regular_price']); $sale = wc_format_decimal($row['sale_price']);
            if ($regular === '' || (float)$regular <= 0 || ($sale !== '' && (float)$sale >= (float)$regular)) { return self::fail('Every variation needs a valid price.'); }
            if (array_key_exists('stock_quantity', $row) && filter_var($row['stock_quantity'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]) === false) { return self::fail('Stock must be a nonnegative whole number.'); }
            if (!empty($row['manage_stock']) && !array_key_exists('stock_quantity', $row)) { return self::fail('A managed variation needs an explicit stock quantity.'); }
            if (!empty($row['sku'])) {
                $sku = self::sku($row, '');
                if (isset($skus[$sku]) || ($sku !== '' && !$id && $sku === self::sku($input, ''))) { return self::fail('SKUs must be unique in the product.', 'duplicate_sku'); }
                $skus[$sku] = true;
            }
            $normalized[] = $row;
        }
        if (!$id) {
            $created = self::draft_create($input);
            if (is_wp_error($created)) { return $created; }
            $id = (int)$created['id'];
        }
        if ($supplier_map) {
            $stored_map = get_post_meta($id, '_dreminex_ai_color_supplier_sku_map', true);
            $stored_map = is_array($stored_map) ? array_filter($stored_map, 'is_string', ARRAY_FILTER_USE_KEY) : [];
            update_post_meta($id, '_dreminex_ai_color_supplier_sku_map', array_merge($stored_map, $supplier_map));
        }
        if ($type === 'variable') {
            // An explicitly supplied sparse matrix is the offered set; other pairs are not missing.
            update_post_meta($id, '_dreminex_ai_intended_variations', array_keys($seen));
        }
        $done = [];
        if ($type === 'variable') {
            foreach (array_chunk($normalized, self::VARIATION_BATCH_SIZE) as $batch) {
                $result = self::variations_upsert(['product_id' => $id, 'variants' => $batch]);
                if (is_wp_error($result)) {
                    return ['id' => $id, 'product_id' => $id, 'resume_product_id' => $id, 'operation' => $operation, 'status' => 'draft', 'partial' => true, 'error' => $result->get_error_message(), 'error_code' => $result->get_error_code(), 'upserted' => count($done), 'processed_variation_count' => count($done), 'remaining_variation_count' => count($normalized) - count($done), 'normalized_variation_count' => count($normalized), 'variation_capacity' => self::variation_capacity(), 'resume' => 'Correct the rows and call draft-complete with operation=resume, this product_id, and the intended variant rows. Existing combinations are updated.'];
                }
                $done = array_merge($done, $result['upserted']);
            }
        }
        $audit = self::draft_audit(['product_id' => $id]);
        if (is_wp_error($audit)) { return ['id' => $id, 'product_id' => $id, 'resume_product_id' => $id, 'operation' => $operation, 'status' => 'draft', 'partial' => true, 'error' => $audit->get_error_message()]; }
        if (!empty($input['publish'])) {
            if (!$audit['ready']) {
                return ['id' => $id, 'product_id' => $id, 'resume_product_id' => $id, 'operation' => $operation, 'status' => 'draft', 'partial' => true, 'audit' => $audit, 'error' => 'Audit has blocking issues; product remains Draft.'];
            }
            $published = self::draft_publish(['product_id' => $id, 'publish' => true]);
            if (is_wp_error($published)) { return ['id' => $id, 'product_id' => $id, 'resume_product_id' => $id, 'operation' => $operation, 'status' => 'draft', 'partial' => true, 'audit' => $audit, 'error' => $published->get_error_message()]; }
            $published['operation'] = $operation;
            $published['ignored_product_id'] = $operation === 'create' && $requested_product_id > 0;
            $published['upserted'] = count($done);
            $published['elapsed_ms'] = (int)round((microtime(true) - $started) * 1000);
            return $published;
        }
        return ['id' => $id, 'product_id' => $id, 'resume_product_id' => $id, 'status' => 'draft', 'type' => $type, 'operation' => $operation,
            'ignored_product_id' => $operation === 'create' && $requested_product_id > 0,
            'permalink' => get_permalink($id), 'audit' => $audit, 'upserted' => count($done), 'processed_variation_count' => count($done), 'remaining_variation_count' => max(0, count($normalized) - count($done)), 'normalized_variation_count' => count($normalized), 'variation_capacity' => self::variation_capacity(), 'elapsed_ms' => (int)round((microtime(true) - $started) * 1000), 'next' => $audit['ready'] ? 'Draft saved.' : 'Resolve technical issues and resume with operation=resume and this product_id.'];
    }

    /** Apply a prepared sheet, with media and variations, without an editorial duplicate search. */
    /** Persist independently applicable stages before optional media, variants and publication. */
    public static function supplier_source_read(array $input) {
        if (!class_exists('Dreminex_Supplier_Monitor')) return self::fail('Supplier Monitor is unavailable.', 'monitor_unavailable');
        return Dreminex_Supplier_Monitor::source_read(absint($input['product_id'] ?? 0));
    }

    public static function supplier_source_set(array $input) {
        if (!class_exists('Dreminex_Supplier_Monitor')) return self::fail('Supplier Monitor is unavailable.', 'monitor_unavailable');
        return Dreminex_Supplier_Monitor::source_set(absint($input['product_id'] ?? 0), $input['supplier_source_url'] ?? '');
    }

    /** Link an explicitly supplied supplier URL and verify it without making it a listing prerequisite. */
    private static function apply_supplier_source(int $product_id, string $url) {
        $url = trim($url);
        if ($url === '') { return self::fail('A non-empty supplier URL is required.', 'missing_supplier_source'); }
        if (!class_exists('Dreminex_Supplier_Monitor')) { return self::fail('Supplier Monitor is unavailable.', 'monitor_unavailable'); }
        if (!Dreminex_Supplier_Monitor::valid_source_url($url)) { return self::fail('Exact HTTPS ShopBaseBD or ResellKori product URL required.', 'invalid_supplier_source'); }
        $set = self::supplier_source_set(['product_id' => $product_id, 'supplier_source_url' => $url]);
        if (is_wp_error($set)) { return $set; }
        $readback = self::supplier_source_read(['product_id' => $product_id]);
        if (is_wp_error($readback)) { return $readback; }
        foreach ((array)($readback['sources'] ?? []) as $source) {
            if (is_array($source) && ($source['url'] ?? '') === $url) {
                return ['status' => 'saved_and_verified', 'supplier_source_url' => $url, 'supplier' => $source['supplier'] ?? '', 'scan_status' => $source['status'] ?? 'awaiting_first_scan', 'last_success' => $source['last_success'] ?? null];
            }
        }
        return self::fail('Supplier source did not match the saved readback.', 'supplier_source_readback_mismatch');
    }

    private static function canonicalize_for_hash($value) {
        if (!is_array($value)) return $value;
        $is_list = $value === [] || array_keys($value) === range(0, count($value) - 1);
        if ($is_list) return array_map([self::class, 'canonicalize_for_hash'], $value);
        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) {
            if ($key === 'content_base64' && is_string($item)) $value[$key] = 'sha256:' . hash('sha256', (string)base64_decode($item, true));
            else $value[$key] = self::canonicalize_for_hash($item);
        }
        return $value;
    }

    private static function normalized_handoff_hash(array $handoff): string {
        foreach (['ready_for_listing_apply','preparation_validation','pending_inputs','non_blocking_notes','workflow_state'] as $field) unset($handoff[$field]);
        return hash('sha256', wp_json_encode(self::canonicalize_for_hash($handoff), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }

    private static function canonical_description(string $html): string {
        $html = preg_replace('/<div\b[^>]*style=(?:"|\')[^"\']*overflow-x\s*:\s*auto[^"\']*(?:"|\')[^>]*>/iu', '<div class="dreminex-size-table-wrap">', $html);
        return trim(function_exists('wp_kses_post') ? wp_kses_post($html) : $html);
    }

    private static function canonical_handoff(array $handoff): array {
        foreach (['short_description','description'] as $field) if (array_key_exists($field,$handoff)) $handoff[$field]=self::canonical_description((string)$handoff[$field]);
        if (isset($handoff['seo']) && is_array($handoff['seo'])) $handoff['seo']=self::normalize_seo($handoff['seo']);
        return $handoff;
    }

    private static function attribute_prerequisite(array $handoff, string $field, string $taxonomy): ?array {
        $wanted = sanitize_title(preg_replace('/^pa_/', '', $taxonomy));
        foreach ((array)($handoff['publisher_prerequisites'] ?? []) as $row) {
            if (!is_array($row)) continue;
            $action = sanitize_key((string)($row['action'] ?? $row['type'] ?? ''));
            $ability = (string)($row['ability'] ?? '');
            $slug = sanitize_title(preg_replace('/^pa_/', '', (string)($row['slug'] ?? '')));
            $kind = sanitize_key((string)($row['kind'] ?? ''));
            if (!in_array($action, ['ensure_attribute','attribute_ensure'], true) && $ability !== self::NAMESPACE . '/attribute-ensure') continue;
            if ($slug !== $wanted || ($kind !== '' && $kind !== str_replace('_attribute', '', $field))) continue;
            $terms = array_values(array_unique(array_filter(array_map(static fn($term) => trim(sanitize_text_field((string)$term)), (array)($row['terms'] ?? [])))));
            $label = trim(sanitize_text_field((string)($row['label'] ?? '')));
            if ($label === '' || !$terms) return null;
            return ['action' => 'ensure_attribute', 'ability' => self::NAMESPACE . '/attribute-ensure', 'field' => $field, 'kind' => str_replace('_attribute', '', $field), 'label' => $label, 'slug' => $wanted, 'taxonomy' => wc_attribute_taxonomy_name($wanted), 'type' => sanitize_key((string)($row['attribute_type'] ?? $row['type_name'] ?? 'select')) ?: 'select', 'terms' => $terms];
        }
        return null;
    }

    private static function category_prerequisites(array $handoff): array {
        $actions=[];
        foreach((array)($handoff['publisher_prerequisites']??[]) as $row){
            if(!is_array($row))continue;$action=sanitize_key((string)($row['action']??$row['type']??''));$ability=(string)($row['ability']??'');
            if(!in_array($action,['ensure_product_category','ensure_category','category_ensure'],true)&&$ability!==self::NAMESPACE.'/category-ensure')continue;
            $name=trim(sanitize_text_field((string)($row['name']??$row['category_name']??'')));if($name==='')continue;$slug=sanitize_title((string)($row['slug']??$name));
            $existing=get_term_by('slug',$slug,'product_cat');if($existing&&in_array((int)$existing->term_id,array_map('absint',(array)($handoff['category_ids']??[])),true))continue;
            $actions[]=['action'=>'ensure_category','ability'=>self::NAMESPACE.'/category-ensure','name'=>$name,'slug'=>$slug,'parent_id'=>absint($row['parent_id']??0),'description'=>sanitize_textarea_field((string)($row['description']??''))];
        }
        return $actions;
    }

    /** Shared read-only boundary between Preparation's JSON and Publisher's write schema. */
    public static function handoff_preflight(array $request): array {
        $handoff = $request['handoff'] ?? $request;
        $errors = []; $warnings = []; $prerequisites = [];
        if (!is_array($handoff) || ($handoff['handoff_type'] ?? '') !== 'PUBLISHER HANDOFF') {
            return ['ready' => false, 'recoverable' => false, 'next_action' => 'blocked_external', 'errors' => ['A complete PUBLISHER HANDOFF object is required.'], 'hard_errors' => ['A complete PUBLISHER HANDOFF object is required.'], 'prerequisite_actions' => [], 'warnings' => [], 'non_blocking_warnings' => [], 'normalized_variation_count' => 0, 'variation_capacity' => ['configured_limit' => self::variation_capacity(), 'hard_limit' => self::MAX_VARIATION_ROWS]];
        }
        $handoff = self::canonical_handoff($handoff);
        $site = untrailingslashit(home_url('/'));
        $handoff_hash = self::normalized_handoff_hash($handoff);
        $scoped = self::scoped_handoff_preflight($handoff, $site);
        if (is_array($scoped)) return $scoped;
        $locked_url = is_array($handoff['site_lock'] ?? null) ? (string)($handoff['site_lock']['url'] ?? '') : '';
        if ($locked_url !== '' && untrailingslashit(esc_url_raw($locked_url)) !== $site) {
            $errors[] = 'The immutable site_lock does not match this connected WordPress site.';
        }
        if (empty($handoff['site_url']) || untrailingslashit(esc_url_raw((string)$handoff['site_url'])) !== $site) {
            $errors[] = 'The handoff site_url does not match this connected WordPress site.';
        }
        if ($locked_url !== '' && !empty($handoff['site_url']) && untrailingslashit(esc_url_raw((string)$handoff['site_url'])) !== untrailingslashit(esc_url_raw($locked_url))) {
            $errors[] = 'The handoff site_url conflicts with its immutable site_lock.';
        }
        foreach ((array)($handoff['external_blockers'] ?? []) as $blocker) {
            $message = is_array($blocker) ? trim((string)($blocker['message'] ?? $blocker['code'] ?? '')) : trim((string)$blocker);
            if ($message !== '') $errors[] = 'External blocker: ' . sanitize_text_field($message);
        }
        foreach ((array)($handoff['non_blocking_notes'] ?? []) as $note) {
            $message = is_array($note) ? trim((string)($note['message'] ?? $note['code'] ?? '')) : trim((string)$note);
            if ($message !== '') $warnings[] = sanitize_text_field($message);
        }
        if (!empty($handoff['pending_inputs'])) $warnings[] = 'Legacy pending_inputs were re-evaluated by live preflight; the stale list is not an independent readiness gate.';
        $mode = $handoff['mode'] ?? 'draft';
        $existing = $mode === 'update' ? wc_get_product(absint($handoff['product_id'] ?? 0)) : null;
        if ($mode === 'update' && (!$existing || !in_array($existing->get_status(), ['draft','publish'], true))) {
            $errors[] = 'Update requires an existing Draft or Published product on this site.';
        }
        $type = $handoff['type'] ?? $handoff['product_type'] ?? ($existing ? $existing->get_type() : '');
        if (!in_array($type, ['simple','variable'], true) || (isset($handoff['type'], $handoff['product_type']) && $handoff['type'] !== $handoff['product_type'])) {
            $errors[] = 'Product type must be one consistent simple or variable value.';
        }
        if ($existing && $type !== $existing->get_type()) $errors[] = 'Update cannot change the existing product type.';
        if (!in_array($mode, ['draft','publish','update'], true)) $errors[] = 'Choose draft, publish or update mode.';
        if ($mode === 'update' && !absint($handoff['product_id'] ?? 0)) $errors[] = 'Update requires the exact existing product ID.';
        if ($mode !== 'update' && absint($handoff['product_id'] ?? 0)) $errors[] = 'A Create handoff must not carry an existing product ID.';
        if (($handoff['operation'] ?? 'create') === 'resume') $errors[] = 'Resume belongs to the same Publisher run, not a new Preparation handoff.';
        $category_prerequisites=self::category_prerequisites($handoff);
        foreach($category_prerequisites as $category_prerequisite)$prerequisites[]=$category_prerequisite;
        if ($mode !== 'update' && (empty($handoff['name']) || empty($handoff['slug']) || ((empty($handoff['category_ids']) || !is_array($handoff['category_ids'])) && !$category_prerequisites))) {
            $errors[] = 'Name, slug and explicit category IDs or an exact ensure_product_category prerequisite are required.';
        }
        $full_name = trim((string)($handoff['name'] ?? ''));
        $short_description = trim((string)($handoff['short_description'] ?? ''));
        $long_description = trim((string)($handoff['description'] ?? ''));
        $seo = self::normalize_seo($handoff['seo'] ?? []);
        $prepared_tags = is_array($handoff['tags'] ?? null) ? array_filter(array_map(static fn($tag) => trim((string)$tag), $handoff['tags'])) : [];
        if ($full_name === '' || trim((string)($handoff['slug'] ?? '')) === '' || !$prepared_tags) {
            $errors[] = 'A full listing handoff needs a final name, slug and at least one relevant tag.';
        }
        if ($short_description === '' || $long_description === '') {
            $errors[] = 'A full listing handoff needs both professional short and long descriptions.';
        } elseif ($full_name !== '' && !self::exact_h3_matches_name($long_description, $full_name)) {
            $errors[] = 'The long description must begin with exactly one compact H3 containing the exact final product name.';
        }
        if ($long_description !== '' && preg_match('/variation\s*(?:row|limit)|first\s+\d+\s+sizes?|add(?:ed)?\s+later|পরবর্তী\s+ধাপে|লিমিটের\s+কারণে/iu', wp_strip_all_tags($long_description))) {
            $errors[] = 'Customer-facing description contains an internal workflow or variation-limit note. Replace it with product-focused copy.';
        }
        if($message=self::customer_copy_violation($handoff))$errors[]=$message;
        foreach (['title' => 'SEO title', 'description' => 'meta description', 'focus_keyphrase' => 'focus keyphrase'] as $field => $label) {
            if (trim((string)($seo[$field] ?? '')) === '') $errors[] = 'A full listing handoff needs a nonempty ' . $label . '.';
        }
        foreach ((array)($handoff['category_ids'] ?? []) as $category_id) {
            $term = get_term(absint($category_id), 'product_cat');
            if (!$term || is_wp_error($term)) $errors[] = 'Every category ID must exist on this site.';
        }
        $normalized = array_intersect_key($handoff, array_flip([
            'mode','product_id','type','name','slug','sku','category_ids','category_names','size_attribute','color_attribute',
            'short_description','description','seo','tags','upsell_ids','cross_sell_ids','regular_price','sale_price',
            'stock_status','colors','color_supplier_skus','sizes','images','featured_image_index','update_media_metadata',
            'variants','full_matrix','supplier_source_url','brand','facts'
        ]));
        $normalized['seo'] = $seo;
        if ($mode !== 'update' || isset($handoff['type']) || isset($handoff['product_type'])) $normalized['type'] = $type;
        $normalized['mode'] = $mode;
        unset($normalized['product_id']);
        if ($mode === 'update') $normalized['product_id'] = absint($handoff['product_id'] ?? 0);
        if (!empty($handoff['supplier_source_url']) && (!class_exists('Dreminex_Supplier_Monitor')
            || Dreminex_Supplier_Monitor::valid_source_url($handoff['supplier_source_url']) !== $handoff['supplier_source_url'])) {
            $errors[] = 'The supplier_source_url must be an exact supported HTTPS product URL.';
        }
        if (isset($handoff['stock_status'])) {
            $status = strtolower(trim((string)$handoff['stock_status']));
            if ($status === 'in stock') $status = 'instock';
            if (!in_array($status, ['instock','outofstock','onbackorder'], true)) $errors[] = 'Use instock, outofstock or onbackorder for stock_status.';
            else $normalized['stock_status'] = $status;
        }
        $sizes = [];
        foreach ((array)($handoff['sizes'] ?? []) as $item) {
            $size = is_string($item) ? trim($item) : (is_array($item) ? trim((string)($item['name'] ?? '')) : '');
            if ($size === '') { $errors[] = 'Every size needs a nonempty name.'; continue; }
            $sizes[] = $size;
        }
        if (count(array_unique(array_map('sanitize_title', $sizes))) !== count($sizes)) $errors[] = 'Size names must be unique.';
        if (array_key_exists('sizes', $handoff)) $normalized['sizes'] = $sizes;
        if (!empty($handoff['sizes']) && is_array(reset($handoff['sizes']))) $warnings[] = 'Size measurement objects were converted to selectable size names; measurements remain in the handoff description.';
        $missing_attribute_fields = [];
        if ($type === 'variable' && ($mode !== 'update' || isset($handoff['sizes']) || isset($handoff['variants']) || isset($handoff['size_attribute']) || isset($handoff['color_attribute']))) {
            foreach (['size_attribute', 'color_attribute'] as $attribute_key) {
                $current_taxonomy = $existing ? ($attribute_key === 'size_attribute' ? self::size_taxonomy($existing) : self::color_taxonomy($existing)) : '';
                $taxonomy = (string)($handoff[$attribute_key] ?? $current_taxonomy);
                if (!$taxonomy || !taxonomy_exists($taxonomy) || !self::attribute_id($taxonomy)) {
                    $prerequisite = $taxonomy ? self::attribute_prerequisite($handoff, $attribute_key, $taxonomy) : null;
                    if ($prerequisite) { $prerequisites[] = $prerequisite; $missing_attribute_fields[$attribute_key] = true; }
                    else { $errors[] = 'A real global ' . $attribute_key . ' is required on this site, or the handoff must provide an exact ensure_attribute prerequisite.'; }
                }
            }
        }
        if (empty($missing_attribute_fields['size_attribute'])) {
            $size_check = self::check_size_category($normalized, $existing);
            if (is_wp_error($size_check)) $errors[] = $size_check->get_error_message();
        }
        $parent_regular = wc_format_decimal($handoff['regular_price'] ?? ($existing ? $existing->get_regular_price() : ''));
        $parent_sale = wc_format_decimal($handoff['sale_price'] ?? '');
        if (($type === 'simple' && ($parent_regular === '' || (float)$parent_regular <= 0))
            || ($parent_regular !== '' && (float)$parent_regular <= 0)
            || ($parent_sale !== '' && ($parent_regular === '' || (float)$parent_sale >= (float)$parent_regular))) {
            $errors[] = 'Parent regular price must be positive; parent sale price must be lower. Supply both prices or omit both on a variable listing.';
        }
        $colors = []; $invalid_color_names = false;
        foreach ((array)($handoff['colors'] ?? []) as $item) {
            $color = is_string($item) ? ['name' => trim($item)] : $item;
            if (!is_array($color) || trim((string)($color['name'] ?? '')) === '') { $errors[] = 'colors[].name is required for every colour; colors[].color is not a supported field.'; $invalid_color_names = true; continue; }
            $colors[] = $color;
        }
        if (count(array_unique(array_map(static fn($c) => sanitize_title($c['name']), $colors))) !== count($colors)) $errors[] = 'Colour names must be unique.';
        if (array_key_exists('colors', $handoff)) $normalized['colors'] = $colors;
        $images = []; $image_colors = [];
        foreach ((array)($handoff['images'] ?? []) as $i => $entry) {
            if (!is_array($entry)) { $errors[] = "Image {$i} is not an object."; continue; }
            if (strtoupper((string)($entry['match_status'] ?? '')) === 'VISUALLY_VERIFIED' && empty($entry['verification_method']) && empty($entry['visual_evidence_id'])) {
                $warnings[] = "Image {$i} visual-verification claim has no recorded method or evidence ID; the claim was ignored.";
            }
            $id = absint($entry['image_id'] ?? 0);
            if (!$id && !empty($entry['url']) && empty($entry['import_external'])) {
                $resolved = self::resolve_media_url((string)$entry['url']);
                if (!is_wp_error($resolved)) $id = (int)$resolved['id'];
            }
            if (!$id) {
                $source_count = 0;
                foreach (['content_base64','incoming_path','url'] as $source_field) $source_count += isset($entry[$source_field]) && $entry[$source_field] !== '' ? 1 : 0;
                if ($source_count === 1) {
                    $prerequisites[] = ['action' => 'resolve_media', 'ability' => self::NAMESPACE . '/media-batch-upload', 'image_index' => $i];
                    $image = array_intersect_key($entry, array_flip(['filename','content_base64','incoming_path','url','import_external','title','slug','alt','color']));
                    $images[$i] = $image;
                    if (!empty($entry['color'])) $image_colors[sanitize_title((string)$entry['color'])] = $image_colors[sanitize_title((string)$entry['color'])] ?? $i;
                    continue;
                }
                $errors[] = "Image {$i} needs an existing attachment or exactly one accessible original source."; continue;
            }
            if (is_wp_error(self::checked_image($id))) { $errors[] = "Image {$i} needs an existing original attachment on this site."; continue; }
            if (isset($entry['url']) && untrailingslashit((string)$entry['url']) !== untrailingslashit((string)wp_get_attachment_url($id))) {
                $errors[] = "Image {$i} URL does not match its Media Library ID.";
            }
            // The handoff carries the URL for evidence; listing-apply accepts one source.
            $image = array_intersect_key($entry, array_flip(['image_id','title','slug','alt','color']));
            $image['image_id'] = $id;
            $images[$i] = $image;
            if (!empty($entry['color'])) {
                $image_color = sanitize_title((string)$entry['color']);
                if (!isset($image_colors[$image_color])) $image_colors[$image_color] = $i;
            }
        }
        if (array_key_exists('images', $handoff)) $normalized['images'] = array_values($images);
        $supplier_map_check = self::supplier_color_map($handoff);
        if (is_wp_error($supplier_map_check)) $errors[] = $supplier_map_check->get_error_message();
        elseif ($supplier_map_check) $normalized['color_supplier_skus'] = $supplier_map_check;
        if (!empty($handoff['images']) && count($images) !== count($handoff['images'])) $errors[] = 'Every gallery image must resolve before the listing is written.';
        if (isset($handoff['featured_image_index']) && !isset($images[$handoff['featured_image_index']])) $errors[] = 'Featured image index does not resolve.';
        $existing_swatches = $existing ? (array)get_post_meta($existing->get_id(), '_dreminex_ai_swatch_images', true) : [];
        $existing_color_images = $existing ? (array)get_post_meta($existing->get_id(), '_dreminex_ai_color_image_map', true) : [];
        foreach ($colors as $color_index => $color) {
            $color_slug = sanitize_title($color['name']);
            $mapped_index = $image_colors[$color_slug] ?? null;
            $index = $color['swatch_image_index'] ?? $mapped_index;
            $existing_image_id = absint($existing_swatches[$color_slug] ?? $existing_color_images[$color_slug] ?? 0);
            $image_id = absint($color['swatch_image_id'] ?? $existing_image_id);
            if ($image_id && is_wp_error(self::checked_image($image_id))) $errors[] = 'Existing swatch image is unavailable for colour ' . $color['name'] . '.';
            if ($image_id && $existing) {
                $owned_ids = array_merge([(int)$existing->get_image_id()], array_map('intval', $existing->get_gallery_image_ids()));
                foreach ($existing->get_children() as $child_id) {
                    $child = wc_get_product($child_id);
                    if ($child) $owned_ids[] = (int)$child->get_image_id();
                }
                if (!in_array($image_id, $owned_ids, true)) $errors[] = 'Existing swatch image is not attached to this product: ' . $color['name'] . '.';
            }
            if (($mapped_index !== null || $existing_image_id) && ($color['mode'] ?? 'image') === 'color') $errors[] = 'A verified image exists, so image swatch is required for colour ' . $color['name'] . '.';
            if ($index === null && !$image_id && ($color['mode'] ?? '') !== 'color') $errors[] = 'Colour ' . $color['name'] . ' needs its verified image or explicit mode=color.';
            if ($index === null && !$image_id && ($color['mode'] ?? '') === 'color') {
                $taxonomy = (string)($handoff['color_attribute'] ?? ($existing ? self::color_taxonomy($existing) : ''));
                $term = $taxonomy ? (get_term_by('name', $color['name'], $taxonomy) ?: get_term_by('slug', sanitize_title($color['name']), $taxonomy)) : false;
                $existing_hex = $term ? sanitize_hex_color((string)get_term_meta($term->term_id, 'product_attribute_color', true)) : '';
                $supplied_hex = sanitize_hex_color((string)($color['hex'] ?? ''));
                if (!empty($color['hex']) && !$supplied_hex) $errors[] = 'Colour ' . $color['name'] . ' has an invalid HEX.';
                if (!$existing_hex && !$supplied_hex) $errors[] = 'Colour ' . $color['name'] . ' needs a verified HEX or existing colour term for fallback.';
                if ($supplied_hex && $existing_hex && strcasecmp($supplied_hex, $existing_hex) !== 0) $errors[] = 'Colour ' . $color['name'] . ' HEX conflicts with the shared term; verify a distinct term.';
                if ($existing_hex) unset($normalized['colors'][$color_index]['hex']);
            }
            if ($index !== null && (!isset($images[$index]) || (!empty($images[$index]['color']) && sanitize_title($images[$index]['color']) !== sanitize_title($color['name'])))) {
                $errors[] = 'Swatch image is missing or belongs to another colour: ' . $color['name'] . '.';
            }
            if ($index !== null && !isset($normalized['colors'][$color_index]['swatch_image_index'])) {
                $normalized['colors'][$color_index]['swatch_image_index'] = $index;
            }
            if ($image_id && $index === null) $normalized['colors'][$color_index]['swatch_image_id'] = $image_id;
            if ($index !== null || $image_id) $normalized['colors'][$color_index]['mode'] = 'image';
            // A product-specific image swatch does not need to rewrite a shared global HEX term.
            if (($index !== null || $image_id) && isset($normalized['colors'][$color_index]['hex'])) {
                unset($normalized['colors'][$color_index]['hex']);
                $warnings[] = 'Image swatch retained for ' . $color['name'] . '; shared colour-term HEX was not changed.';
            }
        }
        $rows = (array)($handoff['variants'] ?? []);
        $expanded_rows = self::expand_variation_rows($handoff, $rows);
        if (is_wp_error($expanded_rows)) { $errors[] = $expanded_rows->get_error_message(); }
        else { $rows = $expanded_rows; }
        $capacity_check = self::validate_variation_capacity((string)$type, $rows, $mode !== 'update');
        if (is_wp_error($capacity_check)) $errors[] = $capacity_check->get_error_message();
        $pairs = []; $child_skus = [];
        $known_colors = array_map(static fn($c) => sanitize_title($c['name']), $colors);
        $known_sizes = array_map('sanitize_title', $sizes);
        $fallback_colors = [];
        foreach (($normalized['colors'] ?? []) as $color) {
            if (($color['mode'] ?? '') === 'color') $fallback_colors[sanitize_title($color['name'])] = true;
        }
        foreach ($rows as $i => $row) {
            if (!is_array($row)) { $errors[] = "Variation {$i} is not an object."; continue; }
            $c = sanitize_title((string)($row['color'] ?? '')); $s = sanitize_title((string)($row['size'] ?? ''));
            $key = $c . '|' . $s;
            if (!$c || !$s || isset($pairs[$key]) || (!$invalid_color_names && !in_array($c, $known_colors, true)) || !in_array($s, $known_sizes, true)) {
                $errors[] = "Variation {$i} has an invalid, duplicate or unlisted colour/size pair.";
            }
            $pairs[$key] = true;
            if (isset($row['image_index']) && (!isset($images[$row['image_index']]) || (!empty($images[$row['image_index']]['color']) && sanitize_title($images[$row['image_index']]['color']) !== $c))) {
                $errors[] = "Variation {$i} image does not match its colour.";
            }
            if (!isset($row['image_index']) && isset($image_colors[$c])) $row['image_index'] = $image_colors[$c];
            if (!isset($row['image_index']) && isset($fallback_colors[$c])) $row['image_id'] = 0;
            $regular = wc_format_decimal($row['regular_price'] ?? $handoff['regular_price'] ?? '');
            $sale = wc_format_decimal($row['sale_price'] ?? $handoff['sale_price'] ?? '');
            if ($regular === '' || (float)$regular <= 0 || ($sale !== '' && (float)$sale >= (float)$regular)) $errors[] = "Variation {$i} has invalid prices.";
            $stock = $row['stock_status'] ?? $normalized['stock_status'] ?? null;
            if ($stock === 'In stock') $stock = 'instock';
            if ($stock !== null && !in_array($stock, ['instock','outofstock','onbackorder'], true)) $errors[] = "Variation {$i} has invalid stock status.";
            $row['regular_price'] = $regular; $row['sale_price'] = $sale;
            if ($stock !== null) $row['stock_status'] = $stock;
            $code = self::supplier_code($row['supplier_sku'] ?? (is_array($supplier_map_check) ? ($supplier_map_check[$c] ?? '') : ''));
            if (is_wp_error($code)) { $errors[] = "Variation {$i} has an invalid supplier code."; $code = ''; }
            $parent_sku = strtoupper(trim((string)($handoff['sku'] ?? ($existing ? $existing->get_sku('edit') : ''))));
            $base = $parent_sku . '-' . strtoupper($c) . '-' . strtoupper($s);
            $sku = strtoupper(trim((string)($row['sku'] ?? '')));
            if ($sku !== '' && ($parent_sku === '' || !str_starts_with($sku, $parent_sku . '-'))) {
                $errors[] = "Variation {$i} SKU must preserve the parent SKU as its internal identity.";
            }
            if ($sku === '' && $parent_sku !== '') $sku = $base;
            if ($code !== '') {
                $candidate = self::variation_supplier_sku($sku !== '' ? $sku : $base, $code);
                if (is_wp_error($candidate)) $errors[] = "Variation {$i} SKU cannot safely retain its internal child identity with the supplier code.";
                else $sku = $candidate;
            }
            if ($sku !== '') {
                $current_sku_id = 0;
                if ($mode === 'update') {
                    $sku_owner_id = (int)(wc_get_product_id_by_sku($sku) ?: 0);
                    $sku_owner = $sku_owner_id ? wc_get_product($sku_owner_id) : null;
                    if ($sku_owner && (int)$sku_owner->get_parent_id() === (int)$existing->get_id()) $current_sku_id = $sku_owner_id;
                }
                if (isset($child_skus[$sku]) || is_wp_error(self::validate_sku($sku, $current_sku_id))) $errors[] = "Variation {$i} SKU is invalid or duplicated.";
                $child_skus[$sku] = true;
                $row['sku'] = $sku;
            }
            $rows[$i] = $row;
        }
        if (array_key_exists('variants', $handoff) || !empty($handoff['full_matrix'])) $normalized['variants'] = array_values($rows);
        if (!empty($handoff['full_matrix']) && !$invalid_color_names && count($pairs) !== count($colors) * count($sizes)) $errors[] = 'full_matrix is true but some colour/size pairs are missing.';
        if ($mode !== 'update' && !empty($handoff['name']) && !empty($handoff['slug']) && self::exact_product_identity_matches((string)$handoff['name'], sanitize_title((string)$handoff['slug']))) $errors[] = 'Exact product name or slug already exists on this site.';
        if ($mode !== 'update' && $type === 'variable' && trim((string)($handoff['sku'] ?? '')) === '') $errors[] = 'A new Variable product needs its unique prefix-based parent SKU.';
        if ($mode !== 'update' && !empty($handoff['sku']) && is_wp_error(self::validate_sku(strtoupper((string)$handoff['sku'])))) $errors[] = 'Parent SKU already exists or is invalid.';
        if ($mode === 'publish' && !$images) $errors[] = 'Publishing requires verified product media; save as Draft until images are available.';
        if ($mode === 'draft' && !$images) $warnings[] = 'Draft has no verified gallery image; customer-facing publication remains blocked.';
        $unique_prerequisites = [];
        foreach ($prerequisites as $prerequisite) $unique_prerequisites[hash('sha256', wp_json_encode($prerequisite))] = $prerequisite;
        $prerequisites = array_values($unique_prerequisites);
        $errors = array_values(array_unique($errors)); $warnings = array_values(array_unique($warnings));
        $ready = !$errors && !$prerequisites;
        $recoverable = !$errors && (bool)$prerequisites;
        return ['ready' => $ready, 'recoverable' => $recoverable,
            'workflow_state' => $ready ? 'ready' : ($recoverable ? 'ready_after_prerequisites' : 'blocked_external'),
            'next_action' => $ready ? 'apply_and_verify' : ($recoverable ? 'resolve_prerequisites' : 'blocked_external'),
            'errors' => $errors, 'hard_errors' => $errors, 'prerequisite_actions' => $prerequisites,
            'warnings' => $warnings, 'non_blocking_warnings' => $warnings,
            'listing_parameters' => $ready ? $normalized : null,
            'normalized_handoff_hash' => $handoff_hash,
            'normalized_variation_count' => count($rows),
            'variation_capacity' => ['configured_limit' => self::variation_capacity(), 'hard_limit' => self::MAX_VARIATION_ROWS],
            'checked_site' => home_url('/')];
    }

    /**
     * Complete one authorized Publisher run: resolve only declared safe prerequisites,
     * rerun live preflight, apply/resume, and compare the saved product with the handoff.
     */
    public static function handoff_execute(array $request) {
        $started = microtime(true);
        $handoff = $request['handoff'] ?? null;
        if (!is_array($handoff) || ($handoff['handoff_type'] ?? '') !== 'PUBLISHER HANDOFF') {
            return self::fail('A complete PUBLISHER HANDOFF object is required.', 'invalid_handoff');
        }
        $handoff = self::canonical_handoff($handoff);
        $initial = self::handoff_preflight(['handoff' => $handoff]);
        $hash = (string)($initial['normalized_handoff_hash'] ?? self::normalized_handoff_hash($handoff));
        if (!empty($initial['hard_errors'])) {
            return [
                'success' => false, 'partial' => false, 'product_write_started' => false,
                'workflow_state' => 'blocked_external', 'handoff_hash' => $hash,
                'preflight' => $initial, 'errors' => $initial['hard_errors'],
                'next_action' => 'correct_external_blocker_and_resubmit',
            ];
        }

        $resolved = [];
        $media_indexes = [];
        foreach ((array)($initial['prerequisite_actions'] ?? []) as $action) {
            if (!is_array($action)) continue;
            $kind = sanitize_key((string)($action['action'] ?? ''));
            if ($kind === 'ensure_category') {
                $result = self::category_ensure(['name'=>$action['name']??'','slug'=>$action['slug']??'','parent_id'=>$action['parent_id']??0,'description'=>$action['description']??'']);
                if (is_wp_error($result)) return ['success'=>false,'partial'=>true,'product_write_started'=>false,'workflow_state'=>'prerequisite_failed','handoff_hash'=>$hash,'resolved_prerequisites'=>$resolved,'errors'=>[['action'=>$kind,'code'=>$result->get_error_code(),'message'=>$result->get_error_message()]],'next_action'=>'retry_same_handoff'];
                $handoff['category_ids']=array_values(array_unique(array_filter(array_merge(array_map('absint',(array)($handoff['category_ids']??[])),[(int)$result['id']]))));
                $resolved[]=['action'=>$kind,'result'=>$result];
            } elseif ($kind === 'ensure_attribute') {
                $result = self::attribute_ensure([
                    'label' => $action['label'] ?? '', 'slug' => $action['slug'] ?? '',
                    'type' => $action['type'] ?? 'select', 'terms' => $action['terms'] ?? [],
                    'handoff_hash' => $hash,
                ]);
                if (is_wp_error($result)) {
                    return ['success' => false, 'partial' => true, 'product_write_started' => false,
                        'workflow_state' => 'prerequisite_failed', 'handoff_hash' => $hash,
                        'resolved_prerequisites' => $resolved,
                        'errors' => [['action' => $kind, 'code' => $result->get_error_code(), 'message' => $result->get_error_message()]],
                        'next_action' => 'retry_same_handoff'];
                }
                $resolved[] = ['action' => $kind, 'result' => $result];
            } elseif ($kind === 'resolve_media') {
                if (!array_key_exists('image_index', $action) || filter_var($action['image_index'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]) === false) {
                    return self::fail('A media prerequisite has no valid ordered image index.', 'media_prerequisite_mismatch');
                }
                $media_indexes[] = (int)$action['image_index'];
            } else {
                return ['success' => false, 'partial' => false, 'product_write_started' => false,
                    'workflow_state' => 'blocked_external', 'handoff_hash' => $hash,
                    'errors' => [['action' => $kind, 'code' => 'unsafe_prerequisite', 'message' => 'The requested prerequisite is outside the Publisher safe allowlist.']],
                    'next_action' => 'correct_external_blocker_and_resubmit'];
            }
        }

        $media_indexes = array_values(array_unique($media_indexes));
        foreach (array_chunk($media_indexes, 10) as $index_batch) {
            $batch = [];
            foreach ($index_batch as $index) {
                if (!isset($handoff['images'][$index]) || !is_array($handoff['images'][$index])) {
                    return self::fail('A declared media prerequisite no longer matches its image index.', 'media_prerequisite_mismatch');
                }
                $batch[] = $handoff['images'][$index];
            }
            $uploaded = self::media_batch_upload(['images' => $batch]);
            if (is_wp_error($uploaded) || !empty($uploaded['partial'])) {
                $code = is_wp_error($uploaded) ? $uploaded->get_error_code() : (string)($uploaded['error_code'] ?? 'media_prerequisite_failed');
                $message = is_wp_error($uploaded) ? $uploaded->get_error_message() : (string)($uploaded['error'] ?? 'Media prerequisite failed.');
                return ['success' => false, 'partial' => true, 'product_write_started' => false,
                    'workflow_state' => 'prerequisite_failed', 'handoff_hash' => $hash,
                    'resolved_prerequisites' => $resolved, 'media_result' => $uploaded,
                    'errors' => [['action' => 'resolve_media', 'code' => $code, 'message' => $message]],
                    'next_action' => 'retry_same_handoff'];
            }
            foreach ($uploaded['images'] as $position => $media) {
                $index = $index_batch[$position];
                $original = $handoff['images'][$index];
                $handoff['images'][$index] = array_intersect_key($original, array_flip(['title','slug','alt','color','supplier_sku']));
                $handoff['images'][$index]['image_id'] = (int)$media['id'];
            }
            $resolved[] = ['action' => 'resolve_media', 'indexes' => $index_batch, 'image_ids' => array_map('intval', (array)$uploaded['image_ids'])];
        }

        $fresh = self::handoff_preflight(['handoff' => $handoff]);
        if (empty($fresh['ready'])) {
            return ['success' => false, 'partial' => false, 'product_write_started' => false,
                'workflow_state' => !empty($fresh['recoverable']) ? 'prerequisites_remain' : 'blocked_external',
                'handoff_hash' => $hash, 'resolved_prerequisites' => $resolved,
                'preflight' => $fresh, 'errors' => $fresh['hard_errors'] ?? [],
                'next_action' => !empty($fresh['recoverable']) ? 'retry_same_handoff' : 'correct_external_blocker_and_resubmit'];
        }

        $hash = (string)($fresh['normalized_handoff_hash'] ?? $hash);

        $parameters = (array)$fresh['listing_parameters'];
        foreach (['resume_product_id','resume_token','variation_offset'] as $resume_field) {
            if (array_key_exists($resume_field, $request)) $parameters[$resume_field] = $request[$resume_field];
        }
        $saved = self::listing_apply($parameters);
        if (is_wp_error($saved)) return $saved;
        $product_id = absint($saved['product_id'] ?? $saved['id'] ?? 0);
        if ($product_id) update_post_meta($product_id, '_dreminex_ai_handoff_hash', $hash);
        $readback = $product_id ? self::product_read(['product_id' => $product_id]) : self::fail('The listing operation returned no product ID.', 'missing_saved_product');

        $verification_errors = []; $variation_mismatches = []; $verified_variations = 0;
        if (is_wp_error($readback)) {
            $verification_errors[] = $readback->get_error_message();
            $readback = null;
        } else {
            foreach (['name','slug','sku','type'] as $field) {
                if (array_key_exists($field, $parameters) && (string)$parameters[$field] !== (string)($readback[$field] ?? '')) {
                    $verification_errors[] = 'Saved ' . $field . ' does not match the normalized handoff.';
                }
            }
            foreach (['short_description','description'] as $field) {
                if (array_key_exists($field, $parameters) && (string)$parameters[$field] !== (string)($readback[$field] ?? '')) {
                    $verification_errors[] = 'Saved ' . $field . ' does not match the normalized handoff.';
                }
            }
            if (isset($parameters['category_ids'])) {
                $expected = array_values(array_unique(array_map('absint', (array)$parameters['category_ids'])));
                $actual = array_values(array_unique(array_map('absint', (array)($readback['categories'] ?? []))));
                sort($expected); sort($actual);
                if ($expected !== $actual) $verification_errors[] = 'Saved categories do not match the normalized handoff.';
            }
            if (isset($parameters['tags']) && is_array($readback['tags'] ?? null)) {
                $expected = array_values(array_unique(array_map('sanitize_title', (array)$parameters['tags'])));
                $actual = array_values(array_unique(array_map('sanitize_title', (array)$readback['tags'])));
                sort($expected); sort($actual);
                if ($expected !== $actual) $verification_errors[] = 'Saved tags do not match the normalized handoff.';
            }
            foreach (['title','description','focus_keyphrase'] as $field) {
                if (isset($parameters['seo'][$field]) && (string)$parameters['seo'][$field] !== (string)($readback['seo'][$field] ?? '')) {
                    $verification_errors[] = 'Saved SEO ' . $field . ' does not match the normalized handoff.';
                }
            }
            if (($parameters['mode'] ?? 'draft') === 'draft' && ($readback['status'] ?? '') !== 'draft') {
                $verification_errors[] = 'Draft-by-default status was not preserved.';
            }
            if (!empty($parameters['images']) && ($parameters['mode'] ?? 'draft') !== 'update') {
                $ids = array_map(static fn($image) => absint($image['image_id'] ?? 0), (array)$parameters['images']);
                $featured_index = isset($parameters['featured_image_index']) ? absint($parameters['featured_image_index']) : 0;
                $expected_images = array_values(array_unique(array_filter(array_merge(isset($ids[$featured_index]) ? [$ids[$featured_index]] : [], $ids))));
                $actual_images = array_values(array_filter(array_merge([absint($readback['featured_image']['id'] ?? 0)], array_map(static fn($image) => absint($image['id'] ?? 0), (array)($readback['gallery'] ?? [])))));
                if ($expected_images !== $actual_images) $verification_errors[] = 'Saved featured image or gallery order does not match the normalized handoff.';
            }
            if (isset($parameters['colors'])) {
                $actual_swatches = [];
                foreach ((array)($readback['color_swatches'] ?? []) as $swatch) {
                    $actual_swatches[sanitize_title((string)($swatch['base_name'] ?? $swatch['name'] ?? ''))] = $swatch;
                }
                foreach ((array)$parameters['colors'] as $color) {
                    if (!is_array($color)) continue;
                    $key = sanitize_title((string)($color['name'] ?? '')); $actual = $actual_swatches[$key] ?? null;
                    if (!$actual) { $verification_errors[] = 'Saved colour swatch is missing for ' . (string)($color['name'] ?? $key) . '.'; continue; }
                    $expected_image = absint($color['swatch_image_id'] ?? 0);
                    if (isset($color['swatch_image_index'], $parameters['images'][$color['swatch_image_index']]['image_id'])) {
                        $expected_image = absint($parameters['images'][$color['swatch_image_index']]['image_id']);
                    }
                    if ($expected_image && ($actual['swatch_mode'] ?? '') !== 'image') $verification_errors[] = 'Saved swatch mode is not image for ' . (string)$color['name'] . '.';
                    if ($expected_image && $expected_image !== absint($actual['swatch_image']['id'] ?? 0)) $verification_errors[] = 'Saved swatch image does not match for ' . (string)$color['name'] . '.';
                    if (!$expected_image && ($color['mode'] ?? '') === 'color' && ($actual['swatch_mode'] ?? '') !== 'color') $verification_errors[] = 'Saved fallback colour swatch does not match for ' . (string)$color['name'] . '.';
                }
            }
            if (array_key_exists('variants', $parameters) && empty($saved['can_resume'])) {
                $expected_rows = (array)$parameters['variants'];
                $saved_rows = (array)($readback['variations'] ?? []);
                if (count($expected_rows) !== count($saved_rows)) $verification_errors[] = 'Saved variation count does not match the normalized handoff.';
                $color_tax = (string)($readback['color_attribute'] ?? $parameters['color_attribute'] ?? '');
                $size_tax = (string)($readback['size_attribute'] ?? $parameters['size_attribute'] ?? '');
                $saved_by_key = [];
                foreach ($saved_rows as $row) {
                    $attributes = (array)($row['attributes'] ?? []);
                    $key = sanitize_title((string)($attributes[$color_tax] ?? '')) . '|' . sanitize_title((string)($attributes[$size_tax] ?? ''));
                    if ($key !== '|') $saved_by_key[$key] = $row;
                }
                $supplier_map = self::supplier_color_map($parameters);
                if (is_wp_error($supplier_map)) $supplier_map = [];
                foreach ($expected_rows as $index => $row) {
                    $color = sanitize_title((string)($row['color'] ?? '')); $size = sanitize_title((string)($row['size'] ?? ''));
                    $key = $color . '|' . $size; $actual = $saved_by_key[$key] ?? null; $reasons = [];
                    if (!$actual) $reasons[] = 'missing pair';
                    else {
                        $expected_supplier = (string)($row['supplier_sku'] ?? ($supplier_map[$color] ?? ''));
                        $expected_regular = wc_format_decimal($row['regular_price'] ?? $parameters['regular_price'] ?? '');
                        $expected_sale = wc_format_decimal($row['sale_price'] ?? $parameters['sale_price'] ?? '');
                        $expected_stock = strtolower(str_replace(' ', '', (string)($row['stock_status'] ?? $parameters['stock_status'] ?? '')));
                        if ((string)($row['sku'] ?? '') !== (string)($actual['sku'] ?? '')) $reasons[] = 'SKU';
                        if ($expected_supplier !== (string)($actual['supplier_sku'] ?? '')) $reasons[] = 'supplier SKU';
                        if ($expected_regular !== wc_format_decimal($actual['regular_price'] ?? '')) $reasons[] = 'regular price';
                        if ($expected_sale !== wc_format_decimal($actual['sale_price'] ?? '')) $reasons[] = 'sale price';
                        if ($expected_stock !== '' && $expected_stock !== (string)($actual['stock_status'] ?? '')) $reasons[] = 'stock status';
                        if (isset($row['image_index'], $parameters['images'][$row['image_index']]['image_id'])
                            && absint($parameters['images'][$row['image_index']]['image_id']) !== absint($actual['image']['id'] ?? 0)) $reasons[] = 'image';
                    }
                    if ($reasons) {
                        if (count($variation_mismatches) < 25) $variation_mismatches[] = ['index' => $index, 'pair' => $key, 'mismatch' => $reasons];
                    } else $verified_variations++;
                }
                if ($verified_variations !== count($expected_rows)) $verification_errors[] = 'One or more saved variation fields do not match the normalized handoff.';
            }
        }
        $partial = !empty($saved['partial']) || !empty($saved['can_resume']) || (bool)$verification_errors;
        $preflight_summary = array_diff_key($fresh, ['listing_parameters' => true]);
        $apply_summary = array_intersect_key($saved, array_flip(['id','product_id','operation','status','type','partial','stages','errors','pending_inputs','can_resume','resume_product_id','resume_token','variation_offset','normalized_variation_count','processed_variation_count','remaining_variation_count','variation_capacity','media_reused','image_ids','elapsed_ms']));
        $product_summary = $readback ? array_intersect_key($readback, array_flip(['id','name','slug','status','type','sku','permalink','stock_status','categories','tags','seo'])) : null;
        if ($product_summary) {
            $product_summary['gallery_count'] = count((array)($readback['gallery'] ?? [])) + (!empty($readback['featured_image']) ? 1 : 0);
            $product_summary['swatch_count'] = count((array)($readback['color_swatches'] ?? []));
            $product_summary['variation_count'] = count((array)($readback['variations'] ?? []));
        }
        return [
            'success' => !$partial, 'partial' => $partial, 'product_write_started' => true,
            'workflow_state' => !empty($saved['can_resume']) ? 'resume_required' : ($verification_errors ? 'verification_failed' : 'completed'),
            'handoff_hash' => $hash, 'resolved_prerequisites' => $resolved,
            'preflight' => $preflight_summary, 'apply_result' => $apply_summary,
            'product_id' => $product_id, 'product' => $product_summary,
            'verification' => ['passed' => !$verification_errors && empty($saved['partial']), 'errors' => $verification_errors,
                'expected_variation_count' => count((array)($parameters['variants'] ?? [])), 'verified_variation_count' => $verified_variations,
                'variation_mismatch_count' => max(0, count((array)($parameters['variants'] ?? [])) - $verified_variations),
                'variation_mismatches' => $variation_mismatches,
                'readback_sha256' => $readback ? hash('sha256', wp_json_encode(self::canonicalize_for_hash($readback), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) : null],
            'can_resume' => !empty($saved['can_resume']), 'resume_product_id' => $saved['resume_product_id'] ?? null,
            'resume_token' => $saved['resume_token'] ?? null, 'variation_offset' => $saved['variation_offset'] ?? null,
            'next_action' => !empty($saved['can_resume']) ? 'resume_same_product' : ($verification_errors ? 'inspect_saved_product' : 'none'),
            'elapsed_ms' => (int)round((microtime(true) - $started) * 1000),
        ];
    }

    public static function listing_apply(array $input) {
        $started = microtime(true);
        if (($input['handoff_type'] ?? '') === 'PUBLISHER HANDOFF') {
            $preflight = self::handoff_preflight(['handoff' => $input]);
            if (!$preflight['ready']) {
                $message = !empty($preflight['recoverable'])
                    ? 'This handoff has safe Publisher prerequisites. Run dreminex-products/handoff-execute with the complete handoff so they can be resolved and the fresh normalized result can be applied.'
                    : implode(' ', (array)($preflight['hard_errors'] ?? $preflight['errors'] ?? []));
                return self::fail($message ?: 'Handoff preflight did not pass.', !empty($preflight['recoverable']) ? 'handoff_prerequisites_required' : 'handoff_preflight_failed');
            }
            $input = $preflight['listing_parameters'];
        }
        if (isset($input['colors']) && is_array($input['colors'])) {
            $input['colors'] = array_map(static fn($color) => is_string($color) ? ['name' => trim($color)] : $color, $input['colors']);
        }
        if (array_key_exists('selling_price', $input) && !array_key_exists('sale_price', $input)) {
            $regular = wc_format_decimal($input['regular_price'] ?? '');
            $selling = wc_format_decimal($input['selling_price']);
            if ($regular === '' || $selling === '' || (float)$selling <= 0 || (float)$selling > (float)$regular) {
                return self::fail('Selling price must be positive and no higher than the supplied regular price.', 'invalid_selling_price');
            }
            $input['sale_price'] = (float)$selling < (float)$regular ? $selling : '';
        }
        $mode = sanitize_key((string)($input['mode'] ?? 'draft'));
        if (!in_array($mode, ['draft','publish','update'], true)) {
            return self::fail('Choose Draft, Publish, or Update with a product ID.', 'invalid_mode');
        }
        $requested_product_id = absint($input['product_id'] ?? 0);
        $resume_product_id = absint($input['resume_product_id'] ?? 0);
        $resume_token = is_string($input['resume_token'] ?? null) ? trim($input['resume_token']) : '';
        $is_resume = $resume_product_id > 0 || $resume_token !== '';
        if ($is_resume && (!$resume_product_id || $resume_token === '')) return self::fail('Resume needs both the exact returned product ID and opaque resume token.', 'invalid_resume');
        $id = $is_resume ? $resume_product_id : ($mode === 'update' ? $requested_product_id : 0);
        if ($mode === 'update' && !$id) {
            return self::fail('An explicit Update needs the exact existing product ID.', 'invalid_product_id');
        }
        $existing = $id ? wc_get_product($id) : null;
        if ($id && (!$existing || !in_array($existing->get_type(), ['simple','variable'], true)
            || !in_array($existing->get_status(), ['draft','publish'], true))) {
            return self::fail('Update needs an existing Simple or Variable product ID.', 'invalid_product_id');
        }
        $resume_state = [];
        if ($is_resume) {
            $resume_state = (array)get_post_meta($id, '_dreminex_ai_listing_resume', true);
            $provided_hash = hash_hmac('sha256', $resume_token, wp_salt('auth'));
            if (!$existing || !in_array($existing->get_status(), ['draft','publish'], true) || empty($resume_state['token_hash']) || !hash_equals((string)$resume_state['token_hash'], $provided_hash)) {
                return self::fail('The resume token is invalid, expired, or does not belong to this product.', 'invalid_resume');
            }
        }
        $rows = $input['variants'] ?? [];
        if (!is_array($rows)) { return self::fail('Variation rows must be an array.', 'invalid_variants'); }
        if (isset($input['type']) && !in_array($input['type'], ['simple','variable'], true)) { return self::fail('Unsupported product type.', 'unsupported_product_type'); }
        if (!$id && !$rows && empty($input['full_matrix']) && empty($input['colors']) && empty($input['sizes']) && ($input['type'] ?? '') === 'variable') {
            return self::fail('A Variable Draft needs at least one selectable option.', 'missing_options');
        }
        $type = $existing ? $existing->get_type() : ($input['type'] ?? ($rows || !empty($input['colors']) || !empty($input['sizes']) ? 'variable' : 'simple'));
        if ($existing && isset($input['type']) && $input['type'] !== $type) { return self::fail('Existing product type cannot be changed.', 'type_conflict'); }
        if (!$id && $rows) {
            if (empty($input['colors'])) { $input['colors'] = array_values(array_map(static fn($n) => ['name' => $n], array_unique(array_filter(array_column($rows, 'color'))))); }
            if (empty($input['sizes'])) { $input['sizes'] = array_values(array_unique(array_filter(array_column($rows, 'size')))); }
        }
        $rows = self::expand_variation_rows($input, $rows);
        if (is_wp_error($rows)) return $rows;
        foreach ($rows as &$row) {
            if (is_array($row) && isset($row['stock_status'])) {
                $row['stock_status'] = strtolower(str_replace(' ', '', (string)$row['stock_status']));
            }
        }
        unset($row);
        $capacity_check = self::validate_variation_capacity($type, $rows, !$id);
        if (is_wp_error($capacity_check)) return $capacity_check;
        $rows_check = self::validate_variation_rows_input($rows, $input);
        if (is_wp_error($rows_check)) return $rows_check;
        if ($type === 'variable' && !empty($input['full_matrix']) && wc_format_decimal($input['regular_price'] ?? '') === '') return self::fail('A confirmed full matrix needs a regular price before saving.', 'missing_variant_price');
        if (!$id) {
            $seo = self::normalize_seo($input['seo'] ?? []);
            $missing_content = trim((string)($input['short_description'] ?? '')) === '' || trim((string)($input['description'] ?? '')) === ''
                || trim((string)($input['slug'] ?? '')) === '' || empty($input['tags'])
                || trim((string)($seo['title'] ?? '')) === '' || trim((string)($seo['description'] ?? '')) === '' || trim((string)($seo['focus_keyphrase'] ?? '')) === '';
            if ($missing_content) return self::fail('A new full listing needs short and long descriptions, slug, tags, SEO title, meta description and focus keyphrase before any write.', 'missing_listing_content');
            if (!self::exact_h3_matches_name((string)$input['description'], (string)($input['name'] ?? ''))) return self::fail('The long description must begin with one H3 containing the exact product name.', 'invalid_long_description');
            $input['seo'] = $seo;
        } elseif (isset($input['seo'])) {
            $input['seo'] = self::normalize_seo($input['seo']);
        }
        if($message=self::customer_copy_violation($input))return self::fail($message,'supplier_identity_in_customer_copy');
        $variation_input_hash = hash('sha256', wp_json_encode(['type' => $type, 'sku' => $input['sku'] ?? ($existing ? $existing->get_sku('edit') : ''), 'rows' => $rows]));
        if ($is_resume && ((!empty($resume_state['mode']) && $resume_state['mode'] !== $mode) || !hash_equals((string)($resume_state['input_hash'] ?? ''), $variation_input_hash) || absint($input['variation_offset'] ?? 0) !== absint($resume_state['next_offset'] ?? 0))) {
            return self::fail('Resume input or variation offset does not match the saved partial operation.', 'resume_mismatch');
        }
        $size_check = self::check_size_category($input, $existing);
        if (is_wp_error($size_check)) { return $size_check; }
        if ($existing && !empty($input['size_attribute'])) {
            $current_size_tax = self::size_taxonomy($existing);
            $requested_size_tax = self::size_taxonomy($existing, $input);
            if (is_wp_error($requested_size_tax)) { return $requested_size_tax; }
            if ($current_size_tax !== $requested_size_tax && $existing->is_type('variable') && $existing->get_children()) {
                return self::fail('Existing variations require an explicit attribute migration before changing size taxonomy.', 'size_migration_has_variations');
            }
            if ($current_size_tax !== $requested_size_tax && empty($input['sizes'])) {
                return self::fail('Supply confirmed sizes when changing the size taxonomy.', 'size_migration_missing_sizes');
            }
        }
        $supplier_map = self::supplier_color_map($input);
        if (is_wp_error($supplier_map)) { return $supplier_map; }
        $incoming_parent_sku = array_key_exists('sku', $input) ? self::sku($input, '') : ($existing ? $existing->get_sku('edit') : self::sku($input, (string)($input['slug'] ?? '')));
        if ($type === 'variable' && $incoming_parent_sku === '' && ($rows || !empty($input['full_matrix']))) {
            return self::fail('A parent SKU is required for unique internal or supplier-linked variations.', 'missing_parent_sku');
        }
        $stages = []; $errors = []; $pending = []; $media = []; $image_ids = [];
        $record = static function (string $stage, $result) use (&$stages, &$errors): bool {
            if (is_wp_error($result)) { $stages[$stage] = 'stage_failed'; $errors[] = ['stage' => $stage, 'code' => $result->get_error_code(), 'message' => $result->get_error_message()]; return false; }
            if (($stages[$stage] ?? '') !== 'stage_failed') { $stages[$stage] = 'saved_and_verified'; }
            return true;
        };
        if ($existing && !empty($input['size_attribute']) && self::size_taxonomy($existing) !== self::size_taxonomy($existing, $input)) {
            $migrated = self::extend_options($id, $input);
            if (is_wp_error($migrated)) { return $migrated; }
            $stages['options'] = 'saved_and_verified';
        }
        if (!$id) {
            if (empty($input['name']) || empty($input['category_ids'])) { return self::fail('A title and category ID are required for a new Draft.', 'missing_core'); }
            $core = array_intersect_key($input, array_flip(['name','slug','sku','type','category_ids','colors','sizes','size_attribute','color_attribute','regular_price','sale_price','stock_status']));
            $core['type'] = $type;
            $created = self::draft_create($core);
            if (is_wp_error($created)) { return $created; }
            $id = (int)$created['id'];
            $stages['core_product'] = 'saved_and_verified';
        } else {
            $core = array_intersect_key($input, array_flip(['name','slug','sku','category_ids']));
            if ($core) { $record('core_product', self::listing_update($core + ['product_id' => $id])); }
            else { $stages['core_product'] = 'unchanged'; }
        }
        $active_resume_token = $resume_token;
        $variation_offset = $is_resume ? absint($resume_state['next_offset'] ?? 0) : 0;
        if ($rows && !$is_resume) {
            $active_resume_token = wp_generate_password(40, false, false);
            $resume_state = [
                'token_hash' => hash_hmac('sha256', $active_resume_token, wp_salt('auth')),
                'input_hash' => $variation_input_hash,
                'mode' => $mode,
                'next_offset' => 0,
                'total' => count($rows),
                'created_at' => current_time('mysql', true),
            ];
            update_post_meta($id, '_dreminex_ai_listing_resume', $resume_state);
        }
        $editorial = array_intersect_key($input, array_flip(['description','short_description','tags']));
        if ($editorial) { $record('editorial', self::listing_update($editorial + ['product_id' => $id])); }
        if (isset($input['seo'])) {
            $record('seo', is_array($input['seo']) ? self::listing_update(['product_id' => $id, 'seo' => $input['seo']]) : self::fail('SEO must be an object.', 'invalid_seo'));
        }
        if (!isset($stages['options']) && $type === 'variable' && (!empty($input['colors']) || !empty($input['sizes']) || !empty($input['facts']) || !empty($input['size_attribute']))) {
            $record('options', self::extend_options($id, $input));
        } elseif (!isset($stages['options']) && !empty($input['facts'])) { $record('options', self::extend_options($id, $input)); }
        if ($supplier_map) {
            $stored_map = get_post_meta($id, '_dreminex_ai_color_supplier_sku_map', true);
            $stored_map = is_array($stored_map) ? array_filter($stored_map, 'is_string', ARRAY_FILTER_USE_KEY) : [];
            foreach ($supplier_map as $color => $code) { $stored_map[$color] = $code; }
            update_post_meta($id, '_dreminex_ai_color_supplier_sku_map', $stored_map);
        }
        if ($type === 'variable' && array_key_exists('regular_price', $input) && wc_format_decimal($input['regular_price']) !== '') {
            update_post_meta($id, '_dreminex_ai_reference_price', ['regular' => wc_format_decimal($input['regular_price']), 'sale' => wc_format_decimal($input['sale_price'] ?? '')]);
        }
        $images = $input['images'] ?? [];
        if (!is_array($images) || count($images) > 40) { $record('media', self::fail('Supply at most 40 images.', 'invalid_image_batch')); $images = []; }
        $explicit_color_map = [];
        if ($images) {
            foreach ($images as $index => $entry) {
                if (!is_array($entry)) { $record('media', self::fail('Image entry must be an object.', 'invalid_image')); continue; }
                $result = self::media_batch_upload(['images' => [$entry]]);
                if (is_wp_error($result) || !empty($result['partial'])) {
                    $error = is_wp_error($result) ? $result : self::fail($result['error'] ?? 'Media resolution failed.', $result['error_code'] ?? 'media_failed');
                    $record('media', $error); continue;
                }
                $media[$index] = $result['images'][0];
                $media[$index]['index'] = $index;
                $image_ids[$index] = (int)$media[$index]['id'];
                if (!empty($entry['color'])) {
                    $key = sanitize_title((string)$entry['color']);
                    if (isset($explicit_color_map[$key]) && $explicit_color_map[$key] !== (int)$media[$index]['id']) {
                        // A second detail photo for a color is allowed; retain the first variation image.
                    } else { $explicit_color_map[$key] = (int)$media[$index]['id']; }
                }
                if (!empty($input['update_media_metadata']) && (array_key_exists('alt', $entry) || array_key_exists('title', $entry) || array_key_exists('slug', $entry))) {
                    $record('media_metadata', self::media_update(['image_id' => $image_ids[$index]] + array_intersect_key($entry, array_flip(['alt','title','slug']))));
                }
            }
            if ($image_ids) {
                $existing_product = wc_get_product($id);
                $old_ids = array_values(array_filter(array_merge([$existing_product->get_image_id()], $existing_product->get_gallery_image_ids())));
                $featured_index = $input['featured_image_index'] ?? null;
                if ($featured_index !== null && !isset($image_ids[$featured_index])) {
                    $record('media', self::fail('Featured image index did not resolve.', 'invalid_image_index'));
                } else {
                    $ordered = $mode === 'update'
                        ? array_values(array_unique(array_merge($featured_index !== null ? [$image_ids[$featured_index]] : [], $old_ids, array_values($image_ids))))
                        : array_values(array_unique(array_merge($featured_index !== null ? [$image_ids[$featured_index]] : [], array_values($image_ids))));
                    if ($record('media', self::listing_update(['product_id' => $id, 'image_ids' => $ordered]))) {
                        $previous_color_map = $mode === 'update' ? (array)get_post_meta($id, '_dreminex_ai_color_image_map', true) : [];
                        update_post_meta($id, '_dreminex_ai_color_image_map', array_merge($previous_color_map, $explicit_color_map));
                    }
                }
            }
        } elseif (!empty($input['image_ids'])) {
            $record('media', self::listing_update(['product_id' => $id, 'image_ids' => $input['image_ids']]));
            $image_ids = array_values(array_map('absint', $input['image_ids']));
        }
        $processed_variation_count = $variation_offset ?? 0;
        $variation_resume_required = false;
        if ($type === 'variable') {
            if (!$rows) {
                if ($mode === 'update') $stages['variations'] = 'unchanged';
                else {
                    $stages['variations'] = 'pending_optional_input';
                    $pending[] = 'availability_per_colour_size';
                }
            } else {
                $intended = []; $validated = []; $variation_validation_failed = false;
                foreach ($rows as $index => $row) {
                    if (!is_array($row)) { $record('variations', self::fail('Variation must be an object.', 'invalid_variant')); $variation_validation_failed = true; continue; }
                    $key = sanitize_title((string)($row['color'] ?? '')) . '|' . sanitize_title((string)($row['size'] ?? ''));
                    if ($key === '|' || isset($intended[$key])) { $record('variations', self::fail('Every offered colour/size pair must be nonempty and unique.', 'duplicate_variant')); $variation_validation_failed = true; continue; }
                    $intended[$key] = true;
                    if (!isset($row['regular_price'])) { $row['regular_price'] = $input['regular_price'] ?? ''; }
                    if (!isset($row['sale_price'])) { $row['sale_price'] = $input['sale_price'] ?? ''; }
                    if (!isset($row['stock_status']) && isset($input['stock_status'])) { $row['stock_status'] = $input['stock_status']; }
                    if (isset($row['image_index'])) {
                        if (!isset($image_ids[$row['image_index']])) { $record('variations', self::fail('Variation image index did not resolve.', 'invalid_image_index')); $variation_validation_failed = true; continue; }
                        $row['image_id'] = $image_ids[$row['image_index']]; unset($row['image_index']);
                    } elseif (isset($explicit_color_map[sanitize_title((string)($row['color'] ?? ''))])) {
                        $row['image_id'] = $explicit_color_map[sanitize_title((string)$row['color'])];
                    }
                    $validated[] = $row;
                }
                if ($validated && !$variation_validation_failed) {
                    update_post_meta($id, '_dreminex_ai_intended_variations', array_keys($intended));
                    $remaining_rows = array_slice($validated, $variation_offset);
                    foreach (array_chunk($remaining_rows, self::VARIATION_BATCH_SIZE) as $batch) {
                        $batch_result = self::variations_upsert(['product_id' => $id, 'variants' => $batch]);
                        if (!$record('variations', $batch_result)) {
                            $variation_resume_required = true;
                            $pending[] = 'variation_resume';
                            break;
                        }
                        $processed_variation_count += count($batch);
                        if ($resume_state) {
                            $resume_state['next_offset'] = $processed_variation_count;
                            update_post_meta($id, '_dreminex_ai_listing_resume', $resume_state);
                        }
                    }
                    if (!$variation_resume_required && $processed_variation_count >= count($validated)) delete_post_meta($id, '_dreminex_ai_listing_resume');
                } elseif ($variation_validation_failed) {
                    $variation_resume_required = true;
                    $pending[] = 'variation_validation';
                }
            }
        }
        if (!empty($input['colors']) && is_array($input['colors'])) {
            $swatches = [];
            foreach ($input['colors'] as $color) {
                if (!is_array($color)) continue;
                $color_key = sanitize_title((string)($color['name'] ?? ''));
                $explicit_choice = isset($color['swatch_image_id']) || isset($color['swatch_image_index']) || ($color['mode'] ?? '') === 'color';
                if (!$explicit_choice && isset($explicit_color_map[$color_key])) {
                    $color['swatch_image_id'] = $explicit_color_map[$color_key];
                }
                if (!isset($color['swatch_image_id']) && !isset($color['swatch_image_index']) && ($color['mode'] ?? '') !== 'color') continue;
                $image_id = $color['swatch_image_id'] ?? 0;
                if (isset($color['swatch_image_index'])) {
                    if (!isset($image_ids[$color['swatch_image_index']])) { $record('image_swatches', self::fail('Swatch image index did not resolve.', 'invalid_swatch_index')); continue; }
                    $image_id = $image_ids[$color['swatch_image_index']];
                }
                $swatches[] = ['name' => $color['name'] ?? '', 'image_id' => $image_id, 'mode' => $color['mode'] ?? 'image'];
            }
            if ($swatches) $record('image_swatches', self::color_swatch_set(['product_id' => $id, 'color_attribute' => $input['color_attribute'] ?? '', 'colors' => $swatches]));
        }
        if (array_key_exists('upsell_ids', $input) || array_key_exists('cross_sell_ids', $input)
            || array_key_exists('upsell_skus', $input) || array_key_exists('cross_sell_skus', $input)) {
            $record('related_products', self::apply_related($id, $input));
        }
        $supplier_source_url = is_string($input['supplier_source_url'] ?? null) ? trim($input['supplier_source_url']) : '';
        if ($supplier_source_url !== '') { $record('supplier_source', self::apply_supplier_source($id, $supplier_source_url)); }
        $audit = self::draft_audit(['product_id' => $id]);
        if ($mode === 'publish' && $existing?->get_status() !== 'publish') {
            $listing_errors = array_filter($errors, static fn($error) => ($error['stage'] ?? '') !== 'supplier_source');
            if ($listing_errors || is_wp_error($audit) || empty($audit['ready'])) {
                $stages['publication_gate'] = 'blocker_for_publish';
                $pending[] = 'publication_readiness';
            } else { $record('publication_gate', self::draft_publish(['product_id' => $id, 'publish' => true])); }
        } elseif ($mode === 'draft' && $existing?->get_status() === 'publish') {
            $product = wc_get_product($id); $product->set_status('draft'); $product->save();
        }
        $saved = self::product_read(['product_id' => $id]);
        if (is_wp_error($saved)) {
            $stages['read_back_and_report'] = 'stage_failed';
            $errors[] = ['stage' => 'read_back_and_report', 'code' => $saved->get_error_code(), 'message' => $saved->get_error_message()];
            $fallback = wc_get_product($id);
            $saved = ['id' => $id, 'status' => $fallback ? $fallback->get_status() : get_post_status($id), 'type' => $fallback ? $fallback->get_type() : $type, 'permalink' => get_permalink($id)];
        } else {
            $stages['read_back_and_report'] = 'saved_and_verified';
        }
        $result = ['id' => $id, 'product_id' => $id, 'operation' => $mode === 'update' ? 'update' : 'create',
            'ignored_product_id' => $mode !== 'update' && $requested_product_id > 0,
            'status' => $saved['status'], 'type' => $saved['type'], 'permalink' => $saved['permalink'],
            'partial' => (bool)($errors || $pending), 'stages' => $stages, 'errors' => $errors, 'pending_inputs' => array_values(array_unique($pending)),
            'can_resume' => $variation_resume_required, 'resume_product_id' => $variation_resume_required ? $id : null,
            'resume_token' => $variation_resume_required ? $active_resume_token : null,
            'variation_offset' => $variation_resume_required ? $processed_variation_count : null,
            'normalized_variation_count' => count($rows), 'processed_variation_count' => min(count($rows), $processed_variation_count),
            'remaining_variation_count' => max(0, count($rows) - $processed_variation_count),
            'variation_capacity' => ['configured_limit' => self::variation_capacity(), 'hard_limit' => self::MAX_VARIATION_ROWS, 'batch_size' => self::VARIATION_BATCH_SIZE],
            'media_reused' => count(array_filter($media, static fn($m) => !empty($m['reused']))),
            'media' => $media, 'image_ids' => array_values(array_unique($image_ids)), 'audit' => $audit,
            'elapsed_ms' => (int)round((microtime(true) - $started) * 1000), 'product' => $saved];
        return $result;
    }

    private static function extend_options(int $id, array $input) {
        $product = wc_get_product($id); $attributes = $product->get_attributes(); $warnings = [];
        $color_tax = self::color_taxonomy($product, $input);
        if (!empty($input['colors']) && is_wp_error($color_tax)) { return $color_tax; }
        $old_size_tax = self::size_taxonomy($product);
        $size_tax = self::size_taxonomy($product, $input);
        if (is_wp_error($size_tax)) { return $size_tax; }
        $size_check = self::check_size_category($input, $product);
        if (is_wp_error($size_check)) { return $size_check; }
        if ($old_size_tax !== $size_tax && isset($attributes[$old_size_tax])) {
            if ($product->is_type('variable') && $product->get_children()) {
                return self::fail('Existing variations require an explicit attribute migration before changing size taxonomy.', 'size_migration_has_variations');
            }
            if (empty($input['sizes'])) { return self::fail('Supply confirmed sizes when changing the size taxonomy.', 'size_migration_missing_sizes'); }
            unset($attributes[$old_size_tax]);
        }
        foreach (['color' => 'colors', 'size' => 'sizes'] as $kind => $field) {
            if (empty($input[$field])) { continue; }
            if ($product->is_type('simple') && count($input[$field]) > 1) { return self::fail('Several selectable options require a Variable product.', 'type_conflict'); }
            $taxonomy = $kind === 'size' ? $size_tax : $color_tax;
            if (self::attribute_id($taxonomy) < 1) { return self::fail('Configured global attribute is unavailable.', 'missing_attribute'); }
            $options = isset($attributes[$taxonomy]) ? array_map('intval', $attributes[$taxonomy]->get_options()) : [];
            foreach ($input[$field] as $entry) {
                $name = $kind === 'color' ? (string)($entry['name'] ?? '') : (string)$entry;
                $term = self::term($taxonomy, $name, $kind === 'color' ? ($entry['hex'] ?? null) : null, $warnings);
                if (is_wp_error($term)) { return $term; }
                $options[] = (int)$term->term_id;
            }
            $attribute = isset($attributes[$taxonomy]) ? clone $attributes[$taxonomy] : new WC_Product_Attribute();
            $attribute->set_id(self::attribute_id($taxonomy)); $attribute->set_name($taxonomy);
            $attribute->set_options(array_values(array_unique($options)));
            $attribute->set_visible(true); $attribute->set_variation($product->is_type('variable'));
            $attributes[$taxonomy] = $attribute;
        }
        foreach (($input['facts'] ?? []) as $label => $value) {
            $label = sanitize_text_field((string)$label); $value = sanitize_text_field((string)$value);
            if ($label === '' || $value === '') { continue; }
            $attribute = new WC_Product_Attribute(); $attribute->set_name($label);
            $attribute->set_options([$value]); $attribute->set_visible(true); $attribute->set_variation(false);
            $attributes[$label] = $attribute;
        }
        $product->set_attributes(array_values($attributes)); $product->save();
        if ($old_size_tax !== $size_tax && taxonomy_exists($old_size_tax) && isset($input['sizes'])) {
            $removed = wp_set_object_terms($id, [], $old_size_tax);
            if (is_wp_error($removed)) { return $removed; }
        }
        if (!empty($input['sizes'])) { update_post_meta($id, '_dreminex_ai_size_taxonomy', $size_tax); }
        if (!empty($input['colors'])) { update_post_meta($id, '_dreminex_ai_color_taxonomy', $color_tax); }
        return true;
    }

    private static function apply_related(int $id, array $input) {
        $product = wc_get_product($id);
        $changed = false;
        foreach (['upsell' => 'set_upsell_ids', 'cross_sell' => 'set_cross_sell_ids'] as $kind => $setter) {
            if (!array_key_exists($kind . '_ids', $input) && !array_key_exists($kind . '_skus', $input)) { continue; }
            $ids = array_map('absint', (array)($input[$kind . '_ids'] ?? []));
            foreach ((array)($input[$kind . '_skus'] ?? []) as $sku) { $ids[] = (int)wc_get_product_id_by_sku(sanitize_text_field((string)$sku)); }
            $ids = array_values(array_unique(array_filter($ids, static fn($related_id) => $related_id !== $id && wc_get_product($related_id))));
            $product->$setter($ids);
            $changed = true;
        }
        if ($changed) { $product->save(); }
        return true;
    }

    public static function variations_upsert(array $input) {
        $id = absint($input['product_id'] ?? 0);
        $parent = wc_get_product($id);
        if (!$parent || !$parent->is_type('variable') || !in_array($parent->get_status(), ['draft','publish'], true)) { return self::fail('An existing variable parent is required.'); }
        $rows = $input['variants'] ?? [];
        if (!$rows || count($rows) > 12) { return self::fail('Send 1–12 explicit variants per batch.'); }
        $seen = [];
        foreach ($rows as $row) {
            $key = sanitize_title((string)($row['color'] ?? '')) . '|' . sanitize_title((string)($row['size'] ?? ''));
            if (isset($seen[$key])) { return self::fail('Duplicate color/size combination in batch.', 'duplicate_variant'); }
            $seen[$key] = true;
            if (isset($row['stock_quantity'])) {
                $quantity = filter_var($row['stock_quantity'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
                if ($quantity === false) { return self::fail('Stock quantity must be a nonnegative whole number.', 'invalid_stock'); }
            } elseif (!empty($row['manage_stock'])) { return self::fail('Supply a quantity when managing variation stock.', 'invalid_stock'); }
            $price = wc_format_decimal($row['regular_price'] ?? ''); $sale_price = wc_format_decimal($row['sale_price'] ?? '');
            if ($price === '' || (float)$price <= 0 || ($sale_price !== '' && (float)$sale_price >= (float)$price)) { return self::fail('Invalid variant price.'); }
        }
        $color_tax = self::color_taxonomy($parent); if (is_wp_error($color_tax)) { return $color_tax; }
        $size_tax = self::size_taxonomy($parent);
        if (is_wp_error($size_tax)) { return $size_tax; }
        $supplier_map = (array)get_post_meta($id, '_dreminex_ai_color_supplier_sku_map', true);
        $allowed = [];
        foreach ($parent->get_attributes() as $attribute) { $allowed[$attribute->get_name()] = array_map('intval', $attribute->get_options()); }
        $existing = [];
        foreach ($parent->get_children() as $child_id) {
            $child = wc_get_product($child_id);
            if ($child) { $a = $child->get_attributes(); $existing[($a[$color_tax] ?? '') . '|' . ($a[$size_tax] ?? '')] = $child_id; }
        }
        $done = [];
        foreach ($rows as $row) {
            $color = null;
            if (!empty($allowed[$color_tax])) {
                foreach ($allowed[$color_tax] as $term_id) {
                    $candidate = get_term($term_id, $color_tax);
                    if ($candidate && !is_wp_error($candidate)
                        && (strcasecmp(self::base_color($candidate), (string)($row['color'] ?? '')) === 0 || $candidate->slug === sanitize_title($row['color'] ?? ''))
                        && (empty($row['color_hex']) || strcasecmp((string)get_term_meta($candidate->term_id, 'product_attribute_color', true), (string)sanitize_hex_color($row['color_hex'])) === 0)) {
                        $color = $candidate; break;
                    }
                }
            }
            $size = !empty($allowed[$size_tax])
                ? (get_term_by('name', (string)($row['size'] ?? ''), $size_tax) ?: get_term_by('slug', sanitize_title($row['size'] ?? ''), $size_tax)) : null;
            if ((!empty($allowed[$color_tax]) && !$color) || (!empty($allowed[$size_tax]) && (!$size || !in_array((int)$size->term_id, $allowed[$size_tax], true)))) {
                return self::fail('Variant uses an option absent from the parent.');
            }
            $gallery_ids = array_merge([$parent->get_image_id()], $parent->get_gallery_image_ids());
            $image_id = absint($row['image_id'] ?? ($color ? self::image_for_color($gallery_ids, self::base_color($color)) : $parent->get_image_id()));
            if ($image_id) {
                $image_id = self::checked_image($image_id);
                if (is_wp_error($image_id)) { return $image_id; }
            }
            $mapped = (array)get_post_meta($id, '_dreminex_ai_color_image_map', true);
            $verified_mapping = $color && (int)($mapped[sanitize_title(self::base_color($color))] ?? 0) === $image_id
                && in_array($image_id, array_map('intval', $gallery_ids), true);
            if ($color && $image_id && !empty(self::config()['require_image_match']) && !$verified_mapping && !self::image_has_color($image_id, self::base_color($color))) {
                return self::fail('Variation image is not verified for color ' . self::base_color($color) . '.', 'image_color_mismatch');
            }
            $key = ($color ? $color->slug : '') . '|' . ($size ? $size->slug : '');
            $variant = isset($existing[$key]) ? new WC_Product_Variation($existing[$key]) : new WC_Product_Variation();
            $variant->set_parent_id($id);
            $values = [];
            if ($color) { $values[$color_tax] = $color->slug; }
            if ($size) { $values[$size_tax] = $size->slug; }
            $variant->set_attributes($values);
            $variant->set_image_id($image_id);
            $variant->set_status('publish'); // Child status is internal; parent remains Draft.
            $color_code = $color ? (string)($supplier_map[sanitize_title(self::base_color($color))] ?? '') : '';
            $supplier_code = self::supplier_code($row['supplier_sku'] ?? $color_code);
            if (is_wp_error($supplier_code)) { return $supplier_code; }
            if ($supplier_code !== '' && !$color) { return self::fail('A supplier SKU must be linked to a verified color.', 'supplier_sku_missing_color'); }
            if ($supplier_code !== '' && $color_code !== '' && $supplier_code !== $color_code) {
                return self::fail('Variant supplier SKU conflicts with its verified image color.', 'supplier_sku_color_conflict');
            }
            $internal_sku = $parent->get_sku('edit') . '-' . strtoupper((string)($color ? $color->slug : '')) . ($size ? '-' . strtoupper((string)$size->slug) : '');
            if ($supplier_code !== '') {
                $base_sku = !empty($row['sku']) ? self::sku($row, '') : ((isset($existing[$key]) ? $variant->get_sku('edit') : '') ?: $internal_sku);
                $old_code = (string)get_post_meta((int)$variant->get_id(), '_dreminex_supplier_sku', true);
                if ($old_code !== '' && str_ends_with($base_sku, '-' . $old_code)) $base_sku = substr($base_sku, 0, -strlen($old_code) - 1);
                $sku = self::variation_supplier_sku($base_sku, $supplier_code);
                if (is_wp_error($sku)) { return $sku; }
            } else {
                $sku = (
                !empty($row['sku']) ? self::sku($row, $internal_sku) :
                ((isset($existing[$key]) ? $variant->get_sku('edit') : '') ?: $internal_sku)
                );
            }
            if ($sku === '') { return self::fail('A unique internal variation SKU could not be composed.', 'missing_variant_sku'); }
            $check = self::validate_sku($sku, (int)$variant->get_id());
            if (is_wp_error($check)) { return $check; }
            if ($sku !== '') { $variant->set_sku($sku); }
            $stock = self::stock($variant, $row);
            if (is_wp_error($stock)) { return $stock; }
            $regular = wc_format_decimal($row['regular_price'] ?? '');
            $sale = wc_format_decimal($row['sale_price'] ?? '');
            if ($regular === '' || (float)$regular <= 0 || ($sale !== '' && (float)$sale >= (float)$regular)) { return self::fail('Invalid variant price.'); }
            $variant->set_regular_price($regular); $variant->set_sale_price($sale);
            $variant_id = $variant->save();
            if ($supplier_code !== '') { update_post_meta($variant_id, '_dreminex_supplier_sku', $supplier_code); }
            $existing[$key] = $variant_id;
            $done[] = ['id' => $variant_id, 'color' => $color ? $color->name : null, 'size' => $size ? $size->name : null, 'image_id' => $image_id, 'sku' => $variant->get_sku('edit'), 'supplier_sku' => $supplier_code, 'stock_quantity' => $variant->get_stock_quantity(), 'manage_stock' => $variant->get_manage_stock()];
        }
        WC_Product_Variable::sync($id);
        wc_delete_product_transients($id);
        return ['product_id' => $id, 'parent_status' => get_post_status($id), 'upserted' => $done, 'variation_count' => count($existing)];
    }

    /** Image selection is scoped to a product: global color terms are shared by unrelated items. */
    public static function color_swatch_set(array $input) {
        $id = absint($input['product_id'] ?? 0);
        $product = wc_get_product($id);
        if (!$product || !$product->is_type('variable') || !in_array($product->get_status(), ['draft', 'publish'], true)) return self::fail('An existing variable product is required.', 'invalid_product');
        $taxonomy = self::color_taxonomy($product, $input);
        if (is_wp_error($taxonomy)) { return $taxonomy; }
        if ($taxonomy === '') { return self::fail('Product has no global colour attribute.', 'missing_color_attribute'); }
        $attribute = $product->get_attributes()[$taxonomy] ?? null;
        if (!$attribute || !$attribute->is_taxonomy()) return self::fail('Product has no global color choices.', 'missing_color_attribute');
        $available = [];
        foreach ($attribute->get_options() as $term_id) {
            $term = get_term($term_id, $taxonomy);
            if ($term && !is_wp_error($term)) { $available[$term->slug] = $term; }
        }
        $media_ids = array_map('intval', array_merge([$product->get_image_id()], $product->get_gallery_image_ids()));
        foreach ($product->get_children() as $child_id) {
            $child = wc_get_product($child_id);
            if ($child) $media_ids[] = (int)$child->get_image_id();
        }
        $media_ids = array_values(array_unique(array_filter($media_ids)));
        $rows = $input['colors'] ?? [];
        if (!is_array($rows) || !$rows || count($rows) > 40) return self::fail('Supply 1–40 color swatches.', 'invalid_swatches');
        $stored = get_post_meta($id, '_dreminex_ai_swatch_images', true);
        $map = is_array($stored) ? array_filter($stored, static fn($key) => is_string($key), ARRAY_FILTER_USE_KEY) : [];
        $seen = [];
        foreach ($rows as $row) {
            if (!is_array($row)) return self::fail('Swatch entry must be an object.', 'invalid_swatch');
            $name = trim((string)($row['name'] ?? ''));
            $term = null;
            foreach ($available as $candidate) {
                if (strcasecmp($candidate->name, $name) === 0 || strcasecmp(self::base_color($candidate), $name) === 0 || $candidate->slug === sanitize_title($name)) { $term = $candidate; break; }
            }
            if (!$term || isset($seen[$term->slug])) return self::fail('Swatch name must match one unique product color.', 'invalid_swatch_color');
            $seen[$term->slug] = true;
            $mode = sanitize_key($row['mode'] ?? 'image');
            if ($mode === 'color') { unset($map[$term->slug]); continue; }
            if ($mode !== 'image') return self::fail('Choose image or color mode.', 'invalid_swatch_mode');
            $image_id = self::checked_image($row['image_id'] ?? 0);
            if (is_wp_error($image_id)) return $image_id;
            if (!in_array($image_id, $media_ids, true)) return self::fail('Swatch image must belong to this product gallery or a variation.', 'unrelated_swatch_image');
            $map[$term->slug] = $image_id;
        }
        update_post_meta($id, '_dreminex_ai_swatch_images', $map);
        update_post_meta($id, '_dreminex_ai_color_taxonomy', $taxonomy);
        wc_delete_product_transients($id);
        return ['product_id' => $id, 'color_attribute' => $taxonomy, 'swatches' => $map];
    }

    public static function image_swatches_html($html, $args) {
        $product = $args['product'] ?? null;
        if (!is_string($html) || !$product instanceof WC_Product) return $html;
        $taxonomy = sanitize_key((string)($args['attribute'] ?? ''));
        $product_taxonomy = self::color_taxonomy($product);
        if (is_wp_error($product_taxonomy) || $product_taxonomy === '' || $taxonomy !== $product_taxonomy) return $html;
        $map = get_post_meta($product->get_id(), '_dreminex_ai_swatch_images', true);
        if (!is_array($map) || !$map) return $html;
        return preg_replace_callback('~(<div\\b[^>]*class="[^"]*\\brtwpvs-color-term\\b[^"]*"[^>]*\\bdata-term="([^"]+)"[^>]*>)(.*?)(</div>)~s', static function ($m) use ($map, $taxonomy) {
            $slug = html_entity_decode($m[2], ENT_QUOTES, 'UTF-8');
            $id = absint($map[$slug] ?? 0);
            $url = $id ? wp_get_attachment_image_url($id, 'thumbnail') : false;
            if (!$url) return $m[0];
            $term = get_term_by('slug', $slug, $taxonomy);
            $label = $term ? $term->name : $slug;
            $content = preg_replace('~<span\\b(?=[^>]*\\bclass="[^"]*\\brtwpvs-term-span\\b[^"]*")[^>]*>\\s*</span>~', '<span class="rtwpvs-term-span rtwpvs-term-span-image dreminex-image-swatch"><img src="'.esc_url($url).'" alt="'.esc_attr($label).'" loading="lazy" width="64" height="64"></span>', $m[3], 1, $count);
            if (!$count) return $m[0];
            $open = str_replace('rtwpvs-color-term', 'rtwpvs-color-term dreminex-image-term', $m[1]);
            return $open.$content.$m[4];
        }, $html);
    }

    public static function swatch_styles(): void {
        if (!function_exists('is_product') || !(is_product() || is_shop() || is_product_taxonomy())) return;
        wp_register_style('dreminex-ai-image-swatches', false, [], DREMINEX_SUITE_VERSION);
        wp_enqueue_style('dreminex-ai-image-swatches');
        wp_add_inline_style('dreminex-ai-image-swatches', '.rtwpvs .dreminex-image-term .dreminex-image-swatch{display:block;overflow:hidden;border-radius:inherit;background:#F8F9FA!important}.rtwpvs .dreminex-image-term .dreminex-image-swatch img{display:block;width:100%;height:100%;object-fit:cover;aspect-ratio:1}.rtwpvs .dreminex-image-term:focus-visible{outline:2px solid #00B4D7;outline-offset:3px}');
    }

    public static function colors_reconcile(array $input) {
        $id = absint($input['product_id'] ?? 0);
        $product = wc_get_product($id);
        if (!$product || !in_array($product->get_type(), ['simple', 'variable'], true) || $product->get_status() !== 'draft') { return self::fail('A simple or variable Draft product is required.'); }
        $taxonomy = self::color_taxonomy($product, $input);
        if (is_wp_error($taxonomy)) { return $taxonomy; }
        if ($taxonomy === '') { return self::fail('Product has no global colour attribute.', 'missing_color_attribute'); }
        $attributes = $product->get_attributes();
        if (empty($attributes[$taxonomy])) { return self::fail('Product has no configured global color attribute.'); }
        $old = [];
        foreach ($attributes[$taxonomy]->get_options() as $term_id) {
            $term = get_term($term_id, $taxonomy);
            if ($term && !is_wp_error($term)) { $old[self::base_color($term)] = $term; }
        }
        $definitions = $input['colors'] ?? [];
        if (count($definitions) !== count($old)) { return self::fail('Supply one HEX for every existing color.'); }
        $warnings = []; $new = [];
        foreach ($definitions as $entry) {
            $name = trim((string)($entry['name'] ?? ''));
            $hex = sanitize_hex_color($entry['hex'] ?? '');
            if (!isset($old[$name]) || !$hex || isset($new[$name])) { return self::fail('Color name/HEX does not match product options.'); }
            $term = self::term($taxonomy, $name, $hex, $warnings);
            if (is_wp_error($term)) { return $term; }
            $new[$name] = $term;
        }
        // WooCommerce compares the old and new attribute arrays when marking a
        // property dirty. Mutating the original object in place hides the change.
        $attribute = clone $attributes[$taxonomy];
        $attribute->set_options(array_map(static fn($term) => (int)$term->term_id, array_values($new)));
        $attributes[$taxonomy] = $attribute;
        $product->set_attributes(array_values($attributes));
        $product->save();
        update_post_meta($id, '_dreminex_ai_color_taxonomy', $taxonomy);
        $changed = [];
        if ($product->is_type('variable')) {
            foreach ($product->get_children() as $child_id) {
                $variant = wc_get_product($child_id);
                if (!$variant) { continue; }
                $values = $variant->get_attributes();
                $old_term = get_term_by('slug', $values[$taxonomy] ?? '', $taxonomy);
                $base = $old_term ? self::base_color($old_term) : '';
                if (!isset($new[$base]) || !self::image_has_color((int)$variant->get_image_id(), $base)) { return self::fail('Existing variation cannot be safely mapped to ' . $base . '.', 'image_color_mismatch'); }
                $values[$taxonomy] = $new[$base]->slug;
                $variant->set_attributes($values);
                $variant->save();
                $changed[] = $child_id;
            }
            WC_Product_Variable::sync($id);
        }
        wc_delete_product_transients($id);
        return ['product_id' => $id, 'status' => get_post_status($id), 'colors' => array_map(static fn($term) => ['id' => $term->term_id, 'name' => $term->name, 'slug' => $term->slug, 'hex' => get_term_meta($term->term_id, 'product_attribute_color', true)], array_values($new)), 'variation_ids_updated' => $changed, 'warnings' => $warnings];
    }

    public static function draft_brand_set(array $input) {
        $id = absint($input['product_id'] ?? 0);
        $product = wc_get_product($id);
        if (!$product || !in_array($product->get_status(), ['draft','publish'], true) || !in_array($product->get_type(), ['simple','variable'], true)) { return self::fail('An existing simple or variable product is required.'); }
        $images = array_merge([$product->get_image_id()], $product->get_gallery_image_ids());
        $evidence = self::brand_evidence($input, $images);
        if (is_wp_error($evidence)) { return $evidence; }
        if (!$evidence) { return self::fail('A verified label brand is required.', 'unverified_brand'); }
        $previous = taxonomy_exists('product_brand') ? wp_get_object_terms($id, 'product_brand', ['fields' => 'names']) : [];
        $assigned = self::assign_brand($id, $evidence['name'], $evidence['image_id']);
        if (is_wp_error($assigned)) { return $assigned; }
        $attributes = $product->get_attributes();
        foreach ($attributes as $key => $attribute) {
            if (strcasecmp($attribute->get_name(), 'Brand') === 0) { unset($attributes[$key]); }
        }
        $brand = new WC_Product_Attribute(); $brand->set_name('Brand'); $brand->set_options([$evidence['name']]); $brand->set_visible(true); $brand->set_variation(false);
        $attributes[] = $brand; $product->set_attributes(array_values($attributes)); $product->save();
        return ['product_id' => $id, 'status' => $product->get_status(), 'brand' => $assigned, 'previous_brands' => $previous, 'warning' => $previous && !in_array($evidence['name'], $previous, true) ? 'Image-label brand differs from the previous brand; verify the supplied evidence.' : ''];
    }

    public static function draft_inventory_set(array $input) {
        $id = absint($input['product_id'] ?? 0);
        $parent = wc_get_product($id);
        if (!$parent || !in_array($parent->get_status(), ['draft','publish'], true) || !in_array($parent->get_type(), ['simple','variable'], true)) { return self::fail('An existing simple or variable product is required.'); }
        if ($parent->is_type('variable') && array_key_exists('stock_quantity', $input)) { return self::fail('Variable stock must be set on variations.', 'invalid_stock'); }
        $rows = [['product' => $parent, 'input' => $input]];
        foreach (($input['variations'] ?? []) as $row) {
            $child_id = absint($row['variation_id'] ?? 0);
            if (!$parent->is_type('variable') || !$child_id || !in_array($child_id, $parent->get_children(), true)) { return self::fail('Variation does not belong to this Draft.'); }
            $child = wc_get_product($child_id); if (!$child) { return self::fail('Variation not found.'); }
            $rows[] = ['product' => $child, 'input' => $row];
        }
        if (count($rows) < 2 && $parent->is_type('variable') && !isset($input['sku'])) { return self::fail('Supply a parent SKU or variation rows.'); }
        $used = [];
        foreach ($rows as $entry) {
            $p = $entry['product']; $data = $entry['input'];
            if (array_key_exists('sku', $data)) {
                $sku = self::sku($data, (string)$p->get_id());
                $check = self::validate_sku($sku, (int)$p->get_id()); if (is_wp_error($check)) { return $check; }
                if ($sku !== '' && isset($used[$sku])) { return self::fail('Duplicate SKU in request.', 'duplicate_sku'); }
                $used[$sku] = true;
            }
            if (array_key_exists('stock_quantity', $data)) {
                $quantity = filter_var($data['stock_quantity'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
                if ($quantity === false) { return self::fail('Stock quantity must be a nonnegative whole number.', 'invalid_stock'); }
            }
        }
        $changed = [];
        foreach ($rows as $entry) {
            $p = $entry['product']; $data = $entry['input'];
            if (array_key_exists('sku', $data)) { $p->set_sku(self::sku($data, (string)$p->get_id())); }
            if (array_key_exists('stock_quantity', $data) || array_key_exists('stock_status', $data)) { $stock = self::stock($p, $data); if (is_wp_error($stock)) { return $stock; } }
            if (array_key_exists('sku', $data) || array_key_exists('stock_quantity', $data) || array_key_exists('stock_status', $data)) {
                $p->save();
                $changed[] = ['id' => $p->get_id(), 'sku' => $p->get_sku(), 'manage_stock' => $p->get_manage_stock(), 'stock_quantity' => $p->get_stock_quantity(), 'stock_status' => $p->get_stock_status()];
            }
        }
        if ($parent->is_type('variable')) { WC_Product_Variable::sync($id); wc_delete_product_transients($id); }
        return ['product_id' => $id, 'status' => get_post_status($id), 'changed' => $changed];
    }

    public static function draft_audit(array $input) {
        $id = absint($input['product_id'] ?? 0);
        $product = wc_get_product($id);
        if (!$product || !in_array($product->get_type(), ['simple','variable'], true)) { return self::fail('Product not found.'); }
        $issues = []; $warnings = []; $matrix = []; $config = self::config();
        $mapped = (array)get_post_meta($id, '_dreminex_ai_color_image_map', true);
        if ($product->get_status() !== 'draft') { $warnings[] = 'Product is not a Draft.'; }
        if (!$product->get_name() || !$product->get_description() || !$product->get_short_description()) { $issues[] = 'Title, long and short description are required.'; }
        if (!$product->get_category_ids() || !$product->get_image_id()) { $issues[] = 'Category and featured image are required.'; }
        if (!taxonomy_exists('product_brand') || !wp_get_object_terms($id, 'product_brand', ['fields' => 'ids'])) { $warnings[] = 'No product brand assigned.'; }
        if (!$product->get_sku()) { $warnings[] = 'Parent SKU is blank.'; }
        if ($product->is_type('simple')) {
            if ((float)$product->get_regular_price() <= 0) { $issues[] = 'Simple product price is missing.'; }
        } else {
            $attributes = $product->get_attributes();
            $color_tax = self::color_taxonomy($product); if (is_wp_error($color_tax)) { return $color_tax; }
            $size_tax = self::size_taxonomy($product);
            if (is_wp_error($size_tax)) { return $size_tax; }
            $category_check = self::check_size_category(['sizes' => isset($attributes[$size_tax]) ? $attributes[$size_tax]->get_options() : []], $product);
            if (is_wp_error($category_check)) { $issues[] = $category_check->get_error_message(); }
            $colors = isset($attributes[$color_tax]) ? $attributes[$color_tax]->get_options() : [];
            $sizes = isset($attributes[$size_tax]) ? $attributes[$size_tax]->get_options() : [];
            if (!$colors && !$sizes) { $issues[] = 'No selectable options on the Variable parent.'; }
            $actual = []; $gallery = array_map('intval', array_merge([$product->get_image_id()], $product->get_gallery_image_ids()));
            foreach ($product->get_children() as $child_id) {
                $variant = wc_get_product($child_id); if (!$variant) { continue; }
                $values = $variant->get_attributes(); $key = ($values[$color_tax] ?? '') . '|' . ($values[$size_tax] ?? '');
                if (isset($actual[$key])) { $issues[] = 'Duplicate variation combination: ' . $key; }
                $actual[$key] = true;
                $color = $color_tax !== '' ? get_term_by('slug', $values[$color_tax] ?? '', $color_tax) : null;
                $mapped_image = $color && (int)($mapped[sanitize_title(self::base_color($color))] ?? 0) === (int)$variant->get_image_id();
                if (!$variant->get_image_id() || ($color && !$mapped_image && !self::image_has_color((int)$variant->get_image_id(), self::base_color($color)))) { $issues[] = 'Variation image mismatches color: ' . $key; }
                if (!in_array((int)$variant->get_image_id(), $gallery, true)) { $warnings[] = 'Variation image absent from gallery: ' . $key; }
                if ((float)$variant->get_regular_price() <= 0) { $issues[] = 'Variation price missing: ' . $key; }
                if (!$variant->get_sku()) { $warnings[] = 'Variation SKU blank: ' . $key; }
                if (!empty($config['require_stock_for_variants']) && !$variant->get_manage_stock()) { $issues[] = 'Variation stock quantity missing: ' . $key; }
            }
            $intended = get_post_meta($id, '_dreminex_ai_intended_variations', true);
            $intended = is_array($intended) ? array_fill_keys($intended, true) : null;
            if ($intended === null) { $warnings[] = 'Offered color/size combinations are unconfirmed.'; }
            foreach (($intended === null ? [] : ($colors ?: [0])) as $color_id) { foreach (($sizes ?: [0]) as $size_id) {
                $color = $color_id ? get_term($color_id, $color_tax) : null;
                $size = $size_id ? get_term($size_id, $size_tax) : null;
                if (($color_id && (!$color || is_wp_error($color))) || ($size_id && (!$size || is_wp_error($size)))) { continue; }
                $key = ($color ? $color->slug : '') . '|' . ($size ? $size->slug : '');
                $intended_key = sanitize_title($color ? self::base_color($color) : '') . '|' . sanitize_title($size ? $size->name : '');
                if ($intended !== null && !isset($intended[$intended_key])) { continue; }
                if (!isset($actual[$key])) { $matrix[] = ['color' => $color ? self::base_color($color) : null, 'size' => $size ? $size->name : null]; }
            } }
            if ($matrix) { $issues[] = count($matrix) . ' color/size variations are missing.'; }
            if (!$actual) { $issues[] = 'At least one purchasable variation is required.'; }
        }
        foreach (['_yoast_wpseo_title','_yoast_wpseo_metadesc','_yoast_wpseo_focuskw'] as $key) { if (!get_post_meta($id, $key, true)) { $warnings[] = 'SEO field missing: ' . $key; } }
        return ['product_id' => $id, 'status' => $product->get_status(), 'ready' => !$issues, 'issues' => array_values(array_unique($issues)), 'warnings' => array_values(array_unique($warnings)), 'missing_combinations' => $matrix, 'variation_count' => $product->is_type('variable') ? count($product->get_children()) : 0];
    }

    public static function draft_publish(array $input) {
        $id = absint($input['product_id'] ?? 0);
        if (($input['publish'] ?? null) !== true) { return self::fail('Explicit publish=true is required.', 'publication_not_requested'); }
        if (empty(self::config()['allow_publish'])) { return self::fail('Publication is disabled in the Suite module dashboard.', 'publication_disabled'); }
        $product = wc_get_product($id);
        if (!$product || !in_array($product->get_type(), ['simple','variable'], true)) { return self::fail('Product not found.'); }
        if ($product->get_status() === 'publish') { return ['id' => $id, 'status' => 'publish', 'permalink' => get_permalink($id), 'already_published' => true, 'product' => self::product_read(['product_id' => $id])]; }
        if ($product->get_status() !== 'draft') { return self::fail('Only an audited Draft can be published.', 'invalid_status'); }
        $audit = self::draft_audit(['product_id' => $id]);
        if (is_wp_error($audit)) { return $audit; }
        if (!$audit['ready']) { return self::fail('Publication blocked: ' . implode(' ', $audit['issues']), 'audit_failed'); }
        $product->set_status('publish');
        $product->save();
        if ($product->is_type('variable')) { WC_Product_Variable::sync($id); }
        wc_delete_product_transients($id);
        $saved = wc_get_product($id);
        if (!$saved || $saved->get_status() !== 'publish') { return self::fail('Published status could not be verified.', 'publication_failed'); }
        return ['id' => $id, 'status' => 'publish', 'permalink' => get_permalink($id), 'audit' => $audit, 'product' => self::product_read(['product_id' => $id])];
    }

    public static function product_lifecycle(array $input) {
        $id = absint($input['product_id'] ?? 0);
        $action = sanitize_key((string)($input['action'] ?? ''));
        if (!$id || !in_array($action, ['draft','publish','trash','restore','delete'], true)) {
            return self::fail('An exact product ID and lifecycle action are required.', 'invalid_lifecycle_action');
        }
        $post = get_post($id);
        if (!$post || $post->post_type !== 'product') { return self::fail('Product ID not found.', 'invalid_product_id'); }
        $product = wc_get_product($id);
        if (!$product || !in_array($product->get_type(), ['simple','variable'], true)) {
            return self::fail('Only an existing Simple or Variable product can be changed.', 'unsupported_product_type');
        }
        $status = $post->post_status;
        if (isset($input['expected_status']) && $input['expected_status'] !== $status) {
            return self::fail('Product status changed since the last readback.', 'status_conflict');
        }
        if (!current_user_can(in_array($action, ['trash','delete'], true) ? 'delete_post' : 'edit_post', $id)) {
            return self::fail('This account cannot change this product.', 'product_permission_denied');
        }
        if ($action === 'publish') {
            if (!current_user_can('publish_products')) { return self::fail('This account cannot publish products.', 'publish_permission_denied'); }
            return self::draft_publish(['product_id' => $id, 'publish' => true]);
        }
        if ($action === 'draft') {
            if ($status === 'publish') { $product->set_status('draft'); $product->save(); }
            elseif ($status !== 'draft') { return self::fail('Only a Draft or Published product can be set to Draft.', 'invalid_status'); }
        } elseif ($action === 'trash') {
            if ($status === 'trash') { return ['id' => $id, 'status' => 'trash', 'already_trashed' => true]; }
            if (!in_array($status, ['draft','publish'], true)) { return self::fail('Only a Draft or Published product can be trashed.', 'invalid_status'); }
            if (!defined('EMPTY_TRASH_DAYS') || !EMPTY_TRASH_DAYS) { return self::fail('Trash is disabled; refusing an implicit permanent deletion.', 'trash_unavailable'); }
            $product->delete(false);
        } elseif ($action === 'restore') {
            if ($status !== 'trash') { return self::fail('Only a trashed product can be restored.', 'invalid_status'); }
            $draft_on_restore = static function ($new_status, $post_id) use ($id) {
                return (int)$post_id === $id ? 'draft' : $new_status;
            };
            add_filter('wp_untrash_post_status', $draft_on_restore, PHP_INT_MAX, 2);
            $restored = wp_untrash_post($id);
            remove_filter('wp_untrash_post_status', $draft_on_restore, PHP_INT_MAX);
            if (!$restored) { return self::fail('Product could not be restored.', 'restore_failed'); }
        } else {
            if ($status !== 'trash') { return self::fail('Move this product to Trash before permanent deletion.', 'not_trashed'); }
            if (absint($input['confirm_product_id'] ?? 0) !== $id) {
                return self::fail('Permanent deletion needs the same exact ID in confirm_product_id.', 'confirmation_required');
            }
            $product->delete(true);
            if (get_post($id)) { return self::fail('Product deletion could not be verified.', 'delete_failed'); }
            return ['id' => $id, 'status' => 'deleted', 'permanent' => true, 'media_deleted' => false];
        }
        wc_delete_product_transients($id);
        $saved_status = get_post_status($id);
        $expected = $action === 'restore' ? 'draft' : ($action === 'trash' ? 'trash' : 'draft');
        if ($saved_status !== $expected) { return self::fail('Product status could not be verified.', 'lifecycle_failed'); }
        return ['id' => $id, 'status' => $saved_status, 'permalink' => $saved_status === 'trash' ? null : get_permalink($id), 'media_deleted' => false];
    }

    public static function listing_update(array $input) {
        $id = absint($input['product_id'] ?? 0);
        $product = wc_get_product($id);
        if (!$product || !in_array($product->get_type(), ['simple','variable'], true)
            || !in_array($product->get_status(), ['draft','publish'], true)) { return self::fail('An existing Draft or Published product is required.'); }
        if (isset($input['type']) && $input['type'] !== $product->get_type()) { return self::fail('This ability does not change product type.'); }
        if (array_key_exists('size_attribute', $input)) { return self::fail('Use listing-apply with confirmed sizes to change a size attribute.', 'size_attribute_requires_options'); }
        if (array_key_exists('category_ids', $input)) {
            $size_check = self::check_size_category(['category_ids' => $input['category_ids']], $product);
            if (is_wp_error($size_check)) { return $size_check; }
        }
        if (isset($input['slug']) && sanitize_title($input['slug']) !== $product->get_slug()) {
            if ($product->get_status() === 'publish' && empty($input['allow_live_slug_change'])) { return self::fail('Changing a live URL requires allow_live_slug_change=true.', 'live_url_change'); }
            $slug = sanitize_title($input['slug']);
            $duplicate = get_page_by_path($slug, OBJECT, 'product');
            if (!$slug || ($duplicate && (int)$duplicate->ID !== $id)) { return self::fail('Product slug is blank or already used.', 'duplicate_product'); }
            $product->set_slug($slug);
        }
        foreach (['name' => 'set_name', 'description' => 'set_description', 'short_description' => 'set_short_description'] as $key => $method) {
            if (array_key_exists($key, $input)) {
                $value = $key === 'name' ? wp_strip_all_tags((string)$input[$key]) : wp_kses_post((string)$input[$key]);
                if ($key === 'name' && trim($value) === '') { return self::fail('Product name cannot be blank.'); }
                $product->$method($value);
            }
        }
        if (array_key_exists('category_ids', $input)) {
            $ids = array_values(array_unique(array_map('absint', (array)$input['category_ids'])));
            if (!$ids) { return self::fail('A product must retain at least one category.'); }
            foreach ($ids as $term_id) { if (!term_exists($term_id, 'product_cat')) { return self::fail('Unknown category ID.'); } }
            $product->set_category_ids($ids);
        }
        if (array_key_exists('image_ids', $input)) {
            $ids = array_values(array_unique(array_map('absint', (array)$input['image_ids'])));
            if (!$ids) { return self::fail('A product must retain its featured image.'); }
            foreach ($ids as $image_id) { $checked = self::checked_image($image_id); if (is_wp_error($checked)) { return $checked; } }
            $product->set_image_id($ids[0]); $product->set_gallery_image_ids(array_slice($ids, 1));
        }
        if (array_key_exists('sku', $input)) {
            $sku = self::sku($input, $product->get_slug());
            $check = self::validate_sku($sku, $id); if (is_wp_error($check)) { return $check; }
            $product->set_sku($sku);
        }
        if ($product->is_type('simple')) {
            if (array_key_exists('regular_price', $input) || array_key_exists('sale_price', $input)) {
                $regular = wc_format_decimal($input['regular_price'] ?? $product->get_regular_price());
                $sale = wc_format_decimal($input['sale_price'] ?? $product->get_sale_price());
                if ($regular === '' || (float)$regular <= 0 || ($sale !== '' && (float)$sale >= (float)$regular)) { return self::fail('Invalid regular/sale price.'); }
                $product->set_regular_price($regular); $product->set_sale_price($sale);
            }
            if (array_key_exists('stock_quantity', $input) || array_key_exists('stock_status', $input)) {
                $stock = self::stock($product, $input); if (is_wp_error($stock)) { return $stock; }
            }
        } elseif (array_key_exists('stock_quantity', $input) || array_key_exists('regular_price', $input) || array_key_exists('sale_price', $input)) {
            return self::fail('Variable prices and quantities belong to individual variations.');
        }
        if (isset($input['brand']) && trim((string)$input['brand']) !== '' && !taxonomy_exists('product_brand')) { return self::fail('Product brand taxonomy is unavailable.'); }
        $product->save();
        if (array_key_exists('tags', $input)) {
            $tags = array_values(array_filter(array_map('sanitize_text_field', (array)$input['tags'])));
            $set = wp_set_object_terms($id, $tags, 'product_tag'); if (is_wp_error($set)) { return $set; }
        }
        if (isset($input['brand']) && trim((string)$input['brand']) !== '') {
            $brand = self::assign_brand($id, (string)$input['brand']); if (is_wp_error($brand)) { return $brand; }
            $attributes = $product->get_attributes();
            foreach ($attributes as $key => $attribute) { if (strcasecmp($attribute->get_name(), 'Brand') === 0) { unset($attributes[$key]); } }
            $attribute = new WC_Product_Attribute();
            $attribute->set_name('Brand'); $attribute->set_options([$brand['name']]); $attribute->set_visible(true); $attribute->set_variation(false);
            $attributes[] = $attribute;
            $product->set_attributes(array_values($attributes)); $product->save();
        }
        if (isset($input['seo']) && is_array($input['seo'])) {
            foreach (['title' => '_yoast_wpseo_title', 'description' => '_yoast_wpseo_metadesc', 'focus_keyphrase' => '_yoast_wpseo_focuskw'] as $field => $meta_key) {
                if (array_key_exists($field, $input['seo'])) { update_post_meta($id, $meta_key, sanitize_text_field((string)$input['seo'][$field])); }
            }
        }
        wc_delete_product_transients($id);
        if (!empty($input['colors'])) {
            $swatches = [];
            foreach ((array)$input['colors'] as $color) {
                if (!is_array($color) || (!isset($color['swatch_image_id']) && ($color['mode'] ?? '') !== 'color')) continue;
                $swatches[] = ['name' => $color['name'] ?? '', 'image_id' => $color['swatch_image_id'] ?? 0, 'mode' => $color['mode'] ?? 'image'];
            }
            if ($swatches) {
                $saved = self::color_swatch_set(['product_id' => $id, 'colors' => $swatches]);
                if (is_wp_error($saved)) return $saved;
            }
        }
        $saved = self::product_read(['product_id' => $id]);
        if (is_wp_error($saved)) { return $saved; }
        $supplier_source_url = is_string($input['supplier_source_url'] ?? null) ? trim($input['supplier_source_url']) : '';
        if ($supplier_source_url !== '') {
            $source = self::apply_supplier_source($id, $supplier_source_url);
            if (is_wp_error($source)) {
                $saved['supplier_source'] = ['status' => 'stage_failed', 'code' => $source->get_error_code(), 'message' => $source->get_error_message()];
                $saved['partial'] = true;
                $saved['errors'] = array_merge((array)($saved['errors'] ?? []), [['stage' => 'supplier_source', 'code' => $source->get_error_code(), 'message' => $source->get_error_message()]]);
            } else {
                $saved['supplier_source'] = $source;
                $saved['supplier_source_stage'] = 'saved_and_verified';
            }
        }
        return $saved;
    }

    public static function variation_update(array $input) {
        $id = absint($input['product_id'] ?? 0);
        $child_id = absint($input['variation_id'] ?? 0);
        $parent = wc_get_product($id);
        $child = wc_get_product($child_id);
        if (!$parent || !$parent->is_type('variable') || !in_array($parent->get_status(), ['draft','publish'], true)
            || !$child || !$child->is_type('variation') || (int)$child->get_parent_id() !== $id) {
            return self::fail('Variation does not belong to an existing variable listing.');
        }
        if (array_key_exists('image_id', $input)) {
            $image_id = self::checked_image($input['image_id']); if (is_wp_error($image_id)) { return $image_id; }
            $attributes = $child->get_attributes();
            $color_tax = self::color_taxonomy($parent);
            if (is_wp_error($color_tax)) { return $color_tax; }
            $color = $color_tax !== '' ? get_term_by('slug', $attributes[$color_tax] ?? '', $color_tax) : null;
            if ($color && !empty(self::config()['require_image_match']) && !self::image_has_color($image_id, self::base_color($color))) {
                return self::fail('Variation image filename does not match its color.', 'image_color_mismatch');
            }
            $child->set_image_id($image_id);
        }
        if (array_key_exists('regular_price', $input) || array_key_exists('sale_price', $input)) {
            $regular = wc_format_decimal($input['regular_price'] ?? $child->get_regular_price());
            $sale = wc_format_decimal($input['sale_price'] ?? $child->get_sale_price());
            if ($regular === '' || (float)$regular <= 0 || ($sale !== '' && (float)$sale >= (float)$regular)) { return self::fail('Invalid variation price.'); }
            $child->set_regular_price($regular); $child->set_sale_price($sale);
        }
        if (array_key_exists('sku', $input)) {
            $sku = self::sku($input, (string)$child_id);
            $check = self::validate_sku($sku, $child_id); if (is_wp_error($check)) { return $check; }
            $child->set_sku($sku);
        }
        if (array_key_exists('stock_quantity', $input) || array_key_exists('stock_status', $input)) {
            $stock = self::stock($child, $input); if (is_wp_error($stock)) { return $stock; }
        }
        $child->save(); WC_Product_Variable::sync($id); wc_delete_product_transients($id);
        return ['product_id' => $id, 'variation_id' => $child_id, 'product' => self::product_read(['product_id' => $id])];
    }

    public static function workflow_guide(array $input) {
        $guide = sanitize_key($input['guide'] ?? 'publishing');
        if ($guide === 'preparation' || $guide === 'publishing') { return Dreminex_AI_Workflow_Projects::legacy_guide($guide); }
        $files = ['preparation' => 'dreminex-product-preparation', 'publishing' => 'dreminex-product-publishing', 'media-brand' => 'dreminex-product-media-brand'];
        if (!isset($files[$guide])) { return self::fail('Choose preparation, publishing or media-brand guide.'); }
        $path = dirname(__DIR__) . '/skills/' . $files[$guide] . '/SKILL.md';
        if (!is_readable($path)) { return self::fail('Packaged workflow guide is unavailable.'); }
        $document = $guide === 'preparation' ? 'PRODUCT_PREPARATION_INSTRUCTIONS_BN.md' : 'PRODUCT_PUBLISHING_INSTRUCTIONS_BN.md';
        return ['guide' => $guide, 'content' => file_get_contents($path), 'instructions' => $guide === 'media-brand' ? '' : file_get_contents(dirname(__DIR__) . '/' . $document)];
    }

    public static function workflow_bootstrap(array $input) {
        $profile = sanitize_key((string)($input['profile'] ?? ''));
        if (!in_array($profile, ['preparation','publisher'], true)) return self::fail('Choose preparation or publisher.', 'invalid_profile');
        $manifest = Dreminex_AI_Workflow_Projects::read_profile(['profile' => $profile]);
        if (is_wp_error($manifest)) return $manifest;
        $context = class_exists('Dreminex_Native_OAuth') ? Dreminex_Native_OAuth::context() : [];
        return ['schema_version' => 1, 'suite_version' => DREMINEX_SUITE_VERSION,
            'site_lock' => ['url' => untrailingslashit(home_url('/')), 'site_id' => hash('sha256', home_url('/'))],
            'profile' => $manifest, 'listing_defaults' => self::listing_defaults([]),
            'connection' => ['permission_mode' => $context['permission_mode'] ?? 'unknown', 'scopes' => array_values((array)($context['scopes'] ?? []))],
            'rules' => ['one_bootstrap_per_task' => true, 'draft_by_default' => true, 'preparation_woocommerce_write' => false, 'inline_handoff_rows' => 44, 'hard_variation_rows' => self::MAX_VARIATION_ROWS],
            'usage' => 'Use this response as the single task bootstrap. Read only relevant named source files. Repeat bootstrap or schema inspection only when the profile revision changes.'];
    }
    public static function workflow_profile(array $input) { return Dreminex_AI_Workflow_Projects::read_profile($input); }
    public static function workflow_source(array $input) { return Dreminex_AI_Workflow_Projects::read_source($input); }
    public static function workflow_propose(array $input) { return Dreminex_AI_Workflow_Projects::propose($input); }
    public static function workflow_experience(array $input) { return Dreminex_AI_Workflow_Projects::read_experience($input); }
    public static function workflow_experience_record(array $input) { return Dreminex_AI_Workflow_Projects::record_experience($input); }
    public static function workflow_task_finalize(array $input) { return Dreminex_AI_Workflow_Projects::finalize_task($input); }

    public static function product_read(array $input) {
        $id = absint($input['product_id'] ?? 0);
        $product = wc_get_product($id);
        if (!$product) { return self::fail('Product not found.'); }
        $media = static function ($image_id): ?array {
            $image_id = absint($image_id);
            $attachment = $image_id ? get_post($image_id) : null;
            return $attachment ? ['id' => $image_id, 'url' => wp_get_attachment_url($image_id), 'title' => $attachment->post_title, 'slug' => $attachment->post_name, 'alt' => get_post_meta($image_id, '_wp_attachment_image_alt', true)] : null;
        };
        $saved_supplier_map = get_post_meta($id, '_dreminex_ai_color_supplier_sku_map', true);
        $resolved_color_taxonomy = self::color_taxonomy($product);
        $result = ['id' => $id, 'name' => $product->get_name(), 'slug' => $product->get_slug(), 'status' => $product->get_status(), 'type' => $product->get_type(), 'sku' => $product->get_sku(), 'size_attribute' => self::size_taxonomy($product), 'color_attribute' => is_wp_error($resolved_color_taxonomy) || $resolved_color_taxonomy === '' ? null : $resolved_color_taxonomy, 'color_supplier_skus' => is_array($saved_supplier_map) ? $saved_supplier_map : [], 'manage_stock' => $product->get_manage_stock(), 'stock_quantity' => $product->get_stock_quantity(), 'stock_status' => $product->get_stock_status(), 'permalink' => get_permalink($id), 'description' => $product->get_description(), 'short_description' => $product->get_short_description(), 'regular_price' => $product->get_regular_price(), 'sale_price' => $product->get_sale_price(), 'categories' => $product->get_category_ids(), 'tags' => wp_get_object_terms($id, 'product_tag', ['fields' => 'names']), 'brand' => taxonomy_exists('product_brand') ? wp_get_object_terms($id, 'product_brand', ['fields' => 'names']) : [], 'brand_label_evidence' => get_post_meta($id, '_dreminex_ai_label_brand_evidence', true), 'featured_image' => $media($product->get_image_id()), 'gallery' => array_map($media, $product->get_gallery_image_ids()), 'upsell_ids' => $product->get_upsell_ids(), 'cross_sell_ids' => $product->get_cross_sell_ids(), 'attributes' => [], 'color_swatches' => [], 'variations' => [], 'seo' => []];
        foreach ($product->get_attributes() as $attribute) {
            $values = $attribute->is_taxonomy()
                ? array_map(static fn($term) => $term && !is_wp_error($term) ? $term->name : null, array_map(static fn($term_id) => get_term($term_id, $attribute->get_name()), $attribute->get_options()))
                : $attribute->get_options();
            $result['attributes'][$attribute->get_name()] = ['variation' => $attribute->get_variation(), 'terms' => $values];
        }
        $product_attributes = $product->get_attributes();
        $this_taxonomy = self::color_taxonomy($product);
        $swatch_images = get_post_meta($id, '_dreminex_ai_swatch_images', true);
        $swatch_images = is_array($swatch_images) ? $swatch_images : [];
        if (!is_wp_error($this_taxonomy) && !empty($product_attributes[$this_taxonomy])) {
            foreach ($product_attributes[$this_taxonomy]->get_options() as $term_id) {
                $term = get_term($term_id, $this_taxonomy);
                if ($term && !is_wp_error($term)) { $result['color_swatches'][] = ['id' => $term->term_id, 'name' => $term->name, 'base_name' => self::base_color($term), 'slug' => $term->slug, 'hex' => get_term_meta($term->term_id, 'product_attribute_color', true), 'swatch_mode' => !empty($swatch_images[$term->slug]) ? 'image' : 'color', 'swatch_image' => !empty($swatch_images[$term->slug]) ? $media($swatch_images[$term->slug]) : null]; }
            }
        }
        foreach (['title' => '_yoast_wpseo_title', 'description' => '_yoast_wpseo_metadesc', 'focus_keyphrase' => '_yoast_wpseo_focuskw', 'secondary_keyphrases' => '_dreminex_ai_secondary_keyphrases'] as $field => $meta_key) { $result['seo'][$field] = get_post_meta($id, $meta_key, true); }
        if ($product->is_type('variable')) {
            foreach ($product->get_children() as $child_id) {
                $child = wc_get_product($child_id);
                if ($child) {
                    $explicit_image_id = (int)$child->get_image_id('edit');
                    $result['variations'][] = ['id' => $child_id, 'attributes' => $child->get_attributes(), 'status' => $child->get_status(), 'sku' => $child->get_sku('edit'), 'supplier_sku' => (string)get_post_meta($child_id, '_dreminex_supplier_sku', true), 'manage_stock' => $child->get_manage_stock(), 'stock_quantity' => $child->get_stock_quantity(), 'stock_status' => $child->get_stock_status(), 'regular_price' => $child->get_regular_price(), 'sale_price' => $child->get_sale_price(), 'image' => $media($explicit_image_id), 'display_image_source' => $explicit_image_id ? 'variation' : ($product->get_image_id() ? 'parent_fallback' : 'none')];
                }
            }
        }
        return $result;
    }
}

Dreminex_Suite_AI_Product_Publisher::boot();
