<?php
if (!defined('ABSPATH')) exit;

/** Supplier observations are evidence, never an instruction to overwrite a listing. */
final class Dreminex_Supplier_Monitor {
 const META='_dreminex_sm_sources';
 const SNAP='_dreminex_sm_snapshots';
 const COLOR_SNAP='_dreminex_sm_color_snapshots';
 const VISUAL='_dreminex_sm_visual';
 const TABLE='dreminex_supplier_events';
 const SCHEMA=3;
 const ACCOUNT_OPTION='dreminex_sm_account_vault';
 const HOSTS=['shopbasebd.com','www.shopbasebd.com','resellkori.com','www.resellkori.com'];
 private static function on() {
  $modules=(array)get_option('dreminex_suite_modules',[]);
  return class_exists('WooCommerce') && Dreminex_Native_MCP::enabled() && !empty($modules['supplier_monitor']);
 }
 private static function table() {global $wpdb;return $wpdb->prefix.self::TABLE;}
 public static function boot() {
  if (!self::on()) return;
  add_action('admin_post_dreminex_sm_link',[__CLASS__,'link']);
  add_action('admin_post_dreminex_sm_variant_link',[__CLASS__,'variant_link']);
  add_action('admin_post_dreminex_sm_settings',[__CLASS__,'settings']);
  add_action('admin_post_dreminex_sm_account',[__CLASS__,'save_account']);
  add_action('admin_post_dreminex_sm_scan',[__CLASS__,'scan_now']);
  add_action('admin_post_dreminex_sm_profit',[__CLASS__,'profit']);
  add_action('admin_post_dreminex_sm_decide',[__CLASS__,'decide']);
  add_action('admin_post_dreminex_sm_restore_color',[__CLASS__,'restore_color']);
  add_action('admin_post_dreminex_sm_restore_size',[__CLASS__,'restore_size']);
  add_action('rest_api_init',[__CLASS__,'routes']);
  add_action('wp_abilities_api_categories_init',[__CLASS__,'register_fact_preview_category']);
  add_action('wp_abilities_api_init',[__CLASS__,'register_fact_preview'],35);
  add_filter('cron_schedules',[__CLASS__,'cron_intervals']);
  add_action('init',[__CLASS__,'schedule']);
  add_action('dreminex_sm_reconcile',[__CLASS__,'reconcile']);
  add_action('dreminex_sm_scan_due',[__CLASS__,'scan_due']);
  add_action('add_meta_boxes_product',[__CLASS__,'source_box']);
  add_action('save_post_product',[__CLASS__,'save_source_box'],20,2);
  add_action('woocommerce_new_product',[__CLASS__,'changed']);
  add_action('woocommerce_update_product',[__CLASS__,'changed']);
  add_action('woocommerce_new_product_variation',[__CLASS__,'changed_variation']);
  add_action('woocommerce_update_product_variation',[__CLASS__,'changed_variation']);
  add_action('wp_trash_post',[__CLASS__,'trashed']);
  add_action('untrashed_post',[__CLASS__,'changed']);
 }
 private static function install() {
  if((int)get_option('dreminex_sm_schema',0)>=self::SCHEMA)return;
  global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';
  $table=self::table();$collate=$wpdb->get_charset_collate();
  dbDelta("CREATE TABLE {$table} (
   id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
   product_id bigint(20) unsigned NOT NULL,
   variation_id bigint(20) unsigned NOT NULL DEFAULT 0,
   supplier varchar(100) NOT NULL,
   kind varchar(40) NOT NULL,
   previous_value text NOT NULL,
   observed_value text NOT NULL,
   expected_value text NOT NULL,
   evidence_url varchar(500) NOT NULL,
   observed_at datetime NOT NULL,
   state varchar(20) NOT NULL DEFAULT 'pending',
   decided_at datetime NULL,
   actor_id bigint(20) unsigned NOT NULL DEFAULT 0,
   readback_value text NOT NULL,
   snapshot_id varchar(64) NOT NULL DEFAULT '',
   PRIMARY KEY  (id),
   KEY product_state (product_id,state),
   KEY state_time (state,observed_at)
  ) {$collate};");
  update_option('dreminex_sm_schema',self::SCHEMA,false);
  if(!get_role('dreminex_supplier_worker'))add_role('dreminex_supplier_worker','Dreminex Supplier Worker',['read'=>true,'dreminex_supplier_scan'=>true]);
  // A distinct account is required for secret retrieval. Existing scan-only
  // Application Passwords must never gain access to supplier credentials.
  if(!get_role('dreminex_supplier_auth_worker'))add_role('dreminex_supplier_auth_worker','Dreminex Supplier Auth Worker',['read'=>true,'dreminex_supplier_scan'=>true,'dreminex_supplier_auth'=>true]);
 }
 public static function schedule() {
  if(!self::on()) { foreach(['dreminex_sm_reconcile','dreminex_sm_scan_due'] as $hook)if(wp_next_scheduled($hook))wp_clear_scheduled_hook($hook);return; }
  self::install();
  if(!wp_next_scheduled('dreminex_sm_reconcile'))wp_schedule_event(time()+120,'twicedaily','dreminex_sm_reconcile');
  if(!wp_next_scheduled('dreminex_sm_scan_due'))wp_schedule_event(time()+180,'dreminex_sm_five_minutes','dreminex_sm_scan_due');
 }
 public static function cron_intervals($schedules) { $schedules['dreminex_sm_five_minutes']=['interval'=>300,'display'=>'Supplier Monitor five minutes'];return $schedules; }
 public static function changed_variation($id) {
  $p=wp_get_post_parent_id((int)$id);if($p)self::changed($p);
 }
 public static function changed($id,$notify=true) {
  if(!self::on()||get_post_type($id)!=='product')return;
  // WooCommerce product IDs remain the anchor even when title, slug or SKU changes.
  update_post_meta((int)$id,'_dreminex_sm_seen_at',time());
  delete_post_meta((int)$id,'_dreminex_sm_inactive');
  if(!get_post_meta((int)$id,self::META,true)&&!get_post_meta((int)$id,'_dreminex_sm_needs_source',true)){
   update_post_meta((int)$id,'_dreminex_sm_needs_source',1);
   if($notify)wp_mail(get_option('admin_email'),'Dreminex product needs supplier source','Connect a verified supplier URL for product #'.(int)$id.' in '.admin_url('admin.php?page=dreminex-supplier-monitor'));
  }
 }
 public static function trashed($id) {
  if(self::on()&&get_post_type($id)==='product'){
   update_post_meta((int)$id,'_dreminex_sm_inactive',1);
   global $wpdb;
   $wpdb->update(self::table(),['state'=>'superseded','decided_at'=>current_time('mysql',true)],['product_id'=>(int)$id,'state'=>'pending'],['%s','%s'],['%d','%s']);
  }
 }
 public static function reconcile() {
  if(!self::on())return;
  $page=1;$count=0;
  do {
   $ids=self::catalog_ids($page++,100);
   foreach($ids as $id){self::changed((int)$id,false);delete_post_meta((int)$id,'_dreminex_sm_inactive');$count++;}
  }while(count($ids)===100 && $page<=101);
  update_option('dreminex_sm_last_reconcile',['at'=>time(),'count'=>$count,'partial'=>$page>101],false);
 }
 private static function valid_url($raw) {
  if(class_exists('Dreminex_Supplier_Nexus')){
   $platform=Dreminex_Supplier_Nexus::platform_for_url($raw);
   return $platform?esc_url_raw(trim((string)$raw)):'';
  }
  if(!is_string($raw))return '';
  $url=esc_url_raw(trim((string)$raw));$parts=wp_parse_url($url);
  if(!$parts||($parts['scheme']??'')!=='https'||empty($parts['host'])||isset($parts['user'])||isset($parts['pass'])||isset($parts['port']))return '';
  $host=strtolower($parts['host']);
  if(!in_array($host,self::HOSTS,true)||isset($parts['fragment'])||strlen($url)>500)return '';
  if(isset($parts['query'])||!preg_match($host==='shopbasebd.com'||$host==='www.shopbasebd.com'?'~^/store/products/details/[0-9]+/?$~':'~^/product/[a-z0-9-]+/?$~',(string)($parts['path']??'')))return '';
  return $url;
 }
 private static function supplier($url) {return strtolower((string)wp_parse_url($url,PHP_URL_HOST));}
 /** Credential-safe, read-only facts for Preparation. No account or page HTML leaves PHP. */
 public static function register_fact_preview_category() {
  if(self::on()&&function_exists('wp_register_ability_category'))wp_register_ability_category('dreminex-suppliers',['label'=>'Dreminex Suppliers','description'=>'Read-only authenticated supplier product evidence.']);
 }
 public static function register_fact_preview() {
  if(!self::on()||!function_exists('wp_register_ability'))return;
  wp_register_ability('dreminex-suppliers/fact-preview',[
   'label'=>'Supplier Fact Preview','description'=>'Return a recent phone observation for an exact mapped supplier URL, or enqueue a Nexus scan when the observation is stale. WordPress never requests the supplier page.',
   'category'=>'dreminex-suppliers',
   'input_schema'=>['type'=>'object','properties'=>['url'=>['type'=>'string','format'=>'uri','maxLength'=>500]],'required'=>['url'],'additionalProperties'=>false],
   'output_schema'=>['type'=>'object','additionalProperties'=>true],
   'execute_callback'=>[__CLASS__,'fact_preview'],
   'permission_callback'=>static function(){return current_user_can('manage_woocommerce');},
   'annotations'=>['readonly'=>true,'destructive'=>false,'idempotent'=>true],
   'meta'=>['show_in_rest'=>true,'annotations'=>['readonly'=>true,'destructive'=>false,'idempotent'=>true],'mcp'=>['public'=>true]],
  ]);
 }
 public static function fact_preview(array $input): array {
  $url=self::valid_url($input['url']??'');
  if(!$url)return ['status'=>'invalid_url','reason'=>'Use an exact supported HTTPS product URL.'];
  $latest=Dreminex_Supplier_Nexus::latest_observation($url);
  if(is_array($latest)&&!empty($latest['checked_at'])&&strtotime($latest['checked_at'])>=time()-30*MINUTE_IN_SECONDS){
   return ['canonical_url'=>$url,'supplier'=>$latest['platform_id']??self::supplier($url),'status'=>$latest['status']??'unknown','auth_status'=>($latest['status']??'')==='ok'?'authenticated':'unknown','checked_at'=>$latest['checked_at'],'source_title'=>$latest['source_title']??null,'per_item_cost'=>$latest['wholesale_price']??null,'price_role'=>$latest['price_role']??null,'suggested_price_max'=>$latest['suggested_price_max']??null,'product_availability'=>$latest['product_availability']??'unknown','stock_scope'=>'product','stock_quantity'=>$latest['stock_quantity']??null,'description_sizes'=>array_slice((array)($latest['sizes']??[]),0,30),'order_sizes'=>[],'image_urls'=>array_values(array_filter(array_map(static fn($v)=>is_array($v)?($v['url']??''):'',(array)($latest['images']??[])))),'observation_id'=>$latest['observation_id']??null,'phone_only'=>true];
  }
  $queued=Dreminex_Supplier_Nexus::enqueue_preview($url);
  if(is_wp_error($queued))return ['canonical_url'=>$url,'status'=>$queued->get_error_code(),'reason'=>$queued->get_error_message(),'phone_only'=>true,'checked_at'=>gmdate('c')];
  return $queued+['phone_only'=>true,'reason'=>'A Nexus device will claim this scan. Poll this ability after the observation completes.'];
 }
 public static function source_box() {add_meta_box('dreminex-sm-source','Supplier Monitor source',[__CLASS__,'source_box_html'],'product','side','default');}
 public static function source_box_html($post) {
  wp_nonce_field('dreminex_sm_product_source','dreminex_sm_product_source_nonce');
  $sources=get_post_meta($post->ID,self::META,true);if(!is_array($sources))$sources=[];$current='';
  foreach($sources as $source)if(!empty($source['url'])){$current=$source['url'];break;}
  echo '<p><label for="dreminex_sm_product_url">Supplier product URL</label></p><input id="dreminex_sm_product_url" name="dreminex_sm_product_url" type="url" class="widefat" value="'.esc_attr($current).'" placeholder="https://shopbasebd.com/…">';
  echo '<p>Save an exact active supplier-platform product URL. Dreminex Nexus keeps the login session and performs the scan from the phone. Empty keeps the current mapping.</p>';
 }
 public static function save_source_box($id,$post) {
  if(!self::on()||!isset($_POST['dreminex_sm_product_source_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dreminex_sm_product_source_nonce'])),'dreminex_sm_product_source')||!current_user_can('edit_post',$id)||wp_is_post_revision($id))return;
  $raw=wp_unslash($_POST['dreminex_sm_product_url']??'');if(!is_string($raw)||trim($raw)==='')return;
  $url=self::valid_url($raw);if(!$url)return;
  self::set_source((int)$id,$url);
 }
 private static function set_source($id,$url) {
  $sources=get_post_meta($id,self::META,true);if(!is_array($sources))$sources=[];$host=self::supplier($url);
  if(isset($sources[$host])&&($sources[$host]['url']??'')===$url)return;
  if(isset($sources[$host])){
   $snapshots=(array)get_post_meta($id,self::SNAP,true);unset($snapshots[$host]);update_post_meta($id,self::SNAP,$snapshots);
   $colors=(array)get_post_meta($id,self::COLOR_SNAP,true);unset($colors[$host]);update_post_meta($id,self::COLOR_SNAP,$colors);
   $visual=(array)get_post_meta($id,self::VISUAL,true);unset($visual[$host]);update_post_meta($id,self::VISUAL,$visual);
   if(self::on())self::supersede($id,$host);
  }
  $sources[$host]=['url'=>$url,'linked_at'=>time(),'status'=>'awaiting_first_scan','variants'=>[]];
  update_post_meta($id,self::META,$sources);delete_post_meta($id,'_dreminex_sm_needs_source');
  // A source link becomes eligible immediately; Cron provides the next bounded scan.
  if(!wp_next_scheduled('dreminex_sm_scan_due'))wp_schedule_single_event(time()+60,'dreminex_sm_scan_due');
 }
 /** Publisher and product editor share one validated source mapping. */
 public static function valid_source_url($raw) {return self::valid_url($raw);}
 public static function source_set($id,$raw) {
  $id=absint($id);$url=self::valid_url($raw);
  if(!self::on())return new WP_Error('module_disabled','Enable Supplier Monitor on this site.');
  if(!$id||get_post_type($id)!=='product'||get_post_status($id)==='trash'||!current_user_can('edit_post',$id)||!$url)return new WP_Error('invalid_source','Product and exact HTTPS supplier product URL required.');
  self::set_source($id,$url);
  return self::source_read($id);
 }
 public static function source_read($id) {
  $id=absint($id);if(!$id||get_post_type($id)!=='product'||!current_user_can('edit_post',$id))return new WP_Error('invalid_product','Product access denied.');
  $sources=(array)get_post_meta($id,self::META,true);$snapshots=(array)get_post_meta($id,self::SNAP,true);$colors=(array)get_post_meta($id,self::COLOR_SNAP,true);$visual=(array)get_post_meta($id,self::VISUAL,true);$out=[];
  foreach($sources as $host=>$source){
   $restricted=($source['last_issue']??'')==='account_restricted';
   $color_status=[];foreach((array)($colors[$host]??[]) as $color=>$row)$color_status[$color]=['status'=>$row['status']??'unknown','availability'=>$row['availability']??'unknown','supplier_sku'=>$row['sku']??'','last_success'=>$row['last_success']??null];
   $matches=[];foreach((array)($visual[$host]['matches']??[]) as $image_url=>$match)$matches[]=['color'=>$match['color']??'','image_id'=>(int)($match['image_id']??0),'supplier_image_url'=>$image_url];
   $out[]=['supplier'=>$host,'url'=>$source['url']??'','status'=>$source['status']??'awaiting_first_scan','last_issue'=>$source['last_issue']??'','last_success'=>$source['last_success']??null,
    'last_checked'=>$source['last_checked']??null,'next_attempt'=>$restricted?self::restriction_recheck_at($source):self::next_attempt($source,(array)($snapshots[$host]??[])),
    'access_paused'=>$restricted,'stale'=>time()-((int)($source['last_success']??0)?:((int)($source['linked_at']??time())))>=18*HOUR_IN_SECONDS,
    'stock_scope'=>'product','color_sources'=>$color_status,'size_stock_scope'=>'unverified','image_match_status'=>$visual[$host]['status']??'not_scanned','color_image_matches'=>$matches];
  }
  return ['product_id'=>$id,'sources'=>$out,'scan_interval_hours'=>(int)Dreminex_Supplier_Nexus::settings()['scan_interval_hours'],'authenticated_each_scan'=>false,'phone_only'=>true,'last_scheduler_tick'=>get_option('dreminex_nexus_last_scheduler_tick')?:null,'next_scheduler_tick'=>wp_next_scheduled('dreminex_sm_scan_due')?:null];
 }
 public static function scan_now() {
  if(!self::on()||!current_user_can('manage_woocommerce'))wp_die('Access denied.','',['response'=>403]);
  check_admin_referer('dreminex_sm_scan');$id=absint($_POST['product_id']??0);
  if(!$id||!current_user_can('edit_post',$id))wp_die('Invalid product.','',['response'=>400]);
  $sources=get_post_meta($id,self::META,true);if(!is_array($sources))$sources=[];
  foreach($sources as $source){if(empty($source['url']))continue;$platform=Dreminex_Supplier_Nexus::platform_for_url($source['url']);if($platform)Dreminex_Supplier_Nexus::enqueue($id,$platform['platform_id'],$source['url'],'manual');}
  self::go('scan_requested');
 }
 public static function scan_due() {
  if(!self::on()||get_transient('dreminex_sm_scan_lock'))return;
  set_transient('dreminex_sm_scan_lock',1,4*MINUTE_IN_SECONDS);
  try{Dreminex_Supplier_Nexus::schedule_due();}finally{delete_transient('dreminex_sm_scan_lock');}
 }
 private static function next_attempt($source,$snapshot) {
  $checked=(int)($source['last_checked']??0);
  if(!$checked)return (int)($source['linked_at']??0);
  if(in_array((string)($source['status']??''),['ok','unavailable'],true))return $checked+12*HOUR_IN_SECONDS;
  // A transient failure needs a bounded retry, not a full 12-hour delay.
  $failures=max(1,(int)($snapshot['failure_count']??1));
  $minutes=[15,60,180,360];
  return $checked+$minutes[min($failures-1,count($minutes)-1)]*MINUTE_IN_SECONDS;
 }
 private static function restriction_recheck_at($source) {
  return ((int)($source['last_checked']??0)?:((int)($source['linked_at']??time())))+DAY_IN_SECONDS;
 }
 private static function flag_stale($id,$host,$source) {
  $last=(int)($source['last_success']??0);
  $start=$last?:((int)($source['linked_at']??0));
  if(!$start||time()-$start<18*HOUR_IN_SECONDS||empty($source['url']))return;
  $snapshot=hash('sha256',$id.'|'.$host.'|'.(string)$start);
  if(self::event($id,0,$host,'scan_stale',$last?'last successful observation':'linked without observation','overdue','Review account, scan history and scheduler.',$source['url'],$snapshot)){
   wp_mail(get_option('admin_email'),'Dreminex Supplier Monitor: scan overdue','Supplier data for product #'.$id.' is older than 18 hours. Open Dreminex Nexus → Security → Supplier alerts to review the source and scan history.');
  }
 }
 private static function scan_color_due($vault) {
  // Kept as a compatibility stub. Phone-only mode never performs supplier HTTP from WordPress.
  return;
 }
 private static function scan_color_one($id,$host,$source,$color,$sku,$prior,$sealed) {
  return ['status'=>'pending_device','phone_only'=>true];
 }
 private static function catalog_ids($page,$limit,$linked=false) {
  global $wpdb;$page=max(1,(int)$page);$limit=max(1,min(100,(int)$limit));$offset=($page-1)*$limit;
  $sql="SELECT p.ID FROM {$wpdb->posts} p";
  if($linked)$sql.=" INNER JOIN {$wpdb->postmeta} m ON m.post_id=p.ID AND m.meta_key=%s";
  $sql.=" WHERE p.post_type='product' AND p.post_status IN ('publish','draft','private','pending') GROUP BY p.ID ORDER BY p.ID ASC LIMIT %d OFFSET %d";
  $args=$linked?[is_string($linked)?$linked:self::META,$limit,$offset]:[$limit,$offset];
  return array_map('intval',$wpdb->get_col($wpdb->prepare($sql,...$args)));
 }
 public static function scan_one($id,$host,$source) {
  if(!self::on()||empty($source['url']))return ['status'=>'invalid_source'];
  $platform=Dreminex_Supplier_Nexus::platform_for_url($source['url']);
  if(!$platform)return ['status'=>'invalid_source'];
  $job=Dreminex_Supplier_Nexus::enqueue((int)$id,$platform['platform_id'],$source['url'],'manual');
  return is_wp_error($job)?['status'=>'queue_error','reason'=>$job->get_error_code()]:['status'=>'pending_device','job_id'=>$job,'phone_only'=>true];
 }
 private static function account_host($raw) {
  $host=strtolower(trim((string)$raw));
  return in_array($host,['shopbasebd.com','resellkori.com'],true)?$host:'';
 }
 private static function seal_account($username,$password) {
  if(!function_exists('openssl_encrypt'))return new WP_Error('crypto_missing','OpenSSL is required.');
  $iv=random_bytes(12);$tag='';
  $key=hash('sha256',wp_salt('auth').'|dreminex-supplier-account-v1',true);
  $cipher=openssl_encrypt(wp_json_encode(['username'=>$username,'password'=>$password]),'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag,'dreminex-supplier-v1');
  return $cipher===false?new WP_Error('crypto_failed','Could not encrypt account.'):base64_encode($iv.$tag.$cipher);
 }
 private static function open_account($sealed) {
  if(!is_string($sealed)||!function_exists('openssl_decrypt'))return null;
  $bytes=base64_decode($sealed,true);
  if($bytes===false||strlen($bytes)<29)return null;
  $key=hash('sha256',wp_salt('auth').'|dreminex-supplier-account-v1',true);
  $plain=openssl_decrypt(substr($bytes,28),'aes-256-gcm',$key,OPENSSL_RAW_DATA,substr($bytes,0,12),substr($bytes,12,16),'dreminex-supplier-v1');
  $value=$plain===false?null:json_decode($plain,true);
  return is_array($value)&&is_string($value['username']??null)&&is_string($value['password']??null)?$value:null;
 }
 public static function save_account() {
  if(!current_user_can('manage_woocommerce'))wp_die('Access denied.','',['response'=>403]);
  check_admin_referer('dreminex_sm_account');
  $host=self::account_host(wp_unslash($_POST['supplier']??''));
  if(!$host)wp_die('Unknown supplier.','',['response'=>400]);
  $vault=(array)get_option(self::ACCOUNT_OPTION,[]);
  if(($_POST['operation']??'save')==='remove'){
   unset($vault[$host]);update_option(self::ACCOUNT_OPTION,$vault,false);self::go('account_removed');
  }
  self::go('account_device_only');
 }
 private static function store_account($host,$username,$password) {
  if(!self::account_host($host)||!is_string($username)||!is_string($password)||strlen($username)>255||strlen($password)>1024)return new WP_Error('invalid_account','Invalid account fields.');
  $username=trim($username);
  if($username===''&&$password==='')return false;
  $vault=(array)get_option(self::ACCOUNT_OPTION,[]);
  $previous=self::open_account($vault[$host]??'');
  if($username==='')$username=$previous['username']??'';
  if($password==='')$password=$previous['password']??'';
  if($username===''||$password==='')return new WP_Error('incomplete_account','Enter the account identifier and password.');
  $sealed=self::seal_account($username,$password);
  if(is_wp_error($sealed))return $sealed;
  $vault[$host]=$sealed;update_option(self::ACCOUNT_OPTION,$vault,false);
  // Explicitly updating an account allows one new verification attempt.
  global $wpdb;
  $ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key=%s",self::META));
  foreach($ids as $id){
   $sources=(array)get_post_meta((int)$id,self::META,true);$dirty=false;
   foreach($sources as $key=>&$source)if(str_replace('www.','',$key)===$host&&($source['last_issue']??'')==='account_restricted'){
    $source['last_issue']='';$source['status']='awaiting_account_verification';$source['last_checked']=0;$dirty=true;
   }unset($source);
   if($dirty)update_post_meta((int)$id,self::META,$sources);
  }
  return true;
 }
 public static function worker_account($request) {
  return new WP_Error('device_only_credentials','Supplier credentials and sessions are available only inside Dreminex Nexus.',['status'=>410]);
 }
 public static function link() {
  if(!current_user_can('manage_woocommerce'))wp_die('Access denied.', '', ['response'=>403]);
  check_admin_referer('dreminex_sm_link');
  $id=absint($_POST['product_id']??0);$url=self::valid_url(wp_unslash($_POST['source_url']??''));
  if(!$id||!current_user_can('edit_post',$id)||get_post_type($id)!=='product'||!$url)wp_die('Valid product and HTTPS supplier URL required.', '', ['response'=>400]);
  self::set_source($id,$url);
  self::go('linked');
 }
 public static function variant_link() {
  if(!current_user_can('manage_woocommerce'))wp_die('Access denied.', '', ['response'=>403]);
  check_admin_referer('dreminex_sm_variant_link');
  $id=absint($_POST['product_id']??0);$vid=absint($_POST['variation_id']??0);
  $host=sanitize_text_field(wp_unslash($_POST['supplier']??''));
  $sku=trim(sanitize_text_field(wp_unslash($_POST['supplier_sku']??'')));
  $product=wc_get_product($vid);$sources=(array)get_post_meta($id,self::META,true);
  if(!$id||!current_user_can('edit_post',$id)||get_post_type($id)!=='product'||!isset($sources[$host])||!$product||!$product->is_type('variation')||(int)$product->get_parent_id()!==$id||strlen($sku)>100)wp_die('Invalid source or variation mapping.', '', ['response'=>400]);
  $map=(array)($sources[$host]['variants']??[]);
  if($sku==='')unset($map[$vid]);
  else {
   // Some suppliers use one product code for all sizes of a colour. A shared
   // code is safe only when the size attribute separates every mapped row.
   $size='';foreach($product->get_attributes() as $attribute=>$value)if(stripos($attribute,'size')!==false)$size=strtolower(trim((string)$value));
   foreach($map as $other=>$entry)if((int)$other!==$vid && ($entry['sku']??'')===$sku){
    $other_product=wc_get_product((int)$other);$other_size='';
    if($other_product)foreach($other_product->get_attributes() as $attribute=>$value)if(stripos($attribute,'size')!==false)$other_size=strtolower(trim((string)$value));
    if($size===''||$other_size===''||$size===$other_size)wp_die('Supplier SKU and size must uniquely identify one variation.', '', ['response'=>409]);
   }
   $map[$vid]=['sku'=>$sku,'verified_at'=>time(),'actor'=>(int)get_current_user_id()];
  }
  $sources[$host]['variants']=$map;
  update_post_meta($id,self::META,$sources);
  if(self::on())self::supersede($id,$host);
  self::go('variant_linked');
 }
 private static function supersede($id,$host) {
  global $wpdb;
  $wpdb->update(self::table(),['state'=>'superseded','decided_at'=>current_time('mysql',true)],['product_id'=>$id,'supplier'=>$host,'state'=>'pending'],['%s','%s'],['%d','%s','%s']);
 }
 private static function supersede_kind($id,$vid,$host,$kind) {
  global $wpdb;$table=self::table();
  $wpdb->query($wpdb->prepare("UPDATE {$table} SET state='superseded', decided_at=UTC_TIMESTAMP() WHERE product_id=%d AND variation_id=%d AND supplier=%s AND kind=%s AND state='pending'",$id,$vid,$host,$kind));
 }
 public static function settings() {
  if(!current_user_can('manage_woocommerce'))wp_die('Access denied.', '', ['response'=>403]);
  check_admin_referer('dreminex_sm_settings');
  $rule=[];
  foreach(['other_cost','return_reserve','ad_default','supplier_fee_percent','coupon_reserve','coupon_percent_reserve','minimum_profit','maximum_profit','max_change_percent'] as $key){
   $rule[$key]=self::decimal(wp_unslash($_POST[$key]??''));
   if($rule[$key]===null)wp_die('Complete every non-negative cost, fee and promotion reserve.', '', ['response'=>400]);
  }
  if((float)$rule['minimum_profit']<70||(float)$rule['maximum_profit']>=200||(float)$rule['maximum_profit']<(float)$rule['minimum_profit']||(float)$rule['ad_default']<25||(float)$rule['ad_default']>90||(float)$rule['supplier_fee_percent']>=100||(float)$rule['coupon_percent_reserve']>=100||(float)$rule['max_change_percent']<=0||(float)$rule['max_change_percent']>100)wp_die('Profit must be at least 70 and below 200; default ad budget must be 25 to 90. Selected-item ad overrides must be 30 to 90.', '', ['response'=>400]);
  $rule['configured']=4;$rule['price_enabled']=!empty($_POST['price_enabled'])?1:0;$rule['version']=time();
  update_option('dreminex_sm_pricing',$rule,false);
  if(self::on()){$wpdb=$GLOBALS['wpdb'];$wpdb->query("UPDATE ".self::table()." SET state='superseded', decided_at=UTC_TIMESTAMP() WHERE kind='price_review' AND state='pending'");}
  self::go('settings');
 }
 public static function profit() {
  if(!current_user_can('manage_woocommerce'))wp_die('Access denied.', '', ['response'=>403]);
  check_admin_referer('dreminex_sm_profit');
  $id=absint($_POST['product_id']??0);$vid=absint($_POST['variation_id']??0);
  $product=wc_get_product($vid);$target=self::decimal(wp_unslash($_POST['target_profit']??''));
  $ad=trim((string)wp_unslash($_POST['ad_cost']??''));$ad=$ad===''?'':self::decimal($ad);
  $cap=self::decimal(wp_unslash($_POST['customer_cap']??''));
  $rule=(array)get_option('dreminex_sm_pricing',[]);
  if(!$id||!current_user_can('edit_post',$id)||!$product||!in_array($product->get_type(),['simple','variation'],true)||($vid!==$id&&(int)$product->get_parent_id()!==$id)||$target===null||$ad===null||($ad!==''&&((float)$ad<30||(float)$ad>90))||$cap===null||(float)$cap<=0||(float)$target<max(70,(float)($rule['minimum_profit']??70))||(float)$target>=200||(float)$target>(float)($rule['maximum_profit']??199))wp_die('Invalid product, target, ad budget or delivered-price cap.', '', ['response'=>400]);
  update_post_meta($vid,'_dreminex_sm_profit_target',$target);
  if($ad==='')delete_post_meta($vid,'_dreminex_sm_ad_cost');else update_post_meta($vid,'_dreminex_sm_ad_cost',$ad);
  update_post_meta($vid,'_dreminex_sm_customer_cap',$cap);
  if(self::on()){$wpdb=$GLOBALS['wpdb'];$wpdb->query($wpdb->prepare("UPDATE ".self::table()." SET state='superseded', decided_at=UTC_TIMESTAMP() WHERE product_id=%d AND variation_id=%d AND kind='price_review' AND state='pending'",$id,$vid));}
  self::go('profit');
 }
 private static function price_quote($cost,$vid,$product,$rule) {
  if((int)($rule['configured']??0)!==4||get_woocommerce_currency()!=='BDT')return ['ok'=>false,'reason'=>'Complete the BDT dropshipping pricing policy before requesting a price proposal.'];
  global $wpdb;
  if((int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}woocommerce_tax_rates")>0)return ['ok'=>false,'reason'=>'Tax rates need a separate delivered-total review.'];
  $delivery=[];
  foreach(WC_Shipping_Zones::get_zones() as $zone)foreach($zone['shipping_methods'] as $method)if($method->enabled==='yes'){
   if($method->id!=='flat_rate'||!is_numeric($method->instance_settings['cost']??null))return ['ok'=>false,'reason'=>'A shipping method has a non-flat cost.'];
   $delivery[]=(float)$method->instance_settings['cost'];
  }
  foreach(WC_Shipping_Zones::get_zone(0)->get_shipping_methods(true) as $method){
   if($method->id!=='flat_rate'||!is_numeric($method->instance_settings['cost']??null))return ['ok'=>false,'reason'=>'An uncovered-zone shipping method has a non-flat cost.'];
   $delivery[]=(float)$method->instance_settings['cost'];
  }
  if(!$delivery||min($delivery)<=0)return ['ok'=>false,'reason'=>'Positive delivery charges are required for the advance model.'];
  $coupon_fixed=(float)$rule['coupon_reserve'];$coupon_percent=(float)$rule['coupon_percent_reserve'];
  $newsletter=function_exists('dreminex_news_settings')?dreminex_news_settings():[];
  if(!empty($newsletter['enabled'])&&!empty($newsletter['coupon_enabled']))$coupon_fixed=max($coupon_fixed,(float)($newsletter['amount']??0));
  $offers=$wpdb->prefix.'dreminex_offers';
  if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$offers))===$offers){
   $largest=$wpdb->get_var("SELECT MAX(amount) FROM {$offers} WHERE status='active' AND end_date>=CURDATE()");
   if($largest!==null)$coupon_fixed=max($coupon_fixed,(float)$largest);
  }
  // Individual-use coupons cannot stack with each other. Other published coupons
  // may stack, so sum their exposure. Cart minimums are deliberately ignored.
  $ids=get_posts(['post_type'=>'shop_coupon','post_status'=>'publish','posts_per_page'=>201,'fields'=>'ids']);
  if(count($ids)>200)return ['ok'=>false,'reason'=>'Too many published coupons to audit.'];
  $fixed_stack=0;$percent_stack=0;$fixed_single=0;$percent_single=0;
  foreach($ids as $coupon_id){
   $coupon=new WC_Coupon($coupon_id);$expires=$coupon->get_date_expires();if($expires&&$expires->getTimestamp()<time())continue;
   $type=$coupon->get_discount_type();$amount=(float)$coupon->get_amount();
   if($coupon->get_free_shipping())return ['ok'=>false,'reason'=>'A published coupon can waive the delivery advance.'];
   if(!in_array($type,['fixed_cart','fixed_product','percent'],true))return ['ok'=>false,'reason'=>'An unsupported published coupon needs a separate margin review.'];
   if($amount<=0)continue;
   if($type==='percent'){
    if($coupon->get_individual_use())$percent_single=max($percent_single,$amount);else $percent_stack+=$amount;
   }else{
    if($coupon->get_individual_use())$fixed_single=max($fixed_single,$amount);else $fixed_stack+=$amount;
   }
  }
  $policy=$rule;$policy['coupon_reserve']=max($coupon_fixed,$fixed_stack,$fixed_single);
  $policy['coupon_percent_reserve']=max($coupon_percent,$percent_stack,$percent_single);
  $flash=(array)get_option('dreminex_flash_sale',[]);$offers=(array)($flash['offers']??[]);
  if(isset($offers[$vid])||isset($offers[$product->is_type('variation')?$product->get_parent_id():$vid]))return ['ok'=>false,'reason'=>'This item has a configured Flash Sale offer; review its offer margin separately.'];
  $ad=get_post_meta($vid,'_dreminex_sm_ad_cost',true);
  $item=['ad_cost'=>$ad===''?($rule['ad_default']??null):$ad,
   'target_profit'=>get_post_meta($vid,'_dreminex_sm_profit_target',true)?:($rule['minimum_profit']??70),
   'customer_cap'=>get_post_meta($vid,'_dreminex_sm_customer_cap',true),
   'delivery_min'=>min($delivery),'delivery_max'=>max($delivery)];
  return Dreminex_Supplier_Pricing::quote($cost,$policy,$item);
 }
 private static function go($state) {wp_safe_redirect(admin_url('admin.php?page=dreminex-supplier-monitor&status='.$state),303);exit;}
 public static function routes() {
  register_rest_route('dreminex/v1','/supplier-monitor/jobs',[
   'methods'=>'GET','permission_callback'=>static function(){return self::on()&&current_user_can('dreminex_supplier_scan');},
   'callback'=>[__CLASS__,'jobs'],'args'=>['page'=>['default'=>1,'sanitize_callback'=>'absint']]]);
  register_rest_route('dreminex/v1','/supplier-monitor/observation',[
   'methods'=>'POST','permission_callback'=>static function(){return self::on()&&current_user_can('dreminex_supplier_scan');},
   'callback'=>[__CLASS__,'observe']]);
  register_rest_route('dreminex/v1','/supplier-monitor/account',[
   'methods'=>'GET','permission_callback'=>static function(){return self::on()&&current_user_can('dreminex_supplier_auth');},
   'callback'=>[__CLASS__,'worker_account'],'args'=>['supplier'=>['required'=>true,'sanitize_callback'=>'sanitize_text_field']]]);
 }
 public static function jobs($request) {
  $page=max(1,(int)$request['page']);$ids=self::catalog_ids($page,50,true);
  $jobs=[];
  foreach($ids as $id){$product=wc_get_product($id);if(!$product)continue;
   if(!$product->is_type('simple')&&!$product->is_type('variable'))continue;
   foreach((array)get_post_meta($id,self::META,true) as $host=>$source){
    if(empty($source['url'])||self::valid_url($source['url'])!==$source['url']||self::supplier($source['url'])!==$host)continue;
    $variants=[];
    foreach(($product->is_type('variable')?$product->get_children():[$id]) as $child_id){
     $child=wc_get_product($child_id);if(!$child)continue;
     $mapping=$source['variants'][$child_id]??[];
     if($child_id!==$id&&empty($mapping['sku']))continue;
     $variants[]=['id'=>(int)$child_id,'supplier_sku'=>(string)($mapping['sku']??''),'attributes'=>$child->get_attributes()];
    }
    $jobs[]=['product_id'=>(int)$id,'supplier'=>$host,'url'=>$source['url'],'variations'=>$variants];
   }
  }
  return rest_ensure_response(['jobs'=>$jobs,'page'=>$page,'has_more'=>count($ids)===50]);
 }
 private static function event($product,$variation,$supplier,$kind,$before,$after,$expected,$url,$snapshot_id) {
  global $wpdb;$table=self::table();
  $duplicate=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE product_id=%d AND variation_id=%d AND supplier=%s AND kind=%s AND observed_value=%s AND expected_value=%s AND state='pending' LIMIT 1",$product,$variation,$supplier,$kind,(string)$after,(string)$expected));
  if($duplicate){$wpdb->update($table,['snapshot_id'=>$snapshot_id,'observed_at'=>current_time('mysql',true)],['id'=>$duplicate],['%s','%s'],['%d']);return false;}
  $wpdb->query($wpdb->prepare("UPDATE {$table} SET state='superseded', decided_at=UTC_TIMESTAMP() WHERE product_id=%d AND variation_id=%d AND supplier=%s AND kind=%s AND state='pending'",$product,$variation,$supplier,$kind));
  $ok=$wpdb->insert($table,['product_id'=>$product,'variation_id'=>$variation,'supplier'=>$supplier,'kind'=>$kind,'previous_value'=>(string)$before,'observed_value'=>(string)$after,'expected_value'=>(string)$expected,'evidence_url'=>$url,'observed_at'=>current_time('mysql',true),'state'=>'pending','snapshot_id'=>$snapshot_id],['%d','%d','%s','%s','%s','%s','%s','%s','%s','%s']);
  return $ok!==false;
 }
 private static function decimal($value) {
  if(!is_scalar($value)||!is_numeric($value)||!is_finite((float)$value)||(float)$value<0||(float)$value>10000000)return null;
  return wc_format_decimal($value,2);
 }
 private static function price_event($id,$vid,$supplier,$cost,$old_cost,$snapshot_id,$url) {
  $count=0;
  if($old_cost!==null&&$old_cost!==$cost)$count=self::event($id,$vid,$supplier,'cost_changed',$old_cost,$cost,'',$url,$snapshot_id)?1:0;
  $rule=(array)get_option('dreminex_sm_pricing',[]);
  if(count((array)get_post_meta($id,self::META,true))!==1)return $count; // Fulfilment cost needs an explicit source choice.
  $product=wc_get_product($vid);
  if((int)($rule['configured']??0)!==4||empty($rule['price_enabled'])||(float)$cost<=0||!$product||!in_array($product->get_type(),['simple','variation'],true)||$product->get_sale_price('edit')!==''||$product->get_date_on_sale_from('edit')||$product->get_date_on_sale_to('edit'))return $count;
  $current=$product->get_regular_price('edit');
  if($current===''||(float)$current<=0)return $count;
  $quote=self::price_quote($cost,$vid,$product,$rule);
  if(empty($quote['ok'])){self::supersede_kind($id,$vid,$supplier,'price_review');return $count;}
  $proposal=$quote['price'];
  $limit=(float)($rule['max_change_percent']??20);
  if((float)$proposal===(float)$current){self::supersede_kind($id,$vid,$supplier,'price_review');return $count;}
  if(abs((float)$proposal-(float)$current)/(float)$current*100>$limit)return $count;
  $after=wp_json_encode(['price'=>$proposal,'cost'=>$cost,'rule_version'=>(int)$rule['version'],'quote'=>$quote]);
  $expected=wp_json_encode(['regular'=>(string)$current,'sale'=>(string)$product->get_sale_price('edit')]);
  return $count+(self::event($id,$vid,$supplier,'price_review',$current,$after,$expected,$url,$snapshot_id)?1:0);
 }
 public static function observe($request) {
  $data=$request->get_json_params();if(!is_array($data))return new WP_Error('bad_observation','JSON object required.', ['status'=>400]);
  $id=absint($data['product_id']??0);$url=self::valid_url($data['url']??'');$supplier=self::supplier($url);
  $sources=(array)get_post_meta($id,self::META,true);
  if(!$id||get_post_type($id)!=='product'||get_post_status($id)==='trash'||!$url||!isset($sources[$supplier])||$sources[$supplier]['url']!==$url)return new WP_Error('mapping_mismatch','Observation does not match an active product source.',['status'=>409]);
  $scan_id=is_string($data['scan_id']??null)?$data['scan_id']:'';
  if(!preg_match('/^[a-f0-9-]{36}$/i',$scan_id)||strlen(wp_json_encode($data))>100000)return new WP_Error('invalid_scan','Invalid or oversized observation.',['status'=>400]);
  $status=$data['status']??'unknown';
  if(!in_array($status,['ok','unavailable','unknown','login_required','product_removed'],true))return new WP_Error('invalid_status','Invalid observation status.',['status'=>400]);
  if($scan_id===($sources[$supplier]['last_scan_id']??''))return rest_ensure_response(['recorded'=>false,'duplicate'=>true]);
  $prev=(array)get_post_meta($id,self::SNAP,true);$old=(array)($prev[$supplier]??[]);
  $now=time();$new=$old;$new['attempt_at']=$now;$new['attempt_status']=$status;$events=0;
  $new['scan_id']=$scan_id;
  if($status==='ok'||$status==='unavailable') {
   $rows=$data['variants']??[];if(!is_array($rows)||count($rows)>250)return new WP_Error('invalid_variants','Too many or invalid variants.',['status'=>400]);
   // Validate the entire payload before inserting any event.
   $checked=[];
   foreach($rows as $row){
    if(!is_array($row))return new WP_Error('invalid_row','Variant row must be an object.',['status'=>400]);
    $vid=absint($row['variation_id']??0);$availability=$row['availability']??'unknown';
    if(!$vid||isset($checked[$vid])||!in_array($availability,['instock','outofstock','unknown'],true))return new WP_Error('invalid_row','Duplicate or invalid variant.',['status'=>400]);
    $checked[$vid]=true;$child=wc_get_product($vid);
    if(!$child||($vid!==$id&&(int)$child->get_parent_id()!==$id)||($vid===$id&&!$child->is_type('simple')))return new WP_Error('invalid_mapping','Variant does not belong to this product.',['status'=>409]);
    $map=$sources[$supplier]['variants'][$vid]??[];$sku=(string)($row['supplier_sku']??'');
    if($vid!==$id&&(!$map||($map['sku']??'')!==$sku)||($vid===$id&&$sku!==''))return new WP_Error('invalid_mapping','Supplier variant is not owner-verified.',['status'=>409]);
    if(isset($row['wholesale_price'])&&self::decimal($row['wholesale_price'])===null)return new WP_Error('invalid_price','Invalid variant price.',['status'=>400]);
   }
   $raw=$data['wholesale_price']??null;$cost=$raw===null?null:self::decimal($raw);
   if($raw!==null&&$cost===null)return new WP_Error('invalid_price','Invalid wholesale price.',['status'=>400]);
   $availability=$data['product_availability']??'unknown';
   if(!in_array($availability,['instock','outofstock','unknown'],true))return new WP_Error('invalid_availability','Invalid product availability.',['status'=>400]);
   $quantity=$data['stock_quantity']??null;
   if($quantity!==null&&(!is_int($quantity)||$quantity<0||$quantity>10000000))return new WP_Error('invalid_quantity','Invalid supplier quantity.',['status'=>400]);
   $new=['status'=>$status,'at'=>$now,'attempt_at'=>$now,'attempt_status'=>$status,'last_success_at'=>$now,'failure_count'=>0,'url'=>$url,'scan_id'=>$scan_id,'variants'=>[],'missing'=>[],'wholesale_price'=>$cost];
   $new['product_availability']=$availability;$new['stock_quantity']=$quantity;
   $new['connector_version']=substr(sanitize_text_field((string)($data['connector_version']??'')),0,40);
   $new['evidence_hash']=preg_match('/^[a-f0-9]{64}$/i',(string)($data['evidence_hash']??''))?strtolower($data['evidence_hash']):'';
   $snapshot_id=hash('sha256',$scan_id.'|'.$url.'|'.$new['connector_version']);$new['snapshot_id']=$snapshot_id;
   self::supersede_kind($id,0,$supplier,'scan_problem');
   self::supersede_kind($id,0,$supplier,'scan_stale');
   if($status==='ok')self::supersede_kind($id,0,$supplier,'product_unavailable');
   $product=wc_get_product($id);
   if($status==='ok'&&$old&&isset($old['wholesale_price'])&&$cost!==null&&$old['wholesale_price']!==$cost&&$product&&$product->is_type('variable'))$events+=self::event($id,0,$supplier,'cost_changed',$old['wholesale_price'],$cost,'',$url,$snapshot_id)?1:0;
   if($status==='ok'&&$old&&isset($old['product_availability'])&&$availability!=='unknown'&&$old['product_availability']!==$availability)$events+=self::event($id,0,$supplier,'source_stock_changed',$old['product_availability'],$availability,'',$url,$snapshot_id)?1:0;
   if($status==='ok'&&$old&&isset($old['stock_quantity'])&&$quantity!==null&&$old['stock_quantity']!==$quantity)$events+=self::event($id,0,$supplier,'source_quantity_changed',$old['stock_quantity'],$quantity,'',$url,$snapshot_id)?1:0;
   if($status==='unavailable'){
    global $wpdb;$table=self::table();
    $wpdb->query($wpdb->prepare("UPDATE {$table} SET state='superseded', decided_at=UTC_TIMESTAMP() WHERE product_id=%d AND supplier=%s AND kind='price_review' AND state='pending'",$id,$supplier));
   }
   if($status==='ok'&&$cost!==null&&$product&&$product->is_type('simple'))$events+=self::price_event($id,$id,$supplier,$cost,$old['wholesale_price']??null,$snapshot_id,$url);
   foreach($rows as $row){
    $vid=absint($row['variation_id']??0);$availability=$row['availability']??'unknown';
    $child=wc_get_product($vid);$sku=(string)($row['supplier_sku']??'');
    $vraw=$row['wholesale_price']??null;$vcost=$vraw===null?null:self::decimal($vraw);
    $prior=$old['variants'][$vid]??[];
    $new['variants'][$vid]=['availability'=>$availability,'cost'=>$vcost,'sku'=>$sku];
    if($availability==='unknown'&&($row['reason']??'')==='not_listed'){
     $new['missing'][$vid]=min(100,(int)($old['missing'][$vid]??0)+1);
     if($new['missing'][$vid]>=2)$events+=self::event($id,$vid,$supplier,'variant_missing',is_array($prior)?($prior['availability']??'unknown'):'unknown','not_listed','',$url,$snapshot_id)?1:0;
    }
    else self::supersede_kind($id,$vid,$supplier,'variant_missing');
    if($availability!=='unknown'&&$availability!==$child->get_stock_status())$events+=self::event($id,$vid,$supplier,'stock_review',is_array($prior)?($prior['availability']??'unknown'):'unknown',$availability,$child->get_stock_status(),$url,$snapshot_id)?1:0;
    else self::supersede_kind($id,$vid,$supplier,'stock_review');
    if($status==='ok'&&$vcost!==null&&$child->is_type('variation'))$events+=self::price_event($id,$vid,$supplier,$vcost,is_array($prior)?($prior['cost']??null):null,$snapshot_id,$url);
   }
   if($status==='unavailable')$events+=self::event($id,0,$supplier,'product_unavailable',$old['status']??'unknown','unavailable','',$url,$snapshot_id)?1:0;
   update_option('dreminex_sm_last_successful_scan',$now,false);
  }else{
   $snapshot_id=hash('sha256',$scan_id.'|'.$url);
   $new['failure_count']=min(100,(int)($old['failure_count']??0)+1);
   $new['removed_count']=$status==='product_removed'?min(100,(int)($old['removed_count']??0)+1):0;
   if($status==='product_removed'&&$new['removed_count']<2)$status='unknown';
   $new['attempt_status']=$status;
   $reason=in_array($data['reason']??'', ['account_restricted','login_required'],true)?$data['reason']:'';
   $events+=self::event($id,0,$supplier,'scan_problem',$old['attempt_status']??'unknown',$reason==='account_restricted'?'account_restricted':$status,'',$url,$snapshot_id)?1:0;
  }
  $prev[$supplier]=$new;update_post_meta($id,self::SNAP,$prev);
  update_option('dreminex_sm_last_worker_scan',$now,false);
  $sources[$supplier]['status']=$status;$sources[$supplier]['last_issue']=in_array($data['reason']??'', ['account_restricted','login_required'],true)?$data['reason']:'';$sources[$supplier]['last_checked']=$now;$sources[$supplier]['last_scan_id']=$scan_id;
  if(in_array($status,['ok','unavailable'],true))$sources[$supplier]['last_success']=$now;
  update_post_meta($id,self::META,$sources);
  if($events)wp_mail(get_option('admin_email'),'Dreminex Supplier Monitor: '.$events.' change(s)','Review '.admin_url('admin.php?page=dreminex-supplier-monitor').' for product #'.$id.'.');
  do_action('dreminex_supplier_observation_processed',$id,$supplier,$old,$new,$data,$events);
  return rest_ensure_response(['recorded'=>true,'new_alerts'=>$events]);
 }
 /** Only phone-produced fingerprints are accepted as supplier gallery evidence. */
 private static function observe_visual($id,$host,$url,$result) {
  $images=$result['images']??($result['image_urls']??[]);$urls=array_values(array_filter(array_map(static fn($v)=>is_array($v)?($v['url']??''):(string)$v,(array)$images)));$sizes=$result['sizes']??[];
  $visual=(array)get_post_meta($id,self::VISUAL,true);$old=(array)($visual[$host]??[]);
  $scan=Dreminex_Supplier_Visual::compare($id,str_replace('www.','',$host),$images);
  $fresh=['at'=>time(),'status'=>$scan['status'],'urls'=>$urls,'sizes'=>$sizes,'known_sizes'=>array_values(array_unique(array_merge((array)($old['known_sizes']??[]),$sizes))),'order_sizes'=>$result['order_sizes']??[],'known_order_sizes'=>array_values(array_unique(array_merge((array)($old['known_order_sizes']??[]),(array)($result['order_sizes']??[])))),'matches'=>$old['matches']??[],'missing'=>$old['missing']??[],'size_missing'=>$old['size_missing']??[]];
  $events=0;$snapshot=hash('sha256',$url.'|'.$fresh['at'].'|'.wp_json_encode($urls));
  if($scan['status']==='ok'){
   // Keep verified historical mappings solely for missing-image evidence.
   foreach($scan['matches'] as $image_url=>$match)$fresh['matches'][$image_url]=$match;
   $previous_urls=($old['status']??'')==='ok'?($old['urls']??[]):[];
   foreach($fresh['matches'] as $image_url=>$match){
    $vid=(int)($match['variation_ids'][0]??0);if(!$vid)continue;
    if(in_array($image_url,$urls,true)){
     $fresh['missing'][$image_url]=0;self::supersede_kind($id,$vid,$host,'color_image_missing');if(isset($scan['matches'][$image_url]))self::supersede_kind($id,$vid,$host,'color_image_changed');continue;
    }
    // The image may move to another URL while the same verified colour remains.
    $replacement=false;foreach($scan['matches'] as $present)if(($present['color']??'')===($match['color']??'')){$replacement=true;break;}
    if($replacement){$fresh['missing'][$image_url]=0;self::supersede_kind($id,$vid,$host,'color_image_missing');continue;}
    if(!in_array($image_url,$previous_urls,true)&&empty($old['missing'][$image_url]))continue;
    $fresh['missing'][$image_url]=min(100,(int)($old['missing'][$image_url]??0)+1);
    $already_hidden=false;foreach((array)get_post_meta($id,'_dreminex_sm_hidden_colors',true) as $hidden)if(($hidden['color']??'')===($match['color']??'')){$already_hidden=true;break;}
    if($fresh['missing'][$image_url]>=2&&!$already_hidden){
     $detail=['url'=>$image_url,'color'=>$match['color'],'image_id'=>(int)$match['image_id'],'variation_ids'=>$match['variation_ids'],'missing_scans'=>$fresh['missing'][$image_url]];
     $events+=self::event($id,$vid,$host,'color_image_missing',$match['color'],'gallery_image_absent',wp_json_encode($detail),$url,$snapshot)?1:0;
    }
   }
   if(($old['status']??'')==='ok'&&isset($old['urls']))foreach($scan['uncertain'] as $image_url){
    if(isset($old['matches'][$image_url])){$match=$old['matches'][$image_url];$vid=(int)($match['variation_ids'][0]??0);
     if($vid)$events+=self::event($id,$vid,$host,'color_image_changed',$match['color']??'','image_no_longer_matches_woo','Review supplier image and colour manually.',$url,$snapshot)?1:0;
    }
   }
  }
  // Text is a size hint. A missing size never proves option-level stock.
  if(!empty($result['size_evidence'])){
   foreach(($old['known_sizes']??[]) as $size){
    if(in_array($size,$sizes,true)){$fresh['size_missing'][$size]=0;self::supersede_kind($id,0,$host,'size_text_missing');global $wpdb;$table=self::table();$wpdb->query($wpdb->prepare("UPDATE {$table} SET state='superseded',decided_at=UTC_TIMESTAMP() WHERE product_id=%d AND supplier=%s AND kind='size_option_missing' AND previous_value=%s AND state='pending'",$id,$host,$size));continue;}
    if(($old['status']??'')!=='ok')continue;
    $fresh['size_missing'][$size]=min(100,(int)($old['size_missing'][$size]??0)+1);
    $already_hidden=false;foreach((array)get_post_meta($id,'_dreminex_sm_hidden_sizes',true) as $hidden)if(($hidden['size']??'')===$size){$already_hidden=true;break;}
    if($fresh['size_missing'][$size]>=2&&!$already_hidden){
     $order_known=in_array($size,(array)($old['known_order_sizes']??[]),true);
     $order_absent=!in_array($size,(array)($result['order_sizes']??[]),true);
     $kind=$order_known&&!empty($result['order_size_evidence'])&&$order_absent?'size_option_missing':'size_text_missing';
     $detail=$kind==='size_option_missing'?wp_json_encode(['size'=>$size,'missing_scans'=>$fresh['size_missing'][$size]]):'Size absent in description; verify live order choices before changing WooCommerce.';
     if($kind==='size_text_missing'){global $wpdb;$table=self::table();$wpdb->query($wpdb->prepare("UPDATE {$table} SET state='superseded',decided_at=UTC_TIMESTAMP() WHERE product_id=%d AND supplier=%s AND kind='size_option_missing' AND previous_value=%s AND state='pending'",$id,$host,$size));}
     $size_vid=0;foreach((array)wc_get_product($id)->get_children() as $child_id){$child=wc_get_product($child_id);foreach($child->get_attributes() as $key=>$value)if(stripos($key,'size')!==false&&strtoupper((string)$value)===$size){$size_vid=(int)$child_id;break 2;}}
     $events+=self::event($id,$size_vid,$host,$kind,$size,$kind==='size_option_missing'?'missing_in_description_and_order_options':'not_in_description',$detail,$url,$snapshot)?1:0;
    }
   }
  }else {$fresh['sizes']=$old['sizes']??[];$fresh['known_sizes']=$old['known_sizes']??[];$fresh['order_sizes']=$old['order_sizes']??[];$fresh['known_order_sizes']=$old['known_order_sizes']??[];}
  $visual[$host]=$fresh;update_post_meta($id,self::VISUAL,$visual);
  if($events)wp_mail(get_option('admin_email'),'Dreminex Supplier Monitor: colour/size review','Open Dreminex Nexus → Security → Supplier alerts to review colour/size evidence for product #'.$id.'.');
 }
 public static function decide() {
  if(!self::on()||!current_user_can('manage_woocommerce'))wp_die('Access denied.', '', ['response'=>403]);
  check_admin_referer('dreminex_sm_decide');$id=absint($_POST['event_id']??0);$decision=sanitize_key(wp_unslash($_POST['decision']??''));
  if(!in_array($decision,['approve','dismiss'],true))wp_die('Invalid decision.', '', ['response'=>400]);
  global $wpdb;$table=self::table();$event=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d AND state='pending'",$id));
  if(!$event||!current_user_can('edit_post',$event->product_id))wp_die('Alert is no longer pending.', '', ['response'=>409]);
  if($decision==='dismiss'){
   $ok=$wpdb->update($table,['state'=>'dismissed','decided_at'=>current_time('mysql',true),'actor_id'=>get_current_user_id()],['id'=>$id,'state'=>'pending'],['%s','%s','%d'],['%d','%s']);
   if($ok!==1)wp_die('Already decided.', '', ['response'=>409]);
   self::go('dismissed');
  }
  if(!in_array($event->kind,['stock_review','price_review','color_image_missing','size_option_missing'],true))wp_die('This alert requires manual review.', '', ['response'=>400]);
  $sources=(array)get_post_meta($event->product_id,self::META,true);$all=(array)get_post_meta($event->product_id,self::SNAP,true);
  $source=$all[$event->supplier]??[];$vid=(int)$event->variation_id;
  $product=wc_get_product($vid);
  if(get_post_status($event->product_id)==='trash'||!isset($sources[$event->supplier])||$sources[$event->supplier]['url']!==$event->evidence_url||!$product||($vid!==(int)$event->product_id&&(int)$product->get_parent_id()!==(int)$event->product_id)||!in_array($source['status']??'',['ok','unavailable'],true)||($source['attempt_status']??'')!==$source['status']||($source['last_success_at']??0)<time()-24*HOUR_IN_SECONDS)wp_die('Source, product or scan changed. Recheck before approval.', '', ['response'=>409]);
  if($event->kind==='color_image_missing'||$event->kind==='size_option_missing'){
   $validated=$event->kind==='color_image_missing'?self::validate_color_action($event,$sources):self::validate_size_action($event,$sources);
   if(is_wp_error($validated))wp_die(esc_html($validated->get_error_message()), '', ['response'=>409]);
  } elseif($event->kind==='stock_review'){
   if(($source['variants'][$vid]['availability']??'')!==$event->observed_value||($source['snapshot_id']??'')!==$event->snapshot_id||$product->get_stock_status()!==$event->expected_value||$product->get_manage_stock())wp_die('Stock, mapping or quantity changed. Review manually.', '', ['response'=>409]);
   if($vid!==(int)$event->product_id&&($sources[$event->supplier]['variants'][$vid]['sku']??'')!==($source['variants'][$vid]['sku']??''))wp_die('Variation mapping changed.', '', ['response'=>409]);
   if($event->observed_value==='outofstock')foreach($sources as $host=>$mapping){
    $other=$all[$host]??[];
    if(($other['url']??'')!==($mapping['url']??'')||($other['last_success_at']??0)<time()-24*HOUR_IN_SECONDS||!in_array($other['status']??'',['ok','unavailable'],true)||($other['attempt_status']??'')!==$other['status']||($other['variants'][$vid]['availability']??'')!=='outofstock')wp_die('All linked suppliers must report fresh, explicit out-of-stock for this exact item.', '', ['response'=>409]);
   }
   $value=$event->observed_value;
  }else{
   if(count($sources)!==1)wp_die('Multiple supplier costs require manual source selection and pricing review.', '', ['response'=>409]);
   $data=json_decode($event->observed_value,true);$expected=json_decode($event->expected_value,true);$rule=(array)get_option('dreminex_sm_pricing',[]);
   $cost=$vid===(int)$event->product_id?($source['wholesale_price']??null):($source['variants'][$vid]['cost']??null);
   if(!is_array($data)||!is_array($expected)||($source['status']??'')!=='ok'||($source['snapshot_id']??'')!==$event->snapshot_id||!in_array($product->get_type(),['simple','variation'],true)||empty($rule['price_enabled'])||(int)($rule['configured']??0)!==4||($data['rule_version']??0)!==($rule['version']??0)||$cost!==($data['cost']??null)||$product->get_sale_price('edit')!==''||$product->get_date_on_sale_from('edit')||$product->get_date_on_sale_to('edit')||$product->get_regular_price('edit')!==($expected['regular']??null)||$product->get_sale_price('edit')!==($expected['sale']??null))wp_die('Price rule, source cost or WooCommerce price changed.', '', ['response'=>409]);
   $quote=self::price_quote($cost,$vid,$product,$rule);
   if(empty($quote['ok'])||!isset($data['quote'])||wp_json_encode($quote)!==wp_json_encode($data['quote']))wp_die('Customer cap, costs, coupons, shipping or offer changed. Recheck before approval.', '', ['response'=>409]);
   $value=$quote['price'];
   if($value!==($data['price']??null)||(float)$expected['regular']<=0||abs((float)$value-(float)$expected['regular'])/(float)$expected['regular']*100>(float)($rule['max_change_percent']??20))wp_die('Price proposal is no longer valid.', '', ['response'=>409]);
  }
  // Claim atomically: two concurrent approval requests cannot both save the same event.
  $claimed=$wpdb->update($table,['state'=>'applying','decided_at'=>current_time('mysql',true),'actor_id'=>get_current_user_id()],['id'=>$id,'state'=>'pending'],['%s','%s','%d'],['%d','%s']);
  if($claimed!==1)wp_die('Already being applied.', '', ['response'=>409]);
  try{
   if($event->kind==='color_image_missing'||$event->kind==='size_option_missing'){
    $readback=$event->kind==='color_image_missing'?self::hide_color($event,$validated):self::hide_size($event,$validated);
    if(is_wp_error($readback))throw new RuntimeException($readback->get_error_message());
   }else{
    if($event->kind==='stock_review')$product->set_stock_status($value);
    else $product->set_regular_price($value);
    $product->save();
    $saved=wc_get_product($vid);
    $readback=$event->kind==='stock_review'?$saved->get_stock_status():$saved->get_regular_price('edit');
    if((string)$readback!==(string)$value)throw new RuntimeException('WooCommerce readback differed from the approved value.');
   }
   $wpdb->update($table,['state'=>'verified','readback_value'=>(string)$readback],['id'=>$id,'state'=>'applying'],['%s','%s'],['%d','%s']);
   self::go('verified');
  }catch(Throwable $error){
   $wpdb->update($table,['state'=>'failed','readback_value'=>substr($error->getMessage(),0,300)],['id'=>$id,'state'=>'applying'],['%s','%s'],['%d','%s']);
   wp_die('Apply or readback failed. Inspect the current product and audit event before retry.', '', ['response'=>500]);
  }
 }
 private static function validate_color_action($event,$sources) {
  $id=(int)$event->product_id;$host=$event->supplier;$detail=json_decode($event->expected_value,true);
  $visual=(array)get_post_meta($id,self::VISUAL,true);$now=(array)($visual[$host]??[]);
  if(count($sources)!==1||!is_array($detail)||!isset($sources[$host])||($sources[$host]['url']??'')!==$event->evidence_url||($now['status']??'')!=='ok'||($now['at']??0)<time()-24*HOUR_IN_SECONDS||($now['missing'][$detail['url']??'']??0)<2||in_array($detail['url']??'',(array)($now['urls']??[]),true))return new WP_Error('stale_visual','Source or image evidence changed. Scan and review again.');
  $match=$now['matches'][$detail['url']]??[];$color=$detail['color']??'';$image=(int)($detail['image_id']??0);
  if(!$match||$color===''||$match['color']!==$color||(int)$match['image_id']!==$image||$match['variation_ids']!==($detail['variation_ids']??null))return new WP_Error('mapping_changed','Image to colour mapping changed.');
  foreach((array)($now['urls']??[]) as $url)if(($now['matches'][$url]['color']??'')===$color)return new WP_Error('alternate_image','Another current supplier image shows this colour.');
  $parent=wc_get_product($id);if(!$parent||!$parent->is_type('variable'))return new WP_Error('product_changed','Product type changed.');
  $ids=array_map('intval',(array)$detail['variation_ids']);$all=[];$attribute_key='';$attribute=null;
  foreach($parent->get_children() as $child_id){$child=wc_get_product($child_id);if(!$child)continue;$child_color='';foreach($child->get_attributes() as $key=>$term)if(stripos($key,'color')!==false||stripos($key,'colour')!==false){$child_color=sanitize_title((string)$term);$attribute_key=$key;}
   if($child_color===$color)$all[]=(int)$child_id;
  }
  sort($ids);sort($all);
  if(!$ids||$ids!==$all)return new WP_Error('variation_changed','Colour variations changed.');
  foreach($ids as $child_id){$child=wc_get_product($child_id);if(!$child||$child->get_status()!=='publish'||(int)$child->get_image_id()!==$image)return new WP_Error('variation_changed','Variation status or image changed.');}
  $attributes=$parent->get_attributes();foreach($attributes as $key=>$attr)if($attr->get_variation()&&(stripos($key,'color')!==false||stripos($key,'colour')!==false)){$attribute_key=$key;$attribute=$attr;break;}
  if(!$attribute)return new WP_Error('attribute_changed','Colour attribute unavailable.');
  $options=$attribute->get_options();$target=[];foreach($options as $option){$term=is_numeric($option)?get_term((int)$option,$attribute->get_name()):null;$slug=$term&&!is_wp_error($term)?$term->slug:sanitize_title((string)$option);if($slug===$color)$target[]=$option;}
  if(count($target)!==1||count($options)<2)return new WP_Error('attribute_changed','Colour choice cannot be isolated safely.');
  $replacement=0;foreach((array)($now['urls']??[]) as $present_url){$candidate=(int)($now['matches'][$present_url]['image_id']??0);if($candidate&&$candidate!==$image){$replacement=$candidate;break;}}
  if((int)$parent->get_image_id()===$image&&!$replacement)return new WP_Error('featured_image','No verified replacement for the featured product image.');
  return ['parent'=>$parent,'ids'=>$ids,'attribute_key'=>$attribute_key,'option'=>$target[0],'color'=>$color,'image_id'=>$image,'replacement_id'=>$replacement];
 }
 private static function hide_color($event,$validated) {
  $parent=$validated['parent'];$id=(int)$event->product_id;$attrs=$parent->get_attributes();$key=$validated['attribute_key'];$options=$attrs[$key]->get_options();
  $gallery=$parent->get_gallery_image_ids();$image=$validated['image_id'];$featured=(int)$parent->get_image_id();$before=['featured'=>$featured,'color'=>$validated['color'],'attribute_key'=>$key,'options'=>$options,'option'=>$validated['option'],'gallery'=>$gallery,'variations'=>$validated['ids'],'image_id'=>$image];
  // Persist undo data before touching catalog rows; do not delete media.
  $history=(array)get_post_meta($id,'_dreminex_sm_hidden_colors',true);$history[(int)$event->id]=$before;update_post_meta($id,'_dreminex_sm_hidden_colors',$history);
  foreach($validated['ids'] as $vid){$v=wc_get_product($vid);$v->set_status('private');$v->save();}
  $attrs[$key]->set_options(array_values(array_filter($options,static fn($o)=> (string)$o!==(string)$validated['option'])));$parent->set_attributes($attrs);
  if($featured===$image)$parent->set_image_id((int)$validated['replacement_id']);
  $parent->set_gallery_image_ids(array_values(array_filter($gallery,static fn($o)=>(int)$o!==$image && (int)$o!==(int)$validated['replacement_id'])));
  $parent->save();
  if($attrs[$key]->is_taxonomy()){
   $terms=wp_set_object_terms($id,$attrs[$key]->get_options(),$key,false);
   if(is_wp_error($terms))return $terms;
  }
  clean_post_cache($id);wc_delete_product_transients($id);
  $check=wc_get_product($id);$new=$check->get_attributes()[$key]->get_options();
  foreach($validated['ids'] as $vid)if(get_post_status($vid)!=='private')return new WP_Error('readback_failed','Hidden variation readback failed; undo data was saved.');
  if(in_array((string)$validated['option'],array_map('strval',$new),true))return new WP_Error('readback_failed','Colour attribute readback failed; undo data was saved.');
  $history[(int)$event->id]['after_gallery']=$check->get_gallery_image_ids();$history[(int)$event->id]['after_featured']=$check->get_image_id();update_post_meta($id,'_dreminex_sm_hidden_colors',$history);
  return 'Hidden '.esc_html($validated['color']).' ('.count($validated['ids']).' variations); undo available';
 }
 public static function restore_color() {
  if(!self::on()||!current_user_can('manage_woocommerce'))wp_die('Access denied.', '', ['response'=>403]);
  check_admin_referer('dreminex_sm_restore_color');$id=absint($_POST['event_id']??0);global $wpdb;$table=self::table();$event=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d AND kind='color_image_missing' AND state='verified'",$id));
  if(!$event||!current_user_can('edit_post',$event->product_id))wp_die('Approved colour action unavailable.', '', ['response'=>409]);
  $restored=self::restore_color_record($event);
  if(is_wp_error($restored))wp_die(esc_html($restored->get_error_message()), '', ['response'=>409]);
  self::go('restored');
 }
 private static function restore_color_record($event) {
  global $wpdb;$table=self::table();$id=(int)$event->id;$product_id=(int)$event->product_id;
  $history=(array)get_post_meta($product_id,'_dreminex_sm_hidden_colors',true);$before=$history[$id]??null;$p=wc_get_product($product_id);
  if(!is_array($before)||!$p||!$p->is_type('variable'))return new WP_Error('undo_unavailable','Undo data unavailable.');
  $attrs=$p->get_attributes();$key=$before['attribute_key'];if(!isset($attrs[$key]))return new WP_Error('attribute_changed','Attribute changed; restore manually from audit.');
  $current=$attrs[$key]->get_options();$saved=(array)$before['options'];
  if(isset($before['after_gallery'])&&($p->get_gallery_image_ids()!==$before['after_gallery']||(int)$p->get_image_id()!==(int)$before['after_featured']))return new WP_Error('media_changed','Product media changed since approval; restore manually.');
  if(count(array_diff(array_map('strval',$current),array_map('strval',$saved))))return new WP_Error('attribute_changed','New choices exist; restore manually.');
  foreach((array)$before['variations'] as $vid)if(get_post_status($vid)!=='private')return new WP_Error('variation_changed','Variation changed; restore manually.');
  $attrs[$key]->set_options($saved);$p->set_attributes($attrs);$p->set_image_id((int)$before['featured']);$p->set_gallery_image_ids((array)$before['gallery']);$p->save();
  if($attrs[$key]->is_taxonomy()){$terms=wp_set_object_terms($product_id,$saved,$key,false);if(is_wp_error($terms))return $terms;}clean_post_cache($product_id);
  foreach((array)$before['variations'] as $vid){$v=wc_get_product($vid);if($v){$v->set_status('publish');$v->save();}}
  wc_delete_product_transients($product_id);$checked=wc_get_product($product_id);
  if(!in_array((string)$before['option'],array_map('strval',$checked->get_attributes()[$key]->get_options()),true))return new WP_Error('readback_failed','Restore readback failed; inspect product.');
  foreach((array)$before['variations'] as $vid)if(get_post_status($vid)!=='publish')return new WP_Error('readback_failed','Variation restore readback failed; inspect product.');
  $wpdb->update($table,['state'=>'restored','readback_value'=>'Restored by user #'.get_current_user_id(),'decided_at'=>current_time('mysql',true)],['id'=>$id,'state'=>'verified'],['%s','%s','%s'],['%d','%s']);unset($history[$id]);update_post_meta($product_id,'_dreminex_sm_hidden_colors',$history);
  return 'restored';
 }
 private static function validate_size_action($event,$sources) {
  $id=(int)$event->product_id;$host=$event->supplier;$data=json_decode($event->expected_value,true);$size=$data['size']??'';
  $visual=(array)get_post_meta($id,self::VISUAL,true);$now=(array)($visual[$host]??[]);
  if(count($sources)!==1||!isset($sources[$host])||($sources[$host]['url']??'')!==$event->evidence_url||!preg_match('/^(XXXL|XXL|XL|XS|S|M|L)$/',$size)||($now['status']??'')!=='ok'||($now['at']??0)<time()-24*HOUR_IN_SECONDS||($now['size_missing'][$size]??0)<2||in_array($size,(array)($now['sizes']??[]),true)||in_array($size,(array)($now['order_sizes']??[]),true)||empty($now['order_sizes'])||!in_array($size,(array)($now['known_order_sizes']??[]),true))return new WP_Error('stale_size','Supplier size evidence changed. Scan and review again.');
  $p=wc_get_product($id);if(!$p||!$p->is_type('variable'))return new WP_Error('product_changed','Product type changed.');
  $ids=[];foreach($p->get_children() as $vid){$v=wc_get_product($vid);foreach($v->get_attributes() as $key=>$value)if(stripos($key,'size')!==false&&strtoupper((string)$value)===$size){$ids[]=(int)$vid;break;}}
  if(!$ids||!in_array((int)$event->variation_id,$ids,true))return new WP_Error('mapping_changed','Size variations changed.');
  foreach($ids as $vid)if(get_post_status($vid)!=='publish')return new WP_Error('variation_changed','Variation status changed.');
  $attrs=$p->get_attributes();foreach($attrs as $key=>$attr)if($attr->get_variation()&&stripos($key,'size')!==false){$options=$attr->get_options();$target=[];foreach($options as $option){$term=is_numeric($option)?get_term((int)$option,$attr->get_name()):null;$slug=$term&&!is_wp_error($term)?$term->slug:sanitize_title((string)$option);if(strtoupper($slug)===$size)$target[]=$option;}if(count($target)===1&&count($options)>1)return ['parent'=>$p,'ids'=>$ids,'attribute_key'=>$key,'option'=>$target[0],'size'=>$size];}
  return new WP_Error('attribute_changed','Size choice cannot be isolated safely.');
 }
 private static function hide_size($event,$v) {
  $id=(int)$event->product_id;$p=$v['parent'];$attrs=$p->get_attributes();$key=$v['attribute_key'];$options=$attrs[$key]->get_options();
  $history=(array)get_post_meta($id,'_dreminex_sm_hidden_sizes',true);$history[(int)$event->id]=['size'=>$v['size'],'attribute_key'=>$key,'option'=>$v['option'],'options'=>$options,'variations'=>$v['ids']];update_post_meta($id,'_dreminex_sm_hidden_sizes',$history);
  foreach($v['ids'] as $vid){$child=wc_get_product($vid);$child->set_status('private');$child->save();}
  $attrs[$key]->set_options(array_values(array_filter($options,static fn($o)=>(string)$o!==(string)$v['option'])));$p->set_attributes($attrs);$p->save();
  if($attrs[$key]->is_taxonomy()){$terms=wp_set_object_terms($id,$attrs[$key]->get_options(),$key,false);if(is_wp_error($terms))return $terms;}clean_post_cache($id);wc_delete_product_transients($id);
  $new=wc_get_product($id)->get_attributes()[$key]->get_options();if(in_array((string)$v['option'],array_map('strval',$new),true))return new WP_Error('readback_failed','Size attribute readback failed; undo data was saved.');
  foreach($v['ids'] as $vid)if(get_post_status($vid)!=='private')return new WP_Error('readback_failed','Variation readback failed; undo data was saved.');
  return 'Hidden size '.$v['size'].' ('.count($v['ids']).' variations); undo available';
 }
 public static function restore_size() {
  if(!self::on()||!current_user_can('manage_woocommerce'))wp_die('Access denied.', '', ['response'=>403]);
  check_admin_referer('dreminex_sm_restore_size');$id=absint($_POST['event_id']??0);global $wpdb;$table=self::table();$event=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d AND kind='size_option_missing' AND state='verified'",$id));
  if(!$event||!current_user_can('edit_post',$event->product_id))wp_die('Approved size action unavailable.', '', ['response'=>409]);
  $r=self::restore_size_record($event);if(is_wp_error($r))wp_die(esc_html($r->get_error_message()), '', ['response'=>409]);self::go('restored');
 }
 private static function restore_size_record($event) {
  global $wpdb;$table=self::table();$id=(int)$event->id;$product_id=(int)$event->product_id;$history=(array)get_post_meta($product_id,'_dreminex_sm_hidden_sizes',true);$old=$history[$id]??null;$p=wc_get_product($product_id);
  if(!is_array($old)||!$p||!$p->is_type('variable'))return new WP_Error('undo_unavailable','Undo data unavailable.');
  $attrs=$p->get_attributes();$key=$old['attribute_key'];if(!isset($attrs[$key]))return new WP_Error('attribute_changed','Size attribute changed; restore manually.');
  if(array_diff(array_map('strval',$attrs[$key]->get_options()),array_map('strval',$old['options'])))return new WP_Error('attribute_changed','Size choices changed; restore manually.');
  foreach($old['variations'] as $vid)if(get_post_status($vid)!=='private')return new WP_Error('variation_changed','Variation changed; restore manually.');
  $attrs[$key]->set_options($old['options']);$p->set_attributes($attrs);$p->save();if($attrs[$key]->is_taxonomy()){$terms=wp_set_object_terms($product_id,$old['options'],$key,false);if(is_wp_error($terms))return $terms;}clean_post_cache($product_id);
  foreach($old['variations'] as $vid){$v=wc_get_product($vid);if($v){$v->set_status('publish');$v->save();}}wc_delete_product_transients($product_id);
  $new=wc_get_product($product_id)->get_attributes()[$key]->get_options();if(!in_array((string)$old['option'],array_map('strval',$new),true))return new WP_Error('readback_failed','Size restore readback failed.');
  foreach($old['variations'] as $vid)if(get_post_status($vid)!=='publish')return new WP_Error('readback_failed','Variation restore readback failed.');
  $wpdb->update($table,['state'=>'restored','readback_value'=>'Restored by user #'.get_current_user_id(),'decided_at'=>current_time('mysql',true)],['id'=>$id,'state'=>'verified'],['%s','%s','%s'],['%d','%s']);unset($history[$id]);update_post_meta($product_id,'_dreminex_sm_hidden_sizes',$history);return 'restored';
 }
 public static function page() {
  if(!current_user_can('manage_woocommerce'))wp_die('Access denied.', '', ['response'=>403]);
  global $wpdb;$table=self::table();$on=self::on();$events=[];
  if($on)$events=$wpdb->get_results("SELECT * FROM {$table} WHERE state='pending' ORDER BY id DESC LIMIT 100");
  $unlinked=self::catalog_ids(1,30,'_dreminex_sm_needs_source');
  echo '<div class="wrap dreminex-suite dreminex-sm"><h1>Supplier review actions</h1><p>Dreminex Nexus performs every supplier-facing request from the phone. This legacy view keeps the existing pricing, variation-mapping and approval records. Observations never overwrite listings without review.</p>';
  echo '<div class="ds-summary"><div class="ds-stat"><span>Module</span><strong class="ds-stat-word">'.($on?'On':'Off').'</strong></div><div class="ds-stat"><span>Needs link (first 30)</span><strong>'.count($unlinked).'</strong></div><div class="ds-stat"><span>Pending alerts (first 100)</span><strong>'.count($events).'</strong></div></div>';
  echo '<nav class="ds-sm-jump" aria-label="Supplier Monitor sections"><a href="#ds-sm-connect">1 · Device sessions</a><a href="#ds-sm-products">2 · Map products</a><a href="#ds-sm-alerts">3 · Review alerts</a></nav>';
  if(!$on)echo '<div class="notice notice-warning"><p>Enable Supplier Monitor in Suite Modules to begin catalog tracking.</p></div>';
  $reconcile=(array)get_option('dreminex_sm_last_reconcile',[]);$worker=(int)get_option('dreminex_sm_last_worker_scan',0);$success=(int)get_option('dreminex_sm_last_successful_scan',0);
  $vault=(array)get_option(self::ACCOUNT_OPTION,[]);
  if(!$worker)echo '<div class="notice notice-warning"><p><strong>Awaiting first Nexus observation:</strong> connect a product URL, pair the Android app and complete the supplier login on that device.</p></div>';
  echo '<p>Last catalog reconciliation: '.(!empty($reconcile['at'])?esc_html(wp_date('Y-m-d H:i',(int)$reconcile['at'])):'Not yet run').'. Last scan attempt: '.($worker?esc_html(wp_date('Y-m-d H:i',$worker)):'Not yet received').'. Last successful supplier observation: '.($success?esc_html(wp_date('Y-m-d H:i',$success)):'None').' (site timezone).</p>';
  if($on&&(!$success||$success<time()-18*HOUR_IN_SECONDS))echo '<div class="notice notice-warning"><p>Supplier observations are missing or older than the scan target. Check saved accounts and individual product scan status. No WooCommerce change is inferred from a failed attempt.</p></div>';
  $next_tick=wp_next_scheduled('dreminex_sm_scan_due');
  echo '<p>Next scheduler tick: '.($next_tick?esc_html(wp_date('Y-m-d H:i',$next_tick)):'Not scheduled').' (site timezone). An external server cron calling WordPress cron is required for a strict wall-clock schedule on a low-traffic site.</p>';
  if($on&&(!$next_tick||$next_tick<time()-15*MINUTE_IN_SECONDS))echo '<div class="notice notice-error"><p><strong>Scan scheduler overdue:</strong> check WP-Cron or the hosting cron runner. Product snapshots may be stale.</p></div>';
  echo '<div class="ds-sm-settings"><section class="card" id="ds-sm-connect"><h2>Nexus device sessions</h2><p>New credentials cannot be saved in WordPress. Login, cookies and session refresh stay inside the paired Nexus device. Any old encrypted vault entry below is quarantined and can only be removed.</p>';
  foreach(['shopbasebd.com'=>'ShopBase BD','resellkori.com'=>'ResellKori'] as $host=>$name){
   $saved=isset($vault[$host])&&is_array(self::open_account($vault[$host]));
   echo '<h3>'.esc_html($name).'</h3><p>WordPress credential vault: <strong>'.($saved?'Quarantined; no scan can read or use it':'Empty').'</strong></p>';
   if($saved){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_sm_account"><input type="hidden" name="operation" value="remove"><input type="hidden" name="supplier" value="'.esc_attr($host).'">';wp_nonce_field('dreminex_sm_account');submit_button('Remove account','secondary','submit',false);echo '</form>';}
  }
  echo '</section>';
  echo '<section class="card" id="ds-sm-products"><h2>Connect a product</h2><p>Paste the exact supplier URL here or in the product editor’s Supplier Monitor box. Draft and published products are discovered automatically; the URL and a saved account enable scanning. ResellKori uses the single-item Reseller Price, while ShopBaseBD uses its product price. An individual size/colour remains unverified when the supplier only reports product-wide stock.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_sm_link">';wp_nonce_field('dreminex_sm_link');
  echo '<label>Product ID <input type="number" required min="1" name="product_id"></label> <label>Supplier product HTTPS URL <input type="url" required size="60" name="source_url"></label> ';submit_button('Connect source','primary','submit',false);echo '</form></section>';
  echo '</div><details class="ds-sm-advanced"><summary>Advanced mapping and pricing rules <span>Open when a supplier code or profit policy needs attention</span></summary><div class="ds-sm-settings">';
  echo '<section class="card"><h2>Verify an exact variation mapping</h2><p>First verify the supplier code and available size against its logged-in page. A code may be shared by different sizes when code plus size identifies one WooCommerce variation. Leave code blank to unlink. A changed mapping supersedes pending approvals.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_sm_variant_link">';wp_nonce_field('dreminex_sm_variant_link');
  echo '<label>Product ID <input type="number" required min="1" name="product_id"></label> <label>Variation ID <input type="number" required min="1" name="variation_id"></label> <label>Supplier host <select name="supplier"><option value="shopbasebd.com">shopbasebd.com</option><option value="www.shopbasebd.com">www.shopbasebd.com</option><option value="resellkori.com">resellkori.com</option><option value="www.resellkori.com">www.resellkori.com</option></select></label> <label>Verified supplier SKU <input type="text" maxlength="100" name="supplier_sku"></label> ';submit_button('Save exact mapping','secondary','submit',false);echo '</form></section>';
  $pricing=(array)get_option('dreminex_sm_pricing',[]);
  echo '<section class="card"><h2>Profit and delivered-price protection</h2><p>BDT dropshipping policy. The dropshipping platform fulfils delivery and handles COD. Customer delivery advance (Dhaka ৳80, nearby ৳100, outside ৳130) is shown separately and included only in the delivery-inclusive customer cap; it is not treated as your courier bill or product revenue. Your entered costs are packaging/other, return reserve, product ad budget and 1.5% payment fee on wholesale. Published coupons, newsletter offers and configured Flash Sale items are checked again before approval. Tax rates or non-flat shipping require a separate review. A safe price ending in 9 leaves at least the target profit after discounts, less than ৳200 regular profit, and stays under the item’s delivery-inclusive customer cap. No catalog price changes without explicit approval.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_sm_settings">';wp_nonce_field('dreminex_sm_settings');
  $fields=['other_cost'=>['Packaging and other cost (BDT)','15'],'return_reserve'=>['Return risk reserve (BDT)','30'],'ad_default'=>['Default ad budget (BDT)','25'],'supplier_fee_percent'=>['Payment fee on wholesale (%)','1.5'],'coupon_reserve'=>['Fixed coupon reserve (BDT)','30'],'coupon_percent_reserve'=>['Percentage coupon reserve (%)','0'],'minimum_profit'=>['Minimum net profit (BDT)','70'],'maximum_profit'=>['Maximum regular profit, below 200 (BDT)','199'],'max_change_percent'=>['Maximum suggested price change (%)','20']];
  foreach($fields as $name=>$field)echo '<label style="display:inline-block;margin:5px 14px 5px 0">'.esc_html($field[0]).' <input type="number" required min="0" step="0.01" name="'.esc_attr($name).'" value="'.esc_attr($pricing[$name]??$field[1]).'"></label> ';
  echo '<p><label><input type="checkbox" name="price_enabled" value="1" '.checked(!empty($pricing['price_enabled'])&&(int)($pricing['configured']??0)===4,true,false).'> I verified wholesale cost, 1.5% payment fee, offers, ad budget and delivery charges; enable reviewed regular-price proposals</label></p>';
  submit_button('Save profit rule','secondary','submit',false);echo '</form><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_sm_profit">';wp_nonce_field('dreminex_sm_profit');
  echo '<p>Set a cap for each simple product or variation after comparing its quality and market price. Leave the ad field blank for the ৳25 default; use ৳30–৳90 on selected products.</p><label>Product ID <input type="number" required min="1" name="product_id"></label> <label>Simple product or variation ID <input type="number" required min="1" name="variation_id"></label> <label>Target net profit (BDT) <input type="number" required min="70" max="199.99" step="0.01" name="target_profit" value="70"></label> <label>Ad budget override (BDT) <input type="number" min="30" max="90" step="0.01" name="ad_cost" placeholder="Default 25"></label> <label>Maximum customer total including delivery (BDT) <input type="number" required min="1" step="0.01" name="customer_cap"></label> ';submit_button('Save item policy','secondary','submit',false);echo '</form></section>';
  echo '</div></details><section class="card"><h2>Products needing a source</h2><p>New and updated products appear automatically. No product is matched by title alone.</p><ul>';
  foreach($unlinked as $id)echo '<li><a href="'.esc_url(get_edit_post_link($id)).'">#'.(int)$id.' — '.esc_html(get_the_title($id)).'</a></li>';
  if(!$unlinked)echo '<li>None in this page.</li>';echo '</ul></section>';
  $linked=self::catalog_ids(1,30,true);
  echo '<section class="card"><h2>Connected products</h2><ul>';
  foreach($linked as $id){echo '<li><a href="'.esc_url(get_edit_post_link($id)).'">#'.(int)$id.' — '.esc_html(get_the_title($id)).'</a><ul>';
   foreach((array)get_post_meta($id,self::META,true) as $host=>$source){$snap=(array)get_post_meta($id,self::SNAP,true);$observed=$snap[$host]??[];
    $restricted=($source['last_issue']??'')==='account_restricted';$next=$restricted?self::restriction_recheck_at($source):self::next_attempt($source,(array)$observed);
    echo '<li>'.esc_html($host).' · '.esc_html($source['status']??'pending').(!empty($source['last_issue'])?' · '.esc_html($source['last_issue']):'').' · last success '.(!empty($source['last_success'])?esc_html(wp_date('Y-m-d H:i',(int)$source['last_success'])):'not scanned').' · next attempt '.esc_html(wp_date('Y-m-d H:i',$next)).' · mapped variations '.count((array)($source['variants']??[]));
    if(isset($observed['wholesale_price']))echo ' · single-item cost ৳'.esc_html($observed['wholesale_price']);
    if(isset($observed['product_availability']))echo ' · product stock '.esc_html($observed['product_availability']);
    if(isset($observed['stock_quantity']))echo ' ('.(int)$observed['stock_quantity'].')';
    echo '</li>';
   $colors=(array)get_post_meta($id,self::COLOR_SNAP,true);
   foreach((array)($colors[$host]??[]) as $color=>$row){
    echo '<li>↳ '.esc_html(ucwords(str_replace('-',' ',$color))).' · supplier code '.esc_html($row['sku']??'').' · colour item '.esc_html($row['availability']??'unverified').' · last successful colour scan '.(!empty($row['last_success'])?esc_html(wp_date('Y-m-d H:i',(int)$row['last_success'])):'not yet').'. Size-level stock remains unverified.</li>';
   }
   }
   echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_sm_scan"><input type="hidden" name="product_id" value="'.(int)$id.'">';wp_nonce_field('dreminex_sm_scan');submit_button('Scan this product now','secondary','submit',false);echo '</form>';
   echo '</ul></li>';
  }if(!$linked)echo '<li>No supplier links yet.</li>';echo '</ul></section>';
  echo '<section class="card" id="ds-sm-alerts"><h2>Changes awaiting review</h2><div class="ds-sm-scroll"><table class="widefat striped"><thead><tr><th>Product / supplier</th><th>Change</th><th>Previous → observed</th><th>Action</th></tr></thead><tbody>';
  foreach($events as $event){$display=$event->observed_value;if($event->kind==='size_option_missing')$display='Supplier size absent from description and order controls in 2 scans. Review before hiding.';if($event->kind==='color_image_missing'){$detail=json_decode($event->expected_value,true);$display='Supplier image absent in 2 scans; colour '.($detail['color']??'unknown').'. Review before hiding.';}if($event->kind==='price_review'){$proposal=json_decode($display,true);$q=$proposal['quote']??[];$display=is_array($proposal)&&!empty($q['ok'])?'Suggested regular price: ৳'.$proposal['price'].'; wholesale ৳'.$proposal['cost'].'; regular profit ৳'.$q['regular_profit'].'; discounted profit ৳'.$q['promotion_profit'].'; highest customer total ৳'.$q['customer_total'].' / cap ৳'.$q['customer_cap']: $display;}
   $source=Dreminex_Supplier_Nexus::canonical_supplier_url($event->evidence_url);echo '<tr><td><a href="'.esc_url(get_edit_post_link($event->product_id)).'">#'.(int)$event->product_id.'</a> '.esc_html($event->supplier).'<br>'.($source?'<a href="'.esc_url($source).'" target="_blank" rel="noopener noreferrer">Source ↗</a>':'<em>Supplier URL needs remapping</em>').'</td><td>'.esc_html($event->kind).' '.($event->variation_id?'#'.(int)$event->variation_id:'').'<br><small>'.esc_html($event->observed_at).' UTC</small></td><td>'.($event->kind==='color_image_missing'&&!empty($detail['image_id'])?wp_get_attachment_image((int)$detail['image_id'],[48,48],false,['style'=>'width:48px;height:48px;object-fit:cover;vertical-align:middle;margin-right:8px']):'').esc_html($event->previous_value).' → '.esc_html($display).'</td><td>';
   if(in_array($event->kind,['stock_review','price_review','color_image_missing','size_option_missing'],true))self::button($event->id,'approve',$event->kind==='color_image_missing'?'Hide colour (reversible)':($event->kind==='size_option_missing'?'Hide size (reversible)':($event->kind==='stock_review'?'Approve stock':'Approve price')),'#'.$event->product_id.' / #'.$event->variation_id.' · '.$event->supplier.' · '.$event->kind.' · '.$event->expected_value.' → '.$display.' — confirm this exact change?');
   self::button($event->id,'dismiss','Dismiss');echo '</td></tr>';
  }if(!$events)echo '<tr><td colspan="4">No pending alerts.</td></tr>';echo '</tbody></table></div></section>';
  if($on){$recent=$wpdb->get_results("SELECT * FROM {$table} WHERE state IN ('verified','failed','dismissed','superseded') ORDER BY id DESC LIMIT 30");
   echo '<section class="card"><h2>Recent decisions and audit</h2><div class="ds-sm-scroll"><table class="widefat striped"><thead><tr><th>Product / variant</th><th>Supplier / change</th><th>State</th><th>Readback / error</th></tr></thead><tbody>';
   foreach($recent as $e){echo '<tr><td>#'.(int)$e->product_id.' / #'.(int)$e->variation_id.'</td><td>'.esc_html($e->supplier.' · '.$e->kind).'</td><td>'.esc_html($e->state.' · '.$e->decided_at.' UTC').'</td><td>'.esc_html($e->readback_value).'</td></tr>';if(in_array($e->kind,['color_image_missing','size_option_missing'],true)&&$e->state==='verified'){echo '<tr><td colspan="4"><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="'.($e->kind==='color_image_missing'?'dreminex_sm_restore_color':'dreminex_sm_restore_size').'"><input type="hidden" name="event_id" value="'.(int)$e->id.'">';wp_nonce_field($e->kind==='color_image_missing'?'dreminex_sm_restore_color':'dreminex_sm_restore_size');submit_button($e->kind==='color_image_missing'?'Restore this colour':'Restore this size','secondary','submit',false);echo '</form></td></tr>';}}
   if(!$recent)echo '<tr><td colspan="4">No decisions yet.</td></tr>';
   echo '</tbody></table></div></section>';
  }
  echo '</div>';
 }
 private static function button($id,$decision,$label,$prompt='') {
  $confirmation=$prompt?' onsubmit="return confirm('.esc_attr(wp_json_encode($prompt)).')"':'';
  echo '<form method="post" style="display:inline-block;margin:2px"'.$confirmation.' action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_sm_decide"><input type="hidden" name="event_id" value="'.(int)$id.'"><input type="hidden" name="decision" value="'.esc_attr($decision).'">';wp_nonce_field('dreminex_sm_decide');submit_button($label,'secondary','submit',false);echo '</form>';
 }
}
function dreminex_supplier_monitor_page(){Dreminex_Supplier_Nexus::page();}
