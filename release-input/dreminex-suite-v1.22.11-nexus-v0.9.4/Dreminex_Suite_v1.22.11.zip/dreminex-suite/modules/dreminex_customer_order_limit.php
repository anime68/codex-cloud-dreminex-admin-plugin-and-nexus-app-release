<?php
if (!defined('ABSPATH')) { exit; }
/* Dreminex | Same-browser order policy (separate PHP Code Snippets entry).
 * Works across changed billing phone numbers in the same browser profile.
 * Cookie + localStorage can be erased; no website can guarantee a permanent
 * identity for a physical device without an external verified identity.
 */
function dreminex_device_storage_key() { return 'dreminex_device_token_'.substr(hash('sha256',home_url('/')),0,12); }
if ( ! function_exists( 'dreminex_device_token_valid' ) ) {
	function dreminex_device_token_valid( $token ) {
		if ( ! is_string( $token ) || ! preg_match( '/^([a-f0-9]{32})\.([a-f0-9]{64})$/D', $token, $parts ) ) return false;
		return hash_equals( hash_hmac( 'sha256', $parts[1], wp_salt( 'auth' ) ), $parts[2] );
	}
}
if ( ! function_exists( 'dreminex_device_token' ) ) {
	function dreminex_device_token() {
		$posted = isset( $_POST['dreminex_device_token'] ) ? sanitize_text_field( wp_unslash( $_POST['dreminex_device_token'] ) ) : '';
		if ( dreminex_device_token_valid( $posted ) ) return $posted;
		$key=dreminex_device_storage_key();
		$cookie = sanitize_text_field(wp_unslash($_COOKIE[$key] ?? $_COOKIE['dreminex_device_token'] ?? ''));
		return dreminex_device_token_valid( $cookie ) ? $cookie : '';
	}
}
add_action( 'init', function () {
	if ( is_admin() || dreminex_device_token() || headers_sent() ) return;
	$id = bin2hex( random_bytes( 16 ) );
	$token = $id . '.' . hash_hmac( 'sha256', $id, wp_salt( 'auth' ) );
	setcookie( dreminex_device_storage_key(), $token, array(
		'expires' => time() + YEAR_IN_SECONDS, 'path' => '/', 'secure' => is_ssl(),
		'httponly' => false, 'samesite' => 'Lax',
	) );
	$_COOKIE[ dreminex_device_storage_key() ] = $token;
}, 15 );

add_action( 'wp_footer', function () {
	if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page() ) return;
	$token = dreminex_device_token();
	if ( ! $token ) return;
	?>
	<script>
	(function(){
	 var form=document.querySelector('form.checkout');if(!form)return;
	 var current=<?php echo wp_json_encode( $token ); ?>;
	 var storageKey=<?php echo wp_json_encode(dreminex_device_storage_key()); ?>;
	 var prior='';
	 try{prior=localStorage.getItem(storageKey)||'';}catch(e){}
	 if(/^[a-f0-9]{32}\.[a-f0-9]{64}$/.test(prior))current=prior;
	 else try{localStorage.setItem(storageKey,current);}catch(e){}
	 var input=form.querySelector('input[name="dreminex_device_token"]');
	 if(!input){input=document.createElement('input');input.type='hidden';input.name='dreminex_device_token';form.appendChild(input);}
	 input.value=current;
	 document.cookie=storageKey+'='+current+'; path=/; max-age=31536000; SameSite=Lax'+(location.protocol==='https:'?'; Secure':'');
	})();
	</script>
	<?php
}, 5 );

if ( ! function_exists( 'dreminex_customer_order_limit_result' ) ) {
	function dreminex_customer_order_limit_result( $records, $now = null ) {
		$now = null === $now ? time() : (int) $now;
		$tz = new DateTimeZone(get_option('dreminex_suite_order_timezone',wp_timezone_string()));
		$today = ( new DateTimeImmutable( '@' . $now ) )->setTimezone( $tz )->format( 'Y-m-d' );
		$today_count = 0;
		$today_unfinished = 0;
		foreach ( $records as $record ) {
			$day = ( new DateTimeImmutable( '@' . (int) $record['created'] ) )->setTimezone( $tz )->format( 'Y-m-d' );
			$unfinished = 'completed' !== $record['status'];
			if ( $day < $today && $unfinished ) return 'previous_unfinished';
			if ( $day === $today ) {
				++$today_count;
				if ( $unfinished ) ++$today_unfinished;
			}
		}
			$limit=max(1,min(5,(int)Dreminex_Suite_Control::setting('checkout_protection','daily_limit',2)));
			return $today_count >= $limit && $today_unfinished ? 'today_unfinished' : '';
	}
}
if ( ! function_exists( 'dreminex_device_order_limit_check' ) ) {
	function dreminex_device_order_limit_check( $token ) {
		if ( ! dreminex_device_token_valid( $token ) ) return 'device_missing';
		$key = hash( 'sha256', $token );
		$args = array( 'type' => 'shop_order', 'limit' => -1, 'return' => 'ids' );
		if ( class_exists('\\Automattic\\WooCommerce\\Utilities\\OrderUtil') && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
			$args['meta_query'] = array( array( 'key' => '_dreminex_device_key', 'value' => $key ) );
		} else {
			$args['meta_key'] = '_dreminex_device_key';
			$args['meta_value'] = $key;
		}
		$records = array();
		foreach ( wc_get_orders( $args ) as $id ) {
			$order = wc_get_order( $id );
			if ( ! $order instanceof WC_Order || 'shop_order' !== $order->get_type() ) continue;
			$date = $order->get_date_created();
			if ( $date ) $records[] = array( 'created' => $date->getTimestamp(), 'status' => $order->get_status() );
		}
		return dreminex_customer_order_limit_result( $records );
	}
}
add_action( 'woocommerce_after_checkout_validation', function ( $data, $errors ) {
	// Check even when another validation (including the IP cooldown) already failed.
	// WooCommerce can then return both reasons in its checkout error response.
	$reason = dreminex_device_order_limit_check( dreminex_device_token() );
	if ( 'device_missing' === $reason ) {
			$errors->add( 'dreminex_device_missing', Dreminex_Suite_Control::message( 'checkout_protection', 'msg_device_missing', Dreminex_Suite_Control::tr("This browser could not be verified. Enable cookies, reload this page and try placing your order.", 'ডিভাইস যাচাই করা যাচ্ছে না। এই ব্রাউজারে cookies চালু রেখে পেজটি আবার খুলুন, তারপর অর্ডার দিন।') ) );
	} elseif ( 'previous_unfinished' === $reason ) {
			$errors->add( 'dreminex_previous_order_unfinished', Dreminex_Suite_Control::message( 'checkout_protection', 'msg_previous_unfinished', Dreminex_Suite_Control::tr("An order from a previous day in this browser is still not Completed. Wait until it is completed, or contact us to check its status.", 'এই ডিভাইস থেকে আগের দিনের একটি অর্ডার এখনো Completed হয়নি। সেটি সম্পন্ন হলে নতুন অর্ডার দিন। অর্ডারের অবস্থা জানতে আমাদের সঙ্গে যোগাযোগ করুন।') ) );
	} elseif ( 'today_unfinished' === $reason ) {
			$errors->add( 'dreminex_today_order_limit', Dreminex_Suite_Control::message( 'checkout_protection', 'msg_today_unfinished', Dreminex_Suite_Control::tr("This browser reached its daily order threshold while an earlier order is unfinished. Wait until the earlier orders are completed, or contact us for help.", 'আজ এই browser-এর order limit পূর্ণ হয়েছে এবং আগের একটি order এখনো Completed হয়নি। সেটি সম্পন্ন হলে আবার order দিন অথবা সহায়তার জন্য যোগাযোগ করুন।') ) );
	}
}, 50, 2 );
add_action( 'woocommerce_checkout_create_order', function ( $order ) {
	$token = dreminex_device_token();
	if ( $order instanceof WC_Order && dreminex_device_token_valid( $token ) ) {
		$order->update_meta_data( '_dreminex_device_key', hash( 'sha256', $token ) );
	}
}, 20 );
