<?php
if(!defined('ABSPATH'))exit;
/** Suite-native view over WooCommerce email settings; preserves every unrelated option. */
final class Dreminex_Suite_Email_Branding {
 public static function boot(){
  add_action('dreminex_suite_module_panel',[__CLASS__,'panel'],8);
  add_action('admin_post_dreminex_suite_email_branding',[__CLASS__,'save']);
  add_action('admin_enqueue_scripts',[__CLASS__,'assets']);
 }
 public static function assets($hook){if(strpos((string)$hook,'dreminex-suite')===false)return;wp_enqueue_media();}
 private static function color($name,$default){$v=sanitize_hex_color(get_option($name,$default));return $v?:$default;}
 public static function panel($key){if($key!=='store_email_branding')return;
  if(!class_exists('WooCommerce')){echo '<div class="notice notice-error"><p>WooCommerce is required.</p></div>';return;}
  $logo=(string)get_option('woocommerce_email_header_image','');$logo_id=absint(get_option('dreminex_suite_email_logo_id',0));
  $logo_url=$logo_id?wp_get_attachment_image_url($logo_id,'full'):$logo;
  $accent=Dreminex_Suite_Setup::accent();
  $fields=[
   'woocommerce_email_from_name'=>['Email sender name','text',get_option('woocommerce_email_from_name',Dreminex_Suite_Setup::brand())],
   'woocommerce_email_from_address'=>['Email sender address','email',get_option('woocommerce_email_from_address',get_option('admin_email'))],
   'woocommerce_email_base_color'=>['Accent color',$accent,self::color('woocommerce_email_base_color',$accent)],
   'woocommerce_email_background_color'=>['Email background','#f7f7f7',self::color('woocommerce_email_background_color','#f7f7f7')],
   'woocommerce_email_body_background_color'=>['Email content background','#ffffff',self::color('woocommerce_email_body_background_color','#ffffff')],
   'woocommerce_email_text_color'=>['Email text color','#3c3c3c',self::color('woocommerce_email_text_color','#3c3c3c')],
  ];
  echo '<section class="ds-email-settings"><h3>WooCommerce email branding and delivery</h3><p>This module edits WooCommerce’s own email options. Existing email templates remain intact. Updates keep these values. Use WooCommerce’s native preview to inspect each email before sending real customer messages.</p>';
  if(isset($_GET['email_saved']))echo '<div class="notice notice-success inline"><p>WooCommerce email settings saved.</p></div>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="dreminex_suite_email_branding">';wp_nonce_field('dreminex_suite_email_branding');
  echo '<input type="hidden" id="ds-email-logo-id" name="email_logo_id" value="'.esc_attr($logo_id).'">';
  echo '<p><strong>Customer email logo</strong><br><img id="ds-email-logo-preview" src="'.esc_url($logo_url?:'').'" style="max-width:220px;max-height:90px;'.($logo_url?'':'display:none;').'" alt="Email logo preview"><br><button type="button" class="button" id="ds-email-logo-select">Choose logo</button> <button type="button" class="button" id="ds-email-logo-clear">Remove logo</button></p>';
  foreach($fields as $name=>$f){$type=$name==='woocommerce_email_from_name'?'text':($name==='woocommerce_email_from_address'?'email':'color');echo '<p><label><strong>'.esc_html($f[0]).'</strong><br><input class="'.($type==='color'?'':'regular-text').'" type="'.esc_attr($type).'" name="'.esc_attr($name).'" value="'.esc_attr($f[2]).'" required></label></p>';}
  echo '<p><label><strong>Footer text</strong><br><textarea class="large-text" rows="3" name="woocommerce_email_footer_text">'.esc_textarea((string)get_option('woocommerce_email_footer_text','')).'</textarea></label></p>';
  echo '<h4>WooCommerce email notifications</h4><p class="description">Each toggle preserves the individual email’s other settings. Some email types only send to admins or customers at their matching order events.</p>';
  $emails=WC()->mailer()->get_emails();$toggles=[];foreach($emails as $email){if(empty($email->id))continue;$id=sanitize_key($email->id);$option='woocommerce_'.$id.'_settings';$settings=(array)get_option($option,[]);$toggles[$id]=['label'=>wp_strip_all_tags($email->get_title()),'enabled'=>($settings['enabled']??'yes')==='yes'];}
  if($toggles){echo '<div class="ds-email-toggle-grid">';foreach($toggles as $id=>$info)echo '<label><input type="checkbox" name="email_enabled['.esc_attr($id).']" value="1" '.checked($info['enabled'],true,false).'> '.esc_html($info['label']).'</label>';echo '</div>';}
  submit_button('Save email branding');echo '</form>';
  echo '<h4>Preview and detailed templates</h4><p><a class="button" href="'.esc_url(admin_url('admin.php?page=wc-settings&tab=email')).'">Open WooCommerce email settings and preview</a></p><p class="description">Logo, colors, sender details and email on/off controls are available here. The full WooCommerce template preview and per-email subject/heading/content editor stays in WooCommerce because its email improvements and third-party customizers may add fields that vary by site.</p>';
  echo '<script>(function(){var pick=document.getElementById("ds-email-logo-select"),clear=document.getElementById("ds-email-logo-clear"),input=document.getElementById("ds-email-logo-id"),img=document.getElementById("ds-email-logo-preview");if(pick){pick.addEventListener("click",function(){if(!window.wp||!wp.media)return;var frame=wp.media({title:"Select the email logo",button:{text:"Use this logo"},multiple:false,library:{type:"image"}});frame.on("select",function(){var a=frame.state().get("selection").first().toJSON();input.value=a.id;img.src=a.url;img.style.display="inline-block";});frame.open();});}if(clear)clear.addEventListener("click",function(){input.value="0";img.src="";img.style.display="none";});})();</script></section>';
 }
 public static function save(){
  if(!current_user_can('manage_options'))wp_die('Access denied.',403);check_admin_referer('dreminex_suite_email_branding');
  if(!class_exists('WooCommerce'))wp_die('WooCommerce is required.',400);
  $id=absint(wp_unslash($_POST['email_logo_id']??0));$url='';if($id){$mime=get_post_mime_type($id);$src=wp_get_attachment_image_src($id,'full');if(!$src||!str_starts_with((string)$mime,'image/'))wp_die('Choose a valid image attachment.',400);$url=esc_url_raw($src[0]);}
  $map=['woocommerce_email_from_name'=>'text','woocommerce_email_from_address'=>'email','woocommerce_email_base_color'=>'color','woocommerce_email_background_color'=>'color','woocommerce_email_body_background_color'=>'color','woocommerce_email_text_color'=>'color'];
  foreach($map as $name=>$type){$value=wp_unslash($_POST[$name]??'');if($type==='email'){$value=sanitize_email($value);if(!is_email($value))wp_die('Enter a valid sender email.',400);}elseif($type==='color'){$value=sanitize_hex_color($value);if(!$value)wp_die('Choose a valid email color.',400);}else{$value=sanitize_text_field($value);if($value==='')wp_die('Sender name cannot be empty.',400);}update_option($name,$value,false);}
  $footer=sanitize_textarea_field(wp_unslash($_POST['woocommerce_email_footer_text']??''));update_option('woocommerce_email_footer_text',$footer,false);
  update_option('woocommerce_email_header_image',$url,false);update_option('dreminex_suite_email_logo_id',$id,false);
  $allowed=[];foreach(WC()->mailer()->get_emails() as $email)if(!empty($email->id))$allowed[sanitize_key($email->id)]='woocommerce_'.sanitize_key($email->id).'_settings';
  $requested=is_array($_POST['email_enabled']??null)?array_map('sanitize_key',array_keys(wp_unslash($_POST['email_enabled']))):[];
  foreach($allowed as $id=>$option){$settings=(array)get_option($option,[]);$settings['enabled']=in_array($id,$requested,true)?'yes':'no';update_option($option,$settings,false);}
  Dreminex_Suite_Cache::changed('all',true);wp_safe_redirect(admin_url('admin.php?page=dreminex-suite&module=store_email_branding&email_saved=1'));exit;
 }
}
Dreminex_Suite_Email_Branding::boot();
