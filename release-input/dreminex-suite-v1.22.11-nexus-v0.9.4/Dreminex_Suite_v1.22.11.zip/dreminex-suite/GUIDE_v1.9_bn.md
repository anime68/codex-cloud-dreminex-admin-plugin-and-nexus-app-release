# Dreminex Suite 1.9.1 — সেটআপ ও আপডেট গাইড

## 1.9.1 reliability fixes

- Interrupted payment/authentication requests no longer leave a permanent lock. A stale lock can be reclaimed after five minutes; payment attempts still require provider verification and are never retried as a new charge.
- Order emails keep the original wallet-provider label and order currency after wallet settings change. Existing 1.8 orders without a saved receiver number do not display a guessed current number.
- A staging/development/local WordPress environment can use authenticated sandbox profiles for checkout-route tests. Production accepts only authenticated live profiles. Environment-mismatched profiles are blocked before API requests, even when a token is cached; use sandbox credentials only on non-production.
- No database schema or reset behavior changed in 1.9.1.

## এই রিলিজে কী বদলেছে

- Newsletter ও Offers একই module-এর পৃথক feature switch। Module master switch-ও আলাদা। Newsletter Off হলেও Offers On থাকলে active offer ও offer claim-এর email verification চলবে; newsletter subscription consent লাগবে না। Offers On কিন্তু কোনো active offer না থাকলে offer card/verification prompt দেখাবে না। Expired বা used coupon আর outstanding offer হিসেবে দেখানো হবে না।
- Elementor text widget, সাধারণ widget এবং supported content area-তে Suite shortcode execute করার ব্যবস্থা যোগ হয়েছে; disabled shortcode literal হিসেবে দেখা যাওয়ার ঝুঁকি কমানো হয়েছে। কোনো offer/newsletter কনটেন্ট না থাকলে empty auto-placement সরানো হয়।
- Newsletter/Offers/Contact/Partial Checkout-এর ডুপ্লিকেট left-menu item লুকানো হয়। Records page module-এর “Manage records” link দিয়ে খোলা যাবে।
- Module dashboard-এ category grouping, On/Off state badge এবং responsive card layout যোগ হয়েছে।
- Import form-এর ZIP extension, package limits, PHP syntax/security pattern ফলাফল আলাদা notice হিসেবে দেখায়। Imported PHP trusted code হিসেবেই চলবে—static validation নিরাপত্তার নিশ্চয়তা নয়।
- Delivery advance-এ bKash, Nagad, Rocket ও Upay-এর জন্য পৃথক receiver number, Personal/Merchant account type এবং per-provider enable switch আছে। খালি বা invalid number checkout-এ দেখানো হয় না।
- Registration settings-এ WooCommerce registration form on/off এবং customer-selected password confirmation আছে। First/last name ও Bangladesh mobile field-ও registration module-এর অধীনে। Password hashing/reset WooCommerce/WordPress core করে।
- Store Email Branding module WooCommerce-এর native email logo, sender, color, footer ও notification switches নিয়ন্ত্রণ করে। Template এবং preview WooCommerce-এর নিজস্ব email editor-এ থাকে।
- Courier Tracking tab-এ Pathao ও Steadfast credential profile encrypted করে রাখা, enable/disable/delete করা যায়। **এটি credential storage; courier API authentication, consignment booking বা live tracking adapter এই build-এ সম্পন্ন নয়।** Official API specification, merchant test account ও endpoint contract ছাড়া কোনো guessed URL-এ request পাঠানো হয় না। Manual tracking number এখনও ব্যবহার করা যায়।
- Module backup-এ store email branding options এবং courier profile metadata থাকে; credential blob export-এ বাদ/লুকানো হয়।
- Existing plugin settings/data রেখে schema upgrades additive রাখা হয়েছে। Existing module On/Off values, feature choices, imported module settings/data, orders, pages, users, coupons, payment evidence বা connections upgrade-এ ইচ্ছাকৃতভাবে delete/reset করা হয় না।

## ইনস্টল/আপডেট — live site-এ এখনই নয়

এই ZIP স্থানীয়ভাবে প্রস্তুত। এই কাজ live site-এ প্রয়োগ করা হয়নি। আগে staging/test WordPress + WooCommerce site-এ পরীক্ষা করুন।

1. Hosting/database এবং `wp-content/plugins/dreminex-suite`-এর backup নিন।
2. WordPress → Plugins → Add Plugin → Upload Plugin থেকে ZIP দিন। WordPress যদি “Replace current with uploaded” দেখায়, সেটি বেছে নিন। **পুরোনো plugin আগে Delete/Uninstall করবেন না**; uninstall করলে saved option/data নষ্ট হওয়ার ঝুঁকি থাকে।
3. Plugin slug/folder `dreminex-suite` অপরিবর্তিত রাখুন। Plugin deactivate করা বাধ্যতামূলক নয়; একই plugin replace/update করুন।
4. Dashboard → Dreminex Suite → Overview খুলে plugin version, Site Health, module On/Off এবং load error দেখুন। Upgrade history/schema version যাচাই করুন।
5. পুরোনো feature behavior আলাদা করে পরীক্ষা করুন; optional নতুন modules default Off থাকবে। New module চালু করলে কেবল সেই module-এর প্রয়োজনীয় setup পূরণ করুন।
6. কোনো ত্রুটি হলে hosting backup থেকে পূর্ববর্তী ZIP ফিরিয়ে দিন। Module data fresh reset ব্যবহার করবেন না।

## Newsletter এবং Offers

Dreminex Suite → Newsletter and offers tab-এ যান:

- প্রথমে module master switch On করুন।
- `Newsletter signup` ও `Promotional offers` আলাদাভাবে On/Off করে Save করুন। দুইটি switch default Off।
- Newsletter On করলে subscribe form, consent ও newsletter confirmation email কাজ করে।
- Offers On করলে শুধু Published/active ও date-valid offer দেখায়। Active offer না থাকলে block দেখায় না।
- Account email যাচাই ছাড়া offer claim করা যায় না। Offer-এর email verification newsletter subscribe করে না।
- নতুন offer থাকলে আগের unused/unexpired claim-ও দেখানোর কথা; coupon used/expired হলে তা আর active তালিকায় থাকে না।
- Automatic placement প্রয়োজন হলে Module control centre-এ newsletter automatic placement On রাখুন। Theme footer-এ shortcodes থাকলে builder/widget rendering পরীক্ষা করুন। Cache plugin/CDN-এ logged-in/personalized account/checkout content cache করবেন না।
- Live mail-এর আগে disposable account-এ newsletter confirm, offer verify, claim, resend, used এবং expiry flow পরীক্ষা করুন।

## এক জায়গা থেকে module control

- **Dreminex Suite:** প্রতিটি built-in module-এর Overview ও আলাদা tab; master On/Off, setup এবং troubleshooting।
- **Module control centre:** placement, checkout route, module links, page setup এবং module inventory।
- **Site Health:** উপলব্ধ WP/plugin/theme/runtime/cron/SSL check। Finding-এর পাশে fix ও dismiss আছে।
- **Store setup:** brand name, support email, accent, assigned pages ও onboarding guidance।
- **Backup & module data:** module নির্বাচন করে backup/reset। আগে backup নিন এবং reset confirmation পড়ুন। Orders/users/pages/products বা payment audit অকারণে reset হয় না।
- **Imported modules:** trusted ZIP import, default Off, settings, On/Off, package remove; imported module-এর নিজস্ব dashboard link।
- **Cache Management:** automatic Suite display-cache invalidation ও manual module/all refresh। এটি full-site/object/CDN cache flush নয়। LiteSpeed adapter না থাকলে host/CDN cache আলাদাভাবে purge করতে হবে। Security lock, order বা customer record cache reset-এ মুছে যায় না।

## Wallet ও checkout route

Delivery advance tab-এ provider অনুযায়ী receiver নম্বর, account type এবং enable switch save করুন। Checkout-এ শুধু configured provider দেখাবে। Customer provider বেছে TXID জমা দেবে; TXID একা payment proof নয়—Dashboard/merchant account-এ মিলিয়ে তারপর manually verified করুন। Customer পণ্যের বাকি মূল্য delivery-তে দেবে। Manual wallet advance BDT ও valid shipping charge-এর জন্য।

Production-এ Mobile Payment route কেবল enabled + configured + authenticated live provider connection থাকলে API route হয়; staging/development/local environment-এ authenticated sandbox profile ব্যবহার করা যায়। WordPress environment-এর সঙ্গে profile না মিললে token cache থাকলেও API request বা checkout হবে না। API route active হলে Delivery advance-এর manual wallet/TXID field লুকানো হয়। API connection ready না হলে configured Delivery advance module থাকলে সেটি fallback হয়। Staging checkout test-এ sandbox merchant credentials ব্যবহার করুন; production credentials staging-এ কপি করবেন না।

## Registration ও WooCommerce email

- Registration email module On হলে Suite settings থেকে My Account registration switch এবং customer password choice/confirmation নিয়ন্ত্রণ করা যায়। Email, first name, last name, mobile number ও password field standard Woo registration-এর সঙ্গে কাজ করে।
- Registration email confirmation, lost-password flow এবং password reset link disposable account-এ পরীক্ষা করুন। Password/plain-text credential plugin backup-এ রাখা হয় না।
- Store email branding module On করে media library থেকে logo, sender name/email, accent/background/text colors, footer এবং notification switches নিয়ন্ত্রণ করুন। WooCommerce → Settings → Emails preview-এ customer/admin email আলাদাভাবে দেখুন। SMTP delivery provider আলাদাভাবে configured থাকতে হবে।

## Courier tracking/API credentials

Pathao/Steadfast account key ওই tab-এ encrypted ভাবে save হয়; value পরে blank দেখা স্বাভাবিক। Save করার সময় profile enable/disable হয়; delete করলে সেই profile/key মুছে যায়। **Enabled status মানে connected/authenticated নয়।** এই build automated courier API call বা tracking status sync করে না; order-এ courier ও tracking/consignment number manually দিন। API adapter implement করতে merchant-এর official current API docs, sandbox credentials এবং callback/webhook contract লাগবে। কোনো real secret support chat বা ZIP-এ পাঠাবেন না।

## Backup, updates ও compatibility

- Upgrade data-কে plugin code থেকে আলাদা WordPress options/tables/orders-এ রাখে; version/schema history লেখে, settings overwrite করে না। ZIP replacement একই plugin identity-তে করুন; delete/uninstall করে fresh install করবেন না।
- Backups password, reset/confirmation tokens এবং secret/API credentials export করে না। Courier credential vault WordPress installation-এর secret salt-নির্ভর; salt বদলালে saved ciphertext পড়া নাও যেতে পারে।
- Modules WooCommerce APIs/hooks ব্যবহার করে, তবে checkout blocks, custom theme/builder, cache/CDN, third-party email/checkout/courier plugin-এ আচরণ আলাদা হতে পারে। Checkout-dependent modules-এর জন্য classic Woo checkout bridge আছে; live order দিয়ে না, staging order দিয়ে যাচাই করুন।
- PHP minimum 8.0। WooCommerce আবশ্যক। “যে কোনো site-এ নিশ্চয়ই কাজ করবে” বলা সম্ভব নয়—site-এর PHP, WooCommerce version, hosting extensions, custom checkout/theme এবং security policy test করা প্রয়োজন।
- এই package-এ স্বয়ংক্রিয় license/update server নেই। নতুন ZIP manually upload/replace করতে হবে।

## Site Health-এর সীমা

Site Health installed plugin inventory, updates, Suite loader errors, selected PHP patterns, WP-Cron, HTTPS, debug display ও disk space-এর মতো উপলভ্য বিষয় পরীক্ষা করে। এটি antivirus, vulnerability intelligence বা full code audit নয়; কোনো malicious plugin-এর execution নির্ভুলভাবে block করার নিশ্চয়তা দেয় না। Hosting malware scanner, WordPress security service এবং verified plugin sources ব্যবহার করুন। False-positive পেলে live install block হওয়ার আগে staging-এ review করুন.

## Import module test (Stock Watch & Reorder)

Separate working add-on ZIP `Dreminex_Stock_Watch_Module_v1.0.0.zip`:

1. Suite → Imported modules → ZIP import-এ file দিন এবং source trust confirm করুন। Import সম্পন্ন হলে module Off থাকবে।
2. Manifest/settings review করুন; low-stock threshold, target quantity, variations ও page-size ঠিক করুন।
3. Test/staging-এ PHP package trusted হলে enable confirmation দিন।
4. Stock Watch dashboard থেকে All attention/Low stock/Out of stock/Backorders filter এবং CSV export পরীক্ষা করুন। Suggested restock কেবল হিসাব—এটি stock বা supplier order পরিবর্তন করে না।
5. Disable/remove package করার সময় module data option আলাদা থাকে; data মুছতে Backup & module data-এর scoped controls ব্যবহার করুন।

## English / বাংলা + English style

Dreminex Suite → Settings থেকে English বা বাংলা + English style বাছুন। English default। বর্তমানে language style setting-এর translation-helper ব্যবহার করা labels/messages বদলায়; WordPress/WooCommerce নিজস্ব text, merchant-entered offer/coupon content, courier response, এবং সব legacy static text স্বয়ংক্রিয়ভাবে অনুবাদ হয় না। তাই বাংলা + English string এখনও অন্য plugin/module-এর কিছু screen-এ থাকতে পারে। পুরো plugin-এর zero-Bangla guarantee করার আগে per-screen translation audit ও native localization pass দরকার।

## Staging test checklist

- Plugin activates/deactivates without PHP fatal; Dashboard overview, module tabs, Site Health, imported module manager open হয়।
- Update/replace-এর পর module states, `_features`, settings, imported package/settings, Newsletter records, coupon claims, order statuses/meta এবং pages অক্ষত থাকে।
- Newsletter Off / Offers On / no active offer; Offers On / active offer / logged out; logged in unverified; verified claim; previous unused claim; used/expired claim—সব আলাদা করে পরীক্ষা করুন।
- Builder footer-এ newsletter shortcodes raw text হয় না; empty offer-only block output হয় না; theme placement থাকলে duplicate footer section হয় না।
- bKash/Nagad/Rocket/Upay receiver setup; checkout selection/TXID validation; zero shipping; BDT only; API ready versus manual fallback.
- Registration fields/password confirmation/email confirmation and lost-password reset.
- WooCommerce email logo/color/each notification toggle and SMTP delivery.
- Courier manual reference remains; encrypted profile save/disable/delete; recognize that there is no live API call.
- Imported Stock Watch install/settings/on-off/dashboard/CSV and remove.
- Fresh backups download; data reset options are scoped and never run without your intentional confirmation.

## Known open items before commercial/public release

1. Pathao and Steadfast live API adapters/auth tests/status webhooks are not implemented in this package.
2. Full English-only coverage across every legacy module/admin/customer message needs a string-by-string translation audit.
3. No hosted licensing/update service; manual update is the only release flow.
4. PHP CLI was unavailable in the build environment; final ZIP must be PHP-linted and runtime-tested on staging with the target hosting stack before production.
5. Security scan checks are deliberately limited; they cannot promise to block every malicious package.
