# Dreminex Nexus Five-Site System — A to Z Handoff, Review ও Update Workflow

App: Dreminex Nexus 0.2.0 · Package `com.dreminex.nexus`  
এই file পাঁচটি website connection এবং তাদের সম্পূর্ণ isolation-এর source of truth। পরে connection, storage, worker, login, queue বা site UI update করলে এই file, Nexus মূল reference, integration contract, tests, APK/source ZIP এবং SHA-256 update করতে হবে।

## মূল নিয়ম

- App-এ সর্বোচ্চ ৫টি connected WordPress website থাকবে। Limit UI এবং encrypted store দুই জায়গায় enforce হয়।
- Duplicate site URL বা server site ID নতুন connection তৈরি করে না; existing row replace/select হয়।
- Active site বদলালে Home, Platforms, Activity, Settings, API call এবং manual worker ওই site-এ বদলায়।
- এক site-এর token, supplier account, cookie, cached platform, network setting, schedule, notification বা pending result অন্য site ব্যবহার করতে পারবে না।

## Data map

| Data | Isolation key |
|---|---|
| Connection/token/device key | server `siteId` |
| Supplier credential/cookie | `siteId + platformId` |
| Cached platform response | `siteId` |
| Auto scan/network mode | `siteId` |
| Room pending observation | composite `siteId + jobId` |
| Periodic WorkManager job | hashed `siteId` |
| Token refresh lock | `siteId` |

Encrypted values Android Keystore AES-GCM storage-এ থাকে। Preference key-তে raw credential/token থাকে না। Site ID এবং platform ID hash করে storage key তৈরি হয়।

## Upgrade migration

0.1.0-এর single `connection`, global supplier sessions, platform cache এবং settings প্রথম app start-এ 0.2.0-এর প্রথম site-এর নিচে যায়। Migration marker থাকার কারণে এটি একবারই চলে। Room version 1-এর job-ID-only table version 2-এ `siteId + jobId` composite primary key পায় এবং existing rows current legacy site-এর নিচে copy হয়। Destructive fallback ব্যবহার করা যাবে না।

## API ও worker flow

`NexusApi`-এর প্রতিটি authorized call explicit `siteId` নেয়। Expired token refresh ওই site-এর Mutex-এর ভিতরে rotate ও save হয়। `NexusApplication` প্রতিটি enabled site-এর জন্য আলাদা periodic work schedule করে; input data-তে exact site ID থাকে। Manual run-ও selected site ID দিয়ে one-time work দেয়। Worker selected site-এর settings, queue এবং pending rows ছাড়া কিছু পড়ে না।

Site disconnect করলে ওই site-এর WorkManager job cancel, Room rows delete এবং encrypted sessions/cache/settings remove হয়। Connection list-এ অন্য site থাকলে প্রথম remaining site active হয়।

## Supplier login isolation

Scanner `siteId + platformId` session নেয়। Valid cookie থাকলে আগে product page দেখে; login page এলেই bounded login চেষ্টা করে। WebView login শুরু করার আগে shared cookie jar clear, selected site-এর encrypted cookies exact allowlisted domains-এ restore, সফল login-এর cookies selected site-এ capture এবং Activity finish-এর আগে shared jar আবার clear হয়। অন্য domain navigation block থাকে।

## UI ও branding

- Top bar site switcher-এ connected-site count এবং সব site থাকে।
- Sites screen ১–৫ site, active marker, switch এবং Add Site দেখায়। ষষ্ঠ site button disabled এবং clear message দেয়।
- Pairing screen স্পষ্টভাবে বলে data site অনুযায়ী separate।
- Settings selected site-এর auto scan/network বদলায়; disconnect-এর আগে confirmation আসে।
- Supplier-provided logo-এর DN mark adaptive, round, legacy launcher এবং top-bar icon; full logo splash/pairing/About-এ থাকে। Original logo file থেকে generated assets update করলে crop/safe-zone visual check দিতে হবে।

## Test gate

1. পুরোনো single-site data/token/session/settings migration।
2. পাঁচটি আলাদা site add; ষষ্ঠ reject; duplicate URL replace/select।
3. Site switch-এর পরে endpoint, UI data এবং manual worker target ঠিক।
4. দুই site একসঙ্গে token refresh করলেও token overwrite নয়।
5. একই platform ID দুই site-এ আলাদা credentials/cookies রাখে।
6. WebView login শেষে cookie jar clear এবং অন্য site-এ cookie leak নেই।
7. Room pending rows একই job ID হলেও site অনুযায়ী আলাদা; শুধু targeted site flush।
8. Periodic worker enable/disable ও required network site অনুযায়ী আলাদা।
9. Disconnect শুধু selected site-এর local data/worker/queue মুছে।
10. Android restart-এর পরে active site এবং পাঁচ connection ঠিক থাকে।
11. Unit tests, debug/release build, APK signature/readback এবং physical-phone built-in/custom scan।

Signing key source ZIP-এ রাখা যাবে না। নতুন signing certificate দিয়ে বানানো test APK পুরোনো অন্য-certificate APK-এর উপর install হবে না; release ownership-এর স্থায়ী private signing key আলাদাভাবে সংরক্ষণ করতে হবে।
