# Dreminex Suite 1.13.0 — AI Product Publisher

## ইনস্টল ও চালু

বিদ্যমান Suite প্লাগইন আপডেট করার আগে staging-এর ব্যাকআপ রাখুন। **Plugins → Add New → Upload Plugin** থেকে `Dreminex_Suite_Plugin_v1.13.0.zip` আপলোড করে বিদ্যমান Suite আপডেট করুন; পুরোনো Suite আনইনস্টল করবেন না। নতুন `AI Product Publisher` মডিউলটি শুরুতে Off থাকে। পুরোনো standalone `Dreminex AI Product Publisher` সক্রিয় থাকলে প্রথমে সেটি deactivate করুন, তারপর **Dreminex Suite → All Modules → AI Product Publisher → On** করুন। পুরোনো standalone মুছে ফেললে তার আলাদা কোড হারাবেন, তবে তৈরি প্রোডাক্ট/মিডিয়া থাকে; সেজন্য deactivate করাই যথেষ্ট।

**Dreminex Suite → Dashboard → AI Product Publisher** প্যানেলে color ও size taxonomy, image size limit, SKU prefix/auto SKU, missing stock audit, global term creation, verified image-label brand preference এবং filename–color matching নিয়ন্ত্রণ করুন। Save করার পর Novamira OAuth সংযোগে `dreminex-products/catalog`, `media-import`, `draft-create`, `variations-upsert`, `colors-reconcile`, `product-read`, `draft-brand-set`, `draft-inventory-set`, `draft-audit`, `workflow-guide` এবিলিটি পাওয়া যায়। `workflow-guide`-এ `publishing` বা `media-brand` নাম দিন। ChatGPT-এর কাছে ওই সংযুক্ত Novamira অ্যাপ ব্যবহার করে পণ্যের তথ্য, ছবি ও নির্দেশনা দিন।

## SKU, স্টক, ব্র্যান্ড

- `draft-create`-এ `sku` এবং সাধারণ পণ্যের জন্য `stock_quantity` দেওয়া যায়। ভেরিয়েবল পণ্যের প্রত্যেক `variants` সারিতে আলাদা `sku` ও `stock_quantity` দিন। পরিমাণ না দিলে স্টক অনুমান করা হয় না। ০ দিলে out of stock, ধনাত্মক হলে in stock; backorders বন্ধ। বিদ্যমান SKU অন্য পণ্যে থাকলে অনুরোধ বাতিল হয়।
- Auto SKU Off থাকলে খালি SKU খালিই থাকে। On করলে prefix-সহ স্থিতিশীল SKU তৈরি হয়। `draft-audit` খালি SKU ও চাইলে unmanaged variation stock দেখায়।
- ছবিতে ব্র্যান্ড লেবেল স্পষ্ট হলে ChatGPT `label_brand`, সেই ছবির `label_image_id`, `label_verified=true` পাঠায়। অনুপস্থিত `product_brand` term তৈরি করে Draft-এ বসানো হয়। বিদ্যমান Draft-এ `draft-brand-set` ব্যবহার করা যায়। অস্পষ্ট লেবেলে নাম অনুমান করা যাবে না। ছবির ব্র্যান্ড ও দেওয়া Brand ভিন্ন হলে প্রকাশের আগে মালিকানা নিশ্চিত করুন।
- ছবির নামের রঙ ও product image মিলিয়ে প্রতিটি variation তৈরি হয়; একই নামের global swatch-এর HEX ভিন্ন হলে আলাদা HEX-specific swatch হয়। সবশেষে `draft-audit` ও `product-read` দিয়ে যাচাই করুন।

এই Suite মডিউল নিজে থেকে Publish করে না। staging-এ যাচাই করে তারপর মূল সাইটে ZIP দিয়ে একইভাবে আপডেট করুন। Novamira OAuth মূল সাইটে আলাদাভাবে connected থাকতে হবে; staging সংযোগ নিজে থেকে মূল সাইটে যায় না। সাইটের বিদ্যমান brand taxonomy ও SEO ইন্টিগ্রেশন অনুযায়ী ফল যাচাই করুন।
