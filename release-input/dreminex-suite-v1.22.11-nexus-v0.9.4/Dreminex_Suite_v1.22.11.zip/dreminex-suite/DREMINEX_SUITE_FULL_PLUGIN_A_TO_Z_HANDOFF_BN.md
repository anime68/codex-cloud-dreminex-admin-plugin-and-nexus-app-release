# Dreminex Suite Full Plugin — A to Z Handoff, Review ও Update Workflow

## Plugin পরিচয়

- Package: dreminex-suite
- Release: 1.20.2
- Main file: dreminex-suite.php
- Requires: WordPress, PHP 8.0+ and WooCommerce
- Related app: Dreminex Nexus 0.7.1 / Android versionCode 8

## 1.20.2-এর package delivery

WordPress plugin ZIP-এ signed Android APK ও checksum থাকে, কারণ Android updater connected website-এর authenticated endpoint থেকে same-site APK নেয়। Windows `.exe` plugin ZIP বা এই release-এ রাখা হয় না। Repository private হওয়ায় manifest Windows version ও download URL ফাঁকা রাখে; এতে app কোনো 404 installer link দেখায় না। v1.20.1-এর পুরোনো local Windows installer manifest backward-compatible। আগে থেকে install করা Windows app-এর site pairing অক্ষত থাকে।

## 1.20.1-এর ownership ও পরিবর্তন

Nexus app এখন Contact Requests, Checkout Protection, Welcome Offers ও Orders পরিচালনা করে। Nexus Settings-এর app-module switch-গুলো Suite-এর module option এবং feature gate-এ লিখে; UI switch একা কাজের প্রমাণ নয়। App feature unavailable হলে server update প্রত্যাখ্যান করে এবং exact REST error ফেরত দেয়। Delivery Advance & Wallet WordPress এবং app—দুই জায়গা থেকেই পরিচালিত হয়।

Nexus-এ Preparation/Publisher source editor সরানো হয়েছে। বাইরের Preparation/Publisher MCP projects এখন আগের Native MCP workflow abilities ব্যবহার করবে। Product publication নিজে Native MCP ability-র মাধ্যমে চলে; Nexus project file কপি বা বদলায় না।

Native MCP v1.20.1 Suite-owned abilities default-on রাখে, তবে explicit off state, OAuth scope, WordPress capability ও approval policy মানে। App-managed modules শুধু unset থাকলে default-on হয়; explicit off অপরিবর্তিত থাকে। Legacy Code Snippets active থাকলে app সেটি দেখায় এবং matching source-ই migration করতে দেয়। Third-party/unknown providers remain opt-in. Media upload control JSON-RPC body-এর বাইরে resumable, bounded transfer ব্যবহার করে। App-এর private contact-evidence download site-authenticated, canonical private path-এ সীমাবদ্ধ এবং সর্বোচ্চ 10 MiB।

Security Center Suite-এর always-on shared protection service। Contact Requests form Mail Engine বন্ধ থাকলেও honeypot, form timing, link ও privacy-safe rate limit guard পায়; WordPress login failure-এ network-based temporary lock, optional XML-RPC block এবং safe response header আছে। Nexus-এর former Projects slot-এ Security tab থেকে protection check, blocked-attempt summary, recent event, controls, retention এবং আগের Action Center-এর operational summary দেখা যায়; queue card matching Operations/Product workspace-এ deep link করে। Notification schema 2 পুরোনো Action Center notices-কে Security-তে route করে, record delete করে না। Native MCP `dreminex-security/dashboard-read` read/update abilities explicit allowlist ও `settings:read/write` scope মেনে চলে। বিস্তারিত `SECURITY_CENTER_MODULE_A_TO_Z_HANDOFF_BN.md` ও `NEXUS_NOTIFICATIONS_SECURITY_CENTER_A_TO_Z_HANDOFF_BN.md`।

Release workflow signed Android APK ও checksum এবং `nexus-app-release.json` Suite plugin package-এ যুক্ত করে। Nexus connected site's authenticated app-release API থেকে manifest পড়ে এবং একই site host থেকে APK নেয়; private GitHub repository-তে app-side API call লাগে না। Windows installer distribution এই release-এ paused। Android installer-এর আগে SHA-256, package ID, increasing versionCode ও permanent certificate যাচাই হয়। FCM credential না থাকলে authenticated background sync fallback থাকে।

## Update review-এ অবশ্যই দেখবেন

- Existing OAuth clients/tokens, WooCommerce products/orders, customer Wallet ledger, supplier mappings এবং option values অক্ষত আছে।
- App feature switch underlying module status এবং access gate দুটোই বদলায়।
- Product and order writes current revision যাচাই করে; permanent deletes/critical transitions confirmation ছাড়া হয় না।
- Private evidence source file app-এর public Media URL নয়; download path authorization, size ও MIME boundary মেনে চলে।
- Android signer fingerprint unchanged, versionCode বৃদ্ধি পেয়েছে এবং test handset-এ install-over-existing data readback হয়েছে।
- Staging test ছাড়া release report-এ staging verification লেখা যাবে না; live WordPress-এ deploy এই source task-এর অংশ নয়।

## Architecture

Suite master catalog শুধু 16টি clear module দেখায়। Parent module component file প্রয়োজন হলে load করে। Disabled module-এর checkout/order hooks load হয় না। Existing settings, records, order/user metadata এবং encrypted credentials upgrade-এ থাকে। Dashboard, backup, health, source revision এবং cache management একই Suite UI-তে থাকে।

## Current visible modules

Payments: Delivery Advance & Wallet, including product-only COD. Checkout: Checkout Protection; Checkout Experience. Orders: Order Management. Marketing/Support: Flash Sale, Newsletter & Offers, Contact Requests. Operations: Supplier Monitor, Native MCP, AI Product Publisher. Nexus Security includes the former Action Center queue summary and deep links. Design/Account/Store: Storefront Design, Account Experience & Security, Store Email Branding, Advanced Optimizations.

Account Experience & Security-এর logged-out Registration/Login view Dreminex active palette অনুযায়ী responsive hero, account-benefit band, focused form cards, mobile registration-first order, password visibility/match feedback ও accessible result dialog দেয়। WooCommerce registration, privacy, password hashing, lost-password এবং saved customer data-ই source of truth থাকে।

## OAuth connection rule

Authorization server metadata-এর `issuer` এবং callback-এর `iss` exact same value হবে। Callback RFC 3986 query encoding ব্যবহার করবে এবং approve/deny দুই response-এই issuer থাকবে। Token/code/state log করা যাবে না; diagnostic log শুধু client hash, redirect host, issuer, outcome ও time রাখে।

## Mandatory update workflow

1. Current source, plugin version, schema এবং relevant module reference পড়তে হবে।
2. Production edit নয়; isolated source-এ change করতে হবে।
3. Existing settings/data migration আগে লিখতে হবে; destructive reset ব্যবহার করা যাবে না।
4. File, catalog, loader, source hash, backup spec, health check ও UI route একসাথে মিলাতে হবে।
5. PHP lint, focused tests, package structure, checksum এবং staging backup করতে হবে।
6. Staging update করে activation, schema, admin page, OAuth metadata/callback, relevant checkout/order flow এবং readback পরীক্ষা করতে হবে।
   Visual change থাকলে active Novamira design token পড়ে rendered page-এর desktop/mobile check ও design preflight করতে হবে।
7. Failure হলে previous ZIP দিয়ে rollback; production rollout user-এর আলাদা approval ছাড়া হবে না।
8. কাজ শেষে changed module reference, এই full plugin reference, changelog, test report, rollback note এবং GitHub organized release update করা বাধ্যতামূলক।

## Release package rule

ZIP root-এর ভিতরে একটিই `dreminex-suite/` folder থাকবে। Source ও install ZIP আলাদা থাকবে। SHA-256 file দিতে হবে। Secrets, keystore, OAuth token, customer export বা local cache package/repository-তে রাখা যাবে না।

## Acceptance gate

- PHP syntax clean
- schema migration repeat-safe
- all catalog files present এবং source hash current
- no duplicate consolidated hooks
- OAuth discovery issuer matches callback issuer
- Native MCP initialize/tools list succeeds with a test client
- APK package/signature/version update evidence (যদি Nexus release থাকে)
- staging active version/readback correct
- production untouched

