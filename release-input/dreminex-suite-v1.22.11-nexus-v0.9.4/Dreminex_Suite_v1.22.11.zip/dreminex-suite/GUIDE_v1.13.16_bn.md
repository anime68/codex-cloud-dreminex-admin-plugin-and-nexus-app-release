# Dreminex Suite 1.13.16 — Account dashboard

## কী বদলেছে

- লগইন করা My Account পেজে পরিচ্ছন্ন welcome panel, Orders, Addresses ও Account details shortcut দেখা যাবে। ফোনে menu দুই কলামে সাজানো, tablet ও desktop-এ account navigation ও content পাশাপাশি থাকে।
- `Dreminex Suite → All Modules → Accounts → Account experience & registration` থেকে **Use the Dreminex account dashboard** চালু/বন্ধ, dashboard heading ও description বদলানো যাবে। আগের registration ও confirmation email controls একই জায়গায় আছে।
- প্রতিটি shortcut সাইটের নিজস্ব WooCommerce endpoint ব্যবহার করে। গ্রাহকের order, address, password বা অন্য data পরিবর্তন করে না। অন্য extension-এর `woocommerce_account_dashboard` hook-ও চালু থাকে।

## Update

বর্তমান `dreminex-suite` plugin-এর উপর ZIP update দিন; আগে plugin delete করবেন না। Backup রাখুন। Module যদি on থাকে, নতুন dashboard default-এ চালু হবে। Media Library-র ছবি ও অন্য module settings site-specific; সেগুলি বদলায় না।

Staging-এ লগইন করা সাধারণ customer account দিয়ে Dashboard, Orders, Addresses, Account details ও Log out link দেখা এবং mobile/tablet/desktop মাপ যাচাই করুন। Production-এ update করার আগে একই পরীক্ষা করুন।
