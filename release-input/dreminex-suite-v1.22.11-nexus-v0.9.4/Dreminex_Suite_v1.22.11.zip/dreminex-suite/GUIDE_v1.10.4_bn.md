# Dreminex Suite 1.10.4 — ব্যবহার নির্দেশিকা

এই আপডেটে dashboard navigation, admin menu এবং mobile All Modules card spacing গুছানো হয়েছে। সাধারণ plugin update-এ আগের settings, module On/Off state, subscriber/offer records, coupons, WooCommerce orders বা contact requests মুছে যায় না। Plugin uninstall করে পুনরায় install করবেন না।

## Dashboard ও menu

- **Dreminex Suite → Dashboard**-এ Summary এবং All Modules, Site Health, Module Control Center ও Settings-এর shortcut আছে।
- **All Modules**-এ desktop-এ আগের মতো তিনটি এবং mobile-এ দুইটি card প্রতি সারিতে থাকবে; mobile card-এর মধ্যে দৃশ্যমান gap রাখা হয়েছে।
- **Settings**-এর tab: Language, Store setup, Backup & module data, Imported modules এবং Cache Management।
- **Welcome & Offer**-এর tab: Newsletters and subscribers, Newsletter settings এবং Offers।
- **Contact Requests**-এর tab: Requests এবং Contact email media।

## Popup ও customer message পরিবর্তন

যে module-এর বার্তা customer-কে checkout বা registration popup-এ দেখায়, তার Dashboard → Configure module পেজে message field পাবেন। Delivery advance, Phone validation, Two-hour IP cooldown, Browser order limit এবং Registration email confirmation-এর বার্তা আলাদাভাবে পরিবর্তন করা যায়। Thank-you message এবং order IP notice-ও একইভাবে সম্পাদনাযোগ্য। Order IP notice বদলালে `{ip}` রেখে দিন; সেখানে order-এর recorded IP দেখাবে। কোনো message field ফাঁকা রাখলে ওই module-এর আগের default message চলবে; তাই কিছু না বদলালে আগের ভাষা ও আচরণ অপরিবর্তিত থাকে। Repeat order message-এ `%s` রাখলে সেখানে cooldown-এর ঘণ্টা বসবে।

Dashboard-এর shortcuts থেকেই All Modules, Site Health এবং Module Control Center খুলুন; এগুলোর sidebar entry দেখা যাবে না, তবে shortcut-এর page access ঠিক রাখা হয়েছে। v1.10.3-এ shortcut চাপলে “Sorry, you are not allowed to access this page” এলে এই 1.10.4 update সেটি ঠিক করে।

## Update ও data

আগের `dreminex-suite` plugin-টির উপর WordPress-এর **Replace current with uploaded** দিয়ে update করুন। Plugin uninstall/delete বা Fresh reset করবেন না। এই update-এর জন্য কোনো database/schema migration নেই। Live সাইটে দেওয়ার আগে staging-এ configuration, registration message এবং checkout validation popup পরীক্ষা করুন।
