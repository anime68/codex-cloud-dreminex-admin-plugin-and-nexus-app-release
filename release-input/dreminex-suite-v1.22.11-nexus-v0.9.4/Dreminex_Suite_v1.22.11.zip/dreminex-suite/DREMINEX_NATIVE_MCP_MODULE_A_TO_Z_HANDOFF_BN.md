# Dreminex Suite Native MCP — A to Z Handoff, Review ও Update Workflow

সংস্করণ: Dreminex Suite 1.20.0  
মূল files: `includes/class-dreminex-native-mcp.php`, `includes/class-dreminex-native-oauth.php`

এই reference file রাখার কারণ খুব সহজ। পরে Native MCP-তে নতুন ability, permission, client বা setting যোগ করলে যেনো বোঝা যায় কোন জিনিস কোথায় আছে, কেন রাখা হয়েছে এবং update শেষে কী কী verify করতে হবে। এই file ব্যবহার করে কেউ update করলে কাজ শেষে এই file, Changelog, test evidence, package checksum এবং rollback note-ও update করবে।

## 1.20.0 provider-aware registry ও media transfer

Native MCP Settings-এ master ability state, provider/category/per-ability override, site environment, Nexus capability এবং app distribution metadata আছে। 1.22.8 থেকে mapped agent-facing abilities access profile অনুযায়ী automatic default-on; শুধু explicit off override database-এ থাকে। Internal core context, recursive adapter execution এবং skill-prompt helper প্রকাশ করা হয় না। `catalog` ও `notifications` built-in; অন্য feature off করলে API server-side 403 `app_feature_disabled` দেয়, শুধু app UI লুকিয়ে রাখে না। Discovery-তে normalized metadata, আলাদা coverage counts, stable reason codes এবং masked activity export থাকে।

App distribution manifest `GET /wp-json/dreminex/v1/nexus/app-release` endpoint দিয়ে only paired, authenticated device-কে দেয়। এতে Android version/download/SHA-256, Windows version/installer URL এবং release-notes URL থাকে। URL শুধু HTTPS হলে save হয়। Android system confirmation ছাড়া APK install করে না। Windows package native NSIS `.exe`; PWA নয়।

Environment auto detection `WP_ENVIRONMENT_TYPE`, localhost/local/test host এবং staging/dev/sandbox/Hostinger staging host দেখে। প্রয়োজন হলে Settings-এর override দিয়ে Production/Staging/Development/Local explicit করা যায়। Release validation আলাদা করে target site-এ plugin version, OAuth reconnect, REST readback ও rollback evidence নথিভুক্ত করবে; শুধু source test দিয়ে live site “fixed” বলা যাবে না।

1.18.0-এ Native MCP হচ্ছে AI Publisher, Supplier Monitor, Daily Action Center, app catalog, Contact Requests, Checkout Protection, Delivery Advance & Wallet, notifications ও analytics-এর WordPress control layer। নতুন scope: `workflow:read/write`, `operations:read`, `notifications:read/write`, `analytics:read`, `contacts:read/write`, `checkout:read/write`, `payments:read/write`। পুরোনো token-এ scope silently যোগ হয় না; Nexus 0.5 connection একবার reconnect করতে হবে। App REST-এ OAuth token-এর সঙ্গে device ID/key এবং store-management capability-ও বাধ্যতামূলক। `dreminex-products/cod-policy-update` exact product ও current revision নিয়ে confirmed, idempotent COD-only policy change করে।

## ১. Native MCP আসলে কী

এটি Dreminex Suite-এর নিজের MCP server। ChatGPT/Codex বা অন্য standard MCP client এই server দিয়ে শুধু অনুমোদিত WordPress abilities discover, validate এবং execute করতে পারে। এটি Novamira plugin-এর code, token বা runtime-এর উপর চলে না।

```text
AI client
   ↓ OAuth 2.1 + PKCE + exact scopes
Dreminex Native MCP transport
   ↓ ability switch + permission mode + WP capability
WordPress Abilities API
   ↓ existing Dreminex/WooCommerce module callback
validated result + sanitized audit log
```

Raw PHP, shell, unrestricted filesystem, password, cookie বা administrator takeover tool এখানে নেই। নতুন ability-ও defaultভাবে MCP-তে public হবে না; ability metadata-তে `mcp.public=true` লাগবে।

## ২. কোন file কী কাজ করে

| File | কাজ |
|---|---|
| `includes/class-dreminex-native-oauth.php` | OAuth client, consent, PKCE, access/refresh token, device code, revoke, discovery |
| `includes/class-dreminex-native-mcp.php` | MCP endpoint, four tools, ability policy, approval, rate limit, audit, dashboard |
| `modules/dreminex_native_mcp.php` | Suite module loader marker |
| `assets/native-mcp.css` | Native MCP admin UI |
| `includes/class-dreminex-suite.php` | module registry, menu, load/boot connection |
| এই file | future maintenance source of truth |

## ৩. Endpoint ও discovery

| Endpoint | কাজ |
|---|---|
| `/wp-json/mcp/dreminex` | MCP Streamable HTTP JSON-RPC transport |
| `/.well-known/oauth-protected-resource/wp-json/mcp/dreminex` | Native MCP-এর resource-path-specific metadata; অন্য MCP plugin-এর সঙ্গে conflict হয় না |
| `/.well-known/oauth-authorization-server/dreminex-oauth` | Native OAuth issuer metadata |
| `/wp-json/dreminex/v1/oauth/register` | dynamic public client registration |
| `/wp-json/dreminex/v1/oauth/token` | authorization code, refresh ও device grant exchange |
| `/wp-json/dreminex/v1/oauth/revoke` | token revoke |
| `/wp-json/dreminex/v1/oauth/introspect` | bounded token status |
| `/wp-json/dreminex/v1/oauth/device` | Nexus device code শুরু |

Access token ১ ঘণ্টা এবং rotating refresh token ৩০ দিন থাকে। Database-এ raw token রাখা হয় না; SHA-256 hash থাকে। Authorization code একবার ব্যবহার হয় এবং PKCE `S256` বাধ্যতামূলক। HTTPS redirect লাগে; শুধু localhost development-এর জন্য HTTP accepted। Dreminex নিজেকে OIDC provider হিসেবে advertise করে না। ChatGPT setup-এ DCR চালু থাকবে এবং OIDC বন্ধ থাকবে।

ChatGPT DCR registration-এ `scope` না এলেও client-এর persisted `allowed_scopes` সব supported Dreminex scope পায়। Initial/fallback scope code-এর read-default policy থেকে আসে, তাই নতুন database column লাগে না। পরে ChatGPT tool selection অনুযায়ী `site:write` বা অন্য supported scope চাইলে সেটি ভুলভাবে reject হয় না। পুরোনো active DCR client read করার সময় compatibility allow-list পায়; client ID, redirect URI ও database row বদলায় না।

## ৪. MCP-এর চারটি tool

| Tool | কী করে |
|---|---|
| `dreminex-discover-abilities` | enabled, public এবং client scope-এর মধ্যে থাকা abilities দেখায় |
| `dreminex-get-ability-info` | exact ability schema, annotations, required scope ও policy দেখায় |
| `dreminex-validate-ability` | input validate করে; write করে না |
| `dreminex-execute-ability` | scope, mode, approval এবং WordPress capability পাস হলে callback চালায় |

`initialize`, `notifications/initialized`, `ping`, `tools/list` ও `tools/call` supported। প্রতিটি tool-এর `securitySchemes` এবং compatibility `_meta.securitySchemes` আছে। Discovery/info tool `mcp:discover` চায়; dynamic validate/execute tool সব supported scopes declare করে, আর server প্রতিটি selected ability-এর exact scope আবার যাচাই করে। প্রতিটি MCP request-এর request ID থাকে এবং audit log-এ secret fields redacted হয়। Request body ১ MB-এর বেশি accepted নয়।

## ৫. Scope কীভাবে নির্ধারিত হয়

Supported scopes:

`mcp:discover`, `site:read/write`, `catalog:read/write`, `orders:read/write`, `suppliers:read/write`, `workflow:read/write`, `operations:read`, `notifications:read/write`, `analytics:read`, `settings:read/write`, `approvals:read/write`, `devices:read/write`।

Ability নাম এবং readonly annotation দেখে scope map হয়। Supplier ability `suppliers:*`, product ability `catalog:*`, project ability `workflow:*`, Security dashboard `settings:read` (এতে integrated read-only operations summary আছে), notification ability `notifications:*`, performance ability `analytics:read`, order ability `orders:*`, setting ability `settings:*`; অন্যটি `site:*`। Client-এর token-এ scope না থাকলে ability discovery-তেও দেখাবে না।

Authorization request, authorization code, access token এবং refresh token একই exact MCP `resource`-এর সঙ্গে bound থাকে। Token endpoint-এ অন্য resource দিলে `invalid_target`; MCP endpoint-এ অন্য audience-এর token দিলে `invalid_token` হয়। Introspection saved audience-ই ফেরত দেয়।

## ৬. Permission mode

| Mode | আচরণ |
|---|---|
| `sandbox` | read চলবে; write input validate করে preview দেবে, save করবে না |
| `auto_review` | সাধারণ idempotent write চলতে পারে; high impact/non-idempotent write exact approval চায় |
| `read_only` | সব write server থেকে block |
| `full_access` | granted scope-এর সাধারণ write চলবে; destructive/high impact write exact approval চায় |

Approval ability + exact input hash + client ID-এর সঙ্গে bound। একবার consume হলে reuse করা যায় না। সাত দিন পুরোনো pending/approved approval expire হয়।

## ৭. Dashboard settings

Dashboard: **Dreminex Suite → Native MCP**। Tabs: Overview, Connections, Abilities, Approvals, Activity logs, Settings, Diagnostics।

| Setting | Default | কাজ |
|---|---:|---|
| ability switches | public Dreminex abilities On | প্রতিটি ability আলাদা enable/disable |
| audit retention | 30 days | sanitized MCP log retention |
| request limit | 60/client/minute | abusive বা accidental request loop থামায়; range 10–600 |

Connection row থেকে permission mode বদলানো বা client revoke করা যায়। Token revoke করলে WordPress password বদলায় না।

## ৮. Database tables

| Table suffix | Data |
|---|---|
| `dreminex_oauth_clients` | registered client, redirects, আলাদা allowed/default scopes, mode, revoke state |
| `dreminex_oauth_codes` | short-lived hashed authorization code + exact resource |
| `dreminex_oauth_tokens` | hashed access token + exact resource/audience |
| `dreminex_oauth_refresh_tokens` | hashed rotating refresh token + exact resource |
| `dreminex_oauth_device_codes` | Nexus pairing code state + exact resource |
| `dreminex_mcp_approvals` | exact write approval queue |
| `dreminex_mcp_logs` | sanitized operation audit |

Ordinary update table/data reset করবে না। Migration additive হবে এবং schema version বাড়াতে হবে।

## ৯. নতুন ability যোগ করলে

1. সংশ্লিষ্ট Dreminex module-এ strict input/output schema, permission callback ও execute callback দিন।
2. `readonly`, `destructive`, `idempotent` annotation সত্যভাবে দিন।
3. শুধু external MCP exposure চাইলে `meta.mcp.public=true` দিন।
4. Discovery, ability info, validate এবং execute—চার path test করুন।
5. Read-only token দিয়ে write block এবং missing scope দিয়ে discovery block verify করুন।
6. High impact হলে approval request, approve, single consume ও replay rejection test করুন।
7. এই reference এবং Changelog update করুন।

## ১০. Release gate

- সব PHP file lint।
- fresh database এবং upgrade database—দুই অবস্থায় table install test।
- OAuth discovery, DCR without registration scope, all-scope consent, PKCE, exact resource, token refresh, revoke এবং device code test।
- ChatGPT connector-এ DCR On, OIDC Off রেখে actual connect test; `site:write` আর unsupported দেখাবে না।
- MCP initialize/tools/list/tools/call test।
- per-client rate limit test।
- ability On/Off, four permission modes ও WordPress capability test।
- log-এ password/token/cookie নেই verify।
- Novamira disabled থাকলেও Native MCP read ability চলে verify।
- staging backup, install, readback ও rollback drill।
- package এবং rollback ZIP-এর SHA-256 দিন।

Production-এ promote করার আগে staging evidence মিলবে এবং owner-এর আলাদা production instruction লাগবে।
