# Dreminex Nexus Android 0.7.0 — A to Z Handoff, Review ও Update Workflow

App: Dreminex Nexus 0.7.0  
Suite: Dreminex Suite 1.20.0  
Application ID: com.dreminex.nexus  
versionCode: 7 · Minimum Android API: 26 · Target/compile API: 36  
Room database: dreminex-nexus.db · schema 4

Nexus হলো সর্বোচ্চ পাঁচটি site-এর পৃথক mobile management app। প্রতিটি site-এর OAuth tokens, encrypted supplier session, scan schedule, queue এবং cache আলাদা থাকে। বর্তমান navigation: Home, Products, Operations, Security এবং More। Alerts header bell ও More → Alerts থেকে পাওয়া যায়। Former Projects slot এখন Security Center।

## 1. Screen ও কাজ

| Screen | কাজ |
|---|---|
| Home | store summary and recent alerts |
| Products | Published/Draft catalog, Trash, category/search, details, tags, supplier connection, guarded lifecycle ও revision-checked per-product COD-only setting |
| Operations | Supplier, Orders, Contacts, Checkout Protection, Welcome Offers, Delivery Advance & Wallet |
| Security | Contact bot protection, login rate limit, optional XML-RPC block, response headers, status, recent privacy-safe events, bounded settings ও integrated order/inventory/supplier/contact/checkout summary; queue card exact status filter দিয়ে খুলে |
| Alerts | header bell এবং More → Alerts; category, read state এবং notification destination |
| More | site list, supplier platform sessions, scan activity, alerts এবং selected website settings |

Preparation/Publisher source file editor app থেকে সরানো হয়েছে। বাইরের MCP projects আগের Native MCP workflow abilities দিয়ে Preparation/Publisher কাজ চালাতে থাকবে। Product publisher file নিজে Nexus-এ লিখবে না।

## 2. App module switch

More → Website settings-এ optional module switch connected website-এর Suite state বদলায়। Server required Suite module missing হলে enable request feature_unavailable দিয়ে ফেরায়। Feature বন্ধ থাকলে associated REST ability-ও app_feature_disabled দিয়ে ফেরায়। Built-in catalog/order/notification features switch-off করা যায় না। Wallet ও Delivery Advance app এবং WordPress—দুই জায়গায় থাকবে।

Contact Requests, Checkout Protection এবং Welcome Offers-এর পুরোনো WordPress submenus hidden, module list-এ দেখানো হয় না এবং settings page-এ Nexus-এ পরিচালনার বার্তা দেখায়। Integration সরানো হয় না; customer-facing form, hooks, stored records ও email flow Suite-এই থাকে।

## 3. Orders ও notification routing

Order list recent WooCommerce orders দেখায়। Notification-এ exact order ID থাকলে app /nexus/orders/{id} দিয়ে সরাসরি সেটি আনে; recent 50 order list-এর মধ্যে না থাকলেও খুলবে। Order read এবং update-এর OAuth scopes আলাদা। Update-এর আগে order modified timestamp revision মেলে কিনা server দেখে; cancellation-এর জন্য app-এ আলাদা confirmation আছে।

Android notification tap selected site, screen ও notification ID ধরে। Product/order notification সেই record detail-এ যায়। Notification permission বন্ধ থাকলে app-এ Alerts পড়া যাবে, তবে OS notification bar দেখাবে না। Server record সাত দিন পরে cleanup হয়। Direct FCM-এর server credential না থাকলে authenticated background sync fallback থাকে; Android Doze এই sync দেরি করতে পারে।

## 4. Contact Requests ও private evidence

Contact list status filter, Trash, restore, details, reply history, private note, status update, trash এবং explicit permanent delete দেখায়। Evidence download আলাদা authenticated endpoint দিয়ে হয়। App শুধু server receipt-এ থাকা image/jpeg, image/png, image/webp ও application/pdf নেয়; Base64 bytes-এর size receipt-এর সঙ্গে মিলিয়ে app cache-এ রাখে এবং FileProvider URI-তে viewer খুলে। সর্বোচ্চ download 10 MiB। Public upload URL বা raw server path ব্যবহার হয় না।

## 5. Welcome Offers ও Checkout

Welcome Offers app-এ list, create/edit, amount, minimum, dates, validity, eligible product IDs এবং Draft/Active state আছে। Product IDs app থেকে comma-separated string হিসেবে এলেও backend ID-গুলো validate করে WooCommerce products-এর মধ্যে সীমাবদ্ধ রাখে। Issued coupon-এর পুরোনো terms বদলায় না; Draft করলে নতুন claim বন্ধ হয়। Claims থাকা offer permanent delete করা যায় না; audit রক্ষার জন্য Draft-এ নিতে হয়।

Checkout Protection settings, receipt/IP privacy controls, event review এবং incomplete-checkout follow-up এখান থেকে করা যায়। Setting write connected site-এর checkout feature gate এবং admin capability দুটোই মানে।

Security tab site-level Security Center API-তে connected `settings:read/write` scope ব্যবহার করে। Contact guard Mail Engine-এর enabled/disabled অবস্থার বাইরে চলে; raw IP/message app history-তে ফেরত আসে না। PHP event row 15-minute bucket-এ aggregate হয়, এবং history 7–90 দিনের configured retention-এ cleanup হয়. XML-RPC blocking opt-in, কারণ Jetpack/older integrations নির্ভর করতে পারে। Pending, On hold ও Ready to ship card নির্দিষ্ট order filter খোলে; New contacts সরাসরি New filter খোলে। Hosting/CDN flood protection app-এর অংশ নয়। বিস্তারিত Security Center module reference পড়ুন।

## 6. Delivery Advance & Wallet

Nexus payment verification, provider profiles, wallet cash/promo totals, customer balances, top-up ও withdrawal queue চালায়। Customer-added cash ও promotional credit আলাদা ledger-এ থাকে। WooCommerce COD শুধু স্পষ্টভাবে COD-only চিহ্নিত product/cart-এর জন্য। Wallet বা payment mutation-এর আগে admin authorization ও explicit status transition লাগে।

## 7. GitHub Android update verification

Settings official repository anime68/ChatGPT-cloud-repository-এর latest GitHub release দেখে। Website-এর app-release URL APK update discovery-তে ব্যবহার হয় না। Install button আসার আগে updater:

1. HTTPS এবং GitHub release asset host-এ সীমিত redirect যাচাই করে।
2. GitHub release digest অথবা SHA256SUMS.txt-এ APK-এর exact filename match নেয়।
3. APK-কে 100 MiB-এর মধ্যে download করে hash compare করে।
4. package ID com.dreminex.nexus এবং installed build-এর চেয়ে বড় versionCode যাচাই করে।
5. স্থায়ী certificate fingerprint eae63d3c9761838cd27cd46a28480b0dec9b1431054c006b33b0ea673a0f48da-এর সঙ্গে APK signer মেলায়।
6. সফল হলে Android Package Installer খোলে; final confirmation Android-এর।

Wrong hash, package, signer, old version বা unsafe redirect হলে install বন্ধ হয়। Unknown app source permission চাইলে Settings-এ allow করে Nexus-এ ফিরে Install verified update আবার চাপতে হবে। Existing v0.6.0/0.7.0 same-signer installation uninstall করার দরকার নেই।

## 8. Code map

| Path | দায়িত্ব |
|---|---|
| app/src/main/java/com/dreminex/nexus/MainActivity.kt | Compose navigation, Security Center, product panels, operations, settings |
| NexusViewModel.kt | per-site state, Security + operations summary, operations, notification routes ও update lifecycle |
| network/NexusApi.kt | OAuth/device-bound REST, security, order/contact/offer API |
| updates/GitHubReleaseUpdater.kt | release metadata, bounded download, hash/package/version/signer verification |
| data/SecureStore.kt | Keystore-backed tokens, sessions and per-site settings |
| data/AppDatabase.kt | Room schema 1→2→3→4 additive migrations |
| NexusMessagingService.kt | Optional FCM notification presentation |
| AndroidManifest.xml, res/xml/update_file_paths.xml | package install/evidence FileProvider boundaries |
| app/build.gradle.kts | app identity, 0.7.0/7, signer-secrets-only release build |

## 9. Update করার নিয়ম

- Application ID, certificate digest, database filename, preference keys ও package signing identity একই রাখতে হবে।
- versionCode অবশ্যই আগের public build-এর চেয়ে বাড়াতে হবে।
- Room schema বদলালে explicit migration এবং data-preservation test যোগ করতে হবে।
- Settings UI ও GitHub updater-এর checksum, signer, version, redirect এবং unknown-source permission behavior test করতে হবে।
- Security controls বদলালে honeypot/timing/rate guard, login lock, optional XML-RPC effect, event aggregation/privacy, Nexus save/readback ও alert navigation test করতে হবে।
- একই signer-এর installed app-এর ওপর physical test phone-এ update করে site connections, session, pending queue ও snapshots readback করতে হবে।
- Signed APK CI secrets ছাড়া local build থেকে তৈরি বা প্রকাশ করবেন না।
- Android build ব্যর্থ হলে Suite-এর passing PHP test দিয়ে Android pass দাবি করবেন না।

## 10. Validation ও সীমা

Local PHP/API contract checks Android app compile বা real device update-এর বিকল্প নয়। FCM server secret এই source package-এ নেই; authenticated fallback-ই guaranteed path. Staging/production site আলাদা অনুমতি ছাড়া পরিবর্তন করা যাবে না।
