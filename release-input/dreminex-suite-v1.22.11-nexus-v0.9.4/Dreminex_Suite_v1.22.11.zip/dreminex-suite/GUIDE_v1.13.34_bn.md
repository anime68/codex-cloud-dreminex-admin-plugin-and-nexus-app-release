# Dreminex Suite 1.13.34 — AI workflow projects

এই release আপনার দেওয়া **1.13.33 ZIP** থেকে তৈরি। WordPress Admin → Dreminex Suite → All Modules → **AI Product Publisher** খুললে দুটি আলাদা project tab পাবেন: **Preparation** ও **Publisher**। একটি Novamira সংযোগ থেকেই উভয়ের কাজ হয়, তবে প্রতিটির source list, revision ও experience log আলাদা।

## প্রথম ব্যবহার

1. Preparation-এ ১২টি এবং Publisher-এ ৯টি built-in source file আছে কিনা দেখুন। এগুলো আগের সর্বশেষ project source pack থেকে bundled default।
2. ChatGPT-এর সংশ্লিষ্ট Project Settings-এ dashboard-এ দেখানো ছোট **One-time ChatGPT Project instruction** বসান। WordPress-এ source upload করলে ChatGPT-এর আগে attach করা Project file নিজে থেকে বদলায় না; পুরোনো conflicting attachment থাকলে Project Settings/Source তালিকা মিলিয়ে সরান।
3. Assistant প্রতিটি নতুন কাজে `dreminex-products/workflow-profile` দিয়ে সঠিক profile ও revision পড়বে, তারপর `workflow-source` দিয়ে প্রয়োজনীয় নথি পড়বে। আগের `workflow-guide`-ও বর্তমান dashboard source পড়ে, তাই existing skill workflow কার্যকর থাকে।
4. Preparation supplier information, screenshot SKU, media identity, copy ও handoff তৈরি করে। Publisher handoff প্রয়োগ করে এবং saved product/image metadata readback করে। Source file নতুন authorization তৈরি করতে পারে না।

## Dashboard file controls

- প্রতি project সর্বোচ্চ **২০টি active `.md`/`.txt`**, প্রতি ফাইল সর্বোচ্চ **৫ MiB (5,242,880 bytes)**। বড়, binary, invalid UTF-8 ও অনিরাপদ filename reject হয়।
- **Replace** বর্তমান নামে নতুন text বসায়; **Previous version** শেষ saved content ফিরিয়ে আনে। **Remove** built-in source লুকিয়ে রাখে; **Restore built-in** package-এর আসল file ফিরিয়ে আনে। নতুন upload সরালে সেই custom file বাদ যায়।
- Preview প্রথম অংশ দেখায়; Download-এর জন্য WordPress admin permission ও nonce প্রয়োজন। কোনো source file public Media Library-তে আপলোড হয় না।
- Project একেবারে ফাঁকা করা যায় না। Core WooCommerce product image upload limit আলাদা; এই ৫ MiB শুধু project source নথির জন্য।

## শেখা ও review

প্রতি project-এ সর্বশেষ ১০০টি সংক্ষিপ্ত outcome রাখা হয়। Publisher-এর supported write operation-এর সফলতা/ব্যর্থতা স্বয়ংক্রিয়ভাবে log হয়। Preparation ও Publisher যাচাই করা শিক্ষা `workflow-experience-record` দিয়ে যোগ করতে পারে। পুরোনো observation নতুন product-এর fact নয়।

Assistant `workflow-propose` দিয়ে নতুন rule সাজেস্ট করতে পারে; dashboard-এ evidence দেখে admin **Approve** করলে তা `99_APPROVED_LEARNINGS.md` source-এ যোগ হয়, **Dismiss** করলে বাদ যায়। এটি model weight retraining নয়; WordPress-hosted controlled memory ও source revision। কোনো proposal নিজে থেকে active instruction হয় না।

## Release check ও rollback

Staging-এ default count, file-size/count validation, পৃথক profile read, chunking, experience log, proposal review, source replace/reset এবং original product abilities যাচাই করুন। তারপর main-এ একই readback করুন। আগের ZIP দিয়ে rollback করলে built-in UI/abilities সরবে, কিন্তু WordPress options-এর custom source data মুছে যাবে না; 1.13.34 আবার দিলে তা পাওয়া যাবে। Plugin uninstall করবেন না।
