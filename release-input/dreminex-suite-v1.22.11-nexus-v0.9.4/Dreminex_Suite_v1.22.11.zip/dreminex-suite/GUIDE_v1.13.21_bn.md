# Dreminex Suite 1.13.21 — Storefront customer pages

এই release-এ Shop, category, product, Cart, Checkout, tracking, Wishlist, Compare ও Contact-এর 1.13.20 পরিবর্তন রয়েছে। Cart-এর “Proceed to checkout” button-এর সাদা theme override-ও সংশোধিত হয়েছে। মূল WooCommerce/ShopBuilder form, totals, action এবং product data অপরিবর্তিত।

Staging-এ আগের `dreminex-suite` plugin-এর ওপর ZIP update দিন; plugin uninstall/delete করবেন না। Main site update-এর আগে পূর্ণ backup রাখুন। Storefront Design-এর Customer pages controls থেকে আলাদা অংশ চালু বা বন্ধ করা যায়। প্রতিটি site-এর image/page settings আলাদা, তাই update-এর পর Shop, product, Cart, Checkout, Wishlist, Compare, Contact, tracking ও My Account ফোন/desktop-এ smoke test করুন। Payment বা live order submit করবেন না, যদি না আলাদা test method থাকে।

Rollback: আগের plugin ZIP এবং database backup সংরক্ষণ করুন। অসংগতি হলে plugin updater দিয়ে আগের ZIP পুনরায় বসান; customer data বা Suite settings delete করবেন না। Main site-এর PHP এবং saved content staging থেকে আলাদা হওয়ায় production promotion আলাদা অনুমোদন ও verification ধাপ।
