# Dreminex Supplier Monitor ও newsletter welcome offer — 1.13.38 RC

## নতুন customer-এর offer

- Email-confirmed registered **নতুন customer**-এর জন্য একবার **৳৩০ fixed-cart discount**। Minimum order amount নেই; তাই ছোট eligible order-ও বাদ যায় না। Coupon পাওয়ার আগে একই account বা account-email দিয়ে guest হিসেবে যোগ্য আগের order থাকলে নতুন coupon ইস্যু হয় না। একই বাস্তব ব্যক্তি ভিন্ন email/account খুললে তাকে নির্ভুলভাবে শনাক্ত করার দাবি করা হচ্ছে না।
- Woo couponটি একবার ব্যবহারযোগ্য, ওই email ও লগইন করা account-এ সীমিত, অন্য coupon-এর সঙ্গে যুক্ত নয়; সাধারণ মেয়াদ ৩০ দিন। Woo sale item ও Dreminex Flash Sale item-এ discount লাগে না। Flat delivery charge customer আগের মতোই অগ্রিম দেন; free shipping দেওয়া হয় না। Sale-only cart-এ coupon ব্যবহার করা যাবে না।
- আগে ইস্যু করা coupon-এ ৳১০০ বা ৳৯৯৯ minimum থাকলে তাদের নিজস্ব শর্ত বহাল থাকে; admin-কে Marketing → Coupons-এ সেগুলো পৃথকভাবে audit করতে হবে। পূর্বের saved newsletter settings থাকলেও **নতুন** coupon-এর amount সর্বোচ্চ ৳৩০, minimum ৳০ এবং existing customer allowance বন্ধ।
- **Coupon issuance default Off**; newsletter feature নিজেও এখন live এবং staging-এ Off। Catalog margin এবং checkout পরীক্ষা করে admin আলাদাভাবে coupon issuance চালু করবেন। আগে newsletter-only subscription নিশ্চিত হলে পরবর্তীতে coupon চালু করলেই পুরোনো subscriber স্বয়ংক্রিয়ভাবে coupon পাবে না; launch timing পরিকল্পনা করুন।

## লাভ ও price cap

Verified wholesale + প্রতি unit ৳১৫ other/packaging + ৳৩০ return reserve + সাধারণ ৳২৫ ad (নির্বাচিত item-এ বেশি) + payment fee + courier shortfall ধরুন। প্রস্তাবিত regular price-এর সর্বনিম্ন শেষ অঙ্ক ৯; ৳৩০ coupon পুরোটা ওই একটি item-এ পড়লেও net profit কমপক্ষে ৳৭০, আর regular profit ৳২০০-এর নিচে। Fee শূন্য হলে এই welcome offer রক্ষায় regular profit কমপক্ষে ৳১০০ লাগে। Actual merchant courier charge আর customer-এর prepaid delivery একই ধরে নেওয়া হয় না। প্রতিটি item-এ market-checked **পণ্য + সর্বোচ্চ delivery** cap ছাড়া price proposal তৈরি হয় না।

উদাহরণ, প্রকৃত product quote নয়: wholesale ৳২০০, courier max ৳৮০, fee ৳০, other ৳১৫, return ৳৩০, ad ৳২৫, ৳৩০ coupon, target ৳৭০, customer cap ৳৬০০ এবং বর্তমান সর্বোচ্চ delivery ৳১৩০ হলে regular price **৳৩৭৯**। Coupon ছাড়াই net profit ৳১০৯; coupon পরে ৳৭৯; বাইরে delivery-সহ customer total ৳৫০৯ (coupon ব্যবহার করলে ৳৪৭৯)। Courier বেশি বা fee থাকলে price বদলায়; customer cap ছাড়ালে proposal বন্ধ হয়। আগে ইস্যু হওয়া ৳১০০ coupon প্রকাশিত থাকলে সিস্টেম তার বেশি exposure ধরে, তাই এই উদাহরণ প্রযোজ্য নয়।

## চালুর আগে staging gate

1. Full staging backup ও restore rehearsal; package install/activation, module loader, newsletter schema এবং existing flow smoke test। Supplier Monitor default Off রাখুন।
2. Actual courier bill, maximum payment/COD fee, ৩টি representative wholesale item/variation, selected higher ad budget এবং delivery-সহ market cap বসান। Existing catalog-এর প্রতিটি eligible regular-price item-এ coupon পরেও net profit ≥৳৭০ যাচাই করুন।
3. Staging test account-এ email confirmation, guest-previous-order exclusion, account-previous-order exclusion, duplicate confirmation, one-use/expiry/email/login restriction, ছোট cart, sale-only cart, mixed cart, Flash Sale `allow_coupons` উভয় অবস্থায়, coupon stacking, delivery advance এবং checkout readback পরীক্ষা করুন। Live customer/account data দিয়ে test করবেন না।
4. Supplier worker-এর authenticated source sample, SKU/variant mapping, ১২-ঘণ্টার scan, stale approval ও product write/readback পরীক্ষা করুন। আলাদা worker host এবং owner-authorized supplier session ছাড়া coverage দাবি করবেন না।
5. Staging evidence review-এর পরে আলাদা production approval। Main site-এর বর্তমান Suite বা Newsletter settings এই RC তৈরি করতে বদলানো হয়নি। Rollback-এর জন্য আগের verified Suite 1.13.34 package ও staging snapshot রাখুন।

**আরও বিশদ Supplier Monitor নির্দেশনা:** `GUIDE_v1.13.37_bn.md`-এর monitoring এবং safety অংশ; তার ৳১০০ newsletter default সংক্রান্ত পুরোনো সংখ্যাগুলো এই 1.13.38 নির্দেশনায় বদলেছে।
