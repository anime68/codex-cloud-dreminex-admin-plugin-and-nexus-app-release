# Dreminex Suite 1.13.30

এই আপডেটে নতুন product-এর colour supplier SKU map প্রথমবার সেভ করার সময় অপ্রয়োজনীয় খালি `0` entry তৈরি হয় না। আগে তৈরি map-এ এমন entry থাকলে একই product ID-তে পরবর্তী `listing-apply` সেটি সরিয়ে দেয়।

Preparation-এ ছবি খোঁজার সময় নির্দিষ্ট product নাম দিয়ে search-এর পাশাপাশি নির্বাচিত সাইটের সাম্প্রতিক Media Library attachments নামের filter ছাড়া দেখতে হবে। ছবির filename camera-generated হলেও screenshot-এর সঙ্গে ছবি মিলিয়ে তার ID hand-off-এ যাবে। কোনো ability না থাকাকে “ছবি নেই” বলা যাবে না।

Main site-এ Suite > Modules থেকে **AI Product Publisher** চালু থাকলে `dreminex-products/listing-apply`, `media-candidates`, `media-update` এবং `product-read` abilities পাওয়া যায়। Module বন্ধ থাকলে plugin সক্রিয় থাকলেও এই abilities পাওয়া যায় না। Staging ও Main-এর Media ID আলাদা।

Staging-এ 2-colour × 3-size Draft পরীক্ষা: ছবি, metadata ও ছয় SKU readback সঠিক। Main-এ 8-colour × 3-size বিদ্যমান Draft ID 2885 একই `listing-apply` দিয়ে update করে ২৪ SKU, আট attachment-এর Title/Slug/Alt, দাম এবং status readback সঠিক। Product Draft-ই আছে; Publish mode ছাড়া প্রকাশ করা হয়নি।
