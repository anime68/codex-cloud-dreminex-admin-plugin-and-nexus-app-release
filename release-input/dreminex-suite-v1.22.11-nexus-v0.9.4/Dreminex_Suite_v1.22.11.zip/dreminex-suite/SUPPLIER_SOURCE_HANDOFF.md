# Supplier source handoff · Dreminex Suite 1.13.53

## Boundaries

AI Product Publisher owns catalog creation and updates. Supplier Monitor owns source links, subscription-account sign-in, 12-hour observations and approval alerts. Security shows the pending supplier alert count; its card opens the Supplier workspace. One module does not copy another module's credentials, decisions or product content.

## Publisher abilities

Use the connected site's Novamira ability discovery and execute the **site-specific** `dreminex-products/supplier-source-set` ability, with:

```json
{"product_id":2859,"supplier_source_url":"https://shopbasebd.com/store/products/details/31649"}
```

Or pass `supplier_source_url` during `listing-apply` (new Draft, Publish or existing update) or `listing-update` (existing Draft/Published). The new product is saved first; a source-link stage is reported separately so a failed link does not silently lose the listing. `supplier-source-read` with `{"product_id":2859}` returns source URL, status and last successful scan. Product ID is site-specific. Do not use staging ID on production.

For product add/update, a missing, null or blank `supplier_source_url` means skip this optional capability and continue the listing unchanged. When a non-empty owner-supplied exact URL is present, Publisher connects it after saving the product and verifies it through `supplier-source-read` on the same site and product ID. A source failure is a separate partial stage; retry only the source-set operation for that saved ID, never resubmit the entire listing. Never construct a URL or send supplier credentials.

Supplier Monitor also offers its product editor Source box and Connect a product form. Allowed exact HTTPS product links are ShopBaseBD `/store/products/details/<number>` and ResellKori `/product/<slug>/`; query strings and foreign hosts are rejected. Replacing a source resets that supplier's snapshot and supersedes pending alerts. Save account identifier and password separately on each site's Supplier Monitor page; never send them in chat or put them in a ZIP. Every scan signs in afresh, uses cookies in memory for that attempt, and checks for login expiry. CAPTCHA, OTP, disabled account or supplier layout changes raise scan problems; they do not mutate WooCommerce.

## Evidence and decisions

ShopBaseBD uses the displayed product price; ResellKori uses **Reseller Price** (not bulk Wholesale Price). Product-wide stock and cost are not per-colour or per-size stock. The scanner reads bounded same-host gallery images and text sizes. A verified visual match between a supplier image and a Woo variation image links the image to a colour. Changed image is review-only. A missing image must remain absent across two successful authenticated scans before the colour alert can offer **Hide colour**. Approval checks fresh source, unambiguous matching, current variation images and available alternative supplier images, then hides exactly that colour's variations and removes its selectable attribute/gallery image, without deleting media. Recent audit provides **Restore this colour**. A size missing only from the description is review-only. If it is absent from both description and surviving order-size controls in two successful scans, the alert can offer a reversible **Hide size** approval. If the supplier exposes no inspectable size controls, approval stays unavailable. Reappearing evidence supersedes pending alerts.

Example source pairs:

| Site | Product ID | Supplier URL |
| --- | ---: | --- |
| Staging | 2859 | `https://shopbasebd.com/store/products/details/31649` |
| Staging | 3430 | `https://resellkori.com/product/hoodie-combo-3/` |
| Main | 2885 | `https://shopbasebd.com/store/products/details/31649` |
| Main | 3056 | `https://resellkori.com/product/hoodie-combo-3/` |

## Verification

Read the source back, run a manual authenticated scan on staging, inspect Supplier Monitor status and the Security operations summary, then test a second scan when a genuine supplier change occurs. The native 12-hour target is WP-Cron traffic dependent. For precise scheduling use server cron to invoke WP-Cron reliably. Never interpret an authentication failure, image fetch failure or missing textual size as definite stock loss.
