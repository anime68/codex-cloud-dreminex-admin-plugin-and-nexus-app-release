# Nexus Security ও Notifications — A to Z Reference

এই reference-এ Dreminex Nexus-এর site-isolated notifications এবং নতুন Security dashboard-এর একসাথে কাজের নিয়ম দেওয়া আছে। Security tab-এই site protection এবং আগের Daily Action Center-এর summary থাকে। আলাদা Action Center tab বা Native MCP ability নেই।

## কোন notification আসে

- `orders`: নতুন customer order, order status পরিবর্তন।
- `products`: product তৈরি, Draft/Published/Trash status এবং product payment policy পরিবর্তন।
- `suppliers`: connected supplier scan বা verified change review দরকার।
- `contacts`: customer support request।
- `checkout`: checkout protection বা incomplete checkout-এর event।
- `payments`: advance verification এবং Wallet review।
- `security`: blocked contact spam, login burst, Security policy update এবং আগের Action Center-ধরনের notice।
- `system`: বাকি site event।

Notice সাত দিন পরে স্বয়ংক্রিয়ভাবে মুছে যায়। App All বা category filter, unread badge, read এবং delete action দেখায়। Push credential না থাকলে app পরের sync-এ notice পায়; configured FCM থাকলে push আসে এবং app data source হিসেবে WordPress-ই থাকে।

## Security dashboard-এ কী আছে

Security screen-এর `Store operations` section আগের read-only Daily Action Center-এর queue একসাথে দেখায়:

- Pending, on-hold এবং ready-to-ship orders.
- Inventory attention.
- Supplier alerts.
- New contact requests.
- Incomplete checkout.

প্রতিটি card চাপলে সংশ্লিষ্ট Orders, Products, Supplier, Contacts অথবা Checkout workspace খুলে record review/update করা যায়। Summary read-only; কোনো count দেখা মাত্র order status বা payment নিজে বদলায় না। Security settings, site checks এবং recent privacy-safe attack log একই screen-এ থাকে।

## API এবং compatibility

- `GET /wp-json/dreminex/v1/nexus/security` এখন protection state, checks, settings, security events এবং `operations_summary` ফেরত দেয়।
- `PUT /wp-json/dreminex/v1/nexus/security` bounded Security settings সেভ করে এবং readback ফেরত দেয়।
- পুরোনো Nexus app update হওয়ার আগ পর্যন্ত `GET /wp-json/dreminex/v1/nexus/action-center` compatibility route রাখা হয়েছে। এটি একই operations summary ফেরত দেয়; পুরোনো notification filter `action_center` এলে API-ও `security` category দেখায়। নতুন Android app Action Center route/filter আর call করে না।
- Standalone `dreminex-operations/action-center-read` ability এবং app feature switch সরানো হয়েছে। Native MCP-তে একমাত্র dashboard `dreminex-security/dashboard-read`; এতে operations summary-ও আছে।

## Schema 2 notification migration

`Dreminex_Nexus_App::SCHEMA` 1 থেকে 2 হয়েছে। Migration:

1. `action_center` category-র পুরোনো notification-কে `security` category করে।
2. `operations/action-center` deep link-কে `security` করে।
3. Notification ID, message, event history, orders, customer requests বা supplier records delete করে না।
4. Suite schema 5 আলাদাভাবে পুরোনো Action Center module toggle সরায়; module settings, activity history এবং business records অক্ষত রাখে।
5. Seven-day notification cleanup আগের মতোই চলে।

Old push alert ইতিমধ্যে phone notification tray-তে থাকলে Android route fallback সেটিকে Security screen-এ নেয়।

## App file map

| File | দায়িত্ব |
|---|---|
| `includes/class-dreminex-nexus-app.php` | notification table, schema migration, site-scoped API, operations aggregation, FCM and cleanup |
| `includes/class-dreminex-security-center.php` | contact/login guard, privacy-safe event history, Security dashboard and Native MCP abilities |
| Android `data/Models.kt` | `SecurityDashboard`, `OperationsSummary` এবং notification payload types |
| Android `network/NexusApi.kt` | selected-site scoped Security, operations and notification calls |
| Android `NexusViewModel.kt` | per-site refresh, Security destinations and old deep-link compatibility |
| Android `MainActivity.kt` | Security cards/settings/events and Notifications UI; standalone Action Center panel নেই |

## Update ও release gate

1. Android model, REST output এবং Native MCP dashboard contract একসাথে বদলাবেন।
2. Notification category বা route বদলালে schema number বাড়িয়ে additive migration লিখবেন; existing notification delete করবেন না।
3. Unit test-এ `operations_summary` JSON decode, click destination, legacy notice route এবং seven-day expiration যাচাই করবেন।
4. PHP lint, সব Suite tests, cross-project contract এবং Android unit/debug build pass করাবেন।
5. Staging-এ summary counts WooCommerce Orders/Contacts/Supplier/Checkout-এর readback-এর সঙ্গে তুলনা করবেন। Safe test notification তৈরি করে Security category/deep link পড়বেন, তারপর test record মুছবেন।
6. Physical/CI emulator visual check-এ ছোট ফোনে দুই-column queue card, text wrapping, scroll, tap target, saving state ও bottom navigation দেখবেন।
7. Source/reference ZIP ও SHA-256 update করবেন। Staging install না হলে বা screenshot না থাকলে gate-কে অসম্পূর্ণ বলবেন; CI build-কে live proof বলবেন না। Production আলাদা authorization পেলে তবেই deploy হবে।

## Rollback

আগের Suite ZIP plugin update করে ফিরিয়ে আনলে code rollback হবে; schema-2 migration আগের notification row মুছে না, তাই data restore দরকার হয় না। আগের app build `action-center` route/category ব্যবহার করলে compatibility endpoint এবং Android legacy route fallback-এর কারণে তা চলবে।
