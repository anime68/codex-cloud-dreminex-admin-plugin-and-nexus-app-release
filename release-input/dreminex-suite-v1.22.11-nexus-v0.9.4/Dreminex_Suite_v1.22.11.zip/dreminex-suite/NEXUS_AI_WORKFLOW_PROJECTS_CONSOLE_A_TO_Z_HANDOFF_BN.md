# Nexus AI Workflow Projects Console — A to Z Reference

**Suite:** 1.19.0  
**Nexus:** 0.6.0  
**মূল source:** `class-dreminex-ai-workflow-projects.php`, `dreminex_ai_product_publisher.php`, Nexus Projects screen

## দায়িত্ব ভাগ

Preparation supplier packet, screenshot ও original image এক evidence pass-এ বিশ্লেষণ করে complete canonical handoff বানায়; WooCommerce write করে না। Publisher সেই handoff `handoff-execute`-এ দেয়, declared safe prerequisite resolve করে, fresh preflight চালায়, Draft/explicit Update/Publish apply বা resume করে এবং exact saved readback verify করে।

## App console

`GET /nexus/projects` Preparation/Publisher revision, active file manifest, limits, one-time project instruction এবং setup prompt দেয়। Source content list response-এ আসে না; exact file tap করলে আলাদা authenticated request হয়।

App থেকে:

- existing `.md`/`.txt` source পড়া ও edit;
- নতুন text file লেখা বা device file picker থেকে upload;
- একই filename হলে warning-এর পরে replace;
- previous revision recoverable রাখা;
- Publisher maximum rows, SKU prefix এবং Native access mode manage করা যায়।

## Limits

- প্রতি source file সর্বোচ্চ 2 MiB / 2,097,152 bytes।
- সর্বোচ্চ 20 active files per profile।
- 1–44 variation row inline handoff; 45+ complete UTF-8 JSON file।
- listing hard maximum 564; dashboard-configured limit 1–564। Preflight এবং save layer একই value enforce করে।

## One-pass bootstrap

প্রতি task-এ `dreminex-products/workflow-bootstrap` একবার ব্যবহার করে live revision, site snapshot, capacity ও current instruction নেবে। একই discovery/schema বারবার scan করবে না। Final handoff exact canonical preflight payload ও hash হবে। `workflow-task-finalize` task শেষে একবার চলে; repeated verified pattern admin review queue-তে যায়, active instruction নিজে বদলায় না।

## SKU ও copy rule

- New product-এ owner/dashboard prefix দিয়ে unique parent SKU।
- child identity parent-colour-size; supplied/screenshot exact supplier code থাকলে append এবং `supplier_sku`-তেও রাখে। Code না থাকলে বানায় না।
- same title/slug থাকলে verified product differentiator দিয়ে নতুন factual identity; existing product silently update নয়।
- short/long description natural, professional, selling-friendly, SEO-friendly এবং supplied facts-এ সীমিত। Unsupported quality/material claim, unrelated tag/category নয়।
- একই colour-এর এক representative original image swatch; alternate original views gallery-তে।

## Safe recovery

Category/attribute/supplied-media prerequisite handoff-এ declared থাকলে Publisher owner-কে প্রশ্ন না করে resolve করে fresh preflight চালায়। Site lock, price, identity conflict, missing external evidence ও capacity overflow zero-write hard blocker। WordPress sanitization-এর আগে/পরে description canonicalization একই হওয়ায় harmless HTML change false mismatch হয় না।

## Update checklist

1. Default source বদলালে project revision/hash স্বয়ং বদলাচ্ছে যাচাই করুন।
2. Ability/schema বদলালে Project instructions, trigger JSON, Android model/UI এবং A-to-Z reference update করুন।
3. Existing filename replacement confirmation client ও server দুই জায়গায় রাখুন।
4. 44/45 এবং configured max/max+1 boundary test করুন।
5. Staging-এ bootstrap → preflight → prerequisite → execute/resume → readback → finalize পরীক্ষা করুন।
6. শেষে changed files, test report, staging evidence, source ZIP, install ZIP ও SHA-256 update করুন।

