# Dreminex Suite 1.13.31 — Product Preparation ও Description

- Preparation একই সাইটের `preparation-snapshot` একবার পড়ে category, size terms, exact slug/SKU collision, সাম্প্রতিক Media Library candidates এবং published related candidates পাবে। `media_page` দিয়ে প্রাসঙ্গিক পুরোনো upload-ও দেখা যাবে। ছবি ও related product নিজে যাচাই করতে হবে; ফলাফলকে verified ধরা যাবে না।
- Customer-facing short/long description-এ supplier/verification log থাকবে না। পণ্যের title পেজে ইতিমধ্যে আছে, তাই long description সরাসরি product paragraph দিয়ে শুরু হবে; বড় duplicate H2 থাকবে না। যাচাই হয়নি এমন রঙ না ওঠা, কম ঘাম, guarantee ইত্যাদি দাবি বাদ যাবে।
- Single-product description panel-এর H2/H3/H4 আকার কমানো হয়েছে; অন্য পেজের heading style বদলায় না।
- Existing product copy স্বয়ংক্রিয়ভাবে বদলায় না। বর্তমান Draft 2934-এর copy আলাদাভাবে আপডেট ও readback করতে হবে; status Draft-ই থাকবে।
- Staging-এ read-only snapshot, CSS version ও QA Draft readback যাচাই করে Main-এ একই release প্রয়োগ করুন।
