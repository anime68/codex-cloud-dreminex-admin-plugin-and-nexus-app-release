# Delivery Advance & Wallet Module — A to Z Handoff, Review ও Update Workflow

## এই module মূলত কী কাজ করে

Normal product-এর order confirm করার জন্য customer আগে delivery charge দেবে। Delivery advance valid হলে order confirm হবে এবং product-এর বাকি balance delivery-এর সময় customer দেবে। Customer চাইলে শুরুতেই পুরো order-এর payment করতে পারবে।

Customer-এর নিজের Wallet থাকবে। Account ছাড়া Wallet ব্যবহার করা যাবে না। Customer নিজের টাকা Wallet-এ add করে রাখতে, order-এর payment-এ ব্যবহার করতে এবং settled cash withdrawal request করতে পারবে। Offer/coupon থেকে পাওয়া promotional balance শুধু product কেনার জন্য ব্যবহার হবে; এটি withdraw করা যাবে না এবং offer expiry শেষ হলে unused amount expire হবে।

## COD-এর সঠিক নিয়ম

COD পুরো website-এর জন্য চালু নয়। WooCommerce product edit screen অথবা Nexus product detail-এর confirmed **COD-only product** switch On করা থাকলে এবং cart-এর সব product COD-only হলে শুধু তখন Cash on Delivery দেখা যাবে। Normal product-এ COD দেখা যাবে না। COD-only এবং normal product এক cart-এ থাকলে checkout আলাদা order করতে বলবে; এতে normal product-এর advance rule bypass হবে না। COD order, admin summary ও customer email-এ `Cash on Delivery` এবং সম্পূর্ণ `Amount due at delivery` দেখা যায়।

## Payment plan

1. **Delivery advance:** delivery charge এখন পরিশোধ হবে, product balance delivery-এর সময় নেওয়া হবে। Verification সফল হলে order `On hold` হবে।
2. **Full payment:** পুরো order amount এখন পরিশোধ হবে। Verification সফল হলে WooCommerce paid-order flow চলবে।
3. **COD-only product:** explicit product flag ছাড়া এই route পাওয়া যাবে না। পুরো amount delivery-এর সময় due থাকবে।

## Wallet balance কীভাবে আলাদা থাকে

- **Cash balance:** customer-এর verified top-up। এটি order-এ খরচ করা ও withdrawal করা যায়।
- **Promotional balance:** wallet coupon/offer claim থেকে আসে। এটি purchase-only, nonwithdrawable এবং expiry-bound।
- **Reserved balance:** checkout বা withdrawal request চলার সময় lock হওয়া amount। এটি দ্বিতীয়বার ব্যবহার করা যায় না।
- Purchase-এর সময় আগে সবচেয়ে কাছের expiry-এর promotional credit, তারপর customer cash ব্যবহার হয়।

## Checkout flow

- Wallet balance থাকলে checkout-এ **Use available wallet balance first** default selected থাকে।
- Wallet যথেষ্ট হলে payable-now amount Wallet থেকে কাটা হয়।
- Wallet কম হলে Wallet amount reserve হয় এবং বাকি amount bKash/Nagad/Rocket/Upay বা configured official provider দিয়ে দিতে হয়।
- Manual TXID শুধু claim; merchant account বা official API verification না হওয়া পর্যন্ত payment verified নয়।
- Failed, cancelled বা refunded order-এর unused reservation release হয়।
- Order total Wallet deduction দেখানোর জন্য বদলানো হয় না; payment split order meta ও immutable wallet ledger-এ থাকে।

## Add money ও withdrawal

- Customer My Account → Wallet থেকে provider, amount ও TXID দিয়ে top-up request করবে। Admin/Nexus verification-এর পরে এটি withdrawable cash lot হবে।
- Withdrawal request কেবল available customer cash থেকে reserve হবে। Promotional balance withdrawal eligibility-তে যাবে না।
- Withdrawal state: `requested → approved → paid`, অথবা `requested/approved → rejected`। Rejected হলে reservation ফেরত আসে; paid হলে ledger debit final হয়।

## Promotional wallet coupon

WooCommerce coupon meta-তে নিচের values ব্যবহার হয়:

- `_dreminex_wallet_credit_enabled = yes`
- `_dreminex_wallet_credit_amount = amount` (খালি হলে coupon amount)
- `_dreminex_wallet_credit_days = days` (coupon expiry না থাকলে fallback)

এক customer একই wallet coupon একবার claim করতে পারে। Customer Wallet page-এ active promotional amount ও expiry দেখতে পায়।

## Admin ও Nexus dashboard

Dashboard-এ মোট Wallet customer, promotional balance ব্যবহার করা customer, active promo customer, cash-balance customer, active promotional balance, customer-added cash, reserved amount, withdrawable cash, top-up review এবং withdrawal queue দেখা যায়। Nexus থেকে top-up `verified/rejected`, withdrawal `approved/paid/rejected`, order payment `review/verified` এবং provider profile review করা যায়।

প্রত্যেক write action scoped OAuth permission, confirmation এবং server-side state transition ব্যবহার করে।

## গুরুত্বপূর্ণ file

- `modules/dreminex_delivery_advance.php`: product-only COD, checkout plan, manual transfer, wallet split, order status ও summary।
- `modules/dreminex_customer_wallet.php`: tables, ledger lots, reservation, debit/release, top-up, promotional claim, expiry, withdrawal ও My Account UI।
- `modules/dreminex_delivery_advance_api.php`: official provider gateway ও verification; legacy internal IDs existing order compatibility-এর জন্য রাখা।
- `modules/dreminex_delivery_advance_api_config.php`: encrypted provider connections।
- `includes/class-dreminex-suite-routing.php`: COD/API/manual route-এর একমাত্র decision point।
- `includes/class-dreminex-nexus-operations.php`: Nexus REST ও Native MCP operations।
- `includes/class-dreminex-suite-control.php`: module settings।

## Update করার বাধ্যতামূলক নিয়ম

এই reference file ব্যবহার করে future update করলে cash ও promotional balance এক field/table-এ merge করা যাবে না। Ledger entry delete বা silently rewrite করা যাবে না। নতুন payment state যোগ করলে WordPress, Nexus REST, Native MCP, Android model/UI এবং notification deep link একসঙ্গে update করতে হবে। Existing encrypted provider profile ও historical order metadata preserve করতে হবে।

কাজ শেষে অবশ্যই test করতে হবে:

1. wallet ছাড়া delivery advance এবং full payment;
2. wallet দিয়ে full cover ও partial cover;
3. expiry অনুযায়ী promo-first spend;
4. promotional balance withdrawal rejection;
5. concurrent order/withdrawal reservation;
6. failed/cancelled order release;
7. duplicate top-up TXID;
8. top-up verify এবং withdrawal state transitions;
9. normal, COD-only এবং mixed cart routing;
10. order, ledger, REST/Nexus এবং customer readback-এর amount equality।

সব test staging-এ pass না করলে production release করা যাবে না। কাজ শেষে এই reference, main plugin reference, changelog, source hashes এবং release evidence update করতে হবে।
