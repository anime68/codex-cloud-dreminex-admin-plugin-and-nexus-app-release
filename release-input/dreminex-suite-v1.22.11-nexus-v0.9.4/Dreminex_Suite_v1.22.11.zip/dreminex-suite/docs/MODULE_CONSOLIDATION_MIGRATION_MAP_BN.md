# Module Consolidation — Migration Map

| নতুন module | পুরোনো module/component | Data policy |
|---|---|---|
| `checkout_protection` | `phone_validation`, `duplicate_checkout`, `receipt_ip_warning`, `customer_order_limit`, `partial_checkout` | Settings copy, old state becomes feature switch, records/meta retained |
| `checkout_experience` | `receipt_message`, `checkout_error_popup` | Text/settings copy, old state becomes feature switch |
| `order_management` | `customer_history`, `admin_order_alert`, `order_email_notification`, `order_statuses`, `order_tracking` | Settings copy, order/user meta and credentials retained |
| `registration_email` | `registration_email`, `password_reset` | Parent key retained, both old states become component switches |

Schema 3 migration repeat-safe। Legacy keys Off করা হয় যাতে duplicate hooks না চলে; files package-এ internal component/rollback support হিসেবে থাকে। কোনো order, user, partial record, credential option বা message delete হয় না। Downgrade করলে schema reverse করা হয় না।

Release-এর পরে যাচাই: parent state, feature state, copied settings, no duplicate hook, data backup scope এবং rollback package।

