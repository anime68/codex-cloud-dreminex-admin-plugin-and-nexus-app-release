# Native MCP v3 implementation notes

This workstream is isolated on `feature/dreminex-native-mcp-v3`. It keeps the existing `/wp-json/mcp/dreminex` endpoint and OAuth client identities. It does not copy Novamira code or change a connected site.

## Included

- Provider-aware ability attribution. Third-party abilities are grouped separately and remain unavailable until both provider and ability exposure are enabled, an OAuth scope is explicitly mapped, and the connected WordPress user passes the ability's permission check.
- Dedicated `editor:*`, `files:*`, and `security:*` scopes. Adding these to the supported consent list does not add them to an existing token; clients must receive explicit consent for new scopes.
- Twenty-four canonical v3 ability IDs with strict JSON object schemas and no undeclared input properties.
- Revision-bound Gutenberg queues with owner checks, duplicate-target prevention, serialization checks, a review screen, a WordPress nonce, and a deliberate per-change save action. Saving preserves the post's existing publish status.
- Bounded file operations limited to administrator-declared roots outside the WordPress web root, regular text files, size limits, secret redaction, optimistic revision hashes, private backups, and a recovery folder.
- Revision-checked skill/design removal and activation. Design listings read non-autoloaded records correctly, and removing the active design restores the latest available prior active design.
- Unknown namespaced providers are listed as external and denied by default; their abilities are never globally unregistered.

## Deliberately unavailable

- The access-exchange ability returns a denial. This build does not create temporary administrator credentials or login links.
- File sandbox enable/disable abilities fail closed because this deployment has no isolated execution sandbox.
- The only developer maintenance task is a pre-registered ability-registry refresh; arbitrary PHP, shell commands, plugin lifecycle changes, and unrestricted filesystem access are not exposed.
- File roots require an owner-managed `DREMINEX_MCP_SAFE_ROOTS` configuration. No root is enabled by default.

## Verification boundary

Local PHP syntax checks and source/guard tests are included. This does not establish live WordPress integration, plugin compatibility, staging behavior, rollback behavior, external provider counts, or the 35 behavioral parity outcomes. Those require a backed-up staging clone and a separate deployment approval. No website or public GitHub release was changed as part of this source work.
