# Checkout Protection Module — A to Z Handoff ও Update Workflow

## এই module কেন রাখা হয়েছে

আগে Phone validation, IP cooldown, Receipt IP notice, Browser order limit এবং Consented unfinished checkout আলাদা পাঁচটি module ছিল। কাজগুলো একই checkout নিরাপত্তা flow-এর অংশ হওয়ায় এখন `checkout_protection` parent module-এর মধ্যে রাখা হয়েছে। Admin একটি dashboard থেকে প্রতিটি ability আলাদাভাবে On/Off করতে পারবেন।

## কোন file কী কাজ করে

- `modules/dreminex_checkout_protection.php`: parent loader; enabled ability-এর file-ই load করে।
- `modules/dreminex_phone_validation.php`: `01…`, `8801…`, `+8801…` format normalize ও validate করে। OTP পাঠায় না।
- `modules/dreminex_duplicate_checkout.php`: Pending/On-hold order থাকলে configured সময় একই recorded IP থেকে repeat checkout থামায়।
- `modules/dreminex_receipt_ip_warning.php`: order receipt notice এবং `[show_ip]`; default-এ IP masked থাকে।
- `modules/dreminex_customer_order_limit.php`: signed browser token দিয়ে daily threshold ও unfinished order পরীক্ষা করে। এটি permanent device identity নয়।
- `modules/dreminex_partial_checkout.php`: customer checkbox দিয়ে সম্মতি দিলে private partial record রাখে এবং configured retention শেষে WP-Cron-এ মুছে দেয়। WooCommerce order বানায় না।
- `includes/class-dreminex-suite-control.php`: UI field, validation ও health check।
- `includes/class-dreminex-suite-upgrades.php`: পুরোনো settings/module state নতুন parent-এ migrate করে।

## Dashboard settings

- পাঁচটি ability switch
- IP cooldown: 1–24 ঘণ্টা
- Browser threshold: প্রতিদিন 1–5 order
- Partial checkout retention: 24–168 ঘণ্টা
- Receipt IP: Masked, Full, অথবা notice without IP
- প্রত্যেক validation message-এর editable text

Parent module Off করলে সব checkout protection hook বন্ধ হবে। Records, old settings এবং order metadata মুছবে না। Parent On রেখে একটি feature Off করলে শুধু সেই component file load হবে না।

## Data ও privacy

- Browser token-এর raw value order-এ রাখা হয় না; SHA-256 key থাকে।
- Partial checkout শুধু explicit consent-এর পরে name, phone, address, cart reference ও IP রাখে।
- Successful order হলে একই session-এর partial record মুছে যায়।
- Receipt-এ default masked IP ব্যবহার হয়। Full IP নির্বাচন করার আগে privacy policy মিলিয়ে নিতে হবে।

## Update করার নিয়ম

1. Parent loader-এর setting name বদলালে schema migration দিতে হবে।
2. Hook file rename করলে catalog, loader, source hash, backup spec এবং এই reference file একসাথে update করতে হবে।
3. নতুন protection ability যোগ করলে master switch, feature switch, validation, health check এবং rollback path দিতে হবে।
4. Checkout Blocks support দাবি করার আগে real block checkout test করতে হবে; classic bridge থাকলে সেটিও পরীক্ষা করতে হবে।
5. কাজ শেষে PHP lint, migration test, allowed checkout, blocked checkout, consent On/Off, WP-Cron cleanup এবং receipt readback করতে হবে।
6. এই file, full plugin reference, changelog, package checksum এবং staging evidence update না করে release final বলা যাবে না।

## Known boundary

IP shared হতে পারে, cookie clear করা যায়, এবং phone format valid হলেই number ownership প্রমাণ হয় না। তাই customer support override ও order review workflow রাখতে হবে।

