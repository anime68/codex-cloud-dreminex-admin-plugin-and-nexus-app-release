# Order Management Module — A to Z Handoff ও Update Workflow

## Module-এর মধ্যে কী আছে

`order_management` পাঁচটি related order operation এক জায়গায় রাখে:

1. Customer order history
2. WordPress dashboard order alert
3. Owner new-order email
4. Manual workflow statuses ও bulk action
5. Courier tracking reference, customer note এবং optional provider credential vault

প্রত্যেকটি feature আলাদা switch দিয়ে বন্ধ করা যায়। Parent Off করলে সব component hook বন্ধ হবে; existing order/meta/status evidence থাকবে।

## File map

- `modules/dreminex_order_management.php`: parent loader।
- `dreminex_customer_history.php`: billing phone অনুযায়ী এই store-এর history।
- `dreminex_admin_order_alert.php`: admin notice ও dashboard widget।
- `dreminex_order_email_notification.php`: configured recipient-এ detailed owner email ও retry marker।
- `dreminex_order_statuses.php`: HPOS/classic compatible manual statuses ও bulk action।
- `dreminex_order_tracking.php`: courier/reference meta, customer note/email এবং encrypted credential vault UI।

Saved courier credential কখনো backup export-এ plain text যায় না। Credential saved থাকলেই provider API authenticated বলা যাবে না। Official adapter ছাড়া automatic consignment create হবে না।

## Admin workflow

Parent On করুন → দরকারি feature On করুন → owner email দিন → disposable test order দিয়ে history, alert, email, status এবং tracking একে একে যাচাই করুন। Courier reference কেবল booking-এর পরে real value দিয়ে লিখবেন।

## Update rule

Order data HPOS এবং classic storage দুইটিতে কাজ করতে হবে। নতুন feature order mutate করলে capability, nonce, audit note ও idempotency দিতে হবে। Existing order meta reset করা যাবে না। কাজ শেষে component switch, email delivery evidence, HPOS readback, status bulk action, tracking email, docs/changelog/checksum update করতে হবে।

