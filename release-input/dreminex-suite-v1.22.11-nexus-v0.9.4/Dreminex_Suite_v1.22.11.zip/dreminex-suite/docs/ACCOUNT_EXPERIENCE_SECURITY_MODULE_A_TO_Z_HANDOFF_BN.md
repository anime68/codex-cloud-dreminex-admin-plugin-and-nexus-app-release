# Account Experience & Security Module — A to Z Handoff ও Update Workflow

## Module-এর কাজ

আগের Account registration/email experience এবং Cross-account password reset এখন `registration_email` parent key-এর একটি module। Key একই রাখা হয়েছে যাতে existing design, text, confirmation setting এবং user metadata অক্ষত থাকে।

## Component

- `modules/dreminex_account_experience.php`: parent loader।
- `dreminex_registration_email.php`: My Account UI, form, email confirmation ও signed-in dashboard।
- `dreminex_password_reset.php`: অন্য account login থাকা অবস্থাতেও valid WooCommerce reset key-এর safe flow।
- `assets/registration.css`: logged-out Registration/Login page-এর scoped responsive design।
- `assets/registration.js`: password show/hide, password-match feedback এবং confirmation dialog keyboard control।

Admin দুই component আলাদা switch দিয়ে চালাতে পারেন। Reset link, email-confirmation token বা customer password backup/export করা হয় না।

## Registration page এখন যেভাবে কাজ করে

Registration ও Login একই WooCommerce My Account flow-এর মধ্যে থাকে। উপরে compact Dreminex hero, Create account ও Sign in action থাকে। Hero-এর নিচে order tracking, faster checkout এবং secure email confirmation-এর তিনটি বাস্তব account benefit দেখায়। Desktop-এ Register card একটু বেশি জায়গা পায়; mobile-এ Register আগে এবং Login পরে আসে। First name, last name, phone, password, confirmation, privacy text ও native WooCommerce submit flow আগের মতোই কাজ করে।

Hero title, text, optional Media Library image, image position এবং button colour dashboard থেকেই বদলানো যায়। Image না থাকলে palette-এর মধ্যে local CSS brand artwork আসে; বাইরের image request হয় না। Password match শুধু live help দেখায়—final validation server-এ হয়। Keyboard focus, popup focus trap, reduced-motion এবং 700px-এর mobile collapse রাখা হয়েছে।

## Design rule

Registration UI শুধু `body.dreminex-account-experience`-এর ভিতরে apply হবে। বর্তমান Dreminex design token হলো Roboto, `#F8F9FA`, `#FFFFFF`, `#212529`, `#586A73`, `#00B4D7`, `#007D96`, `#CAF0F8`, `#DEE2E6`, `#D00000`; card 16px এবং input/button 8px radius। Theme/Elementor global style লিখে বদলানো যাবে না।

## Update rule

WooCommerce native account security bypass করা যাবে না। Reset key সবসময় `check_password_reset_key` দিয়ে verify হবে। Form change-এ nonce, required/optional field validation, password mismatch, email confirmation expiry, valid/invalid/used link, logged-in other account, keyboard এবং 390/700/desktop layout test করতে হবে। Saved user/account data reset করা যাবে না। UI update-এর আগে active design পড়তে হবে এবং শেষে design preflight চালাতে হবে। কাজ শেষে এই reference, full plugin reference, changelog, test report ও GitHub release update করতে হবে।

