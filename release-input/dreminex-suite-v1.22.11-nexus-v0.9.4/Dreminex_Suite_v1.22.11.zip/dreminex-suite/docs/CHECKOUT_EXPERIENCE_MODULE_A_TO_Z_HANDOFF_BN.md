# Checkout Experience Module — A to Z Handoff ও Update Workflow

## Module-এর কাজ

`checkout_experience` একই জায়গা থেকে Thank-you message এবং Checkout error popup চালায়। দুইটি feature আলাদা switch দিয়ে On/Off করা যায়।

## File map

- `modules/dreminex_checkout_experience.php`: parent loader।
- `modules/dreminex_receipt_message.php`: valid order-received page-এ message দেখায়।
- `modules/dreminex_checkout_error_popup.php`: WooCommerce classic এবং detected block error notice সংগ্রহ করে accessible dialog দেখায়। Native WooCommerce error notice মুছে ফেলে না।
- `includes/class-dreminex-suite-control.php`: heading, intro, button ও receipt text setting।

## Accessibility ও UX

- `role="dialog"`, `aria-modal`, labelled heading আছে।
- Open হলে close button-এ focus যায়; close করলে আগের focus ফিরে আসে।
- Escape, backdrop click ও button দিয়ে বন্ধ হয়।
- Tab/Shift+Tab dialog-এর মধ্যে focus ধরে রাখে।
- একই error বারবার duplicate popup করে না।
- Mobile width, scrollable message list এবং theme accent ব্যবহার করে।

## Admin ব্যবহার

Suite → Modules → Checkout Experience খুলে feature switch এবং customer-facing text save করবেন। Test order-এর thank-you page এবং invalid checkout দুইটিই staging-এ যাচাই করবেন।

## Update rule

WooCommerce notice selector বদলালে classic AJAX এবং Checkout Blocks দুই route test করতে হবে। Error detail কখনো invent বা hide করা যাবে না। নতুন visual change-এ keyboard focus, screen reader label, mobile viewport এবং native fallback পরীক্ষা করতে হবে। কাজ শেষে এই reference, full plugin reference, changelog ও staging evidence update করতে হবে।

