# Preparation → Publisher Advanced Hybrid Connection (v1.17.0)

## পুরো flow

1. **Preparation** supplier text, screenshots ও originals এক evidence pass-এ পড়ে। Selected site-এ `preparation-snapshot` এবং new product হলে `identity-plan` চালিয়ে distinct name/slug এবং prefix-based parent SKU নেয়। WordPress write করে না।
2. Preparation complete `PUBLISHER HANDOFF`-এ immutable `site_lock`, exact operation, verified facts, complete offered rows, parent-based child SKU plan, media order এবং safe `publisher_prerequisites` রাখে। Genuine missing fact `external_blockers`; optional note `non_blocking_notes`।
3. **Publisher** full object `dreminex-products/handoff-execute`-এ দেয়। এটি site lock check করে; hard error হলে zero product write; declared exact attribute/term এবং supplied original media safe prerequisite resolve করে; তারপর fresh preflight চালায়। পুরোনো `ready_for_listing_apply` বা legacy pending list live result override করে না।
4. Fresh preflight ready হলে internal `listing-apply` Draft/Update/explicit Publish চালায়। Variation stage partial হলে returned same product ID/token/offset দিয়ে resume হয়।
5. Exact `product-read`-এ identity, status, descriptions/SEO, gallery, one image swatch per colour এবং সব child SKU/supplier SKU/price/stock/image compare হয়। Safe same-ID mismatch repair করা যায়; new duplicate Create নয়।
6. Supplier URL থাকলে saved product ID-তে source link হয়। Supplier Monitor নিজের schedule-এ observation দেয়; এটি Preparation/Publisher-এর source fact invent করার অনুমতি নয়।
7. Task শেষে `workflow-task-finalize` bounded outcome রাখে। দুই matching verified pattern operational hint; তিন completed patterns admin proposal queue। Admin approve না করলে instruction বদলায় না।

## SKU ও capacity

- Parent: owner/dashboard prefix + product token; site-unique।
- Child code না থাকলে: `PARENT-COLOR-SIZE`।
- Exact screenshot/user supplier code থাকলে: `PARENT-COLOR-SIZE-CODE`; raw `CODE` supplier meta-তেও।
- Inline handoff সর্বোচ্চ 44 rows; 45+ complete JSON file।
- Dashboard default 64, configurable 1–564। Configured limit ছাড়ালে zero write; truncate/split/omit নয়।

## Project/plugin role

Preparation copy quality-তে Sales/Writing Style guidance ব্যবহার করতে পারে। Product/site truth Dreminex Native থেকে আসে। Publisher listing-এর জন্য শুধু Dreminex Native ব্যবহার করে। Create Task কেবল maintenance review; normal product task-এর dependency নয়। WordPress dashboard source update Project Settings-এর আগে paste করা instruction নিজে বদলায় না, তাই release-এর v1.17.0 Project Settings copy/replace করতে হবে।
