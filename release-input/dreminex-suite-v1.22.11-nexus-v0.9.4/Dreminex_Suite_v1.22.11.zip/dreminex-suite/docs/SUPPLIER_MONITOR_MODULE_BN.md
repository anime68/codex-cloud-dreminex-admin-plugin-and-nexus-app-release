# Supplier Monitor — বর্তমান module reference

সংস্করণ: Dreminex Suite 1.14.1। পূর্ণ reference plugin root-এর `SUPPLIER_MONITOR_MODULE_A_TO_Z_HANDOFF_BN.md` এবং exact phone contract `DREMINEX_NEXUS_SUITE_INTEGRATION_CONTRACT_BN.md`।

Supplier scan এখন phone-only। WordPress supplier website-এ login বা HTTP request পাঠায় না। Scheduled, manual, Preparation fact preview এবং old colour scan path Nexus queue-তে job দেয়। Android phone persistent encrypted session reuse করে result পাঠায়। WooCommerce পরিবর্তন existing review/approval ছাড়া হয় না।

Dashboard: **Products → Supplier Monitor**। এখানে built-in ShopBaseBD/ResellKori, custom platform profiles, product mappings, jobs, professional results, paired devices, settings এবং existing review actions আছে।

এই module update করার আগে এবং পরে root A-to-Z reference-এর release gate অনুসরণ করতে হবে।
