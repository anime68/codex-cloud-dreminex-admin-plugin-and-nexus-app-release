# Supplier Monitor + Nexus Queue — A to Z Handoff, Review ও Update Workflow

সংস্করণ: Dreminex Suite 1.17.0  
মূল files: `modules/class-dreminex-supplier-nexus.php`, `modules/dreminex_supplier_monitor.php`

এই system-এর সবচেয়ে গুরুত্বপূর্ণ নিয়ম:

> Supplier website-এর HTTP request শুধু Dreminex Nexus Android phone থেকে যাবে। WordPress/Hostinger queue, mapping, result, alert ও approval রাখবে; supplier page fetch করবে না।

1.17.0-এ Supplier Monitor-এর WordPress dashboard/menu সরানো হয়েছে। Native MCP On এবং WooCommerce available থাকলে service/queue চলে; app Operations screen profile, login/session, history ও alerts দেখায়। Product detail থেকে supplier URL link ও immediate scan queue করা যায়। Successful scan এবং detected change categorized app notification তৈরি করে। Existing encrypted phone session আগে reuse হয়; due scan-এর প্রয়োজন না হলে login চলে না।

পুরোনো direct HTTP scanner release package থেকে সরানো হয়েছে। Cron, manual scan, fact preview এবং colour scan entry point এখন phone job queue করে। কোনো silent server fallback নেই।

## ১. পুরো workflow

```text
WooCommerce product + exact supplier URL
              ↓
WordPress creates one idempotent scan job
              ↓
Nexus phone claims a timed lease
              ↓
phone reuses encrypted supplier session
              ↓
phone network fetch + bounded parser/evidence
              ↓
validated observation submit
              ↓
snapshot + change alert + existing approval workflow
```

Phone offline হলে job pending থাকবে। Lease শেষ হলে claimed/running job আবার pending হবে। Lost response-এর পরে একই observation retry করলে duplicate-safe response হবে; দ্বিতীয় snapshot বা duplicate alert হবে না।

## ২. File map

| File | কাজ |
|---|---|
| `modules/class-dreminex-supplier-nexus.php` | platforms, devices, queue, leases, observation validation, APIs, abilities, new dashboard |
| `modules/dreminex_supplier_monitor.php` | existing mapping, pricing, event, approval/hide/restore compatibility |
| `modules/dreminex_supplier_visual.php` | phone-produced SHA-256/dHash-এর সঙ্গে local WooCommerce gallery compare; কোনো supplier URL fetch করে না |
| `assets/supplier-monitor-v2.css` | new professional dashboard UI |
| `assets/supplier-monitor.css` | existing review/action controls |
| `includes/class-dreminex-native-oauth.php` | phone device OAuth token |
| `DREMINEX_NEXUS_SUITE_INTEGRATION_CONTRACT_BN.md` | exact WordPress ↔ Android contract |

## ৩. Built-in ও custom platforms

ShopBaseBD এবং ResellKori built-in। Built-in domain, URL pattern, login mode, selector rules, price role ও image limits versioned profile হিসেবে table-এ থাকে। Built-in profile code update হলে revision এবং config hash বদলায়; phone পুরোনো config hash দিয়ে result পাঠালে server reject করে refresh করতে বলে।

Dashboard থেকে custom platform যোগ করা যায়। Required fields:

- stable platform ID ও display name
- exact HTTPS domains
- product URL regex
- HTTPS login URL
- `manual_webview` বা `form_credentials`
- title/price/stock/image/size CSS selectors
- price role এবং session success rule

Custom profile arbitrary PHP/JavaScript নেয় না। Mapping করার আগে Nexus phone দিয়ে login/test করা উচিত। Built-in ID custom profile দিয়ে replace করা যায় না।

## ৪. Session ও login rule

- Credential, cookie ও session শুধু Android Keystore encrypted storage-এ থাকে।
- WordPress job, observation, log বা plugin option-এ supplier password/cookie যায় না।
- Valid cookie থাকলে আবার login নয়; due product page সরাসরি fetch হয়।
- Session login page-এ redirect করলে এবং saved credential থাকলে একবার login attempt হয়।
- Failed login-এর পরে ২৪ ঘণ্টা cooldown।
- `account_restricted` হলে automatic login বন্ধ; owner app থেকে Resume না করা পর্যন্ত retry নয়।
- CAPTCHA/manual login platform-এর জন্য isolated WebView আছে।

## ৫. Queue ও integrity

Job fields: UUID, idempotency key, platform/product/URL, type, status, priority, payload, schedule, lease, device, attempts, error/retry timestamps। Scheduled job time bucket দিয়ে duplicate suppression হয়। Manual request থাকলেও একই product/platform/URL-এর active job দ্বিতীয়বার তৈরি হয় না।

Observation গ্রহণের আগে server যাচাই করে:

- OAuth user ও device key একই owner-এর কি না
- device job lease-এর owner কি না এবং lease valid কি না
- platform revision/config hash current কি না
- payload 150 KB-এর মধ্যে কি না
- status/network/price/quantity/image domain valid কি না
- প্রতিটি variation ID ও supplier SKU claimed job mapping-এর সঙ্গে exact match কি না
- mapped সব variation একবার করে ফেরত এসেছে কি না

Supplier observation WooCommerce price/stock সরাসরি বদলায় না। Existing Supplier Monitor snapshot/event বানায়; owner approval ছাড়া controlled write হয় না।

Image evidence-এ phone supplier image download করে SHA-256 ও 64-bit dHash পাঠায়। WordPress শুধু নিজের Media Library file পড়ে exact SHA-256 বা সীমিত, unique dHash match করে। URL-only evidence দিয়ে server image download করে না; fingerprint অসম্পূর্ণ হলে result `incomplete` থাকে। একই supplier image একাধিক local colour-এর কাছাকাছি হলে auto-match না করে review-এর জন্য uncertain রাখা হয়।

## ৬. REST routes

Routes `/wp-json/dreminex/v1/nexus/...` namespace-এ। Device register, heartbeat, platform list, pending jobs, history, enqueue due, claim, renew, observation ও fail route আছে। Exact field details integration contract file-এ।

## ৭. MCP abilities

| Ability | Type | কাজ |
|---|---|---|
| `dreminex-suppliers/monitor-status-read` | read | phone-only state, devices, queue, settings |
| `dreminex-suppliers/jobs-read` | read | bounded job list |
| `dreminex-suppliers/results-read` | read | normalized observation list |
| `dreminex-suppliers/job-enqueue` | write | exact mapped product/platform/URL-এর manual phone scan |

Write ability Native MCP client policy ও approval নিয়ম মানে।

## ৮. Dashboard

Menu: **WooCommerce Products → Supplier Monitor** এবং Suite submenu। Tabs:

- Overview: platform/device/job/result cards এবং phone-only flow
- Platforms: built-in/custom profile
- Product mappings: exact product URL এবং Queue phone scan
- Jobs: status, attempts, errors
- Scan results: professional normalized result cards
- Nexus devices: last seen/network/revoke
- Settings: interval, lease, jobs per claim, evidence retention, required network
- Review actions: পুরোনো controlled alert/price/stock decisions

Default product scan interval ১২ ঘণ্টা, device sync ১৫ মিনিট, lease ১৫ মিনিট, job batch ১০, evidence retention ৩০ দিন।

## ৯. Database ও WordPress storage

Tables: `dreminex_nexus_platforms`, `dreminex_nexus_devices`, `dreminex_nexus_jobs`, `dreminex_nexus_observations`। Existing source meta `_dreminex_sm_sources`; custom snapshot `_dreminex_sm_snapshots`; existing supplier event table অপরিবর্তিত।

Device key hash আকারে থাকে। IP audit-এ raw IP নয়, hash থাকে। Revoked device আর job claim করতে পারে না এবং তার live lease queue-তে ফেরে।

## ১০. Future update rule

Platform selector বদলালে built-in config revision/hash বদলাতে দিন এবং real phone scan দিয়ে title, exact cost role, stock, sizes, image host verify করুন। নতুন status যোগ করলে Android model, server allowed list, legacy adapter, dashboard এবং contract একই release-এ বদলাবেন। Queue schema বদলালে additive migration ও old app compatibility লিখবেন।

## ১১. Release gate

- codebase-এ server supplier HTTP scanner/call নেই static verify।
- scheduled/manual/preview/colour entry point শুধু enqueue করে।
- duplicate queue, lease expiry, two-device claim conflict, lost-response retry test।
- wrong device, wrong SKU, missing variation, stale config hash, oversized response reject test।
- active session login পুনরাবৃত্তি করে না; failed/restricted policy test।
- Wi-Fi এবং Mobile Data phone scan-এ network type evidence test।
- WordPress result readback এবং existing alert/approval regression test।
- staging backup/install/rollback ও package checksums।

এই file দিয়ে future update করলে কাজ শেষে এই file, integration contract, Android reference, Changelog ও test report update করা বাধ্যতামূলক।
