# AI Product Publisher — উদ্দেশ্য ও রক্ষণাবেক্ষণ

সংস্করণ: Dreminex Suite 1.13.65। এই নথি মডিউলের কাজ ও পরের সম্পাদনার সীমা বোঝায়; কোনো পণ্যের hand-off নয়।

`handoff-preflight` এখন exact `site_url`, `colors[].name`, image-first `swatch_image_index`, image না থাকলে explicit `mode=color` + verified HEX/existing term পরীক্ষা করে। Media ছাড়া Draft-এ fallback সম্ভব; Publish-এর আগে verified media লাগে। `mode=update` exact existing ID নেয় এবং handoff-এ অনুল্লিখিত field listing parameters-এ ঢোকায় না।

## উদ্দেশ্য ও কাজের ভাগ

Product Preparation প্রমাণ যাচাই করে সম্পূর্ণ `PUBLISHER HANDOFF` তৈরি করে; WordPress-এ লেখে না। Product Publisher সেই hand-off নির্দিষ্ট staging/main site-এ `Draft`, স্পষ্ট নির্দেশে `Publish`, অথবা নির্দিষ্ট ID-তে `Update` হিসেবে প্রয়োগ করে। `site_url`, `mode`, `product_id`, নাম, slug, parent/child SKU, taxonomy, দাম, stock, gallery, রঙের ছবি ও variation—সব একই পণ্যের হওয়া চাই। Publisher নতুন করে supplier research বা copywriting করে না।

## সিদ্ধান্তের নিয়ম

| পাওয়া তথ্য | স্বয়ংক্রিয় সিদ্ধান্ত | মানুষের করণীয় |
|---|---|---|
| `handoff_type=PUBLISHER HANDOFF` এবং `handoff-preflight.ready=true` | যাচাইকৃত `listing_parameters` দিয়ে `listing-apply`; তারপর saved stage/readback দেখা | শুধু অস্বাভাবিক partial stage দেখলে সংশোধন |
| Site, update ID, category, taxonomy, দাম, stock, matrix, image বা SKU-তে `errors[]` | **কোনো নতুন Draft লেখে না**; `next_action=return_to_preparation` | Preparation-এ সুনির্দিষ্ট error ঠিক করা |
| `sizes[]` measurement object | প্রতিটির `name` selectable option হয়; size chart HTML-এ থাকে | HTML chart-এ মাপ মিলিয়ে দেখা |
| Media ID ও URL দুটোই আছে | URL সেই ID-র Media Library URL কিনা যাচাই; live listing-এ শুধু ID পাঠানো | অমিল হলে সঠিক original শনাক্ত |
| রঙের সঙ্গে verified image আছে | `swatch_image_index` পূরণ; product-specific image swatch তৈরি | ভুল ছবি হলে Preparation-এ mapping ঠিক করা |
| Supplier কোনো colour SKU দেয়নি | অনন্য internal `parent-colour-size` SKU ব্যবহার; supplier SKU null | প্রকৃত code পাওয়া গেলে পরে verified mapping |
| Raw hand-off `listing-apply`-তে আসে | একই preflight write-এর আগে চলে | ব্যর্থ হলে error অনুযায়ী ফেরত পাঠানো |

`pending_inputs`-এর কোনো অবশিষ্ট তথ্যকে স্বয়ংক্রিয়ভাবে সত্য ধরা যাবে না। Supplier-wide stock দিয়ে প্রতি size-এর live stock নিশ্চিত করা যায় না। Saved Draft `Published` নয়। সুপারিশকৃত দাম বা supplier cost নিজে থেকে catalog price বদলায় না।

## UI ও ফাইল নির্দেশনা

Admin: Dreminex Suite → AI Product Publisher। উপরে preflight/Draft/media status, নিচে Preparation/Publisher workflow source, তারপর Catalog mapping, SKU/inventory ও product safeguards। Product-specific ছবি swatch হলে colour label ও variation নির্বাচন বজায় থাকে। CSS `assets/suite-admin.css`; ability registration, validation ও `listing-apply` `modules/dreminex_ai_product_publisher.php`; workflow source `workflow-profiles/{preparation,publisher}`। Project Settings-এর নিজস্ব instruction থাকলে bundled source বদলালেই তা নিজে থেকে বদলায় না; Project owner-কে updated source/instruction গ্রহণ করতে হবে।

## পরীক্ষা ও রিলিজ

Staging-এ আগে `handoff-preflight`: missing kids gallery-তে `ready=false`, ভুল site/price/matrix-তে বাধা, একই-সাইট Media ID/URL ও size object-এ normalisation। যে hand-off সত্যিই ready, সেটি পৃথক অনুমোদিত test Draft-এ প্রয়োগ করে variation price/image swatch/readback যাচাই করতে হবে। আগে থেকে থাকা partial Draft-এ resume করতে হলে ঠিক সেই ID ব্যবহার, নতুন duplicate create নয়। Main site-এ plugin code release হলেও কোনো product hand-off নিজে থেকে লেখা হয় না।

## এই ঘটনার শিক্ষা

“Girls Stylish Sweatshirt Set” শিরোনামকে প্রমাণ ছাড়া “Kids'…” করা ঠিক হয়নি। Kids hand-off-এর `images:[]` অবস্থায় ৩০-row variable Draft প্রস্তুত বলে পাঠানোও ঠিক নয়। Polo-তে ৫ রং × ৪ size internal SKU বৈধ, কারণ supplier-এর colour-specific code ছবিতে ছিল না; code আবিষ্কার করা যাবে না। এ ভুলগুলো preflight ও Preparation QA-তে ধরা হবে।
