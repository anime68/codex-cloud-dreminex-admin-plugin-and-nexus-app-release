# Configuring scoped Native MCP file roots

File abilities are denied unless the site owner defines `DREMINEX_MCP_SAFE_ROOTS` before WordPress loads. Configure only a dedicated private directory outside the public WordPress document root. Do not point a root at the hosting account home, the WordPress tree, uploads, backups, or a directory containing credentials.

Example shape (replace the path with a real private absolute path on the host):

```php
define('DREMINEX_MCP_SAFE_ROOTS', [
    'private_notes' => '/absolute/private/path/dreminex-mcp',
]);
```

The handler accepts only `.txt`, `.md`, `.json`, `.csv`, `.html`, and `.css` files, rejects hidden/path traversal segments and symbolic links, caps file content at 128 KiB, and blocks active markup. Reads redact common credential fields. Writes require an explicit confirmation; edits and trash operations require the exact current SHA-256 revision. Edit backups and trashed files remain in private directories under the configured root.

Do not enable `scoped-write`, `scoped-edit`, or `scoped-trash` for an MCP client unless the root has been reviewed and the exact OAuth scope and WordPress capability are appropriate. Sandbox mode still previews ordinary writes; destructive/high-impact operations require the existing exact-request approval flow.
