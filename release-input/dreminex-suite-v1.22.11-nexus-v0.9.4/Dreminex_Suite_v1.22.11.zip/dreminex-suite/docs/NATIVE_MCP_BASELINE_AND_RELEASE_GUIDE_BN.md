# Dreminex Native MCP — স্থায়ী baseline ও release guide

এই নথিটি Native MCP-এর authorization baseline, নতুন WordPress plugin-এর ability onboarding এবং plugin/app update প্রকাশের নিয়ম। এটি কোনো secret, token, keystore বা password রাখে না।

## ১. Ability কীভাবে MCP-তে আসে

Native MCP প্রতি request-এ WordPress Abilities Registry (`wp_get_abilities()`) থেকে registered ability পড়ে। তাই নতুন plugin একটি ability register করলে Native MCP-তে আলাদা hard-coded তালিকা যোগ করতে হয় না। প্রতিটি ability-এর জন্য স্তরগুলো আলাদা:

1. **Registered** — WordPress registry-তে ability আছে।
2. **Internal** — transport/helper ability; public tool হিসেবে কখনো দেখানো হয় না।
3. **Globally exposed** — master, provider, category এবং individual policy চালু এবং ability-এর public MCP contract আছে।
4. **Client-discoverable** — global exposure-এর সঙ্গে ওই OAuth client-এর selected ও granted scope, WordPress capability এবং mode অনুমোদিত।
5. **Executable** — discovery-এর পরেও execution policy, input validation, capability, scope এবং approval সব pass করেছে।

এই সংখ্যাগুলো এক নয়। একটি ability registered হলেও client token-এ scope না থাকলে সেটি discovery-তে আসবে না এবং execute করা যাবে না।

## ২. নতুন plugin developer-এর contract

Public MCP exposure দরকার হলে registered ability-এ reviewed metadata দিন। উদাহরণ:

```php
'meta' => [
    'provider_plugin' => 'acme-store',
    'mcp' => [
        'public' => true,
        'required_scope' => 'catalog:read',
        'risk' => 'read',
        'required_capability' => 'manage_woocommerce',
    ],
]
```

Write বা destructive ability-এর জন্য `required_scope`, `risk` এবং WordPress capability অবশ্যই সঠিকভাবে declare করতে হবে। `mcp.public` না থাকলে অচেনা external ability fail-closed থাকবে। Owner চাইলে **Native MCP → Custom abilities & skills** থেকে registry-তে আগে থেকেই থাকা ability-এর scope, risk, capability, provider/category, public এবং enabled policy ঠিক করতে পারবেন। এই policy নতুন PHP callback register করে না, upload/eval করে না এবং arbitrary code চালায় না।

## ৩. Global controls ও access mode

- **AI Abilities master** বন্ধ হলে সব public ability hide হবে।
- **Provider / category / ability toggle** শুধু visibility ও global eligibility নিয়ন্ত্রণ করে।
- **Read only** — সব authorized read ability দেখা ও চালানো যায়; কোনো write execute হয় না।
- **Sandbox** — authorized write/critical ability validate বা preview হয়, বাস্তব mutation হয় না। High-risk scope default-এ selected নয়।
- **Auto review** — safe write approval ছাড়া চলতে পারে; destructive/high-risk কাজ approval queue-তে যায়।
- **Full access** — consent করা public scope-এর সব authorized ability দেখা যায়; high-risk OAuth scope আলাদা explicit opt-in এবং destructive/high-risk কাজ approval gate-এ থাকে।

Mode OAuth token-এ scope যোগ করে না। Admin connection policy save করার পর owner-কে reauthorize/reconnect করে consent screen-এ scope approve করতে হবে। Existing access token কখনো silently expand হয় না।

## ৪. ৬২টি ability দেখা যাওয়ার কারণ

আগের token-এ সাধারণত `mcp:discover` এবং সীমিত namespace scope ছিল। Abilities Hub-এ tick করলেও OAuth token scope বাড়ে না। তাই ২০০+ registered/global ability থাকলেও client-discoverable সংখ্যা ৬২ হতে পারে। সমাধান:

1. Native MCP → Connections খুলুন।
2. client-এর mode নির্বাচন করুন।
3. **Use this mode scope profile automatically** নির্বাচন করে Save করুন।
4. Reconnect/reauthorize করুন এবং consent screen-এ প্রয়োজনীয় safe scopes approve করুন।
5. ChatGPT MCP connection reconnect করে `dreminex-discover-abilities` চালান।
6. Diagnostics-এ `missing_scope`, `missing_wp_capability`, `not_public`, `provider_disabled` বা `user_disabled` reason দেখুন।

`files:write`, `security:write`, `plugins:write` ও `users:write` high-risk scope default-এ off থাকে। এগুলো দরকার হলে আলাদা করে select ও consent করতে হবে।

## ৫. Owner-approved skills

Custom skill হলো bounded instruction এবং registered ability reference-এর তালিকা। Skill tool শুধু কোন ability কখন ব্যবহার করতে হবে তা জানায়; এটি scope, capability, approval বা execution bypass করতে পারে না। Skill-এ PHP, `eval`, `shell_exec`, `passthru` বা executable code রাখা যাবে না। কোনো referenced ability client-authorized না হলে skill discovery-তে সেটি দেখানো হবে না।

## ৬. Plugin ZIP ও app update baseline

Suite plugin ZIP-এর মধ্যে APK, Windows installer বা app manifest থাকে না। দুই update channel একই public repository ব্যবহার করে:

`https://github.com/anime68/codex-cloud-dreminex-admin-plugin-and-nexus-app-release`

Root `latest.json`-এ:

- `plugin.version`, `plugin.download_url`, `plugin.sha256`, `plugin.release_notes_url`
- `android.version`, `android.download_url`, `android.sha256`
- Windows distribution বন্ধ থাকলে empty `windows` fields

WordPress plugin updater `plugin` section পড়ে, GitHub release prefix ও SHA-256 যাচাই করে, তারপর WordPress updater-এ package দেয়। Native MCP admin card ও connected Nexus `/dreminex/v1/nexus/app-release` route `android` section পড়ে। ZIP-এ app binary রাখলে size বেড়ে যাবে এবং packaging contract fail করবে।

প্রতিটি release-এ:

1. Plugin ZIP root `dreminex-suite/` যাচাই করুন।
2. Plugin header ও constant version মিলিয়ে নিন।
3. ZIP SHA-256 লিখুন।
4. Signed APK package, versionCode, certificate এবং SHA-256 যাচাই করুন।
5. Public release upload করুন।
6. `latest.json` একই tag/asset URL দিয়ে update করুন।
7. Public URL HTTP 200 এবং downloaded hash আবার যাচাই করুন।
8. WordPress **Check for plugin updates** এবং Nexus **Check for updates** চালিয়ে read-back নিন।

Private credentials, keystore, OAuth tokens ও recovery material কখনো source, ZIP, `latest.json`, logs বা public release-এ রাখবেন না।
