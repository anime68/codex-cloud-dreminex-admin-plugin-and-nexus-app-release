# Native MCP OAuth Issuer Fix — 1.15.0

## যে error দেখা গিয়েছিল

ChatGPT approval-এর পরে দেখিয়েছে: `OAuth authorization response is missing the expected issuer`। Registered client তৈরি হয়েছিল, কিন্তু authorization code token exchange পর্যন্ত যায়নি।

## Root cause

Success response-এ `iss` field ছিল, কিন্তু generic URL helper callback query strict RFC 3986 form-এ তৈরি করছিল না। Deny/error response-এ `iss` ছিল না। Strict client callback parser তাই expected issuer নির্ভরযোগ্যভাবে পায়নি।

## Fix

- Dedicated `authorization_response_url()` exact callback builder।
- `PHP_QUERY_RFC3986` দিয়ে `iss=https%3A%2F%2F…` encoding।
- Approve এবং Deny দুই response-এই forced `iss`।
- Consent buttons explicit `decision=approve` ও `decision=deny` পাঠায়; visible button label আর submitted decision গুলিয়ে যায় না।
- `response_type=code`, `response_mode=query`, PKCE S256 validation।
- Metadata-তে `response_modes_supported: ["query"]`।
- Authorization/token response-এ no-store/no-cache।
- Secret-free last response diagnostic।

Test file: `tests/test-oauth-callback.php`। Staging-এ real browser consent, discovery issuer, DCR, approve callback, token exchange এবং MCP initialize/tools list pass না করা পর্যন্ত fix complete নয়।
