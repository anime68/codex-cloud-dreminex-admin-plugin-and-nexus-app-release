# Nexus Product Catalog, Lifecycle ও Analytics — A to Z Reference

**Suite:** 1.19.0  
**Nexus:** 0.6.0  
**মূল source:** `includes/class-dreminex-nexus-app.php`, Android `Models.kt`, `NexusApi.kt`, `NexusViewModel.kt`, `MainActivity.kt`

## এই system কেন আছে

Selected website-এর Draft ও Published product app-এ একসঙ্গে দেখা, category/search/status দিয়ে filter করা, Trash আলাদা রাখা, exact product detail দেখা এবং WooCommerce-এর মতো নিরাপদ status action চালানো এই service-এর কাজ। App নিজে WordPress database লেখে না; authenticated Suite REST endpoint-ই সব read/write করে।

## Catalog contract

- `GET /dreminex/v1/nexus/catalog/products`
- filter: `active`, `draft`, `publish`, `trash`, `category_id`, `search`, `sort`, `page`
- প্রতি server page সর্বোচ্চ 60 row; app সব page ক্রমানুসারে নেয়, তাই প্রথম 60টির পরে product হারায় না।
- card-এ thumbnail, title, display price, primary category, product badge, status, rating এবং scan status থাকে।
- Trash কখনও active catalog response-এ মেশে না।

## Product detail

`GET /nexus/catalog/products/{id}` gallery, SKU, short/long description, variation count, supplier state, review, performance এবং `lifecycle_revision` দেয়। Detail screen-এ প্রয়োজনীয় summary আগে, বিস্তারিত ও actions পরে থাকে।

## Lifecycle guard

| বর্তমান status | অনুমোদিত action |
|---|---|
| Draft | Publish, Trash |
| Published | Trash |
| Trash | Restore as Draft, Permanent Delete |

প্রতি write-এ app সর্বশেষ `expected_revision` পাঠায়। অন্য জায়গা থেকে product বদলে গেলে server `status_conflict` দিয়ে refresh চায়। Permanent Delete শুধু Trash থেকে চলে এবং দুই ধাপে fresh পাঁচ মিনিটের confirmation token লাগে। UI-তেও action confirmation থাকে।

## Supplier state

Product meta `_dreminex_sm_sources` থেকে exact platform/URL নেয়। Latest Nexus job থেকে `unlinked`, `never_scanned`, `queued`, `scanning`, `healthy`, `error`, `paused` তৈরি হয়। Product detail থেকে valid HTTPS supplier URL save করলে enabled platform profile match করে এবং চাইলে scan queue হয়।

## Reach / performance

- storefront product view hourly salted deduplication-এ aggregate হয়; raw IP বা user agent database-এ রাখা হয় না।
- period 30 দিন: views 35%, sold units 35%, revenue 20%, review confidence 10%।
- অন্য active product-এর percentile দিয়ে `High`, `Good`, `Low`, `No data` label হয়। এটি SEO ranking দাবি নয়; store-relative operational signal।
- `dreminex-products/performance-read` Native ability এবং product REST detail একই calculation ব্যবহার করে।

## Permission ও site isolation

OAuth scope `catalog:read`, write action-এ `catalog:write`, performance-এ `analytics:read`। OAuth user-এর `manage_woocommerce` বা `manage_options` capability, device ID এবং device key তিনটিই মিলতে হবে। প্রতিটি app cache row `siteId` দিয়ে আলাদা।

## Update করলে যা করবেন

1. REST response field বদলালে PHP response, Kotlin model এবং reference একই commit-এ বদলাবেন।
2. নতুন status action দিলে server allowlist, UI confirmation, stale revision test এবং rollback rule যোগ করবেন।
3. performance weight বদলালে পুরোনো label-এর সঙ্গে comparison test করবেন এবং cache key invalidation দেখবেন।
4. product list কখনও silently truncate করবেন না; pagination বা complete page loop রাখবেন।
5. শেষে PHP lint/tests, Android unit test/build, staging catalog/detail/status readback, source/release ZIP ও SHA-256 update করবেন।

